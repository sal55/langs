proc main=
	int f

	to 6000 do
		f:=fib(24)
	od
	cpl f
end

func fib(int n)int=
	if n<3 then
		1
	else 
		fib(n-1)+fib(n-2)
	fi
end

