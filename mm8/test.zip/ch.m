!record R = $caligned
record R =
	I16 a,b
end

byte a
[13]R xx

byte c



proc main=
	byte a := 65
	char b := 'A'

	println a, b


end
