!macro x=(y+y)

[10]int a,b,c,d,e,f,g,h
proc main=
![10,10]int a,b,c,d,e,f,g,h
int i,j
!
!eval ((a[i] + b[i]) + (c[i] + d[i])) + ((e[i] + f[i]) + (g[i] + h[i]))
eval a[i] + (b[i] + (c[i] + (d[i] + (e[i] + (f[i] + (g[i] + h[i]))))))
!eval a[i,j] + (b[i,j] + (c[i,j] + (d[i,j] + (e[i,j] + (f[i,j] + (g[i,j] + h[i,j]))))))



!	a:=x+(x+(x+(x+(x+(x+(x+(x+(x+(x)))))))))
end

!function f(int a,b,c,d,e,f,g)T=
!	T y:=10
!	g:=a+b
!
!!	a:=x+(x+(x+(x+(x+(x+(x+(x+(x+(x)))))))))
!	y:=x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x))))))))))))
!!	y:=x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x))))))))))
!	y
!end
!
