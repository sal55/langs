export []byte hello = binclude("hello.exe")
