
global int retindex
global int initstaticsindex
global pcl pcldoswx

const maxnestedloops	= 50

global [maxnestedloops,4]int loopstack
global int loopindex							!current level of nested loop/switch blocks

unitrec zero_unit
global unit pzero=&zero_unit

int nvarlocals, nvarparams

macro divider = gencomment("------------------------")

global proc codegen_il(ichar dummy)=
!generate code for module n
	symbol d
	ref procrec pp

	pcl_start(nil, nunits)

	dolibs()

	pp:=staticlist
	while pp do
		d:=pp.def
		dostaticvar(d)
		pp:=pp.nextproc
	od

	gencomment("")

	for i to ndllproctable do
		gendllproc(dllproctable[i])
	od

	pp:=proclist
	while pp do
		d:=pp.def
		genprocdef(currproc:=d)
		pp:=pp.nextproc
	od

	scanprocs()

	pcl_end()

end

proc genprocdef (symbol p) =
	imodule ms

	ms:=modules[p.moduleno]
	pcldoswx:=nil
!	nblocktemps:=0

	if p=ms.stmain and moduletosub[p.moduleno]=mainsubprogno then
		genmaindef(p)
		return
	elsif p=ms.ststart then
		genstartdef(p)
		return
	fi

	mmpos:=p.pos
	doprocdef(p)

	retindex:=createfwdlabel()

	divider()

	if p.hasdoswx then
		pc_gen(kinitdswx)
		pc_gen(knop)
		pcldoswx:=pccurr
		pc_gen(knop)
	fi
GENCOMMENT("AFTER DOSWX")

	evalunit(p.code)
	divider()

	definefwdlabel(retindex)

	genreturn()

	pc_endproc()
end

proc gendllproc(symbol p)=
	symbol e

!CPL "GENDLLPROC", P.NAME
	pc_setimport(getpsymbol(p))

	e:=p.deflist
	while e, e:=e.nextdef do
		pc_addparam(getpsymbol(e))
	od
	pc_setimport(nil)

end

proc dolibs=
	for i to nlibfiles when libfiles[i]^<>'$' do
		pc_addplib(libfiles[i])
	od
end

proc dostaticvar(symbol d)=

	if d.isimport then return fi

	if d.scope = program_scope and d.name^='$' then
		if eqstring(d.name,"$cmdskip") then
			d.scope:=export_scope				!export from mlib subprog
		fi
	fi

	if d.atvar=1 then
		return
	elsif d.code then
		pc_gen(kistatic,genmem_d(d))
		setmode(d.mode)
		pc_setalign(getalignment(d.mode))
		genidata(d.code)
	else
dozstatic:
		pc_gen(kzstatic,genmem_d(d))
		setmode(d.mode)
		pc_setalign(getalignment(d.mode))
	fi

end

proc genidata(unit p,int doterm=1, am='A',offset=0)=
	[2000]byte data
	int t,tbase
	byte allbytes, nbytes
	unit q,a
	symbol d
	ref char s

	t:=p.mode
	mmpos:=p.pos
	tbase:=ttbasetype[t]

	case p.tag
	when jconst then
		if ttisref[t] then
			if t=trefchar then
				if p.svalue then
!CPL "GID/CONST1", P.SVALUE, p.strtype
					if p.strtype='B' then gerror("1:B-str?") fi
					pc_gen(kdata, genstring(p.svalue, p.slength))
				else
					pc_gen(kdata,genint(0))
				fi
			else
				pc_gen(kdata,genint(p.value))
			fi
			setmode(ti64)
		elsif ttisreal[t] then
			pc_gen(kdata,genrealimm(p.xvalue, getpclmode(t)))
			setmode(t)

		elsif ttbasetype[t]=tarray then
			IF P.STRTYPE=0 THEN GERROR("IDATA/ARRAY/NOT BLOCKDATA") FI
!CPL "GID/CONST2", P.SVALUE, p.strtype
			pc_gen(kdata, gendata(p.svalue, p.slength))

		else						!assume int/word
			pc_gen(kdata,genint(p.value))
			setmode_u(p)
		fi

	when jmakelist then
		q:=p.a

		allbytes:=1
		nbytes:=0
		while q, q:=q.nextunit do
			if q.tag=jconst and q.mode=tu8 and nbytes<data.len then
				data[++nbytes]:=q.value
			else
				allbytes:=0
				exit
			end
		end

		if allbytes and nbytes then		!was all byte constants, not in data[1..nbytes]
			pc_gen(kdata, gendata(pcm_copyheapstringn(cast(&data), nbytes), nbytes))
		else
			q:=p.a
			while q, q:=q.nextunit do
				genidata(q)
			od
		fi

	when jname then
		d:=p.def
		case d.nameid
		when staticid,procid,dllprocid then
			pc_gen(kdata, genmemaddr_d(d))
			if offset then
				pc_setscaleoff(1, offset)
			fi
			if am='P' then
				setmode(tu64)
			else
				setmode(t)
			fi
		when labelid then
			if d.index=0 then d.index:=++mlabelno fi
			pc_gen(kdata, genlabel(d.index))
			setmode(ti64)
		else
			gerror("Idata &frameXXX")
		esac
		return
	when jconvert then
		genidata(p.a)
	when jshorten then
		pc_gen(kdata,genint(p.a.value))
		setmode(t)

	when jaddrof,jaddroffirst then
!		genidata(p.a,am:'P',offset:(p.b|p.b.value|0))
		genidata(p.a,am:'P', offset:(p.b|p.b.value|0))
	else
		gerror_s("IDATA: ",jtagnames[p.tag],p)

	esac
end

global func genmem_u(unit p)pcl=
	return genmem(getpsymbol(p.def))
end

global func genmem_d(symbol d)pcl=
	return genmem(getpsymbol(d))
end

global proc genpushmem_d(symbol d)=
	pc_gen(kload,genmem(getpsymbol(d)))
end

global func genmemaddr_d(symbol d)pcl=
	return genmemaddr(getpsymbol(d))
end

global proc genpushmemaddr_d(symbol d)=
	pc_gen(kload,genmemaddr(getpsymbol(d)))
end

global func definelabel:int =
	pc_gen(klabel,genlabel(++mlabelno))
	return mlabelno
end

global func createfwdlabel:int =
	return ++mlabelno
end

global proc definefwdlabel(int lab) =
	pc_gen(klabel,genlabel(lab))
end

global proc genreturn=
!assume returning from currproc
	case currproc.nretvalues
	when 0 then
		pc_gen(kretproc)
	when 1 then
		pc_gen(kretfn)
		setmode(currproc.mode)

	else
		pc_genx(kretfn,currproc.nretvalues)
	esac
end

global func reversecond(int cc)int=
!reverse conditional operator
	case cc
	when eq_cc then cc:=ne_cc
	when ne_cc then cc:=eq_cc
	when lt_cc then cc:=ge_cc
	when le_cc then cc:=gt_cc
	when ge_cc then cc:=lt_cc
	when gt_cc then cc:=le_cc
	esac

	return cc
end

global func reversecond_order(int cc)int=
	case cc
	when eq_cc then cc:=eq_cc
	when ne_cc then cc:=ne_cc
	when lt_cc then cc:=gt_cc
	when le_cc then cc:=ge_cc
	when ge_cc then cc:=le_cc
	when gt_cc then cc:=lt_cc
	esac

	return cc
end

global proc stacklooplabels(int a,b,c)=
!don't check for loop depth as that has been done during parsing
	++loopindex
	if loopindex>maxnestedloops then
		gerror("Too many nested loops")
	fi

	loopstack[loopindex,1]:=a
	loopstack[loopindex,2]:=b
	loopstack[loopindex,3]:=c

end

global func findlooplabel(int k,n)int=
!k is 1,2,3 for label A,B,C
!n is a 1,2,3, according to loop nesting index
	int i

	i:=loopindex-(n-1)		!point to entry
	if i<1 or i>loopindex then gerror("Bad loop index") fi
	return loopstack[i,k]
end

global proc genpc_sysfn(int fnindex, unit a=nil,b=nil,c=nil)=
	genpc_sysproc(fnindex, a,b,c, 1)
end

global proc genpc_sysproc(int fnindex, unit a=nil,b=nil,c=nil, int asfunc=0)=
	int nargs:=0, opc
	symbol d
	pcl p
	opc:=0

	pc_gen(ksetcall)
	p:=pccurr

!	if c then evalunit(c); pc_gen(ksetarg); setmode_u(c); ++nargs fi
!	if b then evalunit(b); pc_gen(ksetarg); setmode_u(b); ++nargs fi
!	if a then evalunit(a); pc_gen(ksetarg); setmode_u(a); ++nargs fi

	pushsysarg(c, 3, nargs)
	pushsysarg(b, 2, nargs)
	pushsysarg(a, 1, nargs)
!
	p.nargs:=nargs

	d:=getsysfnhandler(fnindex)
	if d then
		pc_gen((asfunc|kcallf|kcallp), genmemaddr(getpsymbol(d)))
		pc_setnargs(nargs)
	else
		pc_gen((asfunc|kcallf|kcallp), gennameaddr(sysfnnames[fnindex]+3))
	fi
	pccurr.nargs:=nargs
end

global proc pushsysarg(unit p, int n, &nargs) =
!return 0 or 1 args pushed
	if p then
		evalunit(p)
		pc_gen(ksetarg)
		setmode_u(p)
		pccurr.x:=n
		pccurr.y:=n			!ASSUMES ALL INTS; however this only important
							!for arm64, and only matters if more than 8 args
		++nargs
	fi
end

proc start=
	zero_unit.tag:=jconst
	zero_unit.mode:=ti64
	zero_unit.value:=0
	zero_unit.resultflag:=1
end

global func getsysfnhandler(int fn)symbol p=
	[300]char str
	int report

	if sysfnhandlers[fn] then
		return sysfnhandlers[fn]
	fi

	strcpy(str,"m$")
	strcat(str,sysfnnames[fn]+3)	!"sf_stop" => "m$stop"

	ref procrec pp:=proclist
	while pp, pp:=pp.nextproc do
		if eqstring(pp.def.name, str) then
			sysfnhandlers[fn]:=pp.def
			return pp.def
		fi
	od

!	report:=passlevel>asm_pass
	report:=1
	report:=0

	if report then
		println "Sysfn not found:",str
	fi
	if fn<>sf_unimpl then
		p:=getsysfnhandler(sf_unimpl)
		if p=nil and report then
			gerror("No m$unimpl")
		fi
		return p
	fi

	return nil
end

global func findhostfn(int opc)psymbol=
!called from pcl/mcl backend. opc refers to a PCL op

	case opc
	when kpower then			!assume for i64
		getpsymbol(getsysfnhandler(sf_power_i64))

	else
		nil
	esac
end

global proc genpushint(int a)=
	pc_gen(kload, genint(a))
	setmode(ti64)
end

global proc genpushreal(real x, int mode)=
	pc_gen(kload,genreal(x, getpclmode(mode)))
	setmode(mode)
end

global proc genpushstring(ichar s, int length)=
	pc_gen(kload,genstring(s, length))
	setmode(tu64)
end

proc genmaindef(symbol p)=
	symbol d

	mmpos:=p.pos
	doprocdef(p,1)

	retindex:=createfwdlabel()
	for i to nsubprogs when i<>mainsubprogno do
		d:=modules[subprogs[i].mainmodule].ststart
		docallproc(d)
	od
	d:=modules[subprogs[mainsubprogno].mainmodule].ststart
	docallproc(d)

	divider()
	evalunit(p.code)
	divider()

	definefwdlabel(retindex)

	pc_gen(kload, genint(0))
	setmode(ti64)
	pc_gen(kstop)
	genreturn()

	pc_endproc()
end

proc genstartdef(symbol p)=
	symbol d
	int lead:=0, m,s

	m:=p.moduleno
	s:=p.subprogno

	if s=mainsubprogno and p.moduleno=subprogs[s].mainmodule then
		LEAD:=1
	elsif p.moduleno=subprogs[s].firstmodule then
		LEAD:=2
	fi

	mmpos:=p.pos
	doprocdef(p)

	retindex:=createfwdlabel()

	if lead then
		for i to nmodules when moduletosub[i]=s and i<>m do
			d:=modules[i].ststart
			docallproc(d)
		od
	fi

	divider()
	evalunit(p.code)
	divider()

	definefwdlabel(retindex)

	genreturn()

	pc_endproc()
!	gencomment("")
end

proc initstaticvar(symbol d)=
	if d.code then
		evalunit(d.code)
	fi
	pc_gen(kstore,genmem_d(d))
end

proc docallproc(symbol d)=
!call a simple proc, eg. start(), with no args
	return unless d
	pc_gen(ksetcall)
	pc_setnargs(0)

	pc_gen(kcallp, genmemaddr_d(d))
end

proc doprocdef(symbol d, int ismain=0)=
	psymbol p
	symbol e

	pc_defproc(p:=getpsymbol(d), isentry:ismain, threaded:d.isthreaded)

	e:=d.deflist
	while e, e:=e.nextdef do
		case e.nameid
		when paramid then
			pc_addparam(getpsymbol(e))

		when frameid then
			unless e.atvar and e.equivvar then
				pc_addlocal(getpsymbol(e))
			end

		esac
	od
end

proc scanprocs=
	const maxprocs=1000
	[maxprocs]psymbol proctable
	pcl currpcl
	int nprocs:=0

	currpcl:=pcstart

	repeat
		if currpcl.opcode in [kproc,ktcproc] and currpcl.def.ishandler then
			if nprocs>=maxprocs then gerror("PCL proctab overflow") fi
			proctable[++nprocs]:=currpcl.def
		fi
		++currpcl
	until currpcl>pccurr

	if nprocs=0 and pnprocs=nil then
		pnprocs:=pc_makesymbol("$nprocs", static_id)

		pnprocs.mode:=tpi64
!CPL "++++++++", =PNPROCS, PNPROCS.NAME

		goto finish
	fi

	setfunctab()

!CPL "SCANP", =PNPROCS, =PPROCADDR

	pc_gen(kistatic, genmem(pprocaddr))
	pccurr.mode:=tpblock
	pccurr.size:=nprocs*8
	pprocaddr.mode:=tpblock
	pprocaddr.size:=pccurr.size

	for i to nprocs do
		pc_gen(kdata, genmemaddr(proctable[i]))
		setmode(tu64)
	od

	pc_gen(kistatic, genmem(pprocname))
	pccurr.mode:=tpblock
	pccurr.size:=nprocs*8
	pprocname.mode:=tpblock
	pprocname.size:=pccurr.size

	for i to nprocs do
		pc_gen(kdata, genstring(getbasename(proctable[i].name)))
		setmode(tu64)
	od

finish:
	pc_gen(kistatic, genmem(pnprocs))
	setmode(ti64)
	pc_gen(kdata, genint(nprocs))
	setmode(ti64)
end

global proc setfunctab=
	if pnprocs=nil then
		pnprocs:=pc_makesymbol("$nprocs", static_id)
!CPL "SET PNPROCS", PNPROCS
		pnprocs.mode:=tpi64
		pprocname:=pc_makesymbol("$procname", static_id)
		pprocaddr:=pc_makesymbol("$procaddr", static_id)
	fi
end
