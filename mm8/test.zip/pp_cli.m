global enumdata []ichar passnames =
!								Output (when this is the final step)
	(pcl_pass,		"pcl"),			! .pcl
	(runpcl_pass,	"(int)"),			! interpret
	(mcl_pass,		"asm"),			! .asm
	(obj_pass,		"obj"),			! .obj (via .asm and aa)
	(dll_pass,		"dll"),			! .dll
	(exe_pass,		"exe"),			! .exe
	(mx_pass,		"mx"),			! .mx
!	(clang_pass,	"c"),			! .c
	(run_pass,		"(run)"),		! run in-memory
end

enumdata []ichar optionnames, []byte optionvalues =

!normal production outputs
	(pcl_sw,		"p",			pcl_pass),
	(runpcl_sw,		"i",			runpcl_pass),
	(asm_sw,		"a",			mcl_pass),
	(nasm_sw,		"nasm",			mcl_pass),
	(obj_sw,		"obj",			obj_pass),
	(dll_sw,		"dll",			dll_pass),
	(exe_sw,		"exe",			exe_pass),		!default
	(mx_sw,			"mx",			mx_pass),
!	(clang_sw,		"clang",		clang_pass),
	(run_sw,		"r",			run_pass),		!default with ms.exe

	(noopt_sw,		"no",			0),
	(opt_sw,		"opt",			0),
	(peephole_sw,	"peep",			0),
	(regoptim_sw,	"regs",			0),

!diagnostic outputs, only relevant for debug mode
	(showpcl_sw,	"showpcl",		0),
	(showasm_sw,	"showasm",		0),
	(showc_sw,		"showc",		0),
	(showss_sw,		"showss",		0),
	(shortnames_sw,	"shortnames",	0),

	(pst_sw,		"pst",			0),

	(rip_sw,		"rip",			1),
	(himem_sw,		"himem",		2),
end

int passlevel = exe_pass

byte fshowpcl
byte fshowasm
byte fshowpst
byte fshowss
byte fshowc

int cmdskip
byte highmem

const maxlabel=1 million

ichar inputfile
ichar outputfile
ichar outext

psymbol dentry=nil
!int labelno

[pclnames.bounds]byte isdirective

const maxlocals=1000
[maxlocals]psymbol localvars			!a proc's params and locals
int nlocals

proc main=
	ichar source

CPL "HI THERE"
	getinputoptions()

	println "Processing", inputfile, "to", outputfile

!CPL "PP", $LINENO
	source:=loadsourcefile(inputfile)
!CPL "PP", $LINENO

	parsefile(source)				!parse to internal PCL
!CPL "PP", $LINENO

	if checkundefined() then
		println "Errors seen"
	fi

!CPL =FREGOPTIM
!CPL =FPEEPHOLE

	pcl_reducetest() when fregoptim or fpeephole


!CPL "PP", $LINENO
	pcl_cmdskip(cmdskip)

!CPL "PP", $LINENO
	case passlevel
	when pcl_pass		then pcl_writepcl(outputfile)
	when runpcl_pass	then pcl_runpcl()
	when mcl_pass		then pcl_writeasm(outputfile)
	when obj_pass		then pcl_writeobj(outputfile)
	when dll_pass		then pcl_writedll(outputfile)
	when exe_pass		then
!CPL "PP", $LINENO
 pcl_writeexe(outputfile)
!CPL "PP", $LINENO
	when mx_pass		then pcl_writemx(outputfile)
!	when clang_pass		then pcl_writeclang(outputfile)
	when run_pass		then pcl_exec()
	else
		loaderror("Bad pass")
	esac

	SHOWPCL(outputfile)

end

proc showpcl(ichar outputfile)=
	[256]char str
	ichar filename, ss
	filehandle f

	return when fshowpcl+fshowpst+fshowasm+fshowc+fshowss=0

	f:=fopen("pp.log","wb")

	if fshowc then
		addtolog(outputfile, f)
	fi

	if fshowasm then
		pcl_writeasm(filename:=changeext(outputfile, ".asm"))
		addtolog(filename, f)
	fi
!
	if fshowss then
		ss:=pcl_writess()
		println @f, ss
	fi
!
	if fshowpcl then
		pcl_writepcl(filename:=changeext(outputfile,".pct"))
		addtolog(filename, f)
	fi

	if fshowpst then
		pcl_writepst("psymtab")
		addtolog("psymtab", f)
	fi

	fclose(f)

	print "Press key..."
	stop when os_getch()=27
!
!	fprint @str,"copy/b # + psymtab pp.log", outputfile
!!	cpl =str
!!	os_execwait(str)
!	system(str)
!
	print @str,"\\m\\scripts\\med.bat pp.log"
	os_execwait(str,0,nil)

end

proc getinputoptions=
	int paramno,pmtype,sw,extlen
	ichar name,value,ext
	[300]char filespec

	paramno:=1

	while pmtype:=nextcmdparamnew(paramno,name,value,"pcl") do
		case pmtype
		when pm_option then

			convlcstring(name)
			for sw to optionnames.len do
				if eqstring(name,optionnames[sw]) then
					do_option(sw,value,paramno)
					exit
				fi
			else
				println "Unknown option:",name
				stop 99
			od
		when pm_sourcefile then
			if inputfile then
				loaderror("Specify one lead module only")
			fi
			convlcstring(name)
			inputfile:=pcm_copyheapstring(name)

			if passlevel in [run_pass, runpcl_pass] then
				cmdskip:=paramno-1+$CMDSKIP
				exit
			fi

		else
			loaderror("Invalid params")
		esac

	od

	if passlevel in [obj_pass, dll_pass] or
		passlevel=mcl_pass and assemtype='NASM' then highmem:=2
	fi

	if inputfile=nil then
		println "Usage:"
		println "    ",,cmdparams[0],"filename[.pcl]"
		println "Options:      Output:"
		println "    -exe      EXE file (default)"
		println "    -dll      DLL file"
		println "    -obj      OBJ file"
		println "    -mx       MX file"
		println "    -a        ASM file"
		println "    -i        RUN as PCL code (interpret)"
		println "    -r        RUN as native code"
		stop
	fi

	case passlevel
	when pcl_pass then outext:="pct"
!	when clang_pass then outext:="c"
	else outext:=passnames[passlevel]
	esac

	outputfile:=pcm_copyheapstring(changeext(inputfile, outext))

	pcl_setflags(highmem:highmem, shortnames:0)

end

proc do_option(int sw, ichar value, int paramno=0)=
	static byte outused, outpathused

	if sw in pcl_sw..run_sw then
		passlevel:=optionvalues[sw]
		outext:=passnames[sw]

!		if sw=asm_sw and assemtype<>'AA' or sw=nasm_sw and assemtype<>'NASM' then
!			loaderror("Wrong WRITEASM")
!		fi

		if sw=runpcl_pass then			!in case occurs at end
			cmdskip:=paramno-1+$CMDSKIP
		fi

		return

	fi	

	case sw
	when showpcl_sw then fshowpcl:=1
	when showasm_sw then fshowasm:=1
	when showc_sw then fshowc:=1
	when pst_sw then fshowpst:=1
	when showss_sw then fshowss:=1
	when noopt_sw then fpeephole:=fregoptim:=0

	when rip_sw, himem_sw then highmem:=optionvalues[sw]
!
	end case

end

global proc addtolog(ichar filename, filehandle logdest)=
	filehandle f
	int c

	f:=fopen(filename,"rb")

	if f=nil then
 CPL "ATL ERROR",FILENAME; return fi

	do
		c:=fgetc(f)
		exit when c=c_eof
		fputc(c,logdest)
	od
	fclose(f)
end

func loadsourcefile(ichar filename)ichar s =
	s:=readfile(filename)
	if s=nil then
		println "Can't open", filename
		stop 1
	fi
	s
end	

proc loaderror(ichar mess)=
	println "PP error:", mess
	println
	stop 1
end

