importdll pcl =
    type psymbol = ref pstrec
    type pcl = ref pclrec
    record pclrec = 
        u8 opcode
        u8 opndtype
        u8 condcode
        u8 mode
        u32 size
        union
            struct
                union
                    i64 value
                    r64 xvalue
                    ichar svalue
                    i64 labelno
                    psymbol def
                    ref void asmcode
                end
                union
                    struct
                        i32 x
                        i32 y
                    end
                    struct
                        i32 scale
                        i32 extra
                    end
                    struct
                        i32 nargs
                        union
                            i32 nvariadics
                            i32 simple
                        end
                    end
                    struct
                        i32 minlab
                        i32 maxlab
                    end
                    struct
                        i32 paramslots
                        i32 localslots
                    end
                    i32 stepx
                    i32 align
                    i32 popone
                    i32 slicelwb
                    i32 inplace
                end
            end
        end
        u32 pos
        bitfl sourceoffset
        bitfl fileno
        i32 dummy
        bitfl mode2
        bitfl seqno
    end

    record fwdrec = 
        ref fwdrec nextfwd
        i32 offset
        i16 reltype
        i16 seg
    end

    type procinfo = ref procinforec
    record procinforec = 
        u8 pcldepth
        u8 nparams
        u8 nlocals
        u8 isleaf
        u8 nmaxargs
        u8 assemused
        u8 mcldone
        u8 hasblocks
    end

    type mclopnd = ref mclopndrec
    record mclopndrec = 
        union
            psymbol def
            i64 value
            r64 xvalue
            ichar svalue
            i64 labelno
            i64 sysfn
            i64 tempno
        end
        u16 misc
        bitfl size
        bitfl scale
        bitfl mode
        bitfl valtype
        u8 reg
        u8 regix
        i32 offset
    end

    record mclrec = 
        ref mclrec lastmcl
        ref mclrec nextmcl
        mclopnd a
        mclopnd b
        u8 c
        u8 opcode
        u8 cond
        u8 spare1
        u32 seqno
        union
            u32 mpos
            u32 lineno
        end
        u32 spare2
        union
            [16]u8 regfreed
            pair regfreedpr
        end
    end

    record relocrec = 
        ref relocrec nextreloc
        i64 reloctype
        i64 offset
        i64 stindex
    end

    record dbuffer = 
        ref u8 pstart
        union
            ref u8 pcurr
            ref u16 pcurr16
            ref u32 pcurr32
            ref u64 pcurr64
        end
        ref u8 pend
        i64 alloc
    end

    record mcxreloc = 
        u32 offset
        union
            u16 stindex
            u8 targetsegment
        end
        u8 segment
        u8 reloctype
    end

    record librec = 
        ichar version
        i64 codesize
        i64 idatasize
        i64 zdatasize
        i64 nrelocs
        i64 ndlllibs
        i64 nlibs
        i64 nimports
        i64 nexports
        ref u8 codeptr
        ref u8 idataptr
        ref []mcxreloc reloctable
        ref []ichar dllnames
        ref []ichar libnames
        ref []ichar importnames
        ref []ichar exports
        ref []u8 exportsegs
        ref []u64 exportoffsets
        u64 entryoffset
        ref u8 zdataptr
        i64 codexsize
        ref []u64 exportaddr
        ref []i16 importxreftable
        ichar filespec
        ichar libname
        ref u8 entryaddr
        i64 libno
    end

    var u8 pc_userunpcl
    var i64 pclseqno
    var pcl pcstart
    var pcl pccurr
    var pcl pcend
    var i64 mlabelno
    var u8 phighmem
    var u8 pfullsys
    var ref proc(ref void $1) idomcl_assem
    var ref proc(ref void $1)i64 icheckasmlabel
    var ref proc(i64 $1)ref pstrec igethostfn
    var i64 mmpos
    var psymbol currfunc
    var ref proc(i64 pos,ref ichar filename,ref ichar sourceline)i64 igetmsourceinfo
    var u8 pverbose
    var i64 assemtype
    var u8 fpeephole
    var u8 fregoptim
    var i64 mcltime
    var i64 sstime
    var i64 objtime
    var i64 exetime
    var ichar $pmodulename
    var [0..142]i64 pclflags
    var i64 pstartclock
    var [0..13]ichar pstdnames
    var [0..13]u8 psize
    var [0..13]u8 psigned
    var [0..13]u8 pint
    var [0..13]u8 pfloat
    var [0..13]u8 pmin
    var [0..13]u8 piwrb
    var [0..13]ichar opndnames
    var [0..142]ichar pclnames
    var [0..142]u8 pclhastype
    var [0..142]u8 pclextra
    var [0..142]u8 pclhasopnd
    var [0..142]u8 pclargs
    var [0..6]ichar ccnames
    var [0..9]ichar idnames
    var i64 mclseqno
    var i64 nmclopnd
    var [0..8]ichar valtypenames
    var [152]ichar mclnames
    var [152]u8 mclnopnds
    var [152]u8 mclcodes
    var [0..20]ichar regnames
    var [0..20]u8 regcodes
    var [0..19]ichar condnames
    var [0..19]ichar asmcondnames
    var [0..19]i64 asmrevcond
    var [137]ichar dregnames
    var [137]u8 regsizes
    var [137]u8 regindices
    var [16]ichar xmmregnames
    var [8]ichar fregnames
    var [8]ichar mregnames
    var [18]ichar jmpccnames
    var [18]u8 jmpcccodes
    var [16]ichar setccnames
    var [16]u8 setcccodes
    var [16]ichar cmovccnames
    var [16]u8 cmovcccodes
    var [0..5]ichar segmentnames
    var [0..2]ichar reftypenames
    var [0..5]ichar opndnames_ma
    var [0..16]ichar xregnames
    var ref mclrec mccode
    var ref mclrec mccodex
    var [8]u8 regmodes
    var [0..13]ichar mcxdirnames
    var [0..5]ichar mcxrelocnames
    var i64 nsymimports
    var i64 nsymexports

    const i64 tpvoid = 0
    const i64 tpr32 = 1
    const i64 tpr64 = 2
    const i64 tpu8 = 3
    const i64 tpu16 = 4
    const i64 tpu32 = 5
    const i64 tpu64 = 6
    const i64 tpi8 = 7
    const i64 tpi16 = 8
    const i64 tpi32 = 9
    const i64 tpi64 = 10
    const i64 tpblock = 11
    const i64 tpvector = 12
    const i64 tplast = 13
    const i64 no_opnd = 0
    const i64 mem_opnd = 1
    const i64 memaddr_opnd = 2
    const i64 label_opnd = 3
    const i64 int_opnd = 4
    const i64 real_opnd = 5
    const i64 r32_opnd = 6
    const i64 string_opnd = 7
    const i64 strimm_opnd = 8
    const i64 assem_opnd = 9
    const i64 realimm_opnd = 10
    const i64 realimm32_opnd = 11
    const i64 data_opnd = 12
    const i64 any_opnd = 13
    const i64 knop = 0
    const i64 kload = 1
    const i64 kiload = 2
    const i64 kiloadx = 3
    const i64 kstore = 4
    const i64 kistore = 5
    const i64 kistorex = 6
    const i64 kstorem = 7
    const i64 kdupl = 8
    const i64 kdouble = 9
    const i64 kswapstk = 10
    const i64 kunload = 11
    const i64 kopnd = 12
    const i64 ktype = 13
    const i64 kloadbit = 14
    const i64 kloadbf = 15
    const i64 kstorebit = 16
    const i64 kstorebf = 17
    const i64 kcallp = 18
    const i64 kicallp = 19
    const i64 kretproc = 20
    const i64 kcallf = 21
    const i64 kicallf = 22
    const i64 kretfn = 23
    const i64 kjump = 24
    const i64 kijump = 25
    const i64 kjumpcc = 26
    const i64 kjumpt = 27
    const i64 kjumpf = 28
    const i64 kjumpret = 29
    const i64 kjumpretm = 30
    const i64 ksetcc = 31
    const i64 kstop = 32
    const i64 kto = 33
    const i64 kforup = 34
    const i64 kfordown = 35
    const i64 kiswap = 36
    const i64 kswitch = 37
    const i64 kswitchu = 38
    const i64 kswlabel = 39
    const i64 kendsw = 40
    const i64 kclear = 41
    const i64 kassem = 42
    const i64 kadd = 43
    const i64 ksub = 44
    const i64 kmul = 45
    const i64 kdiv = 46
    const i64 kidiv = 47
    const i64 kirem = 48
    const i64 kidivrem = 49
    const i64 kbitand = 50
    const i64 kbitor = 51
    const i64 kbitxor = 52
    const i64 kshl = 53
    const i64 kshr = 54
    const i64 kmin = 55
    const i64 kmax = 56
    const i64 kaddpx = 57
    const i64 ksubpx = 58
    const i64 ksubp = 59
    const i64 kneg = 60
    const i64 kabs = 61
    const i64 kbitnot = 62
    const i64 knot = 63
    const i64 ktoboolt = 64
    const i64 ktoboolf = 65
    const i64 ksqr = 66
    const i64 ksqrt = 67
    const i64 ksin = 68
    const i64 kcos = 69
    const i64 ktan = 70
    const i64 kasin = 71
    const i64 kacos = 72
    const i64 katan = 73
    const i64 klog = 74
    const i64 klog10 = 75
    const i64 kexp = 76
    const i64 kround = 77
    const i64 kfloor = 78
    const i64 kceil = 79
    const i64 ksign = 80
    const i64 katan2 = 81
    const i64 kpower = 82
    const i64 kfmod = 83
    const i64 kincrto = 84
    const i64 kdecrto = 85
    const i64 kincrload = 86
    const i64 kdecrload = 87
    const i64 kloadincr = 88
    const i64 kloaddecr = 89
    const i64 kaddto = 90
    const i64 ksubto = 91
    const i64 kmulto = 92
    const i64 kdivto = 93
    const i64 kidivto = 94
    const i64 kiremto = 95
    const i64 kbitandto = 96
    const i64 kbitorto = 97
    const i64 kbitxorto = 98
    const i64 kshlto = 99
    const i64 kshrto = 100
    const i64 kminto = 101
    const i64 kmaxto = 102
    const i64 kaddpxto = 103
    const i64 ksubpxto = 104
    const i64 knegto = 105
    const i64 kabsto = 106
    const i64 kbitnotto = 107
    const i64 knotto = 108
    const i64 ktoboolto = 109
    const i64 ktypepun = 110
    const i64 kfloat = 111
    const i64 kfix = 112
    const i64 ktruncate = 113
    const i64 kwiden = 114
    const i64 kfwiden = 115
    const i64 kfnarrow = 116
    const i64 kstartmx = 117
    const i64 kresetmx = 118
    const i64 kendmx = 119
    const i64 kproc = 120
    const i64 ktcproc = 121
    const i64 kendproc = 122
    const i64 kistatic = 123
    const i64 kzstatic = 124
    const i64 kdata = 125
    const i64 kinitdswx = 126
    const i64 klabel = 127
    const i64 klabeldef = 128
    const i64 ksetjmp = 129
    const i64 klongjmp = 130
    const i64 ksetcall = 131
    const i64 ksetarg = 132
    const i64 kloadall = 133
    const i64 keval = 134
    const i64 kcomment = 135
    const i64 kendprog = 136
    const i64 kparam = 137
    const i64 klocal = 138
    const i64 krettype = 139
    const i64 kvariadic = 140
    const i64 kaddlib = 141
    const i64 kextproc = 142
    const i64 no_cc = 0
    const i64 eq_cc = 1
    const i64 ne_cc = 2
    const i64 lt_cc = 3
    const i64 le_cc = 4
    const i64 ge_cc = 5
    const i64 gt_cc = 6
    const i64 null_id = 0
    const i64 import_id = 1
    const i64 proc_id = 2
    const i64 static_id = 3
    const i64 local_id = 4
    const i64 param_id = 5
    const i64 label_id = 6
    const i64 export_id = 7
    const i64 misc_id = 8
    const i64 program_id = 9
    const i64 ctarget = 0
    const i64 no_val = 0
    const i64 intimm_val = 1
    const i64 realimm_val = 2
    const i64 realmem_val = 3
    const i64 stringimm_val = 4
    const i64 def_val = 5
    const i64 label_val = 6
    const i64 name_val = 7
    const i64 temp_val = 8
    const i64 m_procstart = 1
    const i64 m_procend = 2
    const i64 m_comment = 3
    const i64 m_labelname = 4
    const i64 m_define = 5
    const i64 m_definereg = 6
    const i64 m_trace = 7
    const i64 m_endx = 8
    const i64 m_labelx = 9
    const i64 m_nop = 10
    const i64 m_param = 11
    const i64 m_mov = 12
    const i64 m_push = 13
    const i64 m_pop = 14
    const i64 m_lea = 15
    const i64 m_cmovcc = 16
    const i64 m_movd = 17
    const i64 m_movq = 18
    const i64 m_movsx = 19
    const i64 m_movzx = 20
    const i64 m_movsxd = 21
    const i64 m_call = 22
    const i64 m_ret = 23
    const i64 m_leave = 24
    const i64 m_retn = 25
    const i64 m_jmp = 26
    const i64 m_jmpcc = 27
    const i64 m_xchg = 28
    const i64 m_add = 29
    const i64 m_sub = 30
    const i64 m_adc = 31
    const i64 m_sbb = 32
    const i64 m_imul = 33
    const i64 m_mul = 34
    const i64 m_imul2 = 35
    const i64 m_imul3 = 36
    const i64 m_idiv = 37
    const i64 m_div = 38
    const i64 m_andx = 39
    const i64 m_orx = 40
    const i64 m_xorx = 41
    const i64 m_test = 42
    const i64 m_cmp = 43
    const i64 m_shl = 44
    const i64 m_sar = 45
    const i64 m_shr = 46
    const i64 m_rol = 47
    const i64 m_ror = 48
    const i64 m_rcl = 49
    const i64 m_rcr = 50
    const i64 m_neg = 51
    const i64 m_notx = 52
    const i64 m_inc = 53
    const i64 m_dec = 54
    const i64 m_cbw = 55
    const i64 m_cwd = 56
    const i64 m_cdq = 57
    const i64 m_cqo = 58
    const i64 m_setcc = 59
    const i64 m_bsf = 60
    const i64 m_bsr = 61
    const i64 m_shld = 62
    const i64 m_shrd = 63
    const i64 m_sqrtss = 64
    const i64 m_sqrtsd = 65
    const i64 m_addss = 66
    const i64 m_addsd = 67
    const i64 m_subss = 68
    const i64 m_subsd = 69
    const i64 m_mulss = 70
    const i64 m_mulsd = 71
    const i64 m_divss = 72
    const i64 m_divsd = 73
    const i64 m_comiss = 74
    const i64 m_comisd = 75
    const i64 m_ucomisd = 76
    const i64 m_xorps = 77
    const i64 m_xorpd = 78
    const i64 m_andps = 79
    const i64 m_andpd = 80
    const i64 m_pxor = 81
    const i64 m_pand = 82
    const i64 m_cvtss2si = 83
    const i64 m_cvtsd2si = 84
    const i64 m_cvttss2si = 85
    const i64 m_cvttsd2si = 86
    const i64 m_cvtsi2ss = 87
    const i64 m_cvtsi2sd = 88
    const i64 m_cvtsd2ss = 89
    const i64 m_cvtss2sd = 90
    const i64 m_movdqa = 91
    const i64 m_movdqu = 92
    const i64 m_pcmpistri = 93
    const i64 m_pcmpistrm = 94
    const i64 m_fld = 95
    const i64 m_fst = 96
    const i64 m_fstp = 97
    const i64 m_fild = 98
    const i64 m_fist = 99
    const i64 m_fistp = 100
    const i64 m_fadd = 101
    const i64 m_fsub = 102
    const i64 m_fmul = 103
    const i64 m_fdiv = 104
    const i64 m_fsqrt = 105
    const i64 m_fsin = 106
    const i64 m_fcos = 107
    const i64 m_fsincos = 108
    const i64 m_fptan = 109
    const i64 m_fpatan = 110
    const i64 m_fabs = 111
    const i64 m_fchs = 112
    const i64 m_minss = 113
    const i64 m_maxss = 114
    const i64 m_minsd = 115
    const i64 m_maxsd = 116
    const i64 m_db = 117
    const i64 m_dw = 118
    const i64 m_dd = 119
    const i64 m_dq = 120
    const i64 m_isegment = 121
    const i64 m_zsegment = 122
    const i64 m_csegment = 123
    const i64 m_align = 124
    const i64 m_resb = 125
    const i64 m_resw = 126
    const i64 m_resd = 127
    const i64 m_resq = 128
    const i64 m_xlat = 129
    const i64 m_loopnz = 130
    const i64 m_loopz = 131
    const i64 m_loopcx = 132
    const i64 m_jecxz = 133
    const i64 m_jrcxz = 134
    const i64 m_cmpsb = 135
    const i64 m_cmpsw = 136
    const i64 m_cmpsd = 137
    const i64 m_cmpsq = 138
    const i64 m_rdtsc = 139
    const i64 m_popcnt = 140
    const i64 m_bswap = 141
    const i64 m_finit = 142
    const i64 m_fldz = 143
    const i64 m_fld1 = 144
    const i64 m_fldpi = 145
    const i64 m_fld2t = 146
    const i64 m_fld2e = 147
    const i64 m_fldlg2 = 148
    const i64 m_fldln2 = 149
    const i64 m_cpuid = 150
    const i64 m_xxxx = 151
    const i64 m_halt = 152
    const i64 rnone = 0
    const i64 r0 = 1
    const i64 r1 = 2
    const i64 r2 = 3
    const i64 r3 = 4
    const i64 r4 = 5
    const i64 r5 = 6
    const i64 r6 = 7
    const i64 r7 = 8
    const i64 r8 = 9
    const i64 r9 = 10
    const i64 r10 = 11
    const i64 r11 = 12
    const i64 r12 = 13
    const i64 r13 = 14
    const i64 r14 = 15
    const i64 r15 = 16
    const i64 r16 = 17
    const i64 r17 = 18
    const i64 r18 = 19
    const i64 r19 = 20
    const i64 rframe = 15
    const i64 rstack = 16
    const i64 ov_cond = 0
    const i64 nov_cond = 1
    const i64 ltu_cond = 2
    const i64 geu_cond = 3
    const i64 eq_cond = 4
    const i64 ne_cond = 5
    const i64 leu_cond = 6
    const i64 gtu_cond = 7
    const i64 s_cond = 8
    const i64 ns_cond = 9
    const i64 p_cond = 10
    const i64 np_cond = 11
    const i64 lt_cond = 12
    const i64 ge_cond = 13
    const i64 le_cond = 14
    const i64 gt_cond = 15
    const i64 flt_cond = 16
    const i64 fge_cond = 17
    const i64 fle_cond = 18
    const i64 fgt_cond = 19
    const i64 no_seg = 0
    const i64 code_seg = 1
    const i64 idata_seg = 2
    const i64 zdata_seg = 3
    const i64 rodata_seg = 4
    const i64 impdata_seg = 5
    const i64 extern_ref = 0
    const i64 fwd_ref = 1
    const i64 back_ref = 2
    const i64 a_none = 0
    const i64 a_reg = 1
    const i64 a_imm = 2
    const i64 a_mem = 3
    const i64 a_cond = 4
    const i64 a_xreg = 5
    const i64 xnone = 0
    const i64 xr0 = 1
    const i64 xr1 = 2
    const i64 xr2 = 3
    const i64 xr3 = 4
    const i64 xr4 = 5
    const i64 xr5 = 6
    const i64 xr6 = 7
    const i64 xr7 = 8
    const i64 xr8 = 9
    const i64 xr9 = 10
    const i64 xr10 = 11
    const i64 xr11 = 12
    const i64 xr12 = 13
    const i64 xr13 = 14
    const i64 xr14 = 15
    const i64 xr15 = 16
    const c64 mcxsig = M6
    const i64 pad_dir = 0
    const i64 version_dir = 1
    const i64 code_dir = 2
    const i64 idata_dir = 3
    const i64 zdata_dir = 4
    const i64 reloc_dir = 5
    const i64 dlls_dir = 6
    const i64 libs_dir = 7
    const i64 importsymbols_dir = 8
    const i64 exportsymbols_dir = 9
    const i64 exportsegs_dir = 10
    const i64 exportoffsets_dir = 11
    const i64 entry_dir = 12
    const i64 end_dir = 13
    const i64 no_rel = 0
    const i64 locabs32_rel = 1
    const i64 locabs64_rel = 2
    const i64 impabs32_rel = 3
    const i64 impabs64_rel = 4
    const i64 imprel32_rel = 5

    func pcl_start(ichar name=nil,i64 nunits=0) => psymbol
    proc pcl_end()
    func pcl_writepcl(ichar filename=nil) => ichar
    func pcl_writepst(ichar filename=nil) => ichar
    proc pcl_genmcl()
    proc pcl_genss(i64 obj=0)
    func pcl_writess(ichar filename=nil,i64 obj=0) => ichar
    func pcl_writeasm(ichar filename=nil,i64 atype=16705) => ichar
    proc pcl_writeobj(ichar filename)
    proc pcl_writedll(ichar filename)
    proc pcl_writeexe(ichar filename)
    proc pcl_writemx(ichar filename)
    proc pcl_exec()
    proc pcl_setflags(i64 highmem=-1,verbose=-1,shortnames=-1)
    proc pc_gen(i64 opcode,pcl p=nil)
    proc pc_genix(i64 opcode,scale=1,offset=0)
    proc pc_genx(i64 opcode,x,pcl p=nil)
    proc pc_genxy(i64 opcode,x,y,pcl p=nil)
    proc pc_gencond(i64 opcode,cond,pcl p=nil)
    func genint(i64 a) => pcl
    func genreal(r64 x,i64 mode=2) => pcl
    func genrealimm(r64 x,i64 mode=2) => pcl
    func genstring(ichar s) => pcl
    func genpcstrimm(ichar s) => pcl
    func genlabel(i64 a) => pcl
    func genmem(psymbol d) => pcl
    func genmemaddr(psymbol d) => pcl
    func gendata(ref u8 s,i64 length) => pcl
    proc gencomment(ichar s)
    func genname(ichar s) => pcl
    func gennameaddr(ichar s) => pcl
    func genassem(ref void code) => pcl
    func strpmode(i64 mode,size=0) => ichar
    proc pc_setmode(i64 m,size=0)
    proc pc_setmode2(i64 m)
    proc pc_setxy(i64 x,y)
    proc pc_setscaleoff(i64 scale,offset=0)
    proc pc_setoffset(i64 offset)
    proc pc_addoffset(i64 offset)
    proc pc_setincr(i64 n)
    proc pc_setnargs(i64 n)
    proc pc_setnvariadics(i64 n)
    proc pc_setalign(i64 n)
    func getbasename(ichar s) => ichar
    proc pc_addsymbol(psymbol d)
    func pc_makesymbol(ichar s,i64 id) => psymbol
    proc pc_addplib(ichar name)
    proc pc_defproc(psymbol d,i64 mode=0,isentry=0,threaded=0)
    proc pc_setimport(psymbol d)
    proc pc_addparam(psymbol d)
    proc pc_addlocal(psymbol d)
    proc pc_endproc()
    func addstr(ichar s,t) => ichar
    proc merror(ichar mess,param="")
    func pc_duplpst(psymbol d) => psymbol
    proc pcl_cmdskip(i64 cmdskip,psymbol dcmdskip=nil)
    func convertstring(ichar s,t) => i64
    proc pcl_reducetest()
    proc pcl_runpcl()
    proc mclinit(i64 bypass=0)
    proc genmc(i64 opcode,mclopnd a=nil,b=nil)
    proc genmc_cond(i64 opcode,cond,mclopnd a=nil,b=nil)
    func mgenindex(i64 areg=0,ireg=0,scale=1,offset=0,size=0,labno=0,psymbol def=nil) => mclopnd
    func mgenstring(ichar s,i64 length=-1) => mclopnd
    func mgenint(i64 x,mode=10) => mclopnd
    func mgenrealimm(r64 x,i64 mode=2) => mclopnd
    func mgenlabel(i64 x=0) => mclopnd
    func mgenmem(psymbol d,i64 mode=6) => mclopnd
    func mgenmemaddr(psymbol d) => mclopnd
    func mgenxreg(i64 xreg,size=8) => mclopnd
    func mgenreg(i64 reg,mode=10) => mclopnd
    func ispoweroftwo(i64 x) => i64
    proc callproc(ichar cpname,name,i64 lineno)
    func getassemstr() => ref strbuffer
    func writessdata(i64 fexe) => ref strbuffer
end

