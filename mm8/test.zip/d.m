module dll_lib

!    func testfn(i64 a,b,r64 c,d,i64 e,r64 f) => i64

proc main=
	u64 libinst
	ref proc fnptr
	[]u64 args := (10, 20, u64@(30.3), u64@(40.4), 50, u64@(60.6))
	int n:=args.len
	u64 a

	libinst:=os_getdllinst("dll")
	println =libinst
	stop unless libinst

	fnptr:=os_getdllprocaddr(libinst, "testfn")

	println =fnptr
	stop unless fnptr

	for i,x in args do
		println i, x:"h"
	od
	

!export function os_calldllfunction(ref proc fnaddr,
!		int retcode, nargs, ref[]i64 args, ref[]byte argcodes)u64 =

!	a:=os_calldllfunction(fnptr, 'I', args.len, cast(&args), nil)
!	a:=newcalldll(fnptr, 0, args.len, cast(&args))
	a:=newcalldll(fnptr, cast(&args), args.len, 0)

	println a

!	int a
!


!	a:=testfn(10, 20, 30.3, 40.4, 50, 60.6)


end



export function newcalldll(ref proc fnaddr, ref[]u64 args, int nargs, floatret)u64 =
!No 'definereg' available here, so use these register allocations:
!   D5		fnaddr
!   D6		floatret, 0/1/ = int/float
!   D7		nargs
!   D8		args; pointer to u64 array of nargs elements

!	D3		p
!	D4		pushedbytes

	STATIC INT A

	assem
		mov D5, D10				!mov args to non-vols, as they'll be overwritten
		mov A6, A13
		mov A7, A12
		mov D8, D11

		mov A4, 0				!pushedbytes := 0

		test A7, 1				!nargs iand 1
		jz L101					!even
		add A4, 8				!pushed bytes := 8
		push 0					!push zero for alignment
L101:
		lea D4, [D4 + D7*8]		!pushedbytes +:= nargs*8

		mov D3, D8				!p := &args[1]
		lea D3, [D8 + D7*8-8]	!p +:= (&args + nargs-1)

		mov A2, A7				!d2 = nargs
		and A2, A2
		jz L103					!no args: skip
L102:
		push u64 [D3]			!push p^
		sub D3, 8				!--p
		dec A2					!--d2
		jnz L102				!loop while d2 not zero
L103:
		mov D10,   [Dstack]
		movq XMM0, [Dstack]
		mov D11,   [Dstack+8]
		movq XMM1, [Dstack+8]
		mov D12,   [Dstack+16]
		movq XMM2, [Dstack+16]
		mov D13,   [Dstack+24]
		movq XMM3, [Dstack+24]

		call D5					! call [fnaddr]
		add Dstack, D4			! Dstack +:= pushedbytes
		and A6, A6				! floatret=0
		jz L104					! yes
		movq D0, XMM0			! get float return
L104:
		mov [a], D0
	end
	a
end	
