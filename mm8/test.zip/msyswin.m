module msys
module mlib
module mclib
module mwindows
!module mnoos
module mwindll

!proc start=
!	CPL "MSYSWIN/START"
!END
