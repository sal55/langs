!hello

int coffseta

global const maxfuncsig=100
global [maxfuncsig]byte fsnargs
global [maxfuncsig]byte fsrettype
global [maxfuncsig, maxcallarg]byte fsargs
global int nfuncsigs

global proc dobinop(pcl p, ichar opstr)=
	if p.opcode=kidiv then
		ccstr("   if (")
		cctpcast(p)
		ccstack(zz)
		ccstrline(") == 0) {puts((u64)""Divide by zero""); exit(1);}");
	fi

	cctab()
	cctpcast(p)
	ccstack(yy, p)
	ccstr(") ")
	ccstr(opstr)
	ccstr("= ")
	cctpcast(p)
	ccstack(zz, p)
	ccrb()
	popcc()
	ccsemi()
end

global proc dounaryop(pcl p, ichar opstr)=
	cctab()
	cctpcast(p)
	ccstack(zz, p)
	ccstr(") = ")
	ccstr(opstr)
	cctpcast(p)
	ccstack(zz, p)
	ccrb()
	ccsemi()
end

global proc domathsop(pcl p, ichar opstr)=
	cctab()
	cctpcast(p)
	ccstack(zz, p)
	ccstr(") = ")
	ccstr(opstr)
	ccstr("(")
	cctpcast(p)
	ccstack(zz, p)
	ccstrline("));")
end

global proc domaths2op(pcl p, ichar opstr)=
	cctab()
	cctpcast(p)
	ccstack(yy)
	ccstr(") = ")
	ccstr(opstr)
	ccstr("(")
	cctpcast(p)
	ccstack(yy)
	ccstr("), ")
	cctpcast(p)
	ccstack(zz)
	ccstrline("));")
	popcc()
end

global proc dobinopto(pcl p, ichar opstr, int scale=0)=
	cctab()
	ccstr("*")
	cccastptrm(p.mode)
	ccstack(zz)
	ccstr(") ")
	ccstr(opstr)
	ccstr("= ")
	cctpcast(p)
	ccstack(yy)
	ccrb()
	if scale>1 then
		ccstr("*")
		ccint(scale)
	fi
	ccsemi()
	popcc()
	popcc()
end

global proc doabs(pcl p)=
	cctab()
	ccstr("if (")
	cctpcast(p)
	ccstack(zz, p)
	ccstr(") < 0) ")
	cctpcast(p)
	ccstack(zz, p)
	ccstr(") = -")
	cctpcast(p)
	ccstack(zz, p)
	ccrb()
	ccsemi()
end

global proc dojumpcc(pcl p)=
	cctab()
	ccstr("if (")
	cctpcast(p)
	ccstack(yy, p)
	ccrb()
	ccstr(getcondstr(p.condcode))
	cctpcast(p)
	ccstack(zz, p)
	ccstr(")) goto ")
	cclabel(p.labelno)
	popcc()
	unless p.popone then
		popcc()
	end

	ccsemi()
end

global proc dojumptf(pcl p)=
	cctab()
	ccstr("if (")
	if p.opcode=kjumpf then ccstr("!") fi
	cctpcast(p)
	ccstack(zz, p)
	ccstr(")) goto ")
	cclabel(p.labelno)
	popcc()

	ccsemi()
end

global proc doprocdef(pcl pc)=
	psymbol d:=pc.def, e
	int needcomma, nstack
	pcl spc

	localmax:=noperands:=0
	nlocaltemps:=0
!	clear blockflags

!CPL "PROC:",D.NAME

	genprocsig(d, " {")


!	ccstr("	u64 $[")
!	ccint(maxoperands)
!	ccstrline("];")
!
	coffseta:=cdest.length
!	cccomment("R DECLS GO HERE")
!	nstack:=8
!
!
!	ccstr("    u64 ")
!	for i to nstack do
!		ccstr("R")
!		ccint(i-1)
!		if i<nstack then ccstr(", ") fi
!	od
!	ccsemi()
!PDECLEN:=CDEST.LENGTH-PDECOFFSET

	e:=d.nextlocal
	while e, e:=e.nextlocal do
		cctab()
		ccstrmode(e.mode, e.size)
		ccstr(" ")
		ccname(e.name)
		ccstrline(";")
	od

	if d.chasstatics then
CCCOMMENT("PROC LOCAL STATICS GO HERE")
!CPL =PCSTART
		spc:=pcstart
		while spc.opcode<>kendprog, ++spc do
			if spc.opcode=kistatic then
				e:=spc.def
				if e.cprocowner=d then
					cctab()
					spc:=genistaticvar(spc,1)-1
				fi
			fi
		od

	fi

end

global proc doendproc(pcl pc)=
	[32]char str
	int coffsetb, t

	if noperands then
		CCCOMMENT(ADDSTR("******** STACK NOT EMPTY:", STRINT(NOPERANDS)))
!		CPL "STACK NOT EMPTY:",CURRFUNC.NAME
		CPL "STACK NOT EMPTY:",CURRFUNC
	fi

!CPL =LOCALMAX

	if localmax then
		coffsetb:=cdest.length
		ccstr("    u64 ")
		for i to localmax do
			ccstr("R")
			ccint(i)
			if i<localmax then ccstr(", ") fi
		od
		ccstr("; ")

		for i to nlocaltemps do
			t:=ltblockno[i]
			ccstrmode(tpblock, blocksizes[t])
			fprint @str, " R#_B#; ", ltstackno[i], t
			ccstr(str)
		od	
		ccstrline("")

!		for t to nblocktypes do
!			cpl t,blockflags[t]
!
!			fprint @str, "R#_B#", n-1, t
!		fi
!		ccstr(str)



!		od

!ccstr("NBLOCKTYPE:")
!ccint(nblocktypes)
!ccstrline("")
		ccswap(coffseta, coffsetb)

	fi
end

global proc docall(pcl p, int isfunc, isptr)=
	int nargs:=p.nargs, ftype
	int dest:=zz-nargs+1-isptr		!point to right-most arg which is dest for funcs
!	int npop:=nargs-isfunc+isptr		!stack slots to pop
	PCL PC

	cctab()

	if isfunc then					!need dest

		cctpcast(p)
		ccstack(dest, p)
		ccstr(") = ")
	fi

	if isptr then
		ftype:=getfstype(p, nargs)
		ccstr("((F")
		ccint(ftype)
		ccstr(")")

		ccstack(zz, p)				!func ptr is from top of stack
		ccstr(")")
		popcc()
	else

		ccname(p.def.name)
	fi
	ccstr("(")

	for i to nargs do
		pc:=callpcmode[ncalldepth, i]
		if pc then
			cctpcast(callpcmode[ncalldepth, i])
			ccstack(zz-i+1, pc)
			ccrb()
		else
			ccstack(zz-i+1)
		fi

		if i<nargs then ccstr(", ") fi
	od
	ccstr(")")
	ccsemi()

!CPL =ZZ
!CPL =DEST
!
!CPL "CALL/NPOP", =NARGS, =ISFUNC, =ISPTR

	to nargs-isfunc do
!CPL "//POP"
		popcc()
	od

	if nargs=0 and isfunc then
		pushcc()
	fi
end

global proc dofor(pcl pc)=
	int step:=pc.stepx
	if pc.opcode=kfordown then -:=step fi

	cctab()
	ccopnd(pc+1)
	ccstr(" += ")
	ccint(step)
	ccstr("; if (")
	ccopnd(pc+1)
	ccstr((step>0|" <= "|" >= "))
	ccopnd(pc+2)
	ccstr(") goto ")
	cclabel(pc.labelno)
	ccsemi()

end

global proc gentypes(pcl pc)=
	int t, ntypes

!	cccomment("TYPES")
	cccomment("***** Types *****")
!	ccstrline("/* Types */")

	while pc.opcode<>kendprog, ++pc do
		gentype(pc.mode, pc.size)
	od

	psymbol d:=psymboltable, e
	while d, d:=d.next do
		if d.id=proc_id then

			e:=d.nextlocal
			while e, e:=e.nextlocal do
				gentype(e.mode, e.size)
			od
		fi
	od

	ccstrline("")
end

proc gentype(int mode, size)=
	static [8]ichar typenames=("u8", "u16","","u32","","","","u64")
	int ntypes, t

	if mode=tpblock then
		ntypes:=nblocktypes
		t:=findblocktype(size, 1)
		if nblocktypes>ntypes then			!new type
			ccstr("struct $B")
			ccint(t)
			ccstr(" {")
			ccstr(typenames[blockelemsizes[t]])
			ccstr(" a[")
			ccint(blocklengths[t])	
			ccstr("];};   // mem:")
			ccint(size)
			ccsemi()
		fi
	fi
end

global proc genvars=
	cccomment("***** Variables *****")

	psymbol d:=psymboltable
	while d, d:=d.next do
		if d.id=static_id and not d.cprocowner then
			genzstaticvar(d)
		fi
	od
	ccstrline("")
end

global proc genimports=
	cccomment("***** Imported Functions *****")
	psymbol d:=psymboltable

	while d, d:=d.next do
		if d.id=import_id then
			genprocsig(d)
		fi
	od
	ccstrline("")
end

proc genprocsig(psymbol p, ichar term=";")=
	psymbol e

	if p.imported then
		ccstr("extern ")
	elsif not p.exported then
		ccstr("static ")
	fi

	ccstrmode(p.mode, p.size)
	ccstr(" ")
	ccname(p.name)
	ccstr("(")

	e:=p.nextparam
	while e, e:=e.nextparam do
		ccstrmode(e.mode, e.size)
		ccstr(" ")
		ccstr(e.name)
		if e.nextparam or p.varparams then
			ccstr(", ")
		fi
	od

	if p.varparams then
		ccstr("...")
	fi
	ccstr(")")
	ccstrline(term)
end

global func genistaticvar(pcl pc, int inproc)pcl=
!pc points to istatic op (which may be out-of-line, if called for local proc statics)
	psymbol d:=pc.def

	if d.imported then
		ccstr("extern ")
	elsif not d.exported then
		ccstr("static ")
	fi

	ccstrmode(d.mode, d.size)
	ccstr(" ")
	ccname(d.name)

	if (pc+1).opcode<>kdata then
		ccsemi()
		return pc+1
	fi


	ccstr(" = ")

	if d.mode=tpblock then
!		ccstrline("{")
		ccstrline("{{")
	fi

!CPL "=================GENISTATICVAR",D.NAME, STRPMODE(D.MODE, D.SIZE),"//",STRPMODE(PC.MODE, PC.SIZE)

	genidata(pc, inproc)
!
!	CCSTR("<")
!	CCSTR(PCLNAMES[(PC+1).OPCODE])
!	CCSTR(">")
!	CCSTRLINE("")

	repeat ++pc until pc.opcode<>kdata

	if d.mode=tpblock then
		if inproc then ccstr("    ") fi
!		ccstr("}")
		ccstr("}}")
	fi

	ccsemi()
	pc
end

proc genidata(pcl pc, int inproc)=
	pcl qc
	byte hasaddr:=0, is64bits:=1

	qc:=pc+1
	while qc.opcode=kdata, ++qc do
		case qc.opndtype
		when string_opnd, mem_opnd, memaddr_opnd, label_opnd then
			hasaddr:=1
		esac

!CPL =QC.SIZE

		if qc.size<>8 then is64bits:=0 fi

	od

!CPL =HASADDR, =IS64BITS

	if hasaddr or is64bits then
		genaddrdata(pc, inproc)
	else
		genconstdata(pc, inproc)
	fi

end

proc genaddrdata(pcl pc, int inproc)=
!data contains addresses. Assume single or multiple u64 elements
	int t

!CPL "GENADDRDATA", PCLNAMES[PC.OPCODE]

	if pc.mode<>tpblock then
		if pc.size<>8 then
			merror("genaddr/not u64")
		fi
!		ccstr("<Single Addr>")
		gendatax(pc+1, 1)
	
	else
		t:=findblocktype(pc.size, 0)
		if blockelemsizes[t]<>8 then
			merror("genaddr/not []u64")
		fi

!		ccstrline("<Mult Addr/mixed>")

		++pc
		do
			if inproc then cctab() fi
			gendatax(pc)
			++pc
			if pc.opcode=kdata then
				ccstrline(",")
			else
				exit
			fi
		od

	fi
end

proc genconstdata(pcl pc, int inproc)=
!data contains only constant 1/2/4/8 byte elements, may be mixed
!dest will be 1/2/4/8 byte elements, all the same

	pcl pca 
	ref byte q8, r
	ref u16 q16 @ q8
	ref u32 q32 @ q8
	ref u64 q64 @ q8
	int t, n, elemsize

!CPL "GENCONSTDATA", PCLNAMES[PC.OPCODE]!,pc.def.name
!CPL =STRPMODE(PC.MODE, PC.SIZE)
 
	q8:=r:=pcm_allocz(pc.size)

	pca:=pc+1
	repeat
		r:=gendatac(pca, r)
		++pca
	until pca.opcode<>kdata

!now need to dump data at q into 1/2/4/8-byte values

	if pc.mode=tpblock then
		t:=findblocktype(pc.size, 0)
		IF T=0 THEN MERROR("CAN'T FIND BLOCK") FI

		n:=blocklengths[t]
		elemsize:=blockelemsizes[t]
	else
		n:=1
		elemsize:=pc.size
	fi

!CPL "-------GENCONST",=N, =ELEMSIZE

	for i to n do
		case elemsize
		when 1 then ccint(q8++^)
		when 2 then ccint(q16++^)
		when 4 then ccint(q32++^)
		else		ccint(q64++^)
		esac

		if n>1 and i<n then
			ccstrline(",")
			if inproc then cctab() fi
		fi

	od
!CPL $LINENO
end

func gendatac(pcl pc, ref byte q)ref byte=
!generate constant data to buffer at q
!return pointer to next location

	case pc.opndtype
	when mem_opnd, memaddr_opnd, label_opnd, string_opnd then
		merror("gendatac/not const")
	esac

	if pc.mode=tpblock then			!block data
		memcpy(q, pc.svalue, pc.size)
	else							!simple
		memcpy(q, &pc.value, pc.size)
	fi

	q+pc.size	
end

proc gendatax(pcl pc, int dataone=0)=
!directly generate data sequence of u64 or addr items to C dest

!	case pc.opndtype
!	when mem_opnd then
!		ccstr(pc.def.name)
!
!	when memaddr_opnd then
!		ccstr("&")
!		ccstr(pc.def.name)
!!	when label_opnd then
!	when int_opnd then
!		ccint(pc.value)
!
!!	when real_opnd then
!!	when r32_opnd then
!	when string_opnd then
!!		ccstr(pc.svalue)
!		ccopnd(pc)
!
!!	when realimm_opnd then
!!	when realimm32_opnd then
!!	when data_opnd then
!	else
!		ccstr(addstr("gendata64:", opndnames[pc.opndtype]))
!	esac
!CCSTR("GDX")

	ccopnd(pc, dataone)

end

global proc genzstaticvar(psymbol d)=
	if d.imported then
		ccstr("extern ")
	elsif not d.exported then
		ccstr("static ")
	fi

	ccstrmode(d.mode, d.size)
	ccstr(" ")
	ccname(d.name)
	ccsemi()
end

global proc genprocdecls=
	cccomment("***** Function Declarations *****")
	psymbol d:=psymboltable
	while d, d:=d.next do
		if d.id=proc_id then
			genprocsig(d)
		fi
	od
	ccstrline("")
end

global proc genmain=
	return when not entryproc
!
	ccstrline("")
	ccstrline("int main(int nargs, char** args) {")
	if pfullsys then
		ccstrline("    msysc_$getcommands(nargs, (u64)args, 0);")
	fi

	ccstr("    ")
	ccname(entryproc.name)
	ccstrline("();\n}\n")
end

global proc pushcc=
	if noperands>=200 then
		cerror("Too many operands?")
	fi
	++noperands
	localmax max:=noperands
end

global proc genloadopnd(pcl pc)=
	[512]char str
	int length

	pushcc()

	cctab()

	case pc.opndtype
	when int_opnd then
		ccstack(zz, pc)
		ccstr(" = ")
		if pc.value=i64.min then
			ccstr("0x8000000000000000")
		else
			ccint(pc.value)
		fi

	when real_opnd, r32_opnd, realimm_opnd, realimm32_opnd then
		cctpcast(pc)
		ccstack(zz, pc)
		if pc.xvalue=infinity then
			print @str,") = (1.0/0.0)"
		else
			fprint @str,") = #", pc.xvalue:"e18.18"
		fi
		ccstr(str)

!	when real32_opnd then
!		sx:=pc.xvalue
!		ccint(u32@(sx))
!
!		fprint @str," /* # */", pc.xvalue:"e8"
!		ccstr(str)

	when string_opnd then
		ccstack(zz, pc)
		ccstr(" = ")
		ccstr("tou64(")
		if (length:=strlen(pc.svalue))<str.len/2 then
			ccstr("""")
			convertstring(pc.svalue,&.str)
			ccstr(str)
			ccstr(""")")
		else
			cclongstr(pc.svalue, length)
			ccstr(")")
		fi

	when mem_opnd then
		cctpcast(pc)
		ccstack(zz, pc)
		ccstr(") = ")
		ccname(pc.def.name)

	when memaddr_opnd then
		ccstack(zz, pc)
		ccstr(" = (u64)&")
		ccname(pc.def.name)

	when label_opnd then
		ccstack(zz, pc)
		ccstr(" = (u64)&&")
		cclabel(pc.labelno)
!
!	when data_opnd then
!		ccstr("<StrData")

	else
!CPL OPNDNAMES[PC.OPNDTYPE]
!		ccstr("<PCLOPND?>")
		CCSTR("<LOADOPND:")
		CCSTR(OPNDNAMES[PC.OPNDTYPE])
		CCSTR(">")
	esac

	ccsemi()
end

global proc genstoreopnd(pcl pc)=
	if noperands<1 then
!		cerror("Opnd stack underflow")
CPL "UNDERFLOW"
CCSTR("UNDERFLOW")
NOPERANDS:=1

	fi

	cctab()

	if pc.opndtype<>mem_opnd then merror("Store?") fi

	ccname(pc.def.name)
	ccstr(" = ")

	cctpcast(pc)
	ccstack(zz, pc)
	ccrb()
	ccsemi()

	popcc()
end

global proc doswap(pcl pc)=
	int mode:=pc.mode
	cctab()
	ccstr("{")
	ccstrmode(mode, pc.size)
	ccstr(" temp; temp = *")
	cccastptr(pc)
	ccstack(yy, pc)
	ccstr("); *")

	cccastptr(pc)
	ccstack(yy, pc)
	ccstr(") = *")
	cccastptr(pc)
	ccstack(zz, pc)
	ccstr("); *")

	cccastptr(pc)
	ccstack(zz, pc)
	ccstrline(") = temp; }")
	popcc()
	popcc()

end

global proc doincrload(pcl pc, ichar opstr)=
	cctab()
	cctpcast(pc)
	ccstack(zz)
	ccstr(") = *(")
	cccastptr(pc)
	ccstack(zz)
	ccstr("))")
	ccstr(opstr)
	ccint(pc.stepx)
	ccsemi()
end

global proc doloadincr(pcl pc, ichar opstr)=
	cctab()
	cctpcast(pc)
	localmax max:=zz+1
	ccstack(zz+1)
	ccstr(") = *")
	cccastptr(pc)
	ccstack(zz)
	ccstr("); *(")

	cccastptr(pc)
	ccstack(zz)
	ccstr("))")
	ccstr(opstr)
	ccint(pc.stepx)
	ccstr("; ")

	cctpcast(pc)
	ccstack(zz)
	ccstr(") = ")
	cctpcast(pc)
	ccstack(zz+1)
	ccstrline(");")

end

global func doswitchstmt(pcl pc)pcl =
	const maxlabels = 1000				!matches do_switch in front-end
	[maxlabels]u32 labtable				!list of unique labels
	[maxlabels]u32 indextable			!indices into labtable
	int swbase, n
	pcl pctab
	int labelse, lab, nlabels, index

	swbase:=pc.minlab
	n:=pc.maxlab-swbase+1
	pctab:=pc+3
	labelse:=(pc+1).labelno
	nlabels:=0							!no. unique labels

!	cpl "SWITCH", =SWBASE, =N, =SWBASE, =LABELSE, =pclnames[pctab.opcode], pctab.labelno

!build labtable/indextable

	for i to n do
		lab:=pctab.labelno
		for k to nlabels do
			if labtable[k]=lab then			!already seen
				index:=k
				exit
			fi
		else
			labtable[++nlabels]:=lab
			index:=nlabels
		od

		indextable[i]:=index
		++pctab
	od

!CPL "LABS:"
!FOR I TO NLABELS DO
!	CPL I,LABTABLE[I]
!OD
!CPL "INDICES:"
!FOR I TO N DO
!	CPL I,INDEXTABLE[I], INDEXTABLE[I]+SWBASE-1
!OD

	cctab()
	ccstr("switch (asi64(")
	ccstack(zz)
	ccstrline(")) {")


	for k to nlabels do
		cctab()

		for i to n when indextable[i]=k do
			ccstr("case ")
			ccint(i+swbase-1)
			ccstr(": ")
		od

		ccstr("goto ")
		cclabel(labtable[k])
		ccsemi()
	od

	cctab()
	ccstr("default: goto ")
	cclabel(labelse)
	ccsemi()

	ccstrline("    };")


!	MERROR("SWITCH")

	CCCOMMENT("SWITCH")


	popcc()

	pc+n+4
end

func getfstype(pcl pc, int nargs)int=
	[maxcallarg]byte args
	int rettype
	pcl p

	for i to nargs do
		p:=callpcmode[ncalldepth, i]
		args[i]:=p.mode
		if p.mode=tpblock then merror("getfs/block") fi
	od
	rettype:=pc.mode
	if rettype=tpblock then merror("getfs/blockr") fi

!now search for existing sig that matches
	for i to nfuncsigs when fsrettype[i]=rettype and fsnargs[i]=nargs do
		for k to nargs do
			if fsargs[i, k]<>args[k] then		!mismatch
				exit
			fi
		else
			return i
		od
	od

!new unique funcsig

	if nfuncsigs>=maxfuncsig then merror("Too many fs") fi
	++nfuncsigs

	fsrettype[nfuncsigs]:=rettype
	fsnargs[nfuncsigs]:=nargs
	for i to nargs do
		fsargs[nfuncsigs, i]:=args[i]
	od

	nfuncsigs
end

global proc genfuncsigs(int coffsetf)=
	int coffsetg:=cdest.length, nargs

	cccomment("Function Ptr Types:")
	for i to nfuncsigs do
		ccstr("typedef ")
		ccstrmode(fsrettype[i])
		ccstr(" (*F")
		ccint(i)
		ccstr(")(")
		nargs:=fsnargs[i]
		for k to nargs do
			ccstrmode(fsargs[i,k])
			if k<nargs then ccstr(", ") fi
		od
		ccstrline(");")
	od 
	ccstrline("")
!	ccstrline("FUNTAB1")
!	ccstrline("FUNTAB2")
!	ccstrline("FUNTAB3")

	ccswap(coffsetf, coffsetg)

end

global proc cclongstr(ichar s, int length)=
	if longstring then
		pcm_free(longstring,longstringlen)
	fi
	longstringlen:=length*2
	longstring:=pcm_alloc(longstringlen)
	longstring^:='"'
!	longstring^:='<'
	length:=convertstring(s, longstring+1)
	(longstring+length+1)^:='"'
	(longstring+length+2)^:=0

	clineptr^:=0
	gs_str(cdest,&.clinebuffer)
	ccinitline()
	gs_str(cdest,longstring)
end

global func geninitdoswx(pcl pc)pcl =
	int jtlabel
	pcl q, pcjumptab
	byte first:=1

!	CCSTRLINE("DOSWX INIT")
	++pc						!point to load #jumptab
	jtlabel:=pc.labelno

	pcjumptab:=pc+1
	repeat
		++pcjumptab
	until pcjumptab.opcode=klabel and pcjumptab.labelno=jtlabel
	++PCJUMPTAB

!CPL "FOUND PC JT:", PCJUMPTAB, PCLNAMES[PCJUMPTAB.OPCODE]

!Need to output local doswitchx jumptable
	ccstr("    static void* $jumptable[] = {")

	while pcjumptab.opcode=kswlabel do
		if not first then ccstr(", ") else first:=0 fi
		ccstr("&&L")
		ccint(pcjumptab.labelno)
		++pcjumptab
	od
	ccstrline("};")

!do the load here, using this special jumptable, and skip the instr
	pushcc()
	ccstrline("    R1 = (u64)$jumptable;")

	pc
end
