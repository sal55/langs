global const cbufferlen=4096				!needs to be same size as exprbuffer
global [cbufferlen]char clinebuffer
global ref char clineptr, clineend

export const ctarget=1
export ichar asmext="c"

strbuffer sbuffer
global ref strbuffer cdest=&sbuffer

const maxblocktypes=200
global [maxblocktypes]int blocksizes		!total bytes size
global [maxblocktypes]int blocklengths		!array length
global [maxblocktypes]int blockelemsizes	!array element size
!global [maxblocktypes]byte blockflags		!1 during a proc means a block stack slot needed
global int nblocktypes

global proc cccomment(ichar s=nil)=
!comment that is appended to current line
	ccstr("// ")
	ccstrline(s)
end

global proc ccblank=
	ccsendline()
end

global proc cclinecomment(ichar s)=
	cccomment(s)
end

global proc ccchar(int c)=
	clineptr^:=c
	++clineptr
end

global proc cctab=
	clineptr++^:='\t'
end

global proc ccstr(ref char s)=
	while s^ do
		clineptr++^:=s++^
	od
end

global proc ccname(ref char s)=
	int c

	while c:=s++^ do
		if c='.' then
			clineptr++^:='_'
		else
			clineptr++^:=c
		fi
	od
end

global function xxstrname(ichar s)ichar=
	static [256]char str
	int c
	ichar t:=str

	while c:=s++^ do
		if c='.' then
			t++^:='_'
		else
			t++^:=c
		fi
	od
	t^:=0
	return str
end


global proc ccstrline(ichar cstr)=
	ccstr(cstr)
	ccsendline()
end

global proc ccsemi=
	ccchar(';')

!	ccstr("   // ")
!	ccint(noperands)

	ccsendline()
end

global proc ccstrsemi(ichar cstr)=
	ccstr(cstr)
	ccchar(';')
	ccsendline()
end

global proc ccsendline=
	clineptr^:=0
	gs_strln(cdest,&.clinebuffer)
	ccinitline()
end

global proc ccint(int a)=
	ccstr(strint(a))
end

global proc ccinitline=
	clineptr:=&.clinebuffer
	clineend:=clineptr+cbufferlen-1
end

global proc ccopnd(pcl p, int dataone=0)=
	[512]char str
	int length, t
	r32 sx
	ref u64 q

	t:=p.mode

!CPL "CCOPND", OPNDNAMES[P.OPNDTYPE]
!CCSTR("<CCOPND>")


	case p.opndtype
	when int_opnd then
		ccint(p.value)
	when real_opnd, r32_opnd, realimm_opnd, realimm32_opnd then
!CCSTR("<CCOPND/REAL>")
		if dataone then
			print @str,p.xvalue:"e18.18"
		else
			ccint(u64@(p.xvalue))
			fprint @str," /* # */", p.xvalue:"e16"
		fi
		ccstr(str)

!	when real32_opnd then
!		sx:=p.xvalue
!		ccint(u32@(sx))
!
!		fprint @str," /* # */", p.xvalue:"e8"
!		ccstr(str)

	when string_opnd then
		ccstr("(u64)")
		if (length:=strlen(p.svalue))<str.len/2 then
			ccstr("""")
			convertstring(p.svalue,&.str)
			ccstr(str)
			ccstr("""")
		else
			cclongstr(p.svalue, length)
!			CCSTR("CCOPND)")
		fi

	when mem_opnd then
		ccname(p.def.name)

	when memaddr_opnd then
		ccstr("(u64)&")
		ccname(p.def.name)

	when label_opnd then
		cclabel(p.labelno)

	when data_opnd then
		if p.size=8 then			!suspect only 64-bit data strs get through to here
			q:=cast(p.svalue)
			ccint(q^)
		else
			CPL "CCOPND/STRDATA"
			ccstr("<StrData>")
		fi

	else
		CCSTR("<CCOPNDXXX:")
		CCSTR(OPNDNAMES[P.OPNDTYPE])
		CCSTR(">")
	esac
end

global function getaddrmode(int scale, offset)ichar=
!Xb and Ya on stack (2 and 1) should be a pointer, and an offset
!return an address mode like (Xb+Ya*scale+offset), with casts to byte pointers etc
	static [256]char str

	fprint @str,"((char*)S#+S#*#",yy, zz, scale

	if offset>0 then
		strcat(str,"+")
		strcat(str,strint(offset))
	elsif offset<0 then
		strcat(str,strint(offset))
	fi
	strcat(str,")")
	return str
end

global proc cclabel(int labelno)=
	ccstr("L")
	ccint(labelno)
end

global proc cerror(ichar mess, param=nil)=
	print "C Gen error:",mess
	if param then
		print ":",param
	fi

	println " seq:",ppseqno
	println
	stop 1
end

global proc popcc=
	if noperands<=0 then
CCSTRLINE("\N//POPCC ON EMPTY STACK")
	else
		--noperands
	fi
end

export func getassemstr:ref strbuffer=
	return cdest
end

global func getcondstr(int cc)ichar=
	case cc
	when eq_cc then " == "
	when ne_cc then " != "
	when lt_cc then " < "
	when le_cc then " <= "
	when ge_cc then " >= "
	else            " > "
	esac
end

global proc ccstack(int n, pcl pc=nil)=
	[32]char str
	int t

	if n<1 then
CPL "UNDERFLOW",N
		ccstr("$UNDERFLOW")
	elsif pc=nil or pc.size in [0, 1,2,4,8] then
		ccstr("R")
		ccint(n)

	else		
!		t:=findblocktype(pc.size, 1)
		t:=findblocktype(pc.size, 0)
		addlocaltemp(n, t)
!		blockflags[t]:=1
		fprint @str, "R#_B#", n, t
		ccstr(str)
	fi
end

global proc cctpcast(pcl pc)=
!type punning cast
!caller must provide closing ")" after operand
	if pc.mode<>tpblock then
		ccstr("as")
		ccstrmode(pc.mode, pc.size)
	fi
	ccstr("(")
end


!global proc ccconv(pcl pc)=
!!type conversion cast
!!caller must provide closing ")" after operand
!	if pc.mode<>tpblock then
!		ccstr("to")
!		ccstrmode(pc.mode, pc.size)
!		ccstr("(")
!	fi
!end
!
global proc cctpcastm(int mode)=
!type punning cast
!	if pc.mode<>tpblock then
	ccstr("as")
	ccstrmode(mode)
	ccstr("(")
end

global proc cccastm(int mode)=
	ccstr("to")
	ccstrmode(mode)
	ccstr("(")
end

global proc cccastptr(pcl pc)=
	if pc.mode<>tpblock then
		ccstr("to")
		ccstrmode(pc.mode)
		ccstr("p(")
	else
!		ccstr("*(")
		ccstr("(")
		ccstrmode(pc.mode, pc.size)
		ccstr("*)(")
	fi
end

global proc cccastptrm(int mode)=
IF MODE=TPBLOCK THEN MERROR("CASTPTRM/BLOCK") FI
	ccstr("to")
	ccstrmode(mode)
	ccstr("p(")
end

global proc ccstrmode(int mode, int size=0)=
!write only c version  of mode (may depend on header defining these types
	int t

	case mode
	when tpblock then
		t:=findblocktype(size, 0)
		if t=0 then
!CPL =SIZE
!CPL =NBLOCKTYPES
!FOR I TO NBLOCKTYPES DO
!	CPL "	",I,=BLOCKSIZES[I], =BLOCKLENGTHS[I],=BLOCKELEMSIZES[I]
!OD
!CPL "CAN'T FIND BLOCK TYPE", SIZE
!CCSTR("<CAN'T FIND BLOCK TYPE>")
!STOP
!RETURN

			merror("Can't find block type")
		fi
		ccstr("struct $B")
		ccint(t)
	when tpvoid then
		ccstr("void")
	else
		ccstr(strpmode(mode))
	esac
end

global func findblocktype(int size, add=0)int=
!add=1 to create new block type if not found
	int elemsize

!CPL "FINDBLOCK1", =SIZE
	if size=0 then size:=1 fi

	elemsize:=1

	if size iand 7 = 0 then
		elemsize:=8
	elsif size iand 3 = 0 then
		elemsize:=4
	elsif size iand 1 = 0 then
		elemsize:=2
	fi

!CPL =ELEMSIZE

	for i to nblocktypes do
		if blocksizes[i]=size then
			return i
		fi
	od

	if add then
		newblocktype(size, elemsize)
	else
		0
	fi
end

global func newblocktype(int size, elemsize)int =
!only call when block of that size does not exist
	if nblocktypes>=maxblocktypes then
		merror("Too many blocks")
	fi
	++nblocktypes
	blocksizes[nblocktypes]:=size
	blocklengths[nblocktypes]:=size/elemsize
	blockelemsizes[nblocktypes]:=elemsize

!CPL "**********NEW BLOCK:",SIZE, ELEMSIZE

	nblocktypes
end

global proc doshowpcl(pcl p)=
	[1256]char str

	case p.opcode
	when kproc, ktcproc, kretproc, kendproc, kistatic, kzstatic, kdata then
	else
		strcpy(&.str,"                       ")
		strcat(&.str,strpclstr(p, str.len))
		cccomment(pcm_copyheapstring(str))
	esac
end

global proc cceq=
	ccstr(" = ")
end

global proc ccrb=
	ccstr(")")
end

global proc ccinsert(int offseta, ichar s)=
!writes s to cdest at B (current end), but then moves it to given offset A
	int length
	int offsetb, size
	ichar destptr, buffer

	destptr:=cdest.strptr
	offsetb:=cdest.length
	size:=offsetb-offseta			!bytes to move
	length:=strlen(s)
	buffer:=pcm_alloc(size)

	if size=0 then merror("CCINS") fi

	memcpy(buffer, destptr+offseta, size)					!copy body to buffer

	gs_str(cdest, s)			!write temporarily to end 

	memcpy(destptr+offseta, destptr+offsetb, length)		!copy new str to A
	memcpy(destptr+offseta+length, buffer, size)			!copy body back, but further up
end

global proc ccswap(int offseta, offsetb)=
!Cdest buffer contains text A from offseta to offsetb-1, and text B
!from offsetb to end of buffer
!Swap text A and text B:
! Copy A to buffer
! Copy B to offseta
! Copy A in buffer to offseta+B.len

	int alen, blen
	ichar destptr, buffer

	destptr:=cdest.strptr

	alen:=offsetb-offseta
	blen:=cdest.length-offsetb

	if alen=0 or blen=0 then merror("CCINS") fi

	buffer:=pcm_alloc(alen)

	memcpy(buffer, destptr+offseta, alen)				!A to buffer
	memcpy(destptr+offseta, destptr+offsetb, blen)		!B to A's old offset
	memcpy(destptr+offseta+blen, buffer, alen)			!A to A's old offset + B.len

	pcm_free(buffer, alen)
end

global func addlocaltemp(int stackno, blockno)int=
	for i to nlocaltemps do
		if ltstackno[i]=stackno and ltblockno[i]=blockno then
			return i
		fi
	od
	++nlocaltemps
	if nlocaltemps>=maxlocaltemps then merror("Too many localtemps") fi
	ltstackno[nlocaltemps]:=stackno
	ltblockno[nlocaltemps]:=blockno
	nlocaltemps
end
