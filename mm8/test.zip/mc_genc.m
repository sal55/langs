!const showpclcode=1
const showpclcode=0

!global const maxoperands=20

global const maxcalldepth=16
global const maxcallarg=20
global [maxcalldepth]byte callalign		!pending 1-slot alignment for syscalls
global [maxcalldepth]byte callblockret	!1 if fnc returns a block
global [maxcalldepth]u32 callblocksize	!size of any returned block
global [maxcalldepth, maxcallarg]pcl callpcmode			!get mode/size
global int ncalldepth

global int noperands

global macro zz = noperands
global macro yy = noperands-1
global macro xx = noperands-2
global macro ww = noperands-3

pcl currpcl, nextpcl

global int localmax				!max operands in this function

!the following is a list of unique stackno/blocktype combinations used in this function

global const maxlocaltemps = 100		!max local block temps
global int nlocaltemps					!how many unique ones used in this function
global [maxlocaltemps]i16 ltstackno		!stack number for this temp
global [maxlocaltemps]i16 ltblockno		!block type code


!global const int maxcallargs=20
!global const int maxnestedcall=10
!global [maxnestedcall, maxcallargs]byte argmodes
!global [maxnestedcall, maxcallargs]byte argstack
!global [maxnestedcall, maxcallargs]u32  argsizes
!global int nccalldepth

int seqno

global proc genmcl=
	pcl pc
	int coffsetf

	return when mcldone

!CPL "GEN LINEAR C", ENTRYPROC

	filehandle f

	gs_init(cdest)
	ccinitline()
!
!	cccomment("Generated C")

!ICHAR S:=SINCLUDE(".\\pclhdr.h")

!	ccstrline("#include ""pclhdr.h""")
	ccstrline(strinclude("pclhdr.hdr"))

	ccstrline("/*")
	ccstrline("PROC START")
	ccstrline("*/")

	if entryproc then
		ccstr("void "); ccname(entryproc.name); ccstrline("();")
		ccstr("void (*entrypoint)(void) = ")
		ccname(entryproc.name)
		ccsemi()	
	fi

	gs_line(cdest)



	gentypes(pcstart)
	coffsetf:=cdest.length			!funcsig table goes here

	genvars()
	genimports()
	genprocdecls()
	genmain()
!
	pc:=pcstart
	noperands:=localmax:=0

	cccomment("*"*50)

	while pc<=pccurr do
		seqno:=pc.seqno
		pc:=convertpcl(pc)			!update pc to next; more than one pclrec may be consumed
	od

!	if noperands then
!		CPL("End prog: stack not empty")
!	fi

	genfuncsigs(coffsetf)

!	gs_strln(cdest,"#include ""pcllib.h""")
	gs_strln(cdest,strinclude("pcllib.hdr"))
	cccomment("End of C Code")

	mcldone:=1

end

func convertpcl(pcl p)pcl =
!	[1256]char str
!	ichar ss
	int m

	if showpclcode then
		doshowpcl(p)
!!		ccstr("//                   ")
!		ccstr("                   //")
!		ccint(noperands)
!		ccstr(": ")
!		ccstrline(strpclstr(p))
!		ccstrline("")
	fi

	dopcl(p)
end

proc unimpl(pcl pc)=
CPL "UNIMPL", PCLNAMES[PC.OPCODE]
	CCSTR("\N//UNIMPL:")
	CCSTRLINE(PCLNAMES[PC.OPCODE])

!	merror("Unimpl:",pclnames[pc.opcode])
end

func dopcl(pcl pc)pcl =
	psymbol d
!	static psymbol currfunc

!CPL "DOPCL", PCLNAMES[PC.OPCODE],=PC.SEQNO

	switch pc.opcode
	when knop      then
!		unimpl(pc)

	when kload     then
		genloadopnd(pc)

	when kiload    then
		cctab()
		cctpcast(pc)
		ccstack(zz, pc)
		ccrb()
		ccstr(" = *")
		cccastptr(pc)
!		ccstack(zz, pc)
		ccstack(zz)
		ccrb()
		ccsemi()

	when kiloadx   then
		cctab()
		cctpcast(pc)
		ccstack(yy, pc)
		ccrb()
		ccstr(" = *")
		cccastptr(pc)
		ccstr("((i64)")
		ccstack(yy)
		ccstr("+(i64)")
		ccstack(zz)
		if pc.scale>1 then
			ccstr("*")
			ccint(pc.scale)
		fi
		if pc.extra then
			if pc.extra>0 then ccstr("+") fi
			ccint(pc.extra)
		fi
		ccstr("))")
		ccsemi()
		popcc()

	when kstore    then
		genstoreopnd(pc)

	when kistore   then
		cctab()
		ccstr("*")
		cccastptr(pc)
		ccstack(zz)
		ccrb()
		cceq()
		cctpcast(pc)
		ccstack(yy, pc)
		ccrb()
		ccsemi()
		popcc()
		popcc()

	when kistorex  then
		cctab()
		ccstr("*")
!		cccastptrm(pc.mode)
		cccastptr(pc)
		ccstr("((i64)")
		ccstack(yy)
		ccstr("+(i64)")
		ccstack(zz)
		if pc.scale>1 then
			ccstr("*")
			ccint(pc.scale)
		fi
		if pc.extra then
			if pc.extra>0 then ccstr("+") fi
			ccint(pc.extra)
		fi
		ccstr(")) = ")
		cctpcast(pc)
		ccstack(xx, pc)
		ccrb()
		ccsemi()
		popcc()
		popcc()
		popcc()

	when kstorem   then
		unimpl(pc)

	when kdupl, kdouble     then
		pushcc()
		cctab()
		ccstack(zz)
		cceq()
		ccstack(yy)
		ccsemi()

	when kswapstk  then
		ccstr("    {u64 temp = ");
		ccstack(yy)
		ccstr("; ")
		ccstack(yy)
		ccstr(" = ")
		ccstack(zz)
		ccstr("; ")
		ccstack(zz)
		ccstrline(" = temp;}")

	when kunload   then
		popcc()

	when kopnd     then
		unimpl(pc)

	when ktype     then
		unimpl(pc)

	when kloadbit  then
		ccstr("    asi64(")
		ccstack(yy)
		ccstr(") = Getdotindex(asu64(")
		ccstack(yy)
		ccstr("), asi64(")
		ccstack(zz)
		ccstrline("));")
		popcc()

	when kloadbf   then
		ccstr("    asi64(")
		ccstack(xx)
		ccstr(") = Getdotslice((u64)")
		ccstack(xx)
		ccstr(", (i64)")
		ccstack(yy)
		ccstr(", (i64)")
		ccstack(zz)
		ccstrline(");")
		popcc()
		popcc()

	when kstorebit then
		ccstr("    *toi64p(")
		ccstack(yy)
		ccstr(") = Setdotindex(*toi64p(")
		ccstack(yy)
		ccstr("), (i64)")
		ccstack(zz)
		ccstr(", (i64)")
		ccstack(xx)
		ccstrline(");")
		popcc()
		popcc()
		popcc()

	when kstorebf  then
		ccstr("    *toi64p(")
		ccstack(xx)
		ccstr(") = Setdotslice(*toi64p(")
		ccstack(xx)
		ccstr("), (i64)")
		ccstack(yy)
		ccstr(", (i64)")
		ccstack(zz)
		ccstr(", (i64)")
		ccstack(ww)
		ccstrline(");")
		popcc()
		popcc()
		popcc()
		popcc()

	when kcallp    then
		docall(pc, isfunc:0, isptr:0)
		--ncalldepth

	when kicallp   then
		docall(pc, isfunc:0, isptr:1)
		--ncalldepth

	when kretproc  then
		cctab()
		ccstr("return")
		ccsemi()

	when kcallf    then
		docall(pc, isfunc:1, isptr:0)
		--ncalldepth

	when kicallf   then
		docall(pc, isfunc:1, isptr:1)
		--ncalldepth

	when kretfn    then
		cctab()
		ccstr("return ")
		cctpcast(pc)
		ccstack(1, pc)
		ccrb()
		ccsemi()

	when kjump     then
dojump:
		cctab()
		ccstr("goto ")
		cclabel(pc.labelno)
		ccsemi()

	when kijump    then
		cctab()
		ccstr("{void* p=(void*)")
		ccstack(zz)
		ccstrline("; goto *p;}")
		popcc()

	when kjumpcc   then
		dojumpcc(pc)

	when kjumpt, kjumpf then
		dojumptf(pc)

	when kjumpret  then
		if pc.mode then
			popcc()
		fi
		goto dojump

	when kjumpretm then
		unimpl(pc)

	when ksetcc    then
		cctab()
		cctpcastm(tpi64)
		ccstack(yy)
		ccstr(") = ")

		cctpcast(pc)
		ccstack(yy)
		ccstr(") ")
		ccstr(getcondstr(pc.condcode))
		ccstr(" ")
		cctpcast(pc)
		ccstack(zz)
		ccrb()
		popcc()
		ccsemi()

	when kstop     then
		cctab()
		ccstr("exit(")
		ccstack(zz, pc)
		ccstr(")")
		popcc()
		ccsemi()

	when kto       then
		cctab()
		ccstr("if (--")
		cctpcastm(tpi64)
		ccopnd(pc+1)
		ccrb()
		ccstr(") goto ")
		ccopnd(pc)
		ccsemi()
		++pc

	when kforup, kfordown    then
		dofor(pc)
		pc+:=2

	when kiswap    then
		doswap(pc)

	when kswitch   then
		pc:=doswitchstmt(pc)-1

	when kswitchu  then
		unimpl(pc)

	when kswlabel  then
!		unimpl(pc)

	when kendsw    then
!		unimpl(pc)

	when kclear    then
		cctab()
		ccstr("memset(")
!		cctpcast(pc)
		ccstack(zz)
		ccstr(", 0, ")
		ccint(pc.size)
		ccstrline(");")
		popcc()

	when kassem    then
		unimpl(pc)

	when kadd      then
		dobinop(pc, "+")

	when ksub      then
		dobinop(pc, "-")

	when kmul      then
		dobinop(pc, "*")

	when kdiv      then
		dobinop(pc, "/")

	when kidiv     then
		dobinop(pc, "/")

	when kirem     then
		dobinop(pc, "%")

	when kidivrem  then
		unimpl(pc)

	when kbitand   then
		dobinop(pc, "&")

	when kbitor    then
		dobinop(pc, "|")

	when kbitxor   then
		dobinop(pc, "^")

	when kshl      then
		dobinop(pc, "<<")

	when kshr      then
		dobinop(pc, ">>")

	when kmin      then
		cctab()
		cctpcast(pc)
		ccstack(yy)
		ccstr(") = Min(")
		cctpcast(pc)
		ccstack(yy)
		ccstr("), ")
		cctpcast(pc)
		ccstack(zz)
		ccstrline("));")
		popcc()

	when kmax      then
		cctab()
		cctpcast(pc)
		ccstack(yy)
		ccstr(") = Max(")
		cctpcast(pc)
		ccstack(yy)
		ccstr("), ")
		cctpcast(pc)
		ccstack(zz)
		ccstrline("));")
		popcc()

	when kaddpx, ksubpx    then
		cctab()
		ccstack(yy)
		ccstr((pc.opcode=kaddpx|" += (i64)"|" -= (i64)"))
		ccstack(zz)
		if pc.scale>1 then
			ccstr("*")
			ccint(pc.scale)
		fi
		if pc.extra then
			if pc.extra>=0 then ccstr("+") fi
!			ccstr("+")
			ccint(pc.extra)
		fi
		ccsemi()
		popcc()

	when ksubp     then
		dobinop(pc, "-")
		if pc.scale>1 then
			ccstr("    asi64(")
			ccstack(zz)					!this is zz'
			ccstr(") /= ")
			ccint(pc.scale)
			ccsemi()
		fi

	when kneg      then
		dounaryop(pc, "-")

	when kabs      then
		doabs(pc)

	when kbitnot   then
		dounaryop(pc, "~")

	when knot      then
		dounaryop(pc, "!")

	when ktoboolt  then
		cctab()
		cctpcast(pc)
		ccstack(zz)
		ccstr(") = !!")
		cctpcastm(pc.mode2)
		ccstack(zz)
		ccstrline(");")

	when ktoboolf  then
		cctab()
		cctpcast(pc)
		ccstack(zz)
		ccstr(") = !")
		cctpcastm(pc.mode2)
		ccstack(zz)
		ccstrline(");")

	when ksqr      then
		cctab()
		cctpcast(pc)
		ccstack(zz)
		ccstr(") *= ")
		cctpcast(pc)
		ccstack(zz)
		ccrb()
		ccsemi()

	when ksqrt     then
		domathsop(pc, "sqrt")

	when ksin      then
		domathsop(pc, "sin")

	when kcos      then
		domathsop(pc, "cos")

	when ktan      then
		domathsop(pc, "tan")

	when kasin     then
		domathsop(pc, "asin")

	when kacos     then
		domathsop(pc, "acos")

	when katan     then
		domathsop(pc, "atan")

	when klog      then
		domathsop(pc, "log")

	when klog10    then
		domathsop(pc, "log10")

	when kexp      then
		domathsop(pc, "exp")

	when kround    then
!		domathsop(pc, "round")
		unimpl(pc)

	when kfloor    then
		domathsop(pc, "floor")

	when kceil     then
		domathsop(pc, "ceil")

	when ksign     then
		unimpl(pc)

	when katan2    then
		domaths2op(pc, "atan2")

	when kpower    then
		case pc.mode
		when tpr64 then
			domaths2op(pc, "pow")
		when tpi64 then
			domaths2op(pc, "Poweri64")
		else
			merror("Power?")
		esac

	when kfmod     then
		domaths2op(pc, "fmod")

	when kincrto, kdecrto   then
		cctab()
		ccstr("(*")
		cccastptrm(pc.mode)
		ccstack(zz)
		ccstr((pc.opcode=kincrto|")) += "|")) -="))
		ccint(pc.stepx)
		ccsemi()
		popcc()

	when kincrload then
		doincrload(pc, " += ")

	when kdecrload then
		doincrload(pc, " -= ")

	when kloadincr then
		doloadincr(pc, " += ")

	when kloaddecr then
		doloadincr(pc, " -= ")

	when kaddto    then
		dobinopto(pc, "+")

	when ksubto    then
		dobinopto(pc, "-")

	when kmulto    then
		dobinopto(pc, "*")

	when kdivto, kidivto    then
		dobinopto(pc, "/")

	when kiremto   then
		dobinopto(pc, "%")

	when kbitandto then
		dobinopto(pc, "&")

	when kbitorto  then
		dobinopto(pc, "|")

	when kbitxorto then
		dobinopto(pc, "^")

	when kshlto    then
		dobinopto(pc, "<<")

	when kshrto    then
		dobinopto(pc, ">>")

	when kminto    then
		ccstr("    *")
		cccastptr(pc)
		ccstack(zz)
		ccstr(") = Min(*")
		cccastptr(pc)
		ccstack(zz)
		ccstr("), ")
		cctpcast(pc)
		ccstack(yy)
		ccstrline("));")
		popcc()
		popcc()

	when kmaxto    then
		ccstr("    *")
		cccastptr(pc)
		ccstack(zz)
		ccstr(") = Max(*")
		cccastptr(pc)
		ccstack(zz)
		ccstr("), ")
		cctpcast(pc)
		ccstack(yy)
		ccstrline("));")
		popcc()
		popcc()

	when kaddpxto  then
		dobinopto(pc, "+", pc.scale)

	when ksubpxto  then
		dobinopto(pc, "-", pc.scale)

	when knegto    then
		unimpl(pc)

	when kabsto    then
		unimpl(pc)

	when kbitnotto then
		unimpl(pc)

	when knotto    then
		unimpl(pc)

	when ktoboolto then
		unimpl(pc)

	when ktypepun  then
		cctab()
		cctpcastm(pc.mode)
		ccstack(zz)
		ccstr(") = ")
		cctpcastm(pc.mode)
		ccstack(zz)
		ccstrline(");")

	when kfloat    then
		cctab()
		cctpcast(pc)
		ccstack(zz)
		ccrb()
		cceq()
		cccastm(pc.mode)
		cctpcastm(pc.mode2)
		ccstack(zz)
		ccrb()
		ccrb()
		ccsemi()

	when kfix      then
		cctab()
		ccstack(zz)
		cceq()
		cccastm(pc.mode)
		cctpcastm(pc.mode2)
		ccstack(zz)
		ccrb()
		ccrb()
		ccsemi()

	when ktruncate then
		cctab()
		cctpcastm(pc.mode)
		ccstack(zz)
		ccstr(") = ")
		cccastm(pc.mode)
		cccastm(pc.mode2)
		ccstack(zz)
		ccstrline("));")

	when kwiden    then
		cctab()
		ccstack(zz)
		cceq()
		cccastm(pc.mode)
		cccastm(pc.mode2)
		ccstack(zz)
		ccrb()
		ccrb()
		ccsemi()

	when kfwiden   then
		ccstr("    asr64(")
		ccstack(zz)
		ccstr(") = tor64(asr32(")
		ccstack(zz)
		ccstrline("));")

	when kfnarrow  then
		ccstr("    asr32(")
		ccstack(zz)
		ccstr(") = tor32(asr64(")
		ccstack(zz)
		ccstrline("));")

	when kstartmx  then
!		unimpl(pc)

	when kresetmx  then
		popcc()

	when kendmx    then
!		unimpl(pc)

	when kproc     then
		currfunc:=pc.def
		doprocdef(pc)

	when ktcproc   then
		unimpl(pc)

	when kendproc  then
		doendproc(pc)
		ccstrline("}\n")

	when kistatic  then
		d:=pc.def
		if d.cprocowner=nil then
!CPL "ISTATIC IN CODE", D.NAME
!CCCOMMENT("STATIC INCODE")
			pc:=genistaticvar(pc, 0)
		else


			cccomment(addstr("Istatic skipped:", d.name))
			repeat ++pc until pc.opcode<>kdata

		fi
		ccstrline("")
		--pc				!offset ++pc used at end

	when kzstatic  then
		genzstaticvar(pc.def)

	when kdata     then
		ccopnd(pc)
		ccsemi()

	when klabel    then
		cclabel(pc.labelno)
!		ccstrline(":;")
		ccstrline(":")

	when klabeldef then
		ccstr("// ")
		ccstr(pc.def.name)
		ccstrline(":")

	when ksetjmp   then
		unimpl(pc)

	when klongjmp  then
		unimpl(pc)

	when ksetcall  then
		if ncalldepth>=maxcalldepth then
			merror("Too many nested calls")
		fi

		++ncalldepth

		callblockret[ncalldepth]:=pc.mode=tpblock
		callblocksize[ncalldepth]:=pc.size

	when ksetarg   then
		callpcmode[ncalldepth, pc.x]:=pc

	when kloadall  then
		unimpl(pc)

	when keval     then
		popcc()

	when kcomment  then
!		unimpl(pc)

	when kendprog  then
!		unimpl(pc)

	when kparam    then
		unimpl(pc)

	when klocal    then
		unimpl(pc)

	when krettype  then
		unimpl(pc)

	when kvariadic then
		unimpl(pc)

	when kaddlib   then
		unimpl(pc)

	when kextproc  then
		unimpl(pc)

	when kinitdswx then
		pc:=geninitdoswx(pc)

	else
		merror("dopcl?")
	end


	++pc

	return pc				!usually return next or last following multiple pcs

end

