global function getpsymbol(symbol d)psymbol p=
	symbol e
	[256]char str
	[16]symbol chain
	int n

	return nil when d=nil

	if d.pdef then return d.pdef fi

	if d.atvar and d.equivvar then
		getpsymbol(e:=getequivdef(d))
		d.pdef:=e.pdef
		return e.pdef
	fi

	if d.nameid in [frameid, paramid] or d.isimport then
		strcpy(str, (d.truename|d.truename|d.name))
	else
		e:=d
		n:=0
		repeat
			chain[++n]:=e
			e:=e.owner
		until e=nil or e.nameid=programid

		strcpy(str,chain[n].name)
		for i:=n-1 downto 1 do
			strcat(str,".")
			if chain[i].truename then
				strcat(str,chain[i].truename)
			else
				strcat(str,chain[i].name)
			fi
		od
	fi

	d.pdef:=p:=pc_makesymbol(str, name2pid[d.nameid])

	p.mode:=getpclmode(d.mode)

	p.size:=ttsize[d.mode]

	if d.owner and d.owner.owner then
		p.owner:=getpsymbol(d.owner)
	fi

	if d.scope=export_scope then p.exported:=1 fi
	if d.nameid in [dllprocid, dllvarid] then p.imported:=1 fi
	p.used:=d.used
	p.labelno:=d.index
	p.ishandler:=d.ishandler
	p.isthreaded:=d.isthreaded

	p.varparams:=d.varparams

	e:=d.owner
	if ctarget and d.nameid=staticid and e and e.nameid=procid and d.code then
!CPL "GETPS/STATIC VAR", D.NAME, E.PDEF.CHASSTATICS
		p.cprocowner:=e.pdef
		e.pdef.chasstatics:=1
!		p.pcdata:=cast(123456)
	fi

	return p
end

global proc setmode(int mode)=
	pc_setmode(getpclmode(mode), ttsize[mode])
end

global proc setmode2(int mode)=
	pc_setmode2(getpclmode(mode))
end

global proc setmode_u(unit p)=
	int mode:=p.mode

	pc_setmode(getpclmode(mode), ttsize[mode])
end

func getequivdef(symbol d)symbol=
!assume that d.atvar/d.equivvar are set
	unit p

	p:=d.equivvar
	case p.tag
	when jname then
		p.def
	when jconvert then
		p.a.def			!assume points to name
	else
		gerror("geteqv")
		nil
	esac
end
