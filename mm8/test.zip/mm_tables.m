!include "mm_types.m"

global enumdata  [0:]ichar stdnames,
        [0:]byte stdsize,
        [0:]byte stdpcl =

!    type         name       bits     pcl
    (tvoid=0,     "void",       0,    tpvoid),

    (tr64,        "r64",        8,    tpr64),
    (tr32,        "r32",        4,    tpr32),
    (ti64,        "i64",        8,    tpi64),
    (tu64,        "u64",        8,    tpu64),
    (tc64,        "c64",        8,    tpu64),

    (tbool64,     "bool64",     8,    tu64),

    (tref,        "ref",        8,    tpu64),
    (trecord,     "rec",        0,    tpblock),
    (trange,      "range",     16,    tpblock),

    (tarray,      "array",       0,   tpblock),
    (tslice,      "slice",      16,   tpblock),

    (tc8,         "c8",          1,   tpu8),
    (tbool8,      "b8",          1,   tpu8),
    (ti8,         "i8",          1,   tpi8),
    (ti16,        "i16",         2,   tpi16),
    (ti32,        "i32",         4,   tpi32),
    (tu8,         "u8",          1,   tpu8),
    (tu16,        "u16",         2,   tpu16),
    (tu32,        "u32",         4,   tpu32),

    (trefchar,    "ichar",       8,   tpu64),
    (trefbit,     "refbit",     16,   tpu64),

    (tauto,       "auto",        0,   tpu64),
    (tany,        "any",         0,   tpu64),
    (tproc,       "proc",        0,   tpu64),
    (tlabel,      "label",       0,   tpu64),
    (ttype,       "type",        8,   tpu64),
    (tbitfield,   "bitfl",       8,   tpu64),
    (ttuple,      "tuple",       0,   tpu64),
    (tpending,    "pend",        0,   tpu64),
    (tblock,      "block",       8,   tpblock),

    (tlast,       "last ",       0,   tpvoid),
end

global const tuser	= tlast

global const tint	= ti64
global const tword	= tu64
global const treal	= tr64
global const tbool	= tbool64

global const tfirstnum	= tr64
global const tlastnum	= tc64

global const tfirstshort	= tc8
global const tlastshort		= tu32

global const maxtuplesize = 4

global int trefproc
global int treflabel



global enumdata []ichar sysfnnames, []byte sysfnparams, []byte sysfnres =
	(sf_init,				$,	0,	0),
	(sf_print_startfile,	$,	0,	0),
	(sf_print_startstr,		$,	0,	0),
	(sf_print_startptr,		$,	0,	0),
	(sf_print_startcon,		$,	0,	0),
	(sf_print_setfmt,		$,	0,	0),
	(sf_print_nogap,		$,	0,	0),
	(sf_print_space,		$,	0,	0),
	(sf_print_i64,			$,	0,	0),
	(sf_print_i64_nf,		$,	0,	0),
	(sf_print_u64,			$,	0,	0),
	(sf_print_r64,			$,	0,	0),
	(sf_print_r32,			$,	0,	0),
	(sf_print_str,			$,	0,	0),
	(sf_print_str_nf,		$,	0,	0),
	(sf_print_strsl,		$,	0,	0),
	(sf_print_ptr,			$,	0,	0),
	(sf_print_ptr_nf,		$,	0,	0),
	(sf_print_c8,			$,	0,	0),
	(sf_print_bool,			$,	0,	0),
!	(sf_print_var,			$,	0,	0),
	(sf_print_newline,		$,	0,	0),
	(sf_print_end,			$,	0,	0),
	(sf_read_i64,			$,	0,	0),
	(sf_read_r64,			$,	0,	0),
	(sf_read_str,			$,	0,	0),
	(sf_read_fileline,		$,	0,	0),
	(sf_read_strline,		$,	0,	0),
	(sf_read_conline,		$,	0,	0),

	(sf_getnprocs,			$,	0,	1),		!access functions
	(sf_getprocname,		$,	0,	1),
	(sf_getprocaddr,		$,	0,	1),

	(sf_power_i64,			$,	0,	1),
	(sf_unimpl,				$,	0,	1),

end
!
global [sysfnnames.len]symbol sysfnhandlers

!global [sysfnnames.len]int sysfnproclabels

!global int mmpos
!global byte fshowpst


!!---
global enumdata [0:]ichar jtagnames,
				   [0:]byte jsubs, [0:]byte jisexpr, [0:]byte jsolo =
!Basic units; these don't follow normal rules of params needing to be units or lists
!jisexpr=1/2 when unit returns a value; 1 means unary, 2 binary op,
! 3 means returns a value, but is not a unary or binary op
!jsolo = 1 means unit is allowed standalone without its value being used

!a,b,c are unitrec refs, which can be a single unit, or a linked-list chain
!(usually in forward order)
!	L means .a/b/c pointing to a unitlist; L can be nil for an empty list
!	u means .a/b/c pointing to a single unit
!	u/nil means can be nil

![a=u] means a is a unit/list, or is nil

	(jnone=0,		$,	0,		0,	0), ! For tagname lookups when tag is zero
	(jconst,		$,	0,		3,	0), ! value/etc=value, typeno=type code
	(jnull,			$,	0,		3,	0), ! Place holder unit: means 'param no present' when used where a param is expected
	(jvoidvar,		$,	0,		3,	0), ! create void variant
	(jname,			$,	0,		3,	0), ! def=nameptr
!	(jname,			$,	0,		3,	1), ! def=nameptr
	(jnamelv,		$,	0,		3,	0), ! def=nameptr
	(jblock,		$,	1,		0,	1), ! a=L
	(jdecimal,		$,	0,		3,	0), ! svalue=str, slength
	(jassem,		$,	3,		0,	1), ! svalue=str, slength
	(jassemmacro,	$,	0,		0,	0), !
	(jassemreg,		$,	0,		0,	0), !
	(jassemxreg,	$,	0,		0,	0), !
	(jassemmem,		$,	1,		0,	0), !
	(jstrinclude,	$,	1,		3,	0), !
	(jsourceline,	$,	1,		3,	0), !

!Logical Operators

	(jandl,			$,	2,		2,	0), ! A B	This group are for conditional expressions (no result)
	(jorl,			$,	2,		2,	0), ! A B

	(jnotl,			$,	1,		1,	0), ! a
	(jistruel,		$,	1,		1,	0), ! a
	(jisfalsel,		$,	1,		1,	0), ! a

!Expressions and Operators

	(jmakelist,		$,	2,		3,	0), ! a=L, b=[u], length=N; element list/lower bound expr
	(jmakerange,	$,	2,		3,	0), ! A B
	(jmakeset,		$,	1,		3,	0), ! a=L, length=N
	(jmakedict,		$,	1,		3,	0), !
	(jmakeslice,	$,	2,		3,	0), !
	(jreturnmult,	$,	0,		3,	0), !

	(jkeyword,		$,	1,		3,	0), ! def=st entry
	(jkeyvalue,		$,	2,		3,	0), ! A B
	(jassign,		$,	2,		3,	1), ! A B a := x
	(jassignmm,		$,	2,		3,	1), ! A B (a,b,c) := (x,y,z)
	(jassignms,		$,	2,		3,	1), ! A B (a,b,c) := x
	(jassignmdrem,	$,	2,		3,	1), ! A B (a,b) := x divrem y
!	(jcallfn,		$,	2,		3,	1), ! A B
	(jcall,			$,	2,		3,	1), ! A B

	(jcmp,			$,	2,		2,	0), ! A B
	(jcmpchain,		$,	2,		1,	0), ! A B
	(jbin,			$,	2,		2,	0), ! A B
	(junary,		$,	2,		1,	0), ! A B
	(jprop,			$,	2,		1,	0), ! A B
	(jbinto,		$,	2,		2,	0), ! A B
	(junaryto,		$,	1,		1,	0), ! A B
	(jincr,			$,	1,		3,	0), ! a	++a
	(jin,			$,	2,		2,	0), ! A B

	(jinrev,		$,	2,		2,	0), ! A B
	(jinrange,		$,	2,		2,	0), ! A B
	(jinset,		$,	2,		2,	0), ! A B

	(jstringz,		$,	0,		3,	0), ! A B

	(jindex,		$,	2,		3,	0), ! A B		a[b]
	(jindexlv,		$,	2,		3,	0), ! A B		a[b]
	(jslice,		$,	2,		3,	0), ! A B		a[b.a..b.b]
!	(jnewslice,		$,	2,		3,	0), ! A B		slice(a,b)

	(jdot,			$,	2,		3,	0), ! A B opcode	a.b; opcode=0/1/2 used for signalling in rx pass
	(jdotlv,		$,	2,		3,	0), ! A B opcode	a.b; opcode=0/1/2 used for signalling in rx pass
	(jdotindex,		$,	2,		3,	0), ! A B		a[b]
	(jdotslice,		$,	2,		3,	0), ! A B		a[b]
!	(janddotindex,	$,	2,		3,	0), ! A B		a[b]

	(jptr,			$,	1,		3,	0), ! a		a^
	(jptrlv,		$, 	1,		3,	0), ! a		a^
	(jaddrof,		$,	2,		3,	0), ! a		&a
	(jaddroffirst,	$,	1,		3,	0), ! a		&a
	(jdaddrvv,		$,	1,		3,	0), ! a		&&a
!	(jdaddrtv,		$,	1,		3,	0), ! a		&&a (from jdaddrvv)
	(jconvert,		$,	1,		3,	0), ! typeno=T a		T(a)			T
	(jshorten,		$,	1,		3,	0), !
	(jautocast,		$,	1,		3,	0), ! typeno=T a		T(a)			T
	(jtypepun,		$,	1,		3,	0), ! typeno=T a		T@(a)			T
	(jtypeconst,	$,	0,		3,	0), ! typeno=T			typeconst(T)
	(joperator,		$,	0,		3,	0), ! opcode=opc
	(jupper,		$,	1,		3,	0), ! a		$					T

	(jbitwidth,		$,	1,		1,	0), ! a
	(jbytesize,		$,	1,		1,	0), ! a
	(jtypestr,		$,	0,		1,	0), ! a
!	(jsliceptr,		$,	0,		1,	0), ! a
	(jbitfield,		$,	1,		3,	0), ! a

	(jminvalue,		$,	1,		3,	0), ! a
	(jmaxvalue,		$,	1,		3,	0), ! a

!Translator Variables

	(jcvlineno,		$,	0,		3,	0), !
	(jcvstrlineno,	$,	0,		3,	0), ! 
	(jcvmodulename,	$,	0,		3,	0), ! 
	(jcvfilename,	$,	0,		3,	0), ! 
	(jcvfunction,	$,	0,		3,	0), ! 
	(jcvdate,		$,	0,		3,	0), ! 
	(jcvtime,		$,	0,		3,	0), ! 
	(jcvversion,	$,	0,		3,	0), ! 
	(jcvtypename,	$,	0,		3,	0), ! 
!	(jcvtargetbits,	$,	0,		3,	0), ! 
!	(jcvtargetsize,	$,	0,		3,	0), ! 
!	(jcvtargetcode,	$,	0,		3,	0), ! 
	(jcvnil,		$,	0,		3,	0), ! 
	(jcvpi,			$,	0,		3,	0), ! 
	(jcvinfinity,	$,	0,		3,	0), ! 
	(jcvtrue,		$,	0,		3,	0), ! 
	(jcvfalse,		$,	0,		3,	0), ! 

	(jwhenthen,		$,	2,		0,	0), ! a=L b=u
	(jfmtitem,		$,	2,		3,	0), ! A B  x/fmtstr
	(jnogap,		$,	0,		3,	0), ! 
	(jspace,		$,	0,		3,	0), ! 

!Statements

!	(jcallproc,		$,	2,		0,	1), ! a=fn b=L, length
	(jreturn,		$,	1,		0,	0), ! a=x/nil
	(jsyscall,		$,	1,		3,	1), ! a=x or nil

!	(jassign,		$,	0,		3,	0), ! A B
	(jto,			$,	3,		0,	0), ! a=N, b=body, c=tempvar/nil, def=name
	(jif,			$,	3,		3,	1), ! condcode a=then b=else
	(jforup,		$,	3,		0,	0), ! 
	(jfordown,		$,	3,		0,	0), !
	(jforall,		$,	3,		0,	0), !
	(jforallrev,	$,	3,		0,	0), !
	(jwhile,		$,	3,		0,	1), ! a=x b=u
	(jrepeat,		$,	2,		0,	1), ! a=u b=x
	(jgoto,			$,	1,		0,	1), ! a=x
	(jlabeldef,		$,	0,		0,	0), ! def=nameptr
	(jredo,			$,	0,		0,	1), ! [a=x]
	(jnext,			$,	0,		0,	1), ! [a=x]
	(jexit,			$,	0,		0,	1), ! [a=x]
	(jdo,			$,	1,		0,	1), ! [a=u
	(jcase,			$,	3,		3,	1), ! a=x b=L [c=else]		L is series of whenthen pairs
	(jdocase,		$,	3,		0,	1), ! a=x b=L [c=else]
	(jswitch,		$,	3,		3,	1), ! a=x b=L [c=else]
	(jdoswitch,		$,	3,		0,	1), ! a=x b=L [c=else]
	(jdoswitchu,	$,	3,		0,	1), ! a=x b=L [c=else]
	(jdoswitchx,	$,	3,		0,	1), ! a=x b=L [c=else]
	(jswap,			$,	2,		0,	1), ! A B
	(jselect,		$,	3,		3,	1), ! Not implemented
	(jrecase,		$,	1,		0,	0), ! Not implemented
!	(jrecaseelse,	$,	0,		0,	0), ! Not implemented

	(jprint,		$,	2,		0,	1), ! [a=dev] b=L
	(jprintln,		$,	2,		0,	1), ! [a=dev] b=L
	(jfprint,		$,	3,		0,	1), ! [a=dev] b=fmtstr c=L
	(jfprintln,		$,	3,		0,	1), ! [a=dev] b=fmtstr c=L
!	(jsprint,		$,	2,		0,	0), !         b=L 
!	(jsfprint,		$,	2,		0,	0), !         b=L
	(jread,			$,	2,		0,	1), ! [a=dev] b=L
	(jreadln,		$,	2,		0,	1), ! [a=dev] b=L
!	(jsread,		$,	2,		0,	0), ! [a=dev] b=L
!	(jsreadln,		$,	2,		0,	0), ! [a=dev] b=L
	(jstop,			$,	1,		0,	0), ! [a=x]
	(jeval,			$,	1,		3,	1), ! "
!	(jstack,		$,	1,		0,	0), ! "
!	(junstack,		$,	1,		0,	0), ! "
	(jclear,		$,	1,		1,	1), ! "

!	(jdummy,		$,	0,		3,	0)
end

global enumdata []ichar bitfieldnames=
	(bf_msb,		$),
	(bf_lsb,		$),
	(bf_msbit,		$),
	(bf_lsbit,		$),
	(bf_msw,		$),
	(bf_lsw,		$),
	(bf_odd,		$),
	(bf_even,		$),
end

global enumdata [0:]ichar optypenames =
	(no_op=0,		$),
	(bin_op,		$),
	(mon_op,		$),
	(prop_op,		$),
end

!!---
global enumdata []ichar symbolnames,
					[]byte symboloptypes,
					[]byte symbolgenops,
					[]byte symbolgentoops,
					[]byte symbolopprios,
					[]byte exprstarter =
!First half are basic tokens returned by lexreadtoken()
	(dotsym,			".",		0,			0,	0,	0,	0),		! "."
	(anddotsym,			"",		0,			0,	0,	0,	1),		! ""
	(commasym,			",",		0,			0,	0,	0,	0),		! ","
	(semisym,			";",		0,			0,	0,	0,	0),		! ";"
	(colonsym,			":",		0,			0,	0,	0,	0),		! ":"
	(assignsym,			":=",		bin_op,		0,	0,	1,	0),		! :=
	(sendtosym,			"=>",		0,			0,	0,	0,	0),		! =>
	(pipesym,			"->",		0,			0,	0,	0,	0),		! ->
	(lbracksym,			"(",		0,			0,	0,	0,	1),		! (
	(rbracksym,			")",		0,			0,	0,	0,	0),		! )
	(lsqsym,			"[",		0,			0,	0,	0,	1),		! [
	(rsqsym,			"]",		0,			0,	0,	0,	0),		! ]
	(lcurlysym,			"{",		0,			0,	0,	0,	0),		! {
	(rcurlysym,			"}",		0,			0,	0,	0,	0),		! }
	(ptrsym,			"^",		0,			0,	0,	0,	1),		! ^
	(barsym,			"|",		0,			0,	0,	0,	0),		! |
!	(dbarsym,			"||",		0,			0,	0,	0,	0),		! ||
	(atsym,				"@",		0,			0,	0,	0,	0),		! @
!	(datsym,			"@@",		0,			0,	0,	0,	0),		! @@
	(questionsym,		"?",		0,			0,	0,	0,	0),		! ?
	(addrsym,			"&",		0,			0,	0,	0,	1),		! &
	(daddrsym,			"&&",		0,			0,	0,	0,	0),		! &&
!	(curlsym,			"~",		0,			0,	0,	0,	0),		! ~
	(rangesym,			"..",		bin_op,		0,	0,	5,	0),		! ..
	(ellipsissym,		"...",		0,			0,	0,	0,	0),		! ...
	(hashsym,			"#",		0,			0,			0,			0,	0),		! #

!	(opsym,				$,		0,	0,	0,	0,	0),		! Any operator or property tag (use sets to distinguish)

	(addsym,			"+",		bin_op,		kadd,		kaddto,		4,	1),
	(subsym,			"-",		bin_op,		ksub,		ksubto,		4,	1),
	(mulsym,			"*",		bin_op,		kmul,		kmulto,		3,	0),
	(divsym,			"/",		bin_op,		kdiv,		kdivto,		3,	0),
	(idivsym,			"%",		bin_op,		kidiv,		kidivto,	3,	0),
	(iremsym,			"rem",		bin_op,		kirem,		kiremto,	3,	0),
	(idivremsym,		"divrem",	bin_op,		kidivrem,	0,			3,	0),
	(iandsym,			"iand",		bin_op,		kbitand,	kbitandto,	4,	0),
	(iorsym,			"ior",		bin_op,		kbitor,		kbitorto,	4,	0),
	(ixorsym,			"ixor",		bin_op,		kbitxor,	kbitxorto,	4,	0),
	(shlsym,			"<<",		bin_op,		kshl,		kshlto,		3,	0),
	(shrsym,			">>",		bin_op,		kshr,		kshrto,		3,	0),
	(minsym,			"min",		bin_op,		kmin,		kminto,		4,	1),
	(maxsym,			"max",		bin_op,		kmax,		kmaxto,		4,	1),
	(andlsym,			"and",		bin_op,		0,			0,			7,	0),
	(orlsym,			"or",		bin_op,		0,			0,			8,	0),
	(xorlsym,			"xor",		bin_op,		0,			0,			8,	0),

	(eqsym,				"=",		bin_op,		0,			0,			6,	1),
	(cmpsym,			"cmp",		bin_op,		0,			0,			6,	1),
	(powersym,			"**",		bin_op,		kpower,		0,			2,	0),
	(insym,				"in",		bin_op,		0,			0,			6,	0),
	(notinsym,			"notin",	bin_op,		0,			0,			6,	0),
	(inrevsym,			"inrev",	0,			0,			0,			0,	0),

	(notlsym,			"not",		mon_op,		knot,		knotto,		0,	1),
	(istruelsym,		"istrue",	mon_op,		0,			0,	0,	1),
	(inotsym,			"inot",		mon_op,		kbitnot,	kbitnotto,	0,	1),
	(abssym,			"abs",		mon_op,		kabs,		kabsto,		0,	1),
	(signsym,			"sign",		mon_op,		ksign,		0,			0,	1),
	(sqrtsym,			"sqrt",		mon_op,		ksqrt,		0,			0,	1),
	(sqrsym,			"sqr",		mon_op,		ksqr,		0,			0,	1),

	(propsym,			$,			prop_op,		0,			0,			0,	0),
	(mathsopsym,		$,			0,	0,	0,	0,	1),		! sin etc
	(maths2opsym,		$,			0,	0,	0,	0,	1),		! atan2 etc

	(bitfieldsym,		$,			0,	0,	0,	0,	0),		! Special bit selections
	(eolsym,			$,			0,	0,	0,	0,	0),		! End of line
	(eofsym,			$,			0,	0,	0,	0,	0),		! Eof seen
	(rawxnamesym,		$,			0,	0,	0,	0,	0),		! unassigned name, case-sensitive, that is never a reserved word
	(incrsym,			$,			0,	0,	0,	0,	1),		! 1/2 = ++/--; later may add +2 for x++/x--
	(intconstsym,		$,			0,	0,	0,	0,	1),		! 123 32 bits signed
	(realconstsym,		$,			0,	0,	0,	0,	1),		! 123.4 64 bits
	(charconstsym,		$,			0,	0,	0,	0,	1),		! 'A' or 'ABCD'
	(stringconstsym,	$,			0,	0,	0,	0,	1),		! "ABC"

!Second half are tokens that can be yielded after a name lookup:
	(unitnamesym,		$,			0,	0,	0,	0,	0),		! 
	(namesym,			$,			0,	0,	0,	0,	1),		! identifier symbol
	(kincludesym,		$,			0,	0,	0,	0,	0),		! INCLUDE
	(kstrincludesym,	$,			0,	0,	0,	0,	1),		! SINCLUDE/BINCLUDE
	(regsym,			$,			0,	0,	0,	0,	0),		! x64 registers
	(xregsym,			$,			0,	0,	0,	0,	0),		! XMM registers
	(fregsym,			$,			0,	0,	0,	0,	0),		! ST registers
	(mregsym,			$,			0,	0,	0,	0,	0),		! MMX registers
	(jmpccsym,			$,			0,	0,	0,	0,	0),		! 
	(setccsym,			$,			0,	0,	0,	0,	0),		! 
	(movccsym,			$,			0,	0,	0,	0,	0),		! 
	(segnamesym,		$,			0,	0,	0,	0,	0),		! 
	(asmopcodesym,		$,			0,	0,	0,	0,	0),		! MOV etc

	(stdtypesym,		$,			0,	0,	0,	0,	1),		! INT, CHAR etc
	(kicharsym,			$,			0,	0,	0,	0,	1),		! ICHAR IVOID
	(kifsym,			$,			0,	0,	0,	0,	1),		! 
	(kthensym,			$,			0,	0,	0,	0,	0),		! 
	(kelsifsym,			$,			0,	0,	0,	0,	0),		! 
	(kelsesym,			$,			0,	0,	0,	0,	0),		! 
	(kelsecasesym,		$,			0,	0,	0,	0,	0),		! 
	(kelseswitchsym,	$,			0,	0,	0,	0,	0),		! 
	(kendsym,			$,			0,	0,	0,	0,	0),		! 
	(kunlesssym,		$,			0,	0,	0,	0,	0),		! 
	(kcasesym,			$,			0,	0,	0,	0,	1),		! CASE
	(kdocasesym,		$,			0,	0,	0,	0,	0),		! DOCASE
	(krecasesym,		$,			0,	0,	0,	0,	0),		! RECASE
	(kwhensym,			$,			0,	0,	0,	0,	0),		! 
	(kforsym,			$,			0,	0,	0,	0,	0),		! FOR
	(ktosym,			$,			0,	0,	0,	0,	0),		! TO/DOWNTO
	(kbysym,			$,			0,	0,	0,	0,	0),		! 
	(kdosym,			$,			0,	0,	0,	0,	0),		! 
	(kwhilesym,			$,			0,	0,	0,	0,	0),		! 
	(krepeatsym,		$,			0,	0,	0,	0,	0),		! 
	(kuntilsym,			$,			0,	0,	0,	0,	0),		! 
	(kreturnsym,		$,			0,	0,	0,	0,	0),		! 
	(kstopsym,			$,			0,	0,	0,	0,	0),		! 
	(kloopsym,			$,			0,	0,	0,	0,	0),		! EXIT/NEXT/LOOP/REDO/RESTART
	(kgotosym,			$,			0,	0,	0,	0,	0),		! GO/GOTO
	(kswitchsym,		$,			0,	0,	0,	0,	0),		! SWITCH
	(kdoswitchsym,		$,			0,	0,	0,	0,	0),		! DOSWITCH
	(kprintsym,			$,			0,	0,	0,	0,	0),		! PRINT/PRINTLN/FPRINT/FPRINTLN
	(kreadsym,			$,			0,	0,	0,	0,	0),		! READ/READLN
	(kprocsym,			$,			0,	0,	0,	0,	0),		! PROC
	(kfunctionsym,		$,			0,	0,	0,	0,	0),		! FUNCTION
	(klabelsym,			$,			0,	0,	0,	0,	0),		! LABEL
	(krecordsym,		$,			0,	0,	0,	0,	0),		! RECORD
	(kstructsym,		$,			0,	0,	0,	0,	0),		! STRUCT
	(kunionsym,			$,			0,	0,	0,	0,	0),		! UNION
	(kimportmodulesym,	$,			0,	0,	0,	0,	0),		! IMPORTDLL/IMPORTMODULE
	(kprojectsym,		$,			0,	0,	0,	0,	0),		! PROJECT
	(ktypesym,			$,			0,	0,	0,	0,	0),		! TYPE
	(krefsym,			$,			0,	0,	0,	0,	1),		! REF
	(kvoidsym,			$,			0,	0,	0,	0,	1),		! VOID
	(kvarsym,			$,			0,	0,	0,	0,	0),		! MUT
	(kletsym,			$,			0,	0,	0,	0,	0),		! LET
	(kslicesym,			$,			0,	0,	0,	0,	0),		! SLICE/SLICE2D
	(kmacrosym,			$,			0,	0,	0,	0,	0),		! MACRO
!	(koperatorsym,		$,			0,	0,	0,	0,	0),		! OPERATOR
	(kconstsym,			$,			0,	0,	0,	0,	0),		! 
	(kclearsym,			$,			0,	0,	0,	0,	0),		! CLEAR
	(kheadersym,		$,			0,	0,	0,	0,	0),		! MODULE
	(kglobalsym,		$,			0,	0,	0,	0,	0),		! global
	(kstaticsym,		$,			0,	0,	0,	0,	0),		! STATIC

	(kcastsym,			$,			0,	0,	0,	0,	1),		! CAST
	(compilervarsym,	$,			0,	0,	0,	0,	1),		! $lineno etc
	(dollarsym,			$,			0,	0,	0,	0,	1),		! to be used for current array upperbound; also tabledata names
	(kevalsym,			$,			0,	0,	0,	0,	0),		! EVAL
	(ktabledatasym,		$,			0,	0,	0,	0,	0),		! tabledata
	(kclampsym,			$,			0,	0,	0,	0,	1),			! CLAMP
	(kswapsym,			$,			0,	0,	0,	0,	0),		! SWAP
	(kassemsym,			$,			0,	0,	0,	0,	0),		! ASM/ASSEM
	(ksyscallsym,		$,			0,	0,	0,	0,	1),		! $getprocname etc
end

global enumdata []ichar headerdirnames =
	(hdr_module,		$),
	(hdr_import,		$),
	(hdr_sourcepath,	$),
	(hdr_linkdll,		$),
end

global enumdata [0:]ichar scopenames=
	(Module_scope=0,	"Local"), ! 		!module
	(subprog_scope,		"Global"), ! 		!inter-subprog
	(program_scope,		"Program"), ! 		!inter-module
	(export_scope,		"Export"), ! 		!inter-program
end

global enumdata =
	million_unit,
	billion_unit,
end

global enumdata [0:]ichar parammodenames=
	(byval_param=0,		"Byval "),
	(byref_param,		"Byref "),
end

global enumdata [0:]ichar namenames, [0:]byte name2pid =
	(nullid=0,		$,		0),				!Not assigned
	(programid,		$,		0),				!Main root
	(subprogid,		$,		0),
	(moduleid,		$,		program_id),	!Current or imported module
	(dllmoduleid,	$,		0),				!
	(typeid,		$,		0),				!Type name in type, proc or module
	(procid,		$,		proc_id),		!Proc/method/function/op name
	(dllprocid,		$,		import_id),		!Dll Proc/func name
	(dllvarid,		$,		0),				!Dll variable name
	(constid,		$,		0),				!Named constant in type, proc or module
	(staticid,		$,		static_id),		!Static in type or proc or module
	(frameid,		$,		local_id),		!Local var
	(paramid,		$,		param_id),		!Local param
	(fieldid,		$,		0),				!Field of Record or Class
	(labelid,		$,		label_id),		!Label name in proc only
	(macroid,		$,		0),				!Name of macro
	(macroparamid,	$,		0),				!Macro formal parameter name
	(linkid,		$,		0),				!Name in class defined in a base class
end

global enumdata []ichar propnames =
	(kksliceptr,	$),
	(kklen,			$),
	(kklwb,			$),
	(kkupb,			$),
	(kkbounds,		$),
	(kkbitwidth,	$),
	(kkbytesize,	$),
	(kktypestr,		$),
	(kkminval,		$),
	(kkmaxval,		$),
end

!!---
global tabledata []ichar stnames, []byte stsymbols, []i16 stsubcodes=

	("if",			kifsym,			jif),
	("then",		kthensym,		0),
	("elsif",		kelsifsym,		jif),
	("else",		kelsesym,		0),
	("dummyelse",	kelsesym,		1),
	("elsecase",	kelsecasesym,	jcase),
	("elseswitch",	kelseswitchsym,	jswitch),
	("case",		kcasesym,		jcase),
	("docase",		kdocasesym,		jdocase),
	("recase",		krecasesym,		jrecase),
	("when",		kwhensym,		0),
	("for",			kforsym,		0),
	("to",			ktosym,			0),
	("downto",		ktosym,			1),
	("by",			kbysym,			0),
	("do",			kdosym,			0),
	("end",			kendsym,		0),
	("while",		kwhilesym,		0),
	("repeat",		krepeatsym,		0),
	("until",		kuntilsym,		0),
	("return",		kreturnsym,		0),
	("stop",		kstopsym,		0),
	("redoloop",	kloopsym,		jredo),
	("nextloop",	kloopsym,		jnext),
	("exit",		kloopsym,		jexit),
	("goto",		kgotosym,		0),
	("switch",		kswitchsym,		jswitch),
	("doswitch",	kdoswitchsym,	jdoswitch),
	("doswitchu",	kdoswitchsym,	jdoswitchu),
	("doswitchx",	kdoswitchsym,	jdoswitchx),
	("tabledata",	ktabledatasym,	0),
	("enumdata",	ktabledatasym,	1),
	("clamp",		kclampsym,		0),
	("eval",		kevalsym,		0),
	("print",		kprintsym,		jprint),
	("println",		kprintsym,		jprintln),
	("fprint",		kprintsym,		jfprint),
	("fprintln",	kprintsym,		jfprintln),
!	("sprint",		ksprintsym,		jsprint),
!	("sfprint",		ksprintsym,		jsfprint),

	("cp",			kprintsym,		jprint),
	("cpl",			kprintsym,		jprintln),

	("read",		kreadsym,		jread),
	("readln",		kreadsym,		jreadln),
	("cast",		kcastsym,		jconvert),

	("function",	kfunctionsym,	0),
	("func",		kfunctionsym,	0),
	("proc",		kprocsym,		0),
	("fun",			kfunctionsym,	1),
	("threadedproc",kprocsym,		2),

	("type",		ktypesym,		0),
	("record",		krecordsym,		0),
	("struct",		kstructsym,		0),
	("union",		kunionsym,		0),
	("ref",			krefsym,		0),
	("var",			kvarsym,		0),
	("let",			kletsym,		0),

	("include",		kincludesym,	0),
	("binclude",	kstrincludesym,	'B'),
	("sinclude",	kstrincludesym,	'S'),
	("strinclude",	kstrincludesym,	'S'),

	("macro",		kmacrosym,		0),

	("assem",		kassemsym,		1),
	("asm",			kassemsym,		0),

	("static",		kstaticsym,		0),
	
	("const",		kconstsym,		0),

	("$getnprocs",		ksyscallsym,	sf_getnprocs),
	("$getprocname",	ksyscallsym,	sf_getprocname),
	("$getprocaddr",	ksyscallsym,	sf_getprocaddr),

	("importdll",	kimportmodulesym,	0),
	("project",		kprojectsym,		0),
	("unless",		kunlesssym,			0),

	("global",		kglobalsym,		subprog_scope),
	("export",		kglobalsym,		export_scope),

	("swap",		kswapsym,		0),

	("void",		kvoidsym,		0),
	("int",			stdtypesym,		tint),
	("word",		stdtypesym,		tword),
	("real",		stdtypesym,		treal),

	("ichar",		kicharsym,		tc8),
	("ivoid",		kicharsym,		tvoid),

	("i8",			stdtypesym,		ti8),
	("i16",			stdtypesym,		ti16),
	("i32",			stdtypesym,		ti32),
	("i64",			stdtypesym,		ti64),

	("r32",			stdtypesym,		tr32),
	("r64",			stdtypesym,		tr64),

	("byte",		stdtypesym,		tu8),
	("u8",			stdtypesym,		tu8),
	("u16",			stdtypesym,		tu16),
	("u32",			stdtypesym,		tu32),
	("u64",			stdtypesym,		tu64),

!	("word8",		stdtypesym,		tu8),
!	("u16",		stdtypesym,		tu16),
!	("u32",		stdtypesym,		tu32),
!	("u64",		stdtypesym,		tu64),

	("char",		stdtypesym,		tc8),
	("c8",			stdtypesym,		tc8),
!	("char8",		stdtypesym,		tc8),
	("c64",			stdtypesym,		tc64),
!	("c64",		stdtypesym,		tc64),

	("bool64",		stdtypesym,		tbool64),
	("bool",		stdtypesym,		tbool64),
	("bool8",		stdtypesym,		tbool8),

	("label",		stdtypesym,		tlabel),

	("slice",		kslicesym,		tslice),

	("million",		unitnamesym,	million_unit),
	("billion",		unitnamesym,	billion_unit),

	("$lineno",		compilervarsym,	jcvlineno),
	("$strlineno",	compilervarsym,	jcvstrlineno),
	("$filename",	compilervarsym,	jcvfilename),
	("$modulename",	compilervarsym,	jcvmodulename),
	("$function",	compilervarsym,	jcvfunction),
	("$date",		compilervarsym,	jcvdate),
	("$time",		compilervarsym,	jcvtime),
	("$version",	compilervarsym,	jcvversion),
	("$typename",	compilervarsym,	jcvtypename),
!	("$targetbits",	compilervarsym,	jcvtargetbits),
!	("$targetsize",	compilervarsym,	jcvtargetsize),
!	("$targetname",	compilervarsym,	jcvtargetname),
!	("$targetcode",	compilervarsym,	jcvtargetcode),
	("nil",			compilervarsym,	jcvnil),
	("pi",			compilervarsym,	jcvpi),
	("true",		compilervarsym,	jcvtrue),
	("false",		compilervarsym,	jcvfalse),
	("infinity",	compilervarsym,	jcvinfinity),
	("$",			dollarsym,		0),

	("and",			andlsym,		0),
	("or",			orlsym,			0),
	("xor",			xorlsym,		0),
	("iand",		iandsym,		0),
	("ior",			iorsym,			0),
	("ixor",		ixorsym,		0),
!	("in",			insym,			kkin),
!	("notin",		notinsym,		kknotin),
	("in",			insym,			0),
	("notin",		notinsym,		1),
	("inrev",		inrevsym,		0),
	("rem",			iremsym,		0),
	("divrem",		idivremsym,		0),
	("min",			minsym,			0),
	("max",			maxsym,			0),

	("not",			notlsym,		0),
	("inot",		inotsym,		0),
	("istrue",		istruelsym,		0),
	("abs",			abssym,			kabs),
!	("$neg",		negsym,			0),
!	("byteswap",	byteswapsym,	0),

	("sqr",			sqrsym,			0),
	("sqrt",		sqrtsym,		0),
	("sign",		signsym,		0),

	("sin",			mathsopsym,		ksin),
	("cos",			mathsopsym,		kcos),
	("tan",			mathsopsym,		ktan),
	("asin",		mathsopsym,		kasin),
	("acos",		mathsopsym,		kacos),
	("atan",		mathsopsym,		katan),
	("log",			mathsopsym,		klog),
	("log10",		mathsopsym,		klog10),
	("exp",			mathsopsym,		kexp),
	("round",		mathsopsym,		kround),
	("floor",		mathsopsym,		kfloor),
	("ceil",		mathsopsym,		kceil),

	("atan2",		maths2opsym,	katan2),
	("fmod",		maths2opsym,	kfmod),

	("sliceptr",	propsym,		kksliceptr),
	("len",			propsym,		kklen),
	("lwb",			propsym,		kklwb),
	("upb",			propsym,		kkupb),
	("bounds",		propsym,		kkbounds),
	("bitwidth",	propsym,		kkbitwidth),
	("bytes",		propsym,		kkbytesize),
	("typestr",		propsym,		kktypestr),

	("msb",			bitfieldsym,	bf_msb),
	("lsb",			bitfieldsym,	bf_lsb),
	("msbit",		bitfieldsym,	bf_msbit),
	("lsbit",		bitfieldsym,	bf_lsbit),
	("msw",			bitfieldsym,	bf_msw),
	("lsw",			bitfieldsym,	bf_lsw),
	("odd",			bitfieldsym,	bf_odd),
	("even",		bitfieldsym,	bf_even),

	("fi",			kendsym,		kifsym),
	("esac",		kendsym,		kcasesym),
	("od",			kendsym,		kdosym),

	("$caligned",	atsym,			1),
	("clear",		kclearsym,		0),

	("module",		kheadersym,		hdr_module),
	("import",		kheadersym,		hdr_import),
	("$sourcepath",	kheadersym,		hdr_sourcepath),
	("linkdll",		kheadersym,		hdr_linkdll),
end

global enumdata [0:]ichar convnames, [0:]byte convtopcl =
	(kkerror=0,     $,		0),
!	(kktypepun,     $,		0),
	(kkfloat,       $,		kfloat),
	(kkfix,         $,		kfix),
	(kktruncate,    $,		ktruncate),
	(kkwiden,       $,		kwiden),
	(kkfwiden,      $,		kfwiden),
	(kkfnarrow,     $,		kfnarrow),
	(kksoftconv,    $,		0),
	(kktoboolt,     $,		ktoboolt),
	(kkharderr,     $,		0),
	(kksofttrun,    $,		0),
	(kkichar2sl,    $,		0),
	(kkax2slice,    $,		0),
	(kkcx2ichar,    $,		0),
end

global []int D_typestarterset= (stdtypesym,lsqsym,krefsym,krecordsym,
		kicharsym, kslicesym, ptrsym)

global [tr64..tc64, tr64..tc64]i16 softconvtable = (
!To: r64			r32			i64			u64			c64				 From:
	(kksoftconv,	kkfnarrow,	kkfix,		kkfix,		kkfix),			!r64
	(kkfwiden,		kksoftconv,	kkfix,		kkfix,		kkfix),			!r32
	(kkfloat,		kkfloat,	kksoftconv,	kksoftconv,	kksoftconv),	!i64
	(kkfloat,		kkfloat,	kksoftconv,	kksoftconv,	kksoftconv),	!u64
	(kkfloat,		kkfloat,	kksoftconv,	kksoftconv,	kksoftconv))	!c64

global [symbolnames.lwb..symbolnames.upb]byte endsexpr
global []byte exprendsymbols=(rbracksym,rsqsym,kthensym,kelsifsym,
			kelsesym, kuntilsym, kdosym, kendsym, commasym, barsym,
			semisym, ktosym)

global [jtagnames.lwb..jtagnames.upb]byte isbooltag

proc start=
	int genop, s,t, a, specop

	for i to exprendsymbols.len do
		endsexpr[exprendsymbols[i]]:=1
	od

	isbooltag[jcmp]:=1
	isbooltag[jcmpchain]:=1
	isbooltag[jandl]:=1
	isbooltag[jorl]:=1
	isbooltag[jnotl]:=1
	isbooltag[jistruel]:=1
	isbooltag[jisfalsel]:=1
	isbooltag[jinrange]:=1
	isbooltag[jinset]:=1
end

