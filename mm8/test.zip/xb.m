!proc mainx=
!	PRINTLN "MAIN XB"
!end

proc start=
	PRINTLN "START XB"
end
