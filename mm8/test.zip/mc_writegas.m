const fasmformat=2			!gas
!const fasmformat=1			!nasm
!const fasmformat=0			!aa

!export ichar asmext="s"
export ichar asmext="asm"

[8, r0..r15]ichar nregnames

byte currseg

global func getassemstr:ref strbuffer=
!write all mcl code in system by scanning all procs
!mcl code is only stored per-proc
	psymbol d,e
	ref mclrec m
	[32]char str2,str3
	int i

!CPL "WRITE GAS",=PHIGHMEM


	gs_init(pdest)
!	asmstr("# GAS VERSION\n")

	asmstr("    .code64\n")
!	asmstr("    .intel_syntax noprefix\n")
	asmstr("    .intel_syntax prefix\n")
!	asmstr("    .global main\n")

!	asmstr("    default rel\n")
!	asmstr("    extern fmod\n")
!	asmstr("    extern sin\n")
!	asmstr("    extern cos\n")
!	asmstr("    extern tan\n")
!	asmstr("    extern asin\n")
!	asmstr("    extern acos\n")
!	asmstr("    extern atan\n")
!	asmstr("    extern log\n")
!	asmstr("    extern log10\n")
!	asmstr("    extern exp\n")
!	asmstr("    extern floor\n")
!	asmstr("    extern ceil\n")
!	asmstr("    extern pow\n")
!	asmstr("    extern exit\n")
!	asmstr("    extern __getmainargs\n")
!	asmstr("    global main\n")
	asmstr("\n")

!do globals and externs
	d:=psymboltable

	while d, d:=d.next do
		if d.exported then
			asmstr("    .global ")
			asmstr(getbasename(d.name))
			asmstr("\n")
		fi
	od
	asmstr("\n")
	m:=mccode
	i:=1
	while m do
		writemcl(i,m)
		++i
		m:=m.nextmcl
	od

	byte first:=1
	d:=psymboltable

	while d, d:=d.next do
		if d.dllexport then
			if first then
				first:=0
				asmstr("    .section .drectve\n")
			fi
			asmstr("    .ascii "" -export:\\""")
			asmstr(d.name)
			asmstr("\\""""\n")
		fi
	od
	asmstr("\n")

	return pdest
end

proc writemcl(int index,ref mclrec mcl)=

	case mcl.opcode
!	when m_define, m_definereg then
	when m_definereg then
	else
		strmcl(mcl)
		gs_line(pdest)
	esac
end

proc start=
	byte flag

	assemtype:='GAS'

!initialise table of official gp reg names

	for i in 1..8 when i in [1,2,4,8] do
		for r in r0..r15 do
			flag:=0
			for k in dregnames.bounds do
				if flag then
					if regsizes[k]=i and regindices[k]=r then
						nregnames[i, r]:=dregnames[k]
					fi
				elsif regsizes[k]=0 then
					flag:=1
				fi
			od
		od
	od


!for i in 1..8 do
!	for r in r0..r15 do
!		if nregnames[i,r]=nil then
!			print "nil, "
!		else
!			fprint """#"", ",nregnames[i, r]
!		fi
!	od
!	println "\t!", i
!od
!
end


global proc strmcl(ref mclrec mcl)=
	static [512]char str
	[128]char opcname
	mclopnd a,b
	int opcode,cond,sizepref
	ichar s,comment
	psymbol d

	opcode:=mcl.opcode


	cond:=mcl.cond
	a:=mcl.a
	b:=mcl.b
	comment:=nil

!CPL =MCLNAMES[OPCODE]

	case opcode
	when m_procstart then
		asmstr("# Proc ")
		asmstr(a.def.name)
		currasmproc:=a.def

		return

	when m_procend then
		asmstr("# End ")
		currasmproc:=nil

		return

	when m_comment then
		asmchar('# ')
		asmstr(a.svalue)
		return

	when m_labelname then				!label name will be complete and will have colon(s)
		d:=a.def
		case a.valtype
		when def_val then
			asmstr(getdispname(d))
		when stringimm_val then
			asmstr(a.svalue)
			return
		else
			merror("strmcl/lab")
		esac

		asmstr(":")

		if d.exported then
			if eqstring(getbasename(d.name), d.name) then
!				asmstr(":")
			else
				asmstr("\n")
				asmstr(getbasename(d.name))
!				asmstr("::")
				asmstr(":")
			fi
		fi

		return

	when m_labelx then
!		fprint @str,"L#:",a.value
!		asmstr(str)
!		return
		if a.valtype=label_val then
			fprint @str,"L#:",a.value
		else
			recase m_labelname
		fi
		asmstr(str)
		return

	when m_define then
		asmstr("    .set ")
		asmstr(a.svalue)
		asmstr(", ")
		asmopnd(b)
		return

!	when m_definetemp then
!		asmstr("    .set ")
!		asmstr(a.svalue)
!		asmstr(", ")
!		asmopnd(b)
!		return

!	when m_definereg then
!		d:=a.def
!		asmstr("   %define ")
!		asmstr(getdispname(d))
!		asmstr(" ")
!
!		case b.mode
!		when a_reg then
!			asmstr(strreg(b.reg, b.size))
!
!		else
!!			asmstr(getxregname(b.reg, b.size))
!			asmstr(strxreg(b.reg, b.size))
!		esac
!		return

		return

	when m_csegment then asmstr("    .text"); currseg:=code_seg; return
	when m_isegment then asmstr("    .data"); currseg:=idata_seg; return
	when m_zsegment then asmstr("    .bss"); currseg:=zdata_seg; return

	esac

	case opcode
	when m_jmpcc then
		print @opcname,"j",,asmcondnames[cond]

	when m_setcc then
		print @opcname,"set",,asmcondnames[cond]

	when m_cmovcc then
		print @opcname,"cmov",,asmcondnames[cond]

	when m_andx then
		strcpy(opcname,"and")
	when m_orx then
		strcpy(opcname,"or")
	when m_xorx then
		strcpy(opcname,"xor")
	when m_notx then
		strcpy(opcname,"not")

	when m_imul2 then
		strcpy(opcname,"imul")

	when m_movzx then
		if a.size=8 and b.size=4 then
			mcl.a:=a:=changeopndsize(a, 4)
			opcode:=m_mov
		fi
		recase else

	when m_movsx then
		if a.size=8 and b.size=4 then
			strcpy(opcname, "movsxd")
		else
			recase else
		fi

	when m_movd then
		if a.mode=a_xreg and b.mode=a_xreg then		!
			opcode:=m_movq
		fi

		recase else

    when m_mov then
        if a.mode=a_reg and b.mode=a_imm and b.valtype=intimm_val and b.value not in i32.bounds then
            mcl.opcode:=m_movq
        fi
		recase else

	when m_align then
		strcpy(opcname, ".align")
!		if currseg=zdata_seg then
!			strcpy(opcname, "alignb")
!		else
!			recase else
!		fi
	when m_resb then
		strcpy(opcname, ".space")

	when m_db then
		strcpy(opcname, ".byte")
	when m_dw then
		strcpy(opcname, ".word")
	when m_dd then
		strcpy(opcname, ".long")
	when m_dq then
		strcpy(opcname, ".quad")
	when m_ascii then
		strcpy(opcname, ".ascii")


	when m_endx then
		return

	ELSIF OPCODE>M_HALT THEN
		STRCPY(OPCNAME,STRINT(OPCODE))

	else
		strcpy(opcname,mclnames[opcode]+2)
	esac

	ipadstr(opcname,10," ")

	if not fasmformat then
		if a and b then
			fprint @str,"  #/#",a.size,b.size
		elsif a then
			fprint @str,"  #",a.size
		else
			strcpy(str,"  ")
		fi
	else
		strcpy(str,"  ")
	fi

	ipadstr(str,4)

	strcat(str,opcname)

	asmstr(str)

	if a and b then		!2 operands
		sizepref:=needsizeprefix(opcode,a,b)
!
		asmopnd(a,sizepref)
		asmstr(",	")
		asmopnd(b,sizepref)

		if mcl.c then
			asmstr(",")
			asmstr(strint(mcl.c))
		fi

!		ASMSTR("; ")
!		ASMSTR(strint(a.size))
!		ASMSTR(" ")
!		ASMSTR(strint(b.size))
!		ASMSTR(" #")
!		ASMSTR(STRINT(MCL.SEQNO))
!!
	elsif a and a.mode then								!1 operand
		if opcode=m_call then
			asmopnd(a,0,opcode)
		else
			asmopnd(a,1,opcode)
		fi
	fi

!ASMSTR("	#"); ASMSTR(STRINT(MCL.SEQNO))

end

global func strmclstr(ref mclrec m)ichar=
	gs_init(pdest)
	strmcl(m)
	return pdest.strptr
end

global func mstropnd(mclopnd a,int sizeprefix=0,opcode=0)ichar=
	static [512]char str
	[128]char str2
	ichar plus,t
	int offset,tc

	str[1]:=0

	case a.mode
	when a_reg then
		return strreg(a.reg, a.size)

	when a_imm then
		if opcode=m_dq and a.valtype=intimm_val then
			if a.value in 0..9 then
				strcat(str,strint(a.value))
			else
				strcat(str,"0x")
				strcat(str,strword(a.value,"H"))
			fi
		else
			strcpy(str,strvalue(a))
		fi

	when a_mem then
!		case a.valtype
!		when intimm_val then
!			strcpy(str,strint(a.value))
!		when realimm_val then
!			strcpy(str,strreal(a.xvalue))
!		when realmem_val then
!			fprint @str,"M#",a.xvalue
!		esac

		strcat(str,getsizeprefix(a.size,sizeprefix))
		strcat(str,"[")

		plus:=""
		if a.reg then
			strcat(str,strreg(a.reg,8))
			plus:=" + "
		fi
		if a.regix then
			strcat(str,plus)
			strcat(str,strreg(a.regix,8))
			plus:=" + "

			if a.scale>1 then
				strcat(str,"*")
				strcat(str,strint(a.scale))
			fi
		fi

		if a.valtype in [def_val,label_val, temp_val] then
			IF A.REG=A.REGIX=RNONE AND PHIGHMEM THEN
				STRCAT(STR, "%rip+")
			fi
			if plus^ then
				strcat(str,plus)
			fi
			strcat(str,strvalue(a))
	    elsif offset:=a.offset then
			print @str2,offset:" + "
			strcat(str,str2)
		fi
		strcat(str,"]")

	when a_xreg then
		return strxreg(a.reg,a.size)

	else
		println "BAD OPND",A.MODE
		return "<BAD OPND>"
	esac

	return str
end

global func strvalue(mclopnd a)ichar=
	static [512]char str
	[128]char str2
	psymbol def
	i64 value,offset,length
	ichar ss

	def:=a.def
	value:=a.value

	strcpy(str,"")

	case a.valtype
	when def_val then
		strcat(str,getdispname(def))

	addoffset:
		if offset:=a.offset then
			print @str2,(offset>0|"+"|""),,offset
			strcat(str,str2)
		fi

	when intimm_val then
		strcat(str,strint(value))

	when realimm_val then
		print @str,a.xvalue:"20.20"

	when realmem_val then
		strcat(str,"M")
		strcat(str,strreal(a.xvalue))

	when stringimm_val then
		strcat(str,"""")
		strcat(str,a.svalue)
		strcat(str,"""")

	when name_val then
		strcat(str,a.svalue)

	when label_val then
		strcat(str,"L")
		strcat(str,strint(a.labelno))
		goto addoffset

	when temp_val then
		return gettempname(currasmproc,a.tempno)

	else
		merror("Stropnd?")
	esac

	return str

end

global proc asmopnd(mclopnd a,int sizeprefix=0,opcode=0)=
	asmstr(mstropnd(a,sizeprefix,opcode))
end

global func getxregname(int reg,size=8)ichar=
	static [32]char str

	if reg=rnone then return "-" fi

!	if fasmformat then
		print @str,"%XMM",,reg-xr0
!	else
!		print @str,(size=8|"DX"|"SX"),,reg-xr0
!	fi
	return str
end

proc asmstr(ichar s)=
	gs_str(pdest,s)
end

proc asmchar(int c)=
	gs_char(pdest,c)
end

global func getdispname(psymbol d)ichar=
	static [256]char str

!	if d.reg then
!		fprint @str,"#.#","R", d.name
!		return str
!	fi
!
!	if fpshortnames then
!		return d.name
!	fi

	return getfullname(d)
!	strcpy(str, getfullname(d))
!	if d.id=static_id then
!!IF D.IMPORTED THEN CPL "STATIC", D.NAME, D.IMPORTED FI
!		strcat(str,".")
!	fi
!	return str
!	return "FULL"

end 

global func gettempname(psymbol d, int n)ichar=
	static [128]char str

!CPL "TEMP:", D.NAME,D.OFFSET

	if fpshortnames then
		print @str,"T",,n
	else
		fprint @str,"#.$T#",getdispname(d),n
	fi
	str
end

func strreg(int reg, size=8)ichar=
	static [16]char str

	strcpy(str, "%")
	strcat(str, nregnames[size, reg])

	str

!	nregnames[size, reg]
end

func strxreg(int reg, size=8)ichar=
	psymbol d

	d:=checkregvar(reg,1)

	if size=8 and d then
		return getdispname(d)
	else
		return getxregname(reg,size)
	fi
end

global func needsizeprefix(int opcode,mclopnd a,b)int=
	case opcode
	when m_movsx, m_movzx, m_cvtsi2ss, m_cvtsi2sd then
		return 1

	when m_cvtss2si,m_cvtsd2si, m_cvttss2si,m_cvttsd2si then
		return 1
	when m_shl, m_shr, m_sar then
		if a.mode=a_mem then return 1 fi
		return 0
	esac

	if a.mode=a_reg or a.mode=a_xreg or b.mode=a_reg or b.mode=a_xreg then
		return 0
	fi
	return 1
end

global func getsizeprefix(int size,enable=0)ichar=
	if not enable then return "" fi
	case size
	when 1 then return "byte ptr"
	when 2 then return "word ptr"
	when 4 then return "dword ptr"
	when 8 then return "qword ptr"
	esac
	return ""
end

func checkregvar(int reg, ispfloat)psymbol d=
	RETURN NIL
end

