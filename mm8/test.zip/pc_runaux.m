

global func pci_getopnd(pcl p, ref i64 locals)i64 a =
!return operand value
!locals is a pointer stack[fp]

	psymbol d
	ref byte         ptr
	ref u8  pu8		@ptr
	ref u16 pu16	@ptr
	ref u32 pu32	@ptr
	ref u64 pu64	@ptr
	ref i8  pi8		@ptr
	ref i16 pi16	@ptr
	ref i32 pi32	@ptr
	ref i64 pi64	@ptr
	ref r32 pr32	@ptr
	ref r64 pr64	@ptr

	case p.opndtype
	when int_opnd then
		a:=p.value

	when mem_opnd then
		d:=p.def
		case d.id
		when static_id then
			pi64:=d.staddr
		else
			pi64:=locals+d.offset
			if d.mode=tpblock and d.id=param_id then pi64:=cast(pi64^) fi
		esac

		a:=pci_loadptr(ptr, p.mode)

	when memaddr_opnd then
		d:=p.def
		case d.id
		when local_id then
			a:=cast(locals+d.offset)
		when param_id then
			a:=cast(locals+d.offset)
			if d.mode=tpblock then			!need value of param not its address
				ptr:=cast(a)				!value contains reference to block
				a:=pu64^
			fi
		when import_id then
			a:=cast(getdllfnptr(d))

		else
			a:=cast(d.staddr)		!also does proc_id/import_id
		esac

	when string_opnd then
		a:=cast(p.svalue)

	when real_opnd, r32_opnd then
		a:=int@(p.xvalue)

	when label_opnd then
		a:=cast(labeltable[p.labelno])

	else
		pcusopnd(p)
	esac

	a
end

global func pci_loadptr(ref byte p, int mode)i64 =
!p points to a primitive or block
!any scaling/offset has been applied

	ref u8  pu8		@p
	ref u16 pu16	@p
	ref u32 pu32	@p
	ref u64 pu64	@p
	ref i8  pi8		@p
	ref i16 pi16	@p
	ref i32 pi32	@p
	ref i64 pi64	@p
	ref r32 pr32	@p
	ref r64 pr64	@p
	real x

	if p=nil then pclerror("Null ptr access") fi

	switch mode
	when tpblock then
		cast(p)

	when tpr64 then
		pu64^
	when tpr32 then
		x:=pr32^				!widen to r64
		int@(x)					!typepun to i64

	when tpi64 then pi64^
	when tpi32 then pi32^
	when tpi16 then pi16^
	when tpi8  then pi8^

	when tpu64 then pu64^
	when tpu32 then pu32^
	when tpu16 then pu16^
	when tpu8  then pu8^
	else
		0
	end
end

global proc pci_storeptr(ref byte p, int a, mode, size=0) =
!p points to a primitive or block
!a represents any value including a real, or a block reference

	ref i8  pi8		@p
	ref i16 pi16	@p
	ref i32 pi32	@p
	ref i64 pi64	@p
	ref r32 pr32	@p
	real x

	if p=nil then pclerror("Null ptr access") fi

	case mode
	when tpblock then
		memcpy(p, ref byte(a), size)

	when tpr32 then
		x:=real@(a)
		pr32^:=x

	elsecase psize[mode]
	when 8 then pi64^:=a
	when 4 then pi32^:=a
	when 2 then pi16^:=a
	else        pi8^ :=a
	esac
end

global func pci_getopndaddr(pcl p, ref i64 locals)ref i64 =
	psymbol d

	if p.opndtype<>mem_opnd then pcerrorx(p,"Not mem") fi

	d:=p.def
	if d.id=static_id then
		d.staddr
	else
		locals+d.offset
	fi
end

global proc pcerrorx(pcl p, ichar mess, param="")=
	println "PC Exec error:",mess, param, "seq:", (p|p.seqno|0)
	println
	stop 1
end

global proc pcusopnd(pcl p)=
	println "Unsupported operand:", opndnames[p.opndtype],"in", pclnames[p.opcode], p.seqno
	println
	stop 1
end

global func docalldll(psymbol d, ref proc fnaddr, ref[]int revargs, int nargs, nvars, retmode)int=
!d=st entry, fnaddr=nil; or d=nil; fnaddr is fn ptr
!note: args are in reverse order
	[100]i64 args
	int retval

	if fnaddr=nil then
		fnaddr:=getdllfnptr(d)
	fi

	for i:=nargs downto 1 do
		args[nargs-i+1]:=revargs[i]
	od

	retval:=os_calldllfunction(fnaddr, (retmode in [tpr32,tpr64]|'R'|'I'), nargs, &args, nil)

	retval
end

global func getdllfnptr(psymbol d)ref proc fnaddr=
	int libindex
	word dllinst
	ichar procname, libname

	fnaddr:=d.dlladdr
	return fnaddr when fnaddr

	procname:=d.name

	for i to nplibfiles do
		fnaddr:=os_getdllprocaddr(plibinst[i],procname)
		exit when fnaddr
	else
		pcerrorx(nil,"Can't find DLL func:",procname)
	od
	d.dlladdr:=fnaddr
	return fnaddr
end

global proc loadlibs=
	for i to nplibfiles do
		plibinst[i]:=os_getdllinst(plibfiles[i])
		if not plibinst[i] then
			pcerrorx(nil, "Can't load lib:",plibfiles[i])
		fi
	od
end

global func cmpreal(int cond, real x, y)int=
	case cond
	when eq_cc then x=y
	when ne_cc then x<>y
	when lt_cc then x<y
	when le_cc then x<=y
	when ge_cc then x>=y
	else            x>y
	esac
end

global func cmpint(int cond, x, y)int=
	case cond
	when eq_cc then x=y
	when ne_cc then x<>y
	when lt_cc then x<y
	when le_cc then x<=y
	when ge_cc then x>=y
	else            x>y
	esac
end

global func cmpword(int cond, word x, y)int=
	case cond
	when eq_cc then x=y
	when ne_cc then x<>y
	when lt_cc then x<y
	when le_cc then x<=y
	when ge_cc then x>=y
	else            x>y
	esac
end

global proc doincr(ref byte pu8, int incr, mode)=
!uses negative incr for decr
	ref u16 pu16	@pu8
	ref u32 pu32	@pu8
	ref u64 pu64	@pu8

	case psize[mode]
	when 8 then	pu64^+:=incr
	when 4 then	pu32^+:=incr
	when 2 then	pu16^+:=incr
	else		pu8^+:=incr
	esac
end

global proc docmdskip=
	psymbol d

	d:=psymboltable
	while d, d:=d.next do
		if eqstring(getbasename(d.name), "$cmdskip") then
			(ref byte(d.staddr))^:=pcmdskip
			exit
		fi
	od
end

global func pci_loadbf(word a, i, j)word=
!a.[i..j]:=x; return new a
	u64 mask                    ! ...0000000111100000    i=5, j=8, n=4
	int n

	if j<i then swap(i,j) fi
	n:=j-i+1					! width of bitfield

	mask:=inot(inot(0) << n)<<i

	return (a iand mask)>>i
end

global func pci_storebf(word a, i, j, x)word =
!a.[i..j]:=x; return new a
	u64 mask                    ! ...0000000111100000    i=5, j=8, n=4
	u64 n

	if j<i then swap(i,j) fi
	n:=j-i+1					! width of bitfield

	mask:=inot(inot(0) << n)<<i

	x:=x<<i iand mask

	a iand inot(mask) ior x
end
