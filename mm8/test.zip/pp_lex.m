!lex

ref char lxstart, lxsptr

macro hashc(hsum,c) = hsum<<4-hsum+c
macro hashw(hsum)   = hsum<<5-hsum

global const hstsize	= 65536
global const hstmask	= hstsize-1

global [0:hstsize]psymbol	hashtable
global psymbol stvoid

[0..255]char alphamap
const cr=13, lf=10

global psymbol currproc=cast(1234)

global proc lex=
!read next token into lx
	[256]char str
	int c,hsum,hashindex,length, hasdot

	IF LX.SYMBOL=EOLSYM THEN ++LX.LINENO FI

	lx.value:=0

	doswitch lxstart:=lxsptr; c:=lxsptr++^
	when 'A'..'Z','a'..'z','_','$','.' then
		hsum:=c
		hasdot:=0
		str[1]:=c
		length:=1

		while alphamap[c:=lxsptr++^] do
			str[++length]:=c
			hsum:=hashc(hsum,c)
			hasdot ior:= int(c='.')
		od
		--lxsptr

		str[++length]:=0
		lookup(str, hashw(hsum))
		lx.symbol:=namesym
		lx.symptr.hasdot:=hasdot

		return

	when '0'..'9' then
		if c='0' and lxsptr^ in ['x', 'X'] then
			++lxsptr
			readhex()
		else
			--lxsptr
			readdec(0)
		fi
		return

	when '-' then
		if lxsptr^ not in '0'..'9' then lxerror("-123") fi
		readdec(1)
		return

	when '!', ';' then			!comment to eol or blank line
		while (c:=lxsptr++^) not in [lf, 0] do od
		if c=0 then --lxsptr fi

		lx.symbol:=eolsym
		return

	when '#','%' then					!label
		if lxsptr^ not in '0'..'9' then lxerror("Label?") fi
		readdec(0)
		lx.symbol:=(c='#'|labelsym|loclabelsym)
		return

	when ' ', '\t', cr then				!white space

	when ':' then
		lx.symbol:=colonsym
		return

	when '/' then
		lx.symbol:=divsym
		return

	when '&' then
		lx.symbol:=addrsym
		return

	when '"' then
		readstring()
		return

	when lf then
		lx.symbol:=eolsym
		return

	when 0 then		!eof
		--lxsptr
		lx.symbol:=eofsym
		return

	else
CPL =C
		lxerror("Bad token")

	end doswitch

end

global proc startlex(ichar source)=
	lxstart:=lxsptr:=source
	lx.lineno:=1

end

proc inithashtable=
	[16]char str

	for i in pclnames.bounds do
		addreservedword(pclnames[i], opcode_rw, i)
	od
	for i in pstdnames.bounds do
		addreservedword(pstdnames[i], type_rw, i)
	od

	for i in eq_cc .. gt_cc do
		strcpy(str, "jump")
		strcat(str, ccnames[i])
		addreservedword(str, jumpcc_rw, i)
		strcpy(str, "set")
		strcat(str, ccnames[i])
		addreservedword(str, setcc_rw, i)
	od

	addreservedword("infinity", inf_rw, 0)

end

global proc printhashtable=
	psymbol d

	for i:=0 to hstmask do
		d:=hashtable[i]
		if d then
			println i, d.name, d.opcode, d.mode, rwnames[d.ksymbol]
		fi
	od
end

global proc addreservedword(ichar name, int ksymbol, subcode) =

	if lookup(name, gethashvaluez(name)) then
		lxerror(addstr("PCI:Dupl name:",name))
	fi

	lx.symptr.ksymbol:=ksymbol				!opcode/jumpcc/setccsym
	if ksymbol<>type_rw then
		lx.symptr.opcode:=subcode			!pcl code or cc code
	else
		lx.symptr.mode:=subcode				!typesym
	fi
end

func lookup(ref char name, int hashindex0)int=
!lookup rawnamesym with details in lx
!name points to zero-terminated string in temp buffer
!hash value already worked out in lxhashvalue
!in either case, lx.symptr set to entry where name was found, or will be stored in
	int wrapped, hashindex,INDEX,n
	psymbol d
	int j

	j:=hashindex0 iand hstmask

	d:=hashtable[j]
	wrapped:=0

	do
		if d=nil then exit fi

		if strcmp(d.name, name)=0 then	!match
			lx.symptr:=d
			lx.ksymbol:=d.ksymbol
			return 1
		fi

		if ++j>=hstsize then
			if wrapped then
				lxerror("Hashtab full")
			fi
			wrapped:=1
			j:=0
		fi
		d:=hashtable[j]
	od

!exit when not found; new name will go in entry pointed to by lxsymptr

	d:=pc_makesymbol(name, null_id)
	pc_addsymbol(d)
	hashtable[j]:=d

	lx.symptr:=d
	lx.ksymbol:=0

	return 0
end

proc readdec(int neg)=
	int c
	ref char dest, destend, pstart
	int length
	[1024]byte str
	word a

	pstart:=lxsptr

	dest:=&.str
	destend:=dest+str.len-10
	a:=0

	do
		if (c:=lxsptr++^) in '0'..'9' then
			a:=a*10+c-'0'
			dest++^:=c
		elsif c in ['e','E'] then
			lxsptr:=pstart
			readreal(neg)
			return
		elsif c='.' then
			lxsptr:=pstart
			readreal(neg)
			return

		else
			--lxsptr
			exit
		fi

		if dest>=destend then lxerror("Numlit too long") fi
	end
	length:=dest-&.str

	if length>20 or length=20 and strncmp(&.str, "18446744073709551615", 20) then
		lxerror("u64 overflow")
	fi

	lx.symbol:=intsym
	lx.value:=(neg|-a|a)
end

proc readhex=
	int c
	ref char dest, destend, pstart
	int length
	[1024]byte str
	word a

	pstart:=lxsptr

	dest:=&.str
	destend:=dest+str.len-10
	a:=0

	do
		if (c:=lxsptr++^) in '0'..'9' then
			a:=a*16+c-'0'
			dest++^:=c

		elsif c in 'A'..'F' then
			dest++^:=c
			a:=a*16+c-'A'+10
		elsif c in 'a'..'f' then
			dest++^:=c-32
			a:=a*16+c-'a'+10

		else
			--lxsptr
			exit
		fi

		if dest>=destend then lxerror("Numlit too long") fi
	end
	length:=dest-&.str

	if length>16 then
		lxerror("u64 overflow")
	fi

	lx.symbol:=intsym
	lx.value:=a
end

proc readreal(int neg)=
!at '.', or had been in middle of int where . or e were seen, back at the start

	int c,n,negexpon,dotseen,length, fractlen, expon, expseen
	real x
	[1024]char str
	ichar dest, destend, pexpon

	dest:=&.str
	destend:=dest+str.len-100
	length:=negexpon:=dotseen:=expseen:=expon:=fractlen:=0

	do
		if (c:=lxsptr++^) in '0'..'9' then
			dest++^:=c
			++length
			if dotseen then ++fractlen fi
		elsif c= '.' then
			if dotseen then --lxsptr; exit fi
			dotseen:=1
			dest++^:=c


		elsif c in ['e','E'] then
			if expseen then lxerror("double expon") fi
			expseen:=1
			dest++^:=c
			while lxsptr^=' ' do ++lxsptr od
			if lxsptr^ in ['+','-'] then
				if lxsptr^='-' then negexpon:=1 fi
				dest++^:=lxsptr++^
			fi

			expon:=0
			do
				if (c:=lxsptr++^) in '0'..'9' then
					expon:=expon*10+c-'0'
					dest++^:=c
					if dest>=destend then lxerror("expon?") fi

				else
					--lxsptr
					exit all
				fi
			od

		else
			--lxsptr
			exit
		fi

		if dest>=destend then lxerror("r64lit too long") fi
	od
	dest^:=0

	lx.xvalue:=strtod(str,nil)
	if neg then lx.xvalue:=-lx.xvalue fi
	lx.symbol:=realsym
end

function gethashvaluez(ichar s)int=
!get identical hash function to that calculated by lexreadtoken
!but for a zero-terminated string
!ASSUMES S is lower-case, as conversion not done
	int c,hsum

	if s^=0 then return 0 fi

	hsum:=s++^

	do
		c:=s++^
		exit when c=0
		hsum:=hashc(hsum,c)
	od
	return hashw(hsum)
end

proc start=

	for i:=0 to 255 do
		if i in 'A'..'Z' or i in 'a'..'z' or
			i in '0'..'9' or i in ['$', '_', '.'] then
			alphamap[i]:=1
		fi
	od

	inithashtable()
!	printhashtable()

end

proc lxerror(ichar mess)=
	println "LEX error:",mess,"on line:",lx.lineno
	println
	stop 1
end

proc readstring=
	ichar s,t
	int c, d, length, hasescape
	[8]char str

	lx.symbol:=stringsym
	s:=lxsptr

!do a first pass that terminates length of final string
	length:=0
	hasescape:=0

	doswitch c:=lxsptr++^
	when '\\' then			!escape char
		c:=tolower(lxsptr^)
		++lxsptr
		hasescape:=1

		switch c
		when 'a','b','c','e','r','f','l','n','s','t','v','y','z','0','"','q','\\','\'' then
			++length
		when 'w' then
			++length
		when 'x' then	!2-digit hex code follows
			lxsptr+:=2
			++length
		else
			lxerror("Bad str escape")
		end switch
	when '"' then
		if c='"' then		!terminator char
			exit
		else
			++length
		fi
	when cr,lf,0 then
		lxerror("String not terminated")
	else
		++length
	end doswitch

	if length=0 then
		lx.svalue:=""
		return
	elsif not hasescape then
		lx.svalue:=pcm_copyheapstringn(s,length)
		return
	fi

!need to copy string to dest and expand the escape codes

	lx.svalue:=t:=pcm_alloc(length+1)

	do
		switch c:=s++^
		when '\\' then			!escape char
			switch c:=tolower(s++^)
			when 'c','r' then		!carriage return
				c:=cr
			when 'l','n' then		!linefeed, or linux/c-style newline
				c:=lf
			when 't' then			!tab
				c:=9
			when 'x' then	!2-digit hex code follows
				c:=0
				to 2 do
					case d:=s++^
!					switch d:=s++^
					when 'A','B','C','D','E','F' then
						c:=c*16+d-'A'+10
					when 'a','b','c','d','e','f' then
						c:=c*16+d-'a'+10
					when '0','1','2','3','4','5','6','7','8','9' then
						c:=c*16+d-'0'
					else
						lxerror("Bad \\x code")
					end
				od
			when '"' then		!embedded double quote
				c:='"'
			when '\\' then
				c:='\\'
			when '\'' then			!embedded single quote
				c:='\''
			else
				str[1]:=c; str[2]:=0
				lxerror(addstr("Unknown string escape: ",str))
			end
		when '"' then		!possible terminators
			if c='"' then		!terminator char
				if s^=c then		!repeated, assume embedded term char
					++s
				else			!was end of string
					exit
				fi
			fi
		when cr,lf,0 then
			lxerror("String not terminated")
		end switch

		t++^:=c
	od

	t^:=0
end

global proc printlx=
	psymbol d

	print lx.lineno,,":",symbolnames[lx.symbol],$

	case lx.symbol
	when namesym then
		d:=lx.symptr
		print d.name,$

		case lx.ksymbol
		when opcode_rw then
			print "(Opcode)"

		when jumpcc_rw, setcc_rw then
			print "(Jump/setcc:",ccnames[d.opcode],,")"

		when type_rw then
			print "(Type:",strpmode(d.mode),,")"
		else
			print "(Identifier)"
		esac

	when intsym then print lx.value
	when realsym then print lx.xvalue
	when stringsym then fprint """#""",lx.svalue
	when labelsym then print "#",,lx.value
	when loclabelsym then print "%",,lx.value
	esac
	println
end


