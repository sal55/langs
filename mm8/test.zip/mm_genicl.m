global int retindex
global int initstaticsindex

const maxnestedloops	= 50

global [maxnestedloops,4]int loopstack
global int loopindex							!current level of nested loop/switch blocks

unitrec zero_unit
global unit pzero=&zero_unit

global const maxblocktemps=50
global [maxblocktemps]symbol blockdefs
global int nblocktemps
global symbol blockretname

int nvarlocals, nvarparams

macro divider = genpc_comment("------------------------")

global function codegen_icl:int=
!generate code for module n
	int tt
	symbol d
	ref procrec pp

	tt:=clock()

	icl_start(nunits)

!	scansymbol(stprogram)

	pp:=staticlist
	while pp do
		d:=pp.def
		dostaticvar(d)
		pp:=pp.nextproc
	od

	genpc_comment("")

	pp:=proclist
	while pp do
		d:=pp.def
		genprocdef(currproc:=d)
		pp:=pp.nextproc
	od

	icl_end()

	if (debugmode and fshowicl) then
		icl_writeiclfile(iclfilename)
	fi

	icltime:=clock()-tt

	return 1
end

proc genprocdef (symbol p) =
	imodule ms

	ms:=modules[p.moduleno]
	nblocktemps:=0

	if p=ms.stmain and moduletosub[p.moduleno]=mainsubprogno then
		genmaindef(p)
		return
	elsif p=ms.ststart then
		genstartdef(p)
		return
	fi

	mlineno:=p.pos
	doprocdef(p)

	retindex:=createfwdlabel()

	divider()
	evalunit(p.code)
	divider()

	definefwdlabel(retindex)

	genreturn()
	checkreturn(p)

	genpc(kendproc)

	genpc_comment("")
end

proc checkreturn(symbol p)=
	if p.mode<>tvoid then
		if not checkblockreturn(p.code) then
			gerror_s("Function needs explicit return: ",p.name)
		fi
	fi
end

proc dostaticvar(symbol d)=

	if d.isimport then return fi

	if d.scope = program_scope and d.name^='$' then
		if eqstring(d.name,"$cmdskip") then
			d.scope:=export_scope				!export from mlib subprog
		fi
	fi

	if d.atvar=1 then
		return
	elsif d.code then
		genpc(kistatic,genmem_d(d))
		setmode(d.mode)
		icl_setalign(getalignment(d.mode))
		genidata(d.code)
	else
dozstatic:
		genpc(kzstatic,genmem_d(d))
		setmode(d.mode)
		icl_setalign(getalignment(d.mode))
	fi

end

proc genidata(unit p,int doterm=1, am='A',offset=0)=
	int t,tbase
	unit q,a
	symbol d
	ref char s

	t:=p.mode
	mlineno:=p.pos
	tbase:=ttbasetype[t]

	case p.tag
	when jconst then
		if ttisref[t] then
			if t=trefchar then
				if p.svalue then
					genpc(kdq,genpc_string(p.svalue))
				else
					genpc(kdq,genpc_int(0))
				fi
			else
				genpc(kdq,genpc_int(p.value))
			fi
		elsif ttisreal[t] then
			case ttsize[t]
			when 4 then
				genpc(kdd,genpc_real32(p.xvalue))
			when 8 then
				genpc(kdq,genpc_realimm(p.xvalue))
			else
				gerror_s("IDATA/REAL:",strmode(t),p)
			esac

		elsif ttbasetype[t]=tarray then
!CPL "GENDATA/CONST ARRAY"
!GENPC_COMMENT("<CONST ARRAY>")
			IF P.STRTYPE=0 THEN GERROR("IDATA/ARRAY/NOT BLOCKDATA") FI
!			s:=p.svalue
!			to p.slength do
!				genpc(kdb, genpc_int(s++^))
!			od
			genpc(kdata, genpc_data(p.svalue, p.slength))

		else						!assume int/word
			case ttsize[getmemmode_m(p)]
			when 1 then
				genpc(kdb,genpc_int(p.value))
			when 2 then
				genpc(kdw,genpc_int(p.value))
			when 4 then
				genpc(kdd,genpc_int(p.value))
			when 8 then
				genpc(kdq,genpc_int(p.value))
			when 16 then
				genpc(kdq,genpc_int(p.range_lower))
				genpc(kdq,genpc_int(p.range_upper))
			else
				gerror_s("IDATA/INT:",strmode(t),p)
			esac

		fi

	when jmakelist then
		q:=p.a
		while q do
			genidata(q)
			q:=q.nextunit
		od

	when jname then
		d:=p.def
		case d.nameid
		when staticid,procid,dllprocid then
			genpc((am='P' or ttsize[t]=8|kdq|kdd), genmemaddr_d(d))
			if offset then
				icl_setscale(1)
				icl_setoffset(offset)
			fi
		when labelid then
			if d.index=0 then d.index:=++mlabelno fi
			genpc(kdq, genpc_label(d.index))
		else
			gerror("Idata &frameXXX")
		esac
		return
	when jconvert then
		genidata(p.a)
	when jshorten then
		a:=p.a
		case ttsize[t]
		when 1 then
			genpc(kdb,genpc_int(a.value))
		when 2 then
			genpc(kdw,genpc_int(a.value))
		when 4 then
			genpc(kdd,genpc_int(a.value))
		else
			gerror_s("IDATA/SHORTEN:",strmode(t),p)
		esac

	when jaddrof,jaddroffirst then
		genidata(p.a,am:'P',offset:(p.b|p.b.value|0))
	else
		gerror_s("IDATA: ",jtagnames[p.tag],p)

	esac
end

global function genmem_u(unit p)icl=
	return genpc_mem(p.def)
end

global function genmem_d(symbol d)icl=
	return genpc_mem(d)
end

global proc genpushmem_d(symbol d)=
	genpc(kload,genpc_mem(d))
end

global function genmemaddr_d(symbol d)icl=
	return genpc_memaddr(d)
end

global proc genpushmemaddr_d(symbol d)=
	genpc(kload,genpc_memaddr(d))
end

global proc setmode(int m)=
	icl_settype(geticlmode(m),ttsize[m])
end

global proc setmode_u(unit p)=
	icl_settype(geticlmode(p.mode),ttsize[p.mode])
end

global function definelabel:int =
	genpc(klabel,genpc_label(++mlabelno))
	return mlabelno
end

global function createfwdlabel:int =
	return ++mlabelno
end

global proc definefwdlabel(int lab) =
	genpc(klabel,genpc_label(lab))
end

global proc genreturn=
!assume returning from currproc
	case currproc.nretvalues
	when 0 then
		genpc(kretproc)
	when 1 then
		genpc(kretfn)
		setmode(currproc.mode)

	else
		genpc_x(kretfn,currproc.nretvalues)
	esac
end

global function reversecond(int iclop)int=
!reverse conditional operator
	case iclop
	when keq then iclop:=kne
	when kne then iclop:=keq
	when klt then iclop:=kge
	when kle then iclop:=kgt
	when kge then iclop:=klt
	when kgt then iclop:=kle
	esac

	return iclop
end

global function reversecond_order(int iclop)int=
	case iclop
	when keq then iclop:=keq
	when kne then iclop:=kne
	when klt then iclop:=kgt
	when kle then iclop:=kge
	when kge then iclop:=kle
	when kgt then iclop:=klt
	esac

	return iclop
end

global proc stacklooplabels(int a,b,c)=
!don't check for loop depth as that has been done during parsing
	++loopindex
	if loopindex>maxnestedloops then
		gerror("Too many nested loops")
	fi

	loopstack[loopindex,1]:=a
	loopstack[loopindex,2]:=b
	loopstack[loopindex,3]:=c

end

global function findlooplabel(int k,n)int=
!k is 1,2,3 for label A,B,C
!n is a 1,2,3, according to loop nesting index
	int i

	i:=loopindex-(n-1)		!point to entry
	if i<1 or i>loopindex then gerror("Bad loop index") fi
	return loopstack[i,k]
end

global proc genpc_sysfn(int fnindex, unit a=nil,b=nil,c=nil)=
!CPL "GENSYSFN"
	genpc_sysproc(fnindex, a,b,c, 1)
end

global proc genpc_sysproc(int fnindex, unit a=nil,b=nil,c=nil, int asfunc=0)=
	int nargs:=0, opc
	symbol d
	icl p
	opc:=0

	genpc(ksetcall)
	p:=pccurr

	if c then evalunit(c); genpc(ksetarg); ++nargs fi
	if b then evalunit(b); genpc(ksetarg); ++nargs fi
	if a then evalunit(a); genpc(ksetarg); ++nargs fi

	p.nargs:=nargs

	d:=getsysfnhandler(fnindex)
	if d then
		genpc((asfunc|kcallf|kcallp), genpc_memaddr(d))
		icl_setnargs(nargs)
	else
		genpc((asfunc|kcallf|kcallp), genpc_nameaddr(sysfnnames[fnindex]+3))
	fi
	pccurr.nargs:=nargs
end

proc start=
	zero_unit.tag:=jconst
	zero_unit.mode:=ti64
	zero_unit.value:=0
	zero_unit.resultflag:=1
end

global function getsysfnhandler(int fn)symbol p=
	[300]char str
	int report

	if sysfnhandlers[fn] then
		return sysfnhandlers[fn]
	fi

	strcpy(str,"m$")
	strcat(str,sysfnnames[fn]+3)	!"sf_stop" => "m$stop"

	ref procrec pp:=proclist
	while pp, pp:=pp.nextproc do
		if eqstring(pp.def.name, str) then
			sysfnhandlers[fn]:=pp.def
			return pp.def
		fi
	od

	report:=passlevel>asm_pass

	if report then
		println "Sysfn not found:",&.str
	fi
	if fn<>sf_unimpl then
		p:=getsysfnhandler(sf_unimpl)
		if p=nil and report then
			gerror("No m$unimpl")
		fi
		return p
	fi

	return nil
end

!proc scansymbol(symbol d)=
!	symbol e
!
!	case d.nameid
!	when programid,moduleid then
!	when dllprocid then
!CPL "SS DLLPROC",D.NAME
!		if d.used then
!			
!			s
!
!	else
!		return
!	esac
!
!	e:=d.deflist
!
!	while e, e:=e.nextdef do
!		scansymbol(e)
!	od
!end

global proc genpushint(int a)=
	genpc(kload, genpc_int(a))
end

global proc genpushreal(real x)=
	genpc(kload,genpc_real(x))
end

global proc genpushreal32(real x)=
	genpc(kload,genpc_real32(x))
end

global proc genpushstring(ichar s)=
	genpc(kload,genpc_string(s))
end

proc genmaindef(symbol p)=
	symbol d

	mlineno:=p.pos
	doprocdef(p)

	retindex:=createfwdlabel()
	for i to nsubprogs when i<>mainsubprogno do
		d:=modules[subprogs[i].mainmodule].ststart
		docallproc(d)
	od
	d:=modules[subprogs[mainsubprogno].mainmodule].ststart
	docallproc(d)

	divider()
	evalunit(p.code)
	divider()

	definefwdlabel(retindex)

	genpc(kload,genpc_int(0))
	genpc(kstop)
	genreturn()

	genpc(kendproc)
	genpc_comment("")
end

proc genstartdef(symbol p)=
	symbol d
	int lead:=0, m,s

	m:=p.moduleno
	s:=p.subprogno

	if s=mainsubprogno and p.moduleno=subprogs[s].mainmodule then
		LEAD:=1
	elsif p.moduleno=subprogs[s].firstmodule then
		LEAD:=2
	fi

	mlineno:=p.pos
	doprocdef(p)

	retindex:=createfwdlabel()

	if lead then
		for i to nmodules when moduletosub[i]=s and i<>m do
			d:=modules[i].ststart
			docallproc(d)
		od
	fi

	divider()
	evalunit(p.code)
	divider()

	definefwdlabel(retindex)

	genreturn()

	genpc(kendproc)
	genpc_comment("")
end

proc initstaticvar(symbol d)=
	if d.code then
		evalunit(d.code)
	fi
!	if d.equals=3 then
!		genpc_comment("<deepcopy needed>")
!!*!				genpc(kcopy)
!	fi
	genpc(kstore,genmem_d(d))
end

proc docallproc(symbol d)=
!call a simple proc, eg. start(), with no args
	return unless d
	genpc(ksetcall)
	icl_setnargs(0)

	genpc(kcallp, genmemaddr_d(d))
end

global function newblocktemp(int m)symbol=
	[16]char str
	symbol d

	if nblocktemps>maxblocktemps then
		gerror("Too many block temps")
	fi
	++nblocktemps

	fprint @str,"$T#",nblocktemps
	d:=getduplnameptr(currproc,addnamestr(str),frameid)
	d.used:=1
	ADDDEF(CURRPROC,D)

	d.mode:=m
	blockdefs[nblocktemps]:=d
	d
end

proc doprocdef(symbol p)=
	genpc((p.isthreaded|kthreadedproc|kprocdef),genmem_d(p))
	setmode(p.mode)
	iclprocdef:=pccurr

end
