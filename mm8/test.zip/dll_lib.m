importdll dll =

    func testfn(i64 a,b,r64 c,d,i64 e,r64 f) => i64
end

