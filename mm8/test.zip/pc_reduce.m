export proc pcl_reducetest=
	int nn, seqno, lab, lab2, nargs
	pcl pc, newpc, pcnext, pcnext2, pcproc
	ref[]u16 labelmap
	psymbol pdef
	[maxcalldepth]pcl callstack
	int ncall
	int nprocs:=0, nleaf:=0, nallparams:=0, nalllocals:=0, offset

	nn:=pccurr-pcstart+1

!CPL =REDUCELABELS
	goto skip unless reducelabels

	pc:=pcstart
	labelmap:=pcm_allocz(mlabelno*u16.bytes)

	while pc<=pccurr, ++pc do
		case pc.opcode
		when klabel then				!don't include these
!			labelpclmap[pc.labelno]:=pc			!map labelno to pcl instr
		when kassem then
			if icheckasmlabel then
				lab:=icheckasmlabel(pc.asmcode)		!non-zero means a label number from ast
				if lab then
					++labelmap[lab]
				fi
			fi
!
		else
			if pc.opndtype=label_opnd then
				++labelmap[pc.labelno]
			fi
		esac
	od

skip:
	pc:=pcstart
	newpc:=pcstart-1			!point to last copied instr (none to start)
	seqno:=0

	to nn do
		pcnext:=pc+1

		if nargs:=pclargs[pc.opcode] then
			if nargs=9 then			!explicit calls
				nargs:=pc.nargs
			fi
			pinfo.nmaxargs := max(pinfo.nmaxargs, nargs)
		fi

!		if pc.mode=tpblock and pinfo then pinfo.hasblocks:=1 fi
		if pc.mode=tpblock and pinfo and pc.size<>16 then pinfo.hasblocks:=1 fi

		case pc.opcode
		when kcomment then

		when klabel then
			if not reducelabels then recase else fi
			if labelmap[pc.labelno] then
				recase else
			fi			!else skipped

		when kproc,ktcproc then
			++nprocs
			pdef:=pc.def
			pdef.pcaddr:=newpc+1
			pinfo:=pcm_alloc(procinforec.bytes)
			pdef.info:=pinfo
			pinfo.isleaf:=1
			pinfo.nparams:=pdef.nparams
			pinfo.nlocals:=pdef.nlocals
			nallparams+:=pdef.nparams
			nalllocals+:=pdef.nlocals
			ncall:=0
			pcproc:=newpc+1

			recase else

		when kcallp, kcallf, kicallp, kicallf then
			pinfo.isleaf:=0
			--ncall
			recase else

		when ksetcall then
!			if ncall then
!				for i:=ncall downto 1 do
!					callstack[i].simple:=0
!				od
!			else
!				pc.simple:=1
!			fi
			++newpc
			newpc^:=pc^
			newpc.seqno:=++seqno
			callstack[++ncall]:=newpc

		when kendproc then
			if pinfo.isleaf then ++nleaf fi
			pinfo:=nil

			recase else

		when kassem then
			pinfo.assemused:=1
			recase else

		when kiload, kistore then
			if newpc^.opcode=kaddpx and pc.mode<>tpblock then
				newpc.mode:=pc.mode
				newpc.opcode:=(pc.opcode=kiload|kiloadx|kistorex)
			else
				recase else
			fi

		when kwiden then
			if pcnext.opcode=ktruncate and pc.mode2=pcnext.mode2 then
				++pc				!widen and truncate cancel out
			elsif pcnext.opcode in [kjumpf, kjumpt] then
				pcnext.mode:=pc.mode2			!widen t/u; jumpf t -> jumpf u

			else
				recase else
			fi
		
		when ktruncate then
			if newpc.opcode in [kload, kiload, kiloadx] and newpc.mode=pc.mode2 then
					!truncating to same width (widen has been removed)
			else
				recase else
			fi

		when kload then				!addpx/load imm/addpx -> single addpx
			if pc.opndtype=int_opnd and pcnext.opcode=newpc.opcode=kaddpx then
				newpc.extra +:= pc.value*pcnext.scale+pcnext.extra
				++pc					!skip this load and following addpx
			elsif pcnext.opcode=kunload then
				++pc					!skip load/unload
			else
				recase else
			fi

!		when kaddpx then
!			if newpc.opcode=kload and newpc.opndtype=int_opnd and pcnext.opcode=kload and
!				(pcnext+1).opcode=kaddpx then
!				pcnext2:=pcnext+1
!				pcnext2.extra+:=newpc.value*pc.scale+pc.extra
!				newpc^:=pcnext^				!skip loadimm and 1st addpx
!				pc:=pcnext2					!process next addpx next
!CPL "REDUCE: LOAD IMM/ADDPX/LOAD/ADDPX"
!!CPL "REDUCE: LOAD IMM/ADDPX/LOAD IMM/ADDPX"
!			fi
!
!			recase else

		else
			++newpc
			newpc^:=pc^
			newpc.seqno:=++seqno

			if newpc.opndtype=memaddr_opnd then
				unless newpc.opcode=kload and newpc.inplace then
					newpc.def.addrof:=1
				end
			fi

		esac
!skip:
		++pc
	od

	pccurr:=newpc
	pcm_free(labelmap, mlabelno) when reducelabels
end

