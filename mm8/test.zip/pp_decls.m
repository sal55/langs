!decls


global record lexrec =
	union
		int		value			!for intsym
		real	xvalue			!for realsym
		ichar	svalue			!for stringsym
		psymbol	symptr			!for any reserved word/identifier
	end
	byte	symbol				!token: intsym, namesym etc
	byte	ksymbol				!0, or opcode/jumpcc/setcc when a reserved word
	byte	SPARE1
	byte	SPARE3
	u32		lineno			!within .pcl input source file
end

global lexrec lx

global enumdata []ichar symbolnames, []byte symtoopnd =
	(errorsym,		$,		0),					!           Extra info returned in:
	(namesym,		$,		mem_opnd),			! abc		(.svalue, .symptr)
!	(localsym,		$,		mem_opnd),			! abc		(.svalue, .symptr) (temp local symbols)
	(labelsym,		$,		label_opnd),		! #123		(.value)
	(loclabelsym,	$,		label_opnd),		! %123		(.value)
	(intsym,		$,		int_opnd),			! 123		(.value)
	(realsym,		$,		real_opnd),			! 1.23		(.xvalue)
	(stringsym,		$,		string_opnd),		! "abc"		(.svalue)
	(colonsym,		$,		0),			! :
	(addrsym,		$,		memaddr_opnd),		! &
	(divsym,		$,		0),					! /

!	(opcodesym,		$,		0),					! load etc	(.value)
!	(jumpccsym,		$,		0),					! jumpeq etc	(.value)
!	(setccsym,		$,		0),					! seteq etc	(.value)
!	(typesym,		$,		0),					! i64 etc	(.value)
	(eolsym,		$,		0),					! blank line or comment line
	(eofsym,		$,		0),					! end of file

end

!these codes appear in 
global enumdata []ichar rwnames =
	(not_rw,		$),					! load etc	(.value)
	(opcode_rw,		$),					! load etc	(.value)
	(jumpcc_rw,		$),					! jumpeq etc	(.value)
	(setcc_rw,		$),					! seteq etc	(.value)
	(type_rw,		$),					! i64 etc	(.value)
	(inf_rw,		$),					! infinity
end


