!Auxially routines called by genmcl's PX handlers

INT NNN
GLOBAL INT NAUXPROCS
GLOBAL INT NAUXNOFRAME

ref mclrec mclframesetup

proc allocregvars(int skipparams, isleaf)=
!skipparams is 1 when func is main or variadic

	[4]psymbol params, xparams				!exinclude leaf procs
	[4]psymbol leafparams, xleafparams		!leaf procs only
	[4]byte leafparamno, xleafparamno			!index needed for leaf proc to get right preg
	[32]psymbol locals, xlocals
	int nparams:=0, nxparams:=0
	int nleafparams:=0, nxleafparams:=0
	int nlocals:=0, nxlocals:=0, n, reg, xreg
	int nl, np
	int nlx, npx
	psymbol d

	if maxregvars+maxxregvars=0 then		!disabled
		return
	fi

!note: only args 1-4 considered, even though some may be unsuitable, leaving a slot
!for arg 5+ to fill
	if not skipparams then
		d:=currfunc.nextparam
		n:=0
		while d, d:=d.nextparam do
			++n
			if d.used and not d.atvar and not d.addrof and n<=4 then
				if not isleaf then
					if pint[d.mode] then
						if nparams<4 then
							params[++nparams]:=d
						fi
					elsif pfloat[d.mode] then
						if nxparams<4 then
							xparams[++nxparams]:=d
						fi
					fi
				else						!leaf
					if pint[d.mode] then
						if nleafparams<4 then
							leafparams[++nleafparams]:=d
							leafparamno[nleafparams]:=n
						fi
					elsif pfloat[d.mode] then
						if nxleafparams<4 then
							xleafparams[++nxleafparams]:=d
							xleafparamno[nxleafparams]:=n
						fi
					fi
				fi
			fi
		od
	fi

	d:=currfunc.nextlocal
	while d, d:=d.nextlocal do

		if d.used and not d.atvar and not d.addrof then
			if pint[d.mode] then
				if nlocals<locals.len then
					locals[++nlocals]:=d
				fi
			elsif pfloat[d.mode] and nxlocals<xlocals.len then
				xlocals[++nxlocals]:=d
			fi
		fi
	od

!now allocate regs
	if nlocals=0 then						!params only; no locals
		np:=min(maxregvars, nparams)		!(unlikely regvars is below 4)
		nl:=0
	elsif nparams=0 then					!locals only; no params, or is leaf
		nl:=min(maxregvars, nlocals)
		np:=0
	else									!both locals and params
		nl:=nlocals
		np:=nparams
		n:=np+nl-maxregvars					!n is excess number; neg is OK
		if n>0 then							!at least one short
			--np; --n						!lose one param
			if n>0 and np>0 then			!lose 2nd param
				--np; --n
			fi
			if n>0 then						!still short; lose excess from locals
				nl-:=n
			fi
		fi
	fi

!now allocate regvars

	reg:=r3
	for i to nl do
		d:=locals[i]
		d.reg:=reg
		isregvar[reg]:=1
		++reg
	od

!CPL =NL, =NP

	for i to np do
		d:=params[i]
		d.reg:=reg
		isregvar[reg]:=1
		++reg
	od

!do regvars for leaf procs
	for i to nleafparams do
		d:=leafparams[i]
		reg:=leafparamno[i]+r10-1
		if reg=r10 then r10used:=1 fi
		if reg=r11 then r11used:=1 fi
		d.reg:=reg
		isregvar[reg]:=1
	od

!now allocate xregs
	if nxlocals=0 then						!params only; no locals
		npx:=min(maxxregvars, nxparams)		!(unlikely regvars is below 4)
		nlx:=0
	elsif nxparams=0 then					!locals only; no params, or is leaf
		nlx:=min(maxxregvars, nxlocals)
		npx:=0
	else									!both locals and params
		nlx:=nxlocals
		npx:=nxparams
		n:=npx+nlx-maxregvars					!n is excess number; neg is OK
		if n>0 then							!at least one short
			--npx; --n						!lose one param
			if n>0 and npx>0 then			!lose 2nd param
				--npx; --n
			fi
			if n>0 then						!still short; lose excess from locals
				nlx-:=n
			fi
		fi
	fi

!now allocate Xregvars

	reg:=r15
	for i to nlx do
		d:=xlocals[i]
		d.reg:=reg
		isxregvar[reg]:=1
		--reg
	od

	for i to npx do
		d:=xparams[i]
		d.reg:=reg
		isxregvar[reg]:=1
		--reg
	od

!do regvars for leaf procs
	for i to nxleafparams do
		d:=xleafparams[i]
		reg:=xleafparamno[i]+r0-1
		d.reg:=reg
		isxregvar[reg]:=1
	od
end


global proc initproc(psymbol d)=
!initialise genmcl pass through proc pcl code
	psymbol e
	ref procinforec pinfi

	clear regset
	clear xregset
	clear workregs
	clear workxregs
	clear isregvar
	clear isxregvar
	int reg, xreg, n, r, npregs

!NEW CODE REQUIRED WHICH SETS NWORK/X/REGS
!Works with INFO=NIL, then not critical, but will be some of R0-R9
!Or uses info to decide how many and where; then they will be
!a combo of R0-R2, R9 downtowards R3 (depends on maxregvars), and possibly R12/R12
	nworkregs:=3
	workregs[r0]:=1					!these are always given
	workregs[r1]:=1
	workregs[r2]:=1

	nworkxregs:=2
	workxregs[r4]:=1
	workxregs[r5]:=1
	maxregvars:=maxxregvars:=0
	npregs:=0
	pinfo:=currfunc.info

	if pinfo=nil then
!NOINFO:
!CPL "NO PINFO"

		nworkregs:=10
		nworkxregs:=12
		for r in r3..r9 do workregs[r]:=1 od
		for r in r6..r15 do workxregs[r]:=1 od
	else	
!GOTO NOINFO
		npregs:=min(4, max(currfunc.nparams, pinfo.nmaxargs))
		nworkregs:=4

		if pinfo.hasblocks then ++nworkregs fi
		nworkxregs:=5

		n:=nworkregs-3

		if npregs<=3 and n then		!use at least one preg
			workregs[r13]:=1
			--n
			if npregs<=2 and n then
				workregs[r12]:=1
				--n
			fi
		fi

		r:=r9					!do any remaining workregs from r9 downwards
		to n do					!allocate from r9 down
			workregs[r--]:=1
		od

		r:=r6
		to nworkxregs-2 do					!allocate from r6 up
			workxregs[r++]:=1
		od
	fi

	for r in r3..r9 when not workregs[r] do ++maxregvars od
	for r in r6..r15 when not workxregs[r] do ++maxxregvars od

!CPL =NWORKREGS, =MAXREGVARS
!FOR R IN R0..R15 DO
!	IF WORKREGS[R] THEN CPL "WORK:", GETREGNAME(R) FI
!OD

!	println currfunc.name,,":",=nworkregs, =nworkxregs, =npregs, =MAXREGVARS, =MAXXREGVARS
!	cp "  "; for r in r0..r13 when workregs[r] do print getregname(r),$ od; cpl
!	cp "  "; for r in r0..r15 when workxregs[r] do print getxregname(r),$ od; cpl

	clear usedregs
	clear usedxregs
	clear pcltempflags
	r10used:=r11used:=0

	mstackdepth:=0
	noperands:=0

	frameoffset:=paramoffset:=framebytes:=0
	localshadow:=0

	nblocktemps:=0

	if d.mode=tpblock then
		e:=pc_makesymbol("$1x", misc_id)
		e.mode:=d.mode
		e.used:=1
		e.id:=param_id
		e.nextparam:=currfunc.nextparam
		e.owner:=currfunc
		currfunc.nextparam:=e
		blockretname:=e
	fi

	return unless fregoptim and currfunc.info
!CPL "DOING REGALLOC"

!.info will be available here

	if currfunc.info.assemused then
		return
	fi

	allocregvars(currfunc.ismain or currfunc.variadic, currfunc.info.isleaf)
end

global proc do_procentry(pcl p)=
	int retmode, ntemps, hasequiv, offset, size, reg
	mclopnd ax
	psymbol d
	[100]char str, newname
	int rr, ff

	setmclentry(mclprocentry)

	bspill:=bxspill:=0
!	if highreg>=r3 then bspill:=highreg-r2 fi		!no of regs d3..highreg
!	if highxreg>=r6 then bxspill:=highxreg-r5 fi	!no of xregs x6..highxreg

	unless currfunc.info and currfunc.info.assemused then
		for r in r3..r9 when usedregs[r] or isregvar[r] do ++bspill od

		for r in r6..r15 when usedxregs[r] or isxregvar[r] do ++bxspill od
	end

	d:=currfunc.nextparam
	while d, d:=d.nextparam do
		IF D.ATVAR THEN MERROR("@PARAM") FI
		if not d.reg then			!not a regvar
			d.offset:=paramoffset+16+(bspill+bxspill)*8
			genmc(m_define, mgenname(getdispname(d)), mgenint(d.offset))
		else						!assume regvar
			rr:=d.reg
			ff:=usedregs[rframe]
			d.reg:=0

			genmc(m_definereg, mgenmem(d), mgenreg(rr, d.mode))
			d.reg:=rr
			usedregs[rframe]:=ff
		fi
		paramoffset+:=8
	od

	retmode:=currfunc.mode

	d:=currfunc.nextlocal
	while d, d:=d.nextlocal do
!CPL "LOCAL", CURRFUNC.NAME, D.NAME, =STRPMODE(D.MODE), =D.ATVAR, =D.REG, =D.USED
		size:=psize[d.mode]
		if d.mode=tpblock then
			size:=d.size
		fi
		nextloop unless d.used				!also skips statics added in fixmain

		if d.atvar then
			hasequiv:=1

        elsif d.reg then
			rr:=d.reg
			ff:=usedregs[rframe]
			d.reg:=0
			genmc(m_definereg, mgenmem(d), mgenreg(rr, d.mode))
			d.reg:=rr
			usedregs[rframe]:=ff

        else
			frameoffset-:=roundsizetg(size)
			d.offset:=frameoffset
			genmc(m_define, mgenname(getdispname(d)), mgenint(d.offset))

		fi
	od

	ntemps:=0
	for i to maxoperands when pcltempflags[i] do
		++ntemps
		frameoffset-:=8
		ax:=pcltempopnds[i]
		ax.offset:=frameoffset
!		genmc(m_definetemp, mgenname(gettempname(currfunc,i)), mgenint(ax.offset))
		genmc(m_define, mgenname(gettempname(currfunc,i)), mgenint(ax.offset))
	od

	if currfunc.isthreaded then
		if currfunc.nlocals or currfunc.nparams then merror("Threaded proc has locals/params") fi
		if ntemps then merror("Threaded proc has temps") fi

!*!		if bspill or bxspill then merror("Threaded proc has spill regs") fi

		resetmclentry()
		return
	fi

	framebytes:=-frameoffset

	if (bspill+bxspill).odd then				!need an even number to keep stack alighnment correct
		unless framebytes iand 8 then
			framebytes+:=8
		end
	else
		if framebytes iand 8 then
			framebytes+:=8
		fi
	fi

	if localshadow then
		framebytes+:=32				!shadow space
	fi

!spill any bregs
	if bspill then
		for r:=r3 to r9 when usedregs[r] or isregvar[r] do
			genmc(m_push, mgenreg(r, tpu64))
		od
	fi

	if bxspill then
		ax:=mgenreg(r0, tpu64)
		for r:=xr6 to xr15 when usedxregs[r] or isxregvar[r] do
!			ax:=mgenindex(areg:rframe, size:8, offset:offset)
!			offset+:=8
			genmc(m_movq, ax, mgenxreg(r))
			genmc(m_push, ax)
		od
	fi

	MGENCOMMENT("?]]")
	MCLFRAMESETUP:=MCCODEX

	spillparams()

!MCOMM("COPY PARAMS TO REGVARS?")

	MCOMM("---------------")
	RESETMCLENTRY()
end

global proc do_procexit=
	mclopnd ax
	int offset

	MCOMM("---------------")
	if currfunc.isthreaded then
		genmc(m_ret)				!in case no jump out exists
		return
	fi

	SETMCLENTRYF(mclframesetup)

!CPL "PROCENTRY/", CURRFUNC.NAME, = FRAMEBYTES, CURRFUNC.NPARAMS, USEDREGS[RFRAME]
!	if framebytes or currfunc.nparams then
!CPL =FRAMEBYTES
	if framebytes or currfunc.nparams OR USEDREGS[RFRAME] then
		if usedregs[rframe] then
			genmc(m_push, dframeopnd)
			genmc(m_mov, dframeopnd, dstackopnd)
			pushstack(framebytes)
		else
			IF FRAMEBYTES THEN
				pushstack(framebytes+8)
			FI
		fi
	fi
	RESETMCLENTRYF()

	if framebytes or currfunc.nparams OR USEDREGS[RFRAME] then
!	if framebytes or currfunc.nparams then
		if usedregs[rframe] then
			popstack(framebytes)
			genmc(m_pop, dframeopnd)
		else
			IF FRAMEBYTES THEN
				popstack(framebytes+8)
			FI
		fi
	fi

	if bxspill then
		ax:=mgenreg(r10, tpu64)
		for r:=xr15 downto xr6 when usedxregs[r] do
			genmc(m_pop, ax)
			genmc(m_movq, mgenxreg(r), ax)
		od
	fi

	if bspill then
		for r:=r9 downto r3 when usedregs[r] do
			genmc(m_pop, mgenreg(r, tpu64))
		od
	fi

	genmc(m_ret)
end

proc spillparams=
	psymbol d
	mclopnd ax
	int offset:=16, regoffset:=0, xregoffset, firstoffset

	regoffset:=0

	d:=currfunc.nextparam

	if currfunc.variadic then				!C proc def using ...
		firstoffset:=d.offset				!param offsets may be pushed up

		for i:=currfunc.nparams to 3 do				!0-based; if nparams=2, loops over 2..3 as 0..1 are normal
			ax:=mgenindex(areg:rframe, size:8, offset:i*8+firstoffset)
			genmc(m_mov, ax, mgenreg(i+r10))
		od
	fi

	while d, d:=d.nextparam do
		if regoffset>3 then exit fi

		if d.used  then
			if not d.reg then
				ax:=mgenindex(areg:rframe, size:8, offset:d.offset)
				case d.mode
				when tpr64 then
					genmc(m_movq, ax, mgenxreg(regoffset+xr0))
				when tpr32 then
					genmc(m_movd, changeopndsize(ax,4), mgenxreg(regoffset+xr0))
				else
					genmc(m_mov, ax, mgenreg(regoffset+r10))
				esac
			elsif d.reg then
				if ispfloat(d.mode) then
					if d.reg>=xr4 then				!not in-situ param
						genmc(m_movq, mgenxreg(d.reg), mgenxreg(regoffset+xr0, d.mode))
					fi
				elsif d.reg<=r9 then				!not in-situ param
					genmc(m_mov, mgenreg(d.reg, d.mode), mgenreg(regoffset+r10,d.mode))
				fi
			fi
		fi

		offset+:=8
		++regoffset
	od

end

global proc do_jumptruefalse(pcl p, int cond)=
	mclopnd ax, bx

	ax:=loadopnd(zz, pmode)

	if ispint(pmode) then
		genmc(m_test, ax,ax)

	else
		bx:=getworkregm(pmode)
		genmc(m_xorps+ispwide(pmode), bx, bx)
		genmc(m_comiss+ispwide(pmode), ax, bx)
	fi

	genmc_cond(m_jmpcc, cond, mgenlabel(p.labelno))

	poppcl()
end

global proc do_bitwise(pcl p, int opc)=
	mclopnd ax,bx

	ax:=loadopnd(yy, pmode)
	bx:=getopnd(zz, pmode)

	genmc(opc, ax, bx)

	poppcl()
end

global proc do_shift(pcl p, int opc)=
	mclopnd ax, cx
	pcl y

	ax:=loadopnd(yy, pmode)

	y:=pclopnd[zz]

	if pclloc[zz]=pcl_loc and y.opndtype=int_opnd then
		genmc(opc, ax, mgenint(y.value))
	else
		genmc(m_push, mgenreg(r10)) when r10used
		cx:=loadparam(zz, tpu8, r10)
		genmc(opc,ax, cx)
		genmc(m_pop, mgenreg(r10)) when r10used
	fi
	poppcl()
end

proc setmclentry(ref mclrec p)=
!temporarily set mcl insertion before p

	mce_oldmccodex:=mccodex
	mccodex:=p
	mce_lastmcl:=p.lastmcl
	mce_nextmcl:=p.nextmcl
end

func resetmclentry:ref mclrec pnew =
!restore mcl insertion point to normal
!restireturn mcl instruction that followed	
	mccodex.lastmcl:=mce_lastmcl
	mccodex.nextmcl:=mce_nextmcl
	pnew:=mccodex
	mccodex:=mce_oldmccodex
	pnew
end

proc setmclentryf(ref mclrec p)=
!temporarily set mcl insertion before p

	mcf_oldmccodex:=mccodex
	mccodex:=p
	mcf_lastmcl:=p.lastmcl
	mcf_nextmcl:=p.nextmcl
end

func resetmclentryf:ref mclrec pnew =
!restore mcl insertion point to normal
!restireturn mcl instruction that followed	
	mccodex.lastmcl:=mcf_lastmcl
	mccodex.nextmcl:=mcf_nextmcl
	pnew:=mccodex
	mccodex:=mcf_oldmccodex
	pnew
end

global proc do_pushlowargs(int nargs, nvariadics=0, isptr=0, pstack=0)=
!

!nargs=0 to 4 /operands/, not using more than 4 slots
!load args to D10-13/X0-3
!does not do anything with the stack at all
! Params are categorised as follows:
! Variadic:
!   float:  load to both D and X registers
!   other:  load to D register only
! Normal/non-variadic:
!   float:  load to X register
!   other:  load to D register
!PSTACK is 1, if call* data structures ate not used, eg. via CALLRTS
!Then use mode info from pclstack

	mclopnd ax
	int j,k, nextireg, nextxreg, mode, imode, blockret
	psymbol dblock

	if nargs=0 then return fi

	if pstack then
		blockret:=0
	else
		blockret:=callblockret[ncalldepth]
	fi

	nextireg:=r10
	nextxreg:=xr0

	k:=0
	for i:=noperands downto noperands-nargs+1 do
		++k						!counts params from 1

		if k=1 and blockret then
			dblock:=newblocktemp(callblocksize[ncalldepth])
			dblock.used:=1
			genmc(m_lea, mgenreg(r10), mgenmem(dblock))

		else

			j:=i-isptr+BLOCKRET

!CPL STROPNDSTACK()
			if pstack then
				mode:=pclmode[j]				!will never be a block
			else
				mode:=callargmode[ncalldepth,k]
			fi

!CPL "PUSHLOW", =STRPMODE(MODE), =STRPMODE(CALLARGMODE[NCALLDEPTH,K], CALLARGSIZE[NCALLDEPTH, K])

			case mode
			when tpblock then
!CPL "PUSHLOW/BLOCK"
				ax:=loadparam(j, mode, nextireg)
				copyblockarg(ax, callargsize[ncalldepth,k], k)

			when tpr64, tpr32 then
				loadparam(j, mode, nextxreg)
!CPL "LOADXPARAM", STRPMODE(MODE)

				if nvariadics and k>=nvariadics then			!variadic floats go to both regs

!I need to move xmm reg to int reg
					imode:=(mode=tpr32|tpu32|tpu64)
					genmc(m_mov, mgenreg(nextireg, imode), mgenreg(nextxreg, mode))
				fi
			else
doint:
				loadparam(j, mode, nextireg)
			esac
		fi

		++nextireg
		++nextxreg
	od
end

global proc do_getretvalue(pcl p)=
	int reg,xreg,i,n, m
	[10]int modes

!MERROR("DOGETRETVAL")
!MCOMM("DOGETRETVAL")
	if (p+1).opcode=ktype then
		n:=0
		while (++p).opcode=ktype do
			modes[++n]:=p.mode
		od
		currpcl:=p-1

		for i:=n downto 1 do 
			m:=modes[i]
			pushpcl_reg(m, (ispfloat(m)|multxregs[i]|multregs[i]))
		od

	elsif p.mode then
		pushpcl_reg(p.mode, r0)

	fi
end

global func ismemaddr(int n)int=
	if pclloc[n]=pcl_loc and pclopnd[n].opndtype=memaddr_opnd then return 1 fi
	return 0
end

global proc do_incr(pcl p, int incrop, addop)=
	mclopnd mx

	mx:=getopnd_ind(zz, p.mode)

	if p.stepx=1 then
		genmc(incrop, mx)
	else
		genmc(addop, mx, mgenint(p.stepx))
	fi
	poppcl()
end

global proc do_incrload(pcl p, int incrop, addop)=
	mclopnd ax, mx

	mx:=getopnd_ind(zz, pmode)
	ax:=getworkreg_rm(pclreg[zz], pmode)

	if p.stepx=1 then
		genmc(incrop, mx)
	else
		genmc(addop, mx, mgenint(p.stepx))
	fi

	genmc(m_mov, ax, mx)

!now replace ax opnd with new value
	pclloc[zz]:=reg_loc
	pclopnd[zz]:=nil
	pclreg[zz]:=ax.reg
	pclmode[zz]:=pmode

end

global proc do_loadincr(pcl p, int incrop, addop)=
	mclopnd ax,mx

	mx:=getopnd_ind(zz, pmode)

	pushpcl_reg(pmode)			!to hold loaded value
	ax:=getopnd(zz, pmode)

	genmc(m_mov, ax, mx)

	if p.stepx=1 then
		genmc(incrop, mx)
	else
		genmc(addop, mx, mgenint(p.stepx))
	fi

	swapopnds(yy,zz)
	poppcl()
end

global proc do_for(pcl p, int incop, addop, cond)=
	pcl q,r
	mclopnd ax,bx,cx,dx,mx
	int reg

	q:=p+1
	r:=currpcl:=q+1

	mx:=mgenmem(q.def, pmode)

	if q.def.reg then
		if p.stepx=1 then
			genmc(incop, mx)
		else
			genmc(addop, mx, mgenint(p.stepx))
		fi
		ax:=mx
	else
		ax:=mgenreg(getworkireg())
		genmc(m_mov, ax,mx)
		if p.stepx=1 then
			genmc(incop, ax)
		else
			genmc(addop, ax, mgenint(p.stepx))
		fi
		genmc(m_mov, mx, ax)
	fi

	if r.opndtype=int_opnd then
		bx:=mgenint(r.value)
	else
		bx:=mgenmem(r.def)
	fi

	genmc(m_cmp, ax, bx)

	genmc_cond(m_jmpcc, cond, mgenlabel(p.labelno))
end

!global proc do_for(pcl p, int incop, addop, cond)=
!THIS VERSION USES JMPEQ, so that an upper limit of i64.max/u64.max is handled.
!But behaviour changes a little:
!  loop index after normal termination will be LIMIT not LIMIT+1 or LIMIT-1
!  loop index can't be modified inside the loop, so that it has a
!  value beyond the limit

!	pcl q,r
!	mclopnd ax,bx,cx,dx,mx
!	int reg, lab
!
!	q:=p+1
!	r:=currpcl:=q+1
!
!	lab:=++mlabelno
!
!	mx:=mgenmem(q.def, pmode)
!
!	if q.def.reg then
!		ax:=mx
!	else
!		ax:=mgenreg(getworkireg())
!		genmc(m_mov, ax,mx)
!	fi
!
!	if r.opndtype=int_opnd then
!		bx:=mgenint(r.value)
!	else
!		bx:=mgenmem(r.def)
!	fi
!
!	genmc(m_cmp, ax, bx)
!	genmc_cond(m_jmpcc, z_cond, mgenlabel(lab))
!
!	if q.def.reg then
!		if p.stepx=1 then
!			genmc(incop, ax)
!		else
!			genmc(addop, ax, mgenint(p.stepx))
!		fi
!	else
!		if p.stepx=1 then
!			genmc(incop, ax)
!		else
!			genmc(addop, ax, mgenint(p.stepx))
!		fi
!		genmc(m_mov, mx, ax)
!	fi
!
!	genmc(m_jmp, mgenlabel(p.labelno))
!
!	genmc(m_labelx,mgenlabel(lab))
!
!
!end

global func scaleindex(mclopnd ax, int scale)int=
!when scale is 1/2/3/4, return scale unchanged
!anything else, scale value in ax, return 1
	int n
	if scale in [1,2,4,8] then return scale fi

	mulimm(ax,scale)
	return 1
end

global proc mulimm(mclopnd ax, int n)=
!multiply operand in ax (a simple reg) by constant n
!will try efficient method if possible, otherwise use normal multiply 
	int shifts,m
	mclopnd bx

	case n
	when 0 then
		clearreg(ax)
		return
	when 1 then
		return
	when -1 then
		genmc(m_neg, ax)
		return
	esac

	shifts:=0
	m:=n

	while m.even do
		m>>:=1
		++shifts
	od

	if shifts then
		genmc(m_shl, ax, mgenint(shifts))
	fi

	case m
	when 1 then
		return
	when 3, 5, 9 then
		genmc(m_lea, ax, mgenindex(areg: ax.reg, ireg:ax.reg, scale:m-1))
	else						!mul needed anyway; forget the shift
		if shifts then
			mccodex.opcode:=m_imul2
			mccodex.b:=mgenint(n)
		else
!			genmc(m_imul2, ax, mgenint(n))

			bx:=getworkregm((ax.size=4|tpi32|tpi64))
			genmc(m_mov, bx, mgenint(n))
			genmc(m_imul2, ax, bx)

		fi
	esac
end

global func do_addrmode*(pcl p)mclopnd px =
!Top two stack elements are an array (yy) and index (zz)
!Return a operand which provdes the address mode to access the element,
!for either reading or writing
!The address mode will use 0, 1 or 2 registers. The registers may be 1 or 2
!associated with the pcl operands, or may be regvars.
!If for reading, caller will need to make their own arrangements for a dest reg.
!When Xb has to be loaded into a register anyway, then the caller can make use
!of that

	mclopnd ax,bx
	int scale, extra,offset, reg,regix
	psymbol d
	pcl q

	scale:=p.scale
	extra:=p.extra

	q:=isimmload(zz)
	if q then
		offset:=q.value*scale+extra	!for imm offset
	fi

	px:=nil

	if pclloc[yy]=regvar_loc then
!CPL "AM1"
		if pclloc[zz]=regvar_loc then		!regvar/regvar
			reg:=pclreg[zz]
			regix:=scaleregvar(reg,scale,zz)
			px:=mgenindex(areg:pclreg[yy],ireg:regix, offset:extra, scale:scale)
!
		elsif q then						!regvar/imm
			px:=mgenindex(areg:pclreg[yy], offset:offset)
		else								!regvar/any
			scale:=scaleindex(bx:=loadopnd(zz, pclmode[zz]),scale)
			px:=mgenindex(areg:pclreg[yy], ireg:bx.reg, scale:scale, offset:extra)
		fi

	elsif ismemaddr(yy) then
!CPL "AM2"
		d:=pclopnd[yy].def
!CPL D.NAME, IDNAMES[D.ID], =PHIGHMEM, =D.ID, STATIC_ID, IMPORT_ID
!		if d.id=static_id and phighmem=2 or D.ID=PARAM_ID AND D.MODE=TPBLOCK  then skip fi
		if d.id in [static_id, import_id] and phighmem=2 or D.ID=PARAM_ID AND D.MODE=TPBLOCK  then skip fi

		if pclloc[zz]=regvar_loc then			!memaddr/regvar
			reg:=pclreg[zz]
			regix:=scaleregvar(reg,scale,zz)
			px:=mgenindex(ireg:regix, def:d, offset:extra, scale:scale)
!
		elsif q then			!memaddr/imm
			px:=mgenindex(def:d, offset:offset)
		else							!memaddr/any
			scale:=scaleindex(bx:=loadopnd(zz, tpi64),scale)
			px:=mgenindex(ireg:bx.reg, def:d, offset:extra, scale:scale)
		fi
	else								!
skip:
!CPL "AM3"
		ax:=loadopnd(yy, tpu64)

		if pclloc[zz]=reg_loc then			!any/regvar
			reg:=pclreg[zz]
			regix:=scaleregvar(reg,scale,zz)
			px:=mgenindex(areg:ax.reg, ireg:regix, offset:extra, scale:scale)

		elsif q then						!any/imm	
			px:=mgenindex(areg:ax.reg, offset:offset)
		else
			scale:=scaleindex(bx:=loadopnd(zz, tpu64),scale)
			px:=mgenindex(areg:ax.reg, ireg:bx.reg, scale:scale, offset:extra)
		fi
	fi

	px.size:=psize[p.mode]

	return px
end

function scaleregvar(int reg, &scale, n)int=
!When scale is 1/2/3/4, return reg (a regvar) and scale unchanged;
!otherwise set up a new register for operand n
!Copy reg to it, and scale. Return new reg, and set scale to 1
	int regix
	mclopnd ax

	if scale in [1,2,4,8] then return reg fi

	regix:=getworkireg()
	ax:=mgenreg(regix)

	IF SCALE=16 THEN
		genmc(m_lea, ax, mgenindex(ireg:reg, areg:reg, scale:1))
		scale:=8

	ELSE
		genmc(m_mov,ax, mgenreg(reg))
		mulimm(ax,scale)
		scale:=1
	FI

	pclloc[n]:=reg_loc
	pclreg[n]:=regix
	pclmode[n]:=tpi64
	pclopnd[n]:=nil

	return regix
end

global proc dolea(mclopnd ax, px)=
!do 'lea ax, px`, but suppress in cases like 'lea d0,[d0]'
	unless px.regix=px.valtype=px.offset=0 and px.reg=ax.reg then

		genmc(m_lea, ax, px)
	end
end

global proc do_binto(pcl p, int opc, fopc)=
	mclopnd ax,bx,rx

	if ispfloat(pmode) then
		do_binto_float(p, fopc)
		return
	fi

	ax:=getopnd_ind(zz, p.mode)
	bx:=loadopnd(yy, p.mode)

	genmc(opc,ax,bx)
	poppcl()
	poppcl()
end

global proc do_binto_float(pcl p, int opc)=
	mclopnd px,bx,cx

	pushpcl_reg(pmode)		!z^:=y => y^:=x; z is temo

	px:=getopnd_ind(yy, pmode)
	bx:=getopnd(xx, pmode)
	cx:=getopnd(zz, pmode)

	genmc(m_mov, cx, px)
	genmc(opc+ispwide(pmode), cx, bx)
	genmc(m_mov, px,cx)

	poppcl()
	poppcl()
	poppcl()
end

global proc do_shiftnto(pcl p, int opc)=
!shift opc=shl/shr/sar, when both operands are on the stack
!first operand is address of dest
	mclopnd px, cx

	px:=getopnd_ind(zz, pmode)

	if pclloc[yy]=pcl_loc and pclopnd[yy].opndtype=int_opnd then
		genmc(opc, px, mgenint(pclopnd[yy].value))

	else
		genmc(m_push, mgenreg(r10)) when r10used

		cx:=loadparam(yy, tpu8, r10)
		genmc(opc, px, cx)

		genmc(m_pop, mgenreg(r10)) when r10used

	fi

	poppcl()
	poppcl()
end

global proc do_divrem(pcl p, int issigned, isdiv)=
!isdiv = 0/1/2 = rem/div/divrem
! Z' := Y % Z
	mclopnd ax, bx, px
	pcl q
	int opc, n, shifts
	byte fdivto:=0
	int locyy:=yy, loczz:=zz

	if p.opcode in [kidivto, kiremto] then
		swap(locyy, loczz)

		ax:=loadopnd(locyy, tpu64)
		fdivto:=1
		genmc(m_push, changeopndsize(ax,8))
		px:=makeopndind(ax, pmode)
		ax:=mgenreg(ax.reg, pmode)

		genmc(m_mov, ax, px)
	else
		ax:=loadopnd(locyy, pmode)
	fi

	q:=isimmload(loczz)

	if q and isdiv=1 then
		n:=q.value
		case n
		when 0 then
			merror("Divide by zero")
		when 1 then
			poppcl()
			return
		else
			shifts:=ispoweroftwo(n)
			if shifts AND NOT FDIVTO then
				genmc((issigned|m_sar|m_shr), ax, mgenint(shifts))
				poppcl()
				return
			fi
		esac
	fi 

	bx:=loadopnd(loczz, pmode)

	saverdx()
	fixdivopnds(locyy, loczz)
	bx:=loadopnd(loczz, pmode)			!in case regs have changed

	if issigned then
		opc:=
			case psize[pmode]
			when 8 then	m_cqo
			when 4 then	m_cdq
			when 2 then	m_cwd
			else merror("div/u8"); 0
			esac
		genmc(opc)

		opc:=m_idiv
	else
!		genmc(m_xorx, mgenreg(r11),mgenreg(r11))
		clearreg(mgenreg(r11))
		opc:=m_div
	fi

	genmc(opc, bx)

	case isdiv
	when 0 then				!rem
		genmc(m_xchg, mgenreg(r0), mgenreg(r11))

	when 2 then				!divrem
		genmc(m_xchg, bx, mgenreg(r11))			!rem replace y-operand
		swapopndregs(r1)						!make sure it is in r1
		swapopnds(locyy,loczz)

	esac

	restorerdx()

	if fdivto then
		bx:=getworkregm(tpu64)
		genmc(m_pop, bx)
		genmc(m_mov, makeopndind(bx, pmode), getopnd(locyy, pmode))
		poppcl()
	fi

	if isdiv<>2 then
		poppcl()
	fi

end

proc fixdivopnds(int locyy, loczz)=
!two div operands exist as the top two operands, which will be
!in registers
!the div op requires that x is in d0, and y in any other register
!d11 also needs to be free, which will be the case is reg allocs only
!go up to d9, and d10/d11/12/13 are in use for win64 parameter passing
	int regx,regy,zop
	mclopnd bx, ax

	regx:=pclreg[locyy]
	regy:=pclreg[loczz]

	if regx=r0 then			!regy will be OK
		return
	fi

	bx:=getopnd(locyy, tpu64)
	ax:=getopnd(loczz, tpu64)

	if regy=r0 then			!need to swap then
		genmc(m_xchg, bx, ax)
		swapopnds(locyy,loczz)		!switch operands
		return
	fi

!neither x nor y in r0
	if regset[r0]=0 then	!d0 not in use
		genmc(m_xchg, mgenreg(r0), bx)
		regset[regx]:=0				!switch registers for yy

		pclreg[locyy]:=r0
		regset[r0]:=1

		return
	fi

!need to move current occupier of r0
	for zop:=noperands downto 1 do
		if pclloc[zop]=reg_loc and pclreg[zop]=r0 then exit fi
	else
		return
	od

!zop is the operand number that happens to be using r0
	genmc(m_xchg, mgenreg(r0), getopnd(locyy, tpu64))	
	swap(pclreg[locyy], pclreg[zop])		!switch registers
end

proc saverdx=
	genmc(m_push, mgenreg(r11)) when r11used
end

proc restorerdx=
	genmc(m_pop, mgenreg(r11)) when r11used
end

global proc clearblock(mclopnd ax, int n)=
!ax is the operand with the address of memory to be cleared
!generate code to clear n bytes

!CPL "CLEARBLOCK", MSTROPND(AX), N

	mclopnd rx, rcount
	int nwords,lab,oddbytes,offset,workreg, countreg

	oddbytes:=n rem 8		!will be zero, or 1..7

	n-:=oddbytes			!n will always be a multiple of 8; n can be zero too
	nwords:=n/8				!number of u64s (ie. octobytes)

	rx:=getworkregm(tpu64)
	clearreg(rx)

	offset:=0

	if 1<=nwords<=8 then		!use unrolled code (no loop)
		ax:=changeopndsize(ax,8)

		to nwords do
			genmc(m_mov,applyoffset(ax,offset),rx)
			offset+:=8
		od

	elsif nwords<>0 then		!use a loop

!SPLIT INTO xx VERSIONS:
! NWORDS IS A MULTIPLE OF 4, so can write 4 words at a time, in 1/4 of iterations
! Or do one word at a time like now.
! nword is a multiple of 4 happens when N is a multiple of 32 bytes, which will
! always be the case for power-of-two sizes of 32 bytes or more. 32/64 may already
! be done without a loop. So non-part-unrolled version only really for odd array or
! struct sizes, such as [100]char.

		if nwords iand 3 then		!not 4n

			rcount:=mgenreg(countreg:=getworkireg())
			lab:=++mlabelno

			ax:=makesimpleaddr(ax)

			genmc(m_mov,rcount,mgenint(nwords))
			genmc(m_labelx,mgenlabel(lab))
			genmc(m_mov,ax,rx)

			genmc(m_add,mgenreg(ax.reg),mgenint(8))

			genmc(m_dec,rcount)
			genmc_cond(m_jmpcc,ne_cond,mgenlabel(lab))

			offset:=0
		else
			rcount:=mgenreg(countreg:=getworkireg())
			lab:=++mlabelno

			ax:=makesimpleaddr(ax)
			genmc(m_mov,rcount,mgenint(nwords/4))
			genmc(m_labelx,mgenlabel(lab))

			for i to 4 do
				genmc(m_mov,applyoffset(ax,offset),rx)
				offset+:=8
			od

			genmc(m_add,mgenreg(ax.reg),mgenint(targetsize*4))

			genmc(m_dec,rcount)
			genmc_cond(m_jmpcc,ne_cond,mgenlabel(lab))

			offset:=0
		fi
	fi

	if oddbytes then
		n:=oddbytes						!1..7

		if n>=4 then
			rx:=changeopndsize(rx,4)
			genmc(m_mov,applyoffset(ax,offset,4),rx)
			n-:=4
			offset+:=4
		fi
		if n>=2 then
			rx:=changeopndsize(rx,2)
			genmc(m_mov,applyoffset(ax,offset,2),rx)
			n-:=2
			offset+:=2
		fi
		if n=1 then
			rx:=changeopndsize(rx,1)
			genmc(m_mov,applyoffset(ax,offset,1),rx)
		fi
	fi
end

global proc do_blockdata(pcl p) =
	ref byte s
	ref u64 d
	int n,nqwords,nwords,r

	n:=p.size
	return when n=0

	nwords:=n/8

	d:=cast(p.svalue)
	to nwords do
		genmc(m_dq, mgenint(d++^))
	od

	r:=n-nwords*8
	if r then
		genstring_db(cast(d), r, 'B')
	fi
	MGENCOMMENT("ENDDATA")

end

global proc copyblock(mclopnd ax,bx, int n, savedest=1)=
!ax,bx refer to memory; do ax:=bx for n bytes
!savedest=1 to ensure that the value in ax register is not modified

	mclopnd rx, rcount
	int nwords, lab, oddbytes, offset, workreg, countreg, axreg
	byte saved:=0

	if n=16 then
!		rx:=getworkregm(tur64)
		rx:=getworkregm(tpr64)
!
		genmc(m_movdqu, rx, bx)
		genmc(m_movdqu, ax, rx)

!		genmc(m_movdqa, rx, bx)
!		genmc(m_movdqa, ax, rx)

		return
	fi

	oddbytes:=n rem 8		!will be zero, or 1..7
	n-:=oddbytes			!n will always be a multiple of 8; n can be zero too
	nwords:=n/8				!number of u64s (ie. octobytes)

	rx:=getworkregm(tpu64)		!work reg

	offset:=0

	if 1<=nwords<=4 then		!use unrolled code (no loop)
		ax:=changeopndsize(ax, targetsize)
		bx:=changeopndsize(bx, targetsize)

		to nwords do
			genmc(m_mov, rx, applyoffset(bx, offset))
			genmc(m_mov, applyoffset(ax, offset), rx)
			offset+:=8
		od

	elsif nwords<>0 then		!use a loop
		rcount:=getworkregm(tpu64)
		lab:=++mlabelno
		if savedest then
			axreg:=ax.reg
			genmc(m_push, mgenreg(axreg))
			saved:=1
		fi

		ax:=makesimpleaddr(ax)
		bx:=makesimpleaddr(bx)
		ax.size:=8

		genmc(m_mov, rcount, mgenint(nwords))
		genmc(m_labelx, mgenlabel(lab))
		genmc(m_mov, rx, bx)
		genmc(m_mov, ax, rx)

		genmc(m_add, mgenreg(ax.reg), mgenint(targetsize))
		genmc(m_add, mgenreg(bx.reg), mgenint(targetsize))

		genmc(m_dec, rcount)
		genmc_cond(m_jmpcc, ne_cond, mgenlabel(lab))

		offset:=0
	fi

	if oddbytes then
		n:=oddbytes						!1..7

		if n>=4 then
			rx:=changeopndsize(rx, 4)
			genmc(m_mov, rx, applyoffset(bx, offset, 4))
			genmc(m_mov, applyoffset(ax, offset, 4), rx)
			n-:=4
			offset+:=4
		fi
		if n>=2 then
			rx:=changeopndsize(rx, 2)
			genmc(m_mov, rx, applyoffset(bx, offset, 2))
			genmc(m_mov, applyoffset(ax, offset, 2), rx)
			n-:=2
			offset+:=2
		fi
		if n=1 then
			rx:=changeopndsize(rx, 1)
			genmc(m_mov, rx, applyoffset(bx, offset, 1))
			genmc(m_mov, applyoffset(ax, offset, 1), rx)
		fi
	fi
	if saved then
		genmc(m_pop, mgenreg(axreg))
	fi
end

global proc genstringtable=
	ref constrec p

	return unless cstringlist

	mgencomment("String Table")

	setsegment('I',8)

	if kk0used then
		genmc(m_labelx,mgenlabel(kk0used))
		gendb(0)
	fi

	p:=cstringlist
	while p, p:=p.nextconst do
		genmc(m_labelx,mgenlabel(p.labelno))
		genstring_db(p.svalue, p.slength, strtype:1)
	od
end

global proc genstring_db(ichar s, int length, strtype)=
!string table generated in ax pass, so is just text
!this is target-specific, so should really be moved
!strtype should be zero for a normal string, then a zero-terminator is added.
	int i, c, seqlen
	ref char seq

	if length=-1 then
		length:=strlen(s)
	fi

	if length=0 then
		gendb(0)
		return
	fi

	seqlen:=0

	to length do
		c:=s++^
!		if c<32 or c>=127 or c='\"' then
		if c<32 or c>=127 or c in ['\"', '\\'] then
			if seqlen then
				gendbstring(seq, seqlen)
				seqlen:=0
			fi
			gendb(c)
		else
			if seqlen=0 then
				seqlen:=1
				seq:=s-1
			else
				++seqlen
			fi
		fi
	od
	if seqlen then
		gendbstring(seq,seqlen)
	fi
	if strtype=0 then
		gendb(0)
	fi
end

proc gendb(int a)=
	genmc(m_db,mgenint(a))
end

proc gendbstring(ichar s, int length)=
!string is printable, and doesn't include double quotes
	genmc(m_ascii,mgenstring(s,length))
end

proc gendq(int a)=
	genmc(m_dq,mgenint(a))
end

global proc genrealtable=
	ref constrec p

	return unless creallist or cr32list

	mgencomment("Real Table")
	setsegment('I',8)
	p:=creallist
	while p, p:=p.nextconst do
		genmc(m_labelx,mgenlabel(p.labelno))

		if p.xvalue=infinity then
			genmc(m_dq, mgenint(u64@(p.xvalue)))
		else
			genmc(m_dq, mgenint(u64@(p.xvalue)))
!			genmc(m_dq, mgenrealimm(p.xvalue,tpr64))
!			genmc(m_dq, mgenrealimm(p.xvalue,tpr64))
		fi
	od

	mgencomment("Real32 Table")
	p:=cr32list
	while p, p:=p.nextconst do
		genmc(m_labelx,mgenlabel(p.labelno))
		if p.xvalue=infinity then
			genmc(m_dd, mgenint(i32@(r32(p.xvalue))))
		else
			genmc(m_dd, mgenrealimm(p.xvalue,tpr32))
		fi

	od
end

global proc genabsneg=
	if lababs32+lababs64+labneg32+labneg64 then
		setsegment('I',16)
	fi

	if lababs32 then
		mgencomment("lababs32")
		genmc(m_labelx,mgenlabel(lababs32))
		gendq(0x7FFF'FFFF'7FFF'FFFF)
		gendq(0x7FFF'FFFF'7FFF'FFFF)
	fi
	if lababs64 then
		mgencomment("lababs64")
		genmc(m_labelx,mgenlabel(lababs64))
		gendq(0x7FFF'FFFF'FFFF'FFFF)
		gendq(0x7FFF'FFFF'FFFF'FFFF)
	fi

	if labneg32 then
		mgencomment("labneg32")
		genmc(m_labelx,mgenlabel(labneg32))
		gendq(0x8000'0000'8000'0000)
		gendq(0x8000'0000'8000'0000)
	fi
	if labneg64 then
		mgencomment("labneg64")
		genmc(m_labelx,mgenlabel(labneg64))
		gendq(0x8000'0000'0000'0000)
		gendq(0x8000'0000'0000'0000)
	fi

	if labzero then
		mgencomment("labzero")
		genmc(m_labelx,mgenlabel(labzero))
		gendq(0)
	fi

	if labmask63 then
		mgencomment("mask63/offset64")
		genmc(m_labelx,mgenlabel(labmask63))
		gendq(0x7FFF'FFFF'FFFF'FFFF)
		genmc(m_labelx,mgenlabel(laboffset64))
		gendq(0x43E0'0000'0000'0000)
	fi
end

global proc do_maths(pcl p, ichar opname, int nargs=1)=
	do_callrts(p, opname, nil, nargs)
end

global proc do_host(pcl p, psymbol d, int nargs=1)=
	do_callrts(p, nil, d, nargs)
end

global proc do_callrts(pcl p, ichar opname, psymbol d, int nargs)=
	int slots

	saveopnds(nargs)
	slots:=0

	if mstackdepth.odd then
		pushslots(1)
		slots:=1
	fi

	do_pushlowargs(nargs, pstack:1)

	if mstackdepth then
		slots+:=4
		pushslots(4)					!shadowspace
	else
		localshadow:=1
	fi

	if opname then
		genmc(m_call, mgenextname(opname))
	else
		genmc(m_call, mgenmemaddr(d))
	fi

	to nargs do
		poppcl()
	od

	if slots then
		popslots(slots)
	fi

	do_getretvalue(p)
end

global proc do_max_int(int cond)=
	mclopnd ax,bx

	ax:=loadopnd(yy, pmode)
	bx:=loadopnd(zz, pmode)

	genmc(m_cmp, ax, bx)
	genmc_cond(m_cmovcc, cond, ax, bx)

	poppcl()
end

global proc do_max_float(int opc)=
	mclopnd ax,bx
	ax:=loadopnd(yy, pmode)
	bx:=getopnd(zz, pmode)
	genmc(opc,ax,bx)
	poppcl()
end

global proc do_maxto_int(int cond, mode)=
	mclopnd ax,bx,lx
	int lab

!	if size<8 then merror("min/maxto size?") fi

	ax:=getopnd_ind(zz, pmode)
	bx:=loadopnd(yy, pmode)

	genmc(m_cmp, ax, bx)
	lab:=++mlabelno

	genmc_cond(m_jmpcc, cond, lx:=mgenlabel(lab))
	genmc(m_mov, ax,bx)
	genmc(m_labelx, lx)
	poppcl()
	poppcl()
end

global proc do_maxto_real(int cond, mode)=
	mclopnd px,ax,bx,lx
	int lab

	px:=getopnd_ind(zz, mode)
	bx:=loadopnd(yy, mode)

	pushpcl_reg(mode)

	ax:=getopnd(yy, pmode)

	genmc(m_mov, ax, px)

	genmc(m_comiss+ispwide(mode), ax, bx)
	lab:=++mlabelno

	genmc_cond(m_jmpcc, cond, lx:=mgenlabel(lab))
	genmc(m_mov, px,bx)
	genmc(m_labelx, lx)
	poppcl()
	poppcl()
	poppcl()
end

global proc do_negreal(mclopnd ax, int mode)=
	if ispwide(pmode) then
		if not labneg64 then labneg64:=mcreatefwdlabel() fi
		genmc(m_xorpd, ax, mgenlabelmem(labneg64))
	else
		if not labneg32 then labneg32:=mcreatefwdlabel() fi
		genmc(m_xorps, ax, mgenlabelmem(labneg32))
	fi
end

global proc do_absreal(mclopnd ax, int mode)=
	if ispwide(pmode) then
		if not lababs64 then lababs64:=mcreatefwdlabel() fi
		genmc(m_andpd, ax, mgenlabelmem(lababs64))
	else
		if not lababs32 then lababs32:=mcreatefwdlabel() fi
		genmc(m_andps, ax, mgenlabelmem(lababs32))
	fi
end

global proc do_loadbf_const(pcl p, int i, j) =
	mclopnd ax, mx
	word mask

	ax:=loadopnd(xx, pmode)

	if j=63 then			!signed field includes sign bit; assume i>0
		genmc(m_sar, ax, mgenint(i))
	else

		if i then
			genmc(m_shr, ax, mgenint(i))
		fi

		mask:=inot(0xFFFF'FFFF'FFFF'FFFF<<(j-i+1))
		if mask<=word(i32.max) then			!use immediate
			genmc(m_andx, ax, mgenint(mask))
		else
			mx:=loadopnd(yy, tpu64)
			genmc(m_mov, mx, mgenint(mask))
			genmc(m_andx, ax, mx)
		fi
	fi

	poppcl()
	poppcl()
end

global proc do_loadbf_var(pcl p) =
	merror("LOADBF_VAR")
end

global proc do_storebit(pcl p) =
!yy.[zz]:=xx; y.[z]:=x or b.[c]:=a
	mclopnd px, ax, cx, ix
	pcl q, r
	int i, offset
	byte mask1s, mask0s

	q:=isimmload(zz)
	r:=isimmload(xx)

	if q then						!a.[k] := 0/1/x
		px:=getopnd_ind(yy, tpu8)	!update only a specific byte
		i:=q.value	
		offset:=i/8					! byte offset 0..7
		i iand:=7					! i will be bit index 0..7
		px:=applyoffset(px, offset)	! point to that byte

		mask0s:=1<<i				!eg 00001000
		mask1s:=inot(1<<i)			!eg 11110111

		if r then
			if r.value=0 then
				genmc(m_andx, px, mgenint(mask1s, pmode))
			else
				genmc(m_orx, px, mgenint(mask0s, pmode))
			fi
		else
			ax:=loadopnd(xx, tpu8)
			genmc(m_andx, px, mgenint(mask1s, pmode))		!clear dest bit first
			if i then
				genmc(m_shl, ax, mgenint(i, tpu8))
			fi
			genmc(m_orx, px, ax)							!add in 0 or 1
		fi
	elsif r then								!A.[i]:=0/1/x
		px:=getopnd_ind(yy, pmode)				!update whole dest word

		if q=nil then								!A.[i]:=0/1
			ax:=getworkregm(tpu64)
			genmc(m_mov, ax, mgenint(1))
			
			cx:=mgenreg(r10,tpu64)
			genmc(m_push, cx) when r10used
			ix:=loadparam(zz, tpi64, r10)
			genmc(m_shl, ax, changeopndsize(cx, 1))
			genmc(m_pop, cx) when r10used

!Now have 00001000 for ezzmple in ax
			if r.value=0 then
				genmc(m_notx, ax)				!change to 111101111
				genmc(m_andx, px, ax)			!set to 0
			else								!set to 1 (assume r.value was 1)
				genmc(m_orx, px, ax)
			fi

		else									!A.[i]:=x
			merror("STOREBIT/VAR")
		fi
	else
			merror("Storebit: both vars")
	fi

	poppcl()
	poppcl()
	poppcl()
end

global proc do_storebf(pcl p) =
	mclopnd ax,rx,mx,mx4,dx
	int i,j
	pcl q, r
	word mask

	q:=isimmload(yy)
	r:=isimmload(zz)

	if q=r=nil then
		merror("storebf not imm")
	fi

	dx:=loadopnd(ww, pmode)

	ax:=getopnd_ind(xx, pmode)

	i:=q.value
	j:=r.value

	mx:=getworkregm(tpu64)
	rx:=getworkregm(pmode)

	genmc(m_mov, rx, ax)

	mask:=inot((inot(0xFFFF'FFFF'FFFF'FFFF<<(j-i+1)))<<i)

	genmc(m_mov, mx, mgenint(mask))

	if i then
		genmc(m_shl, dx, mgenint(i))
	fi

	genmc(m_andx, rx, changeopndsize(mx, p.size))
	genmc(m_orx, rx, dx)

	genmc(m_mov, ax, changeopndsize(rx, p.size))

	poppcl()			!j
	poppcl()			!i
	poppcl()			!A
	poppcl()			!x?
end

global func gethostfn(int opc)psymbol d =
	ichar name, namec

	if igethostfn=nil then

!try manual seach through pcl code
		case opc
		when kpower then
			name:="msys.m$power_i64"		!msys or msysc
			namec:="msysc.m$power_i64"
		else
			name:=nil
		esac

		if name then
			psymbol ps:=psymboltable
			while ps, ps:=ps.next do
				if eqstring(name, ps.name) or eqstring(namec, ps.name) then
					return ps
				fi
			od
		fi

		merror("gethostfn?", pclnames[opc])
	fi

	d:=igethostfn(opc)
	if d=nil then
		merror("No host fn:", pclnames[opc])
	fi
	d
end

global proc copyblockarg(mclopnd px, int size, ARGNO)=
!px refers to a block in a parameter register
!if px is nil, then called for block in zz that will be pushed

!copy the block to a block temp, and change px's register to
!refer to that new block

CPL "COPYBLOCKARG"

	psymbol dblock
	mclopnd ax, bx, axi, bxi

	IF PX=NIL THEN
		println "High block arg not copied in", currfunc.name,,"()"
		return
	FI

	dblock:=newblocktemp(size)
	dblock.used:=1


	if px then
		bx:=getworkregm(tpref)			!copy of px
		genmc(m_mov, bx, px)
	else
		bx:=loadopnd(zz, tpblock)
	fi
	ax:=getworkregm(tpref)			!refer to temp block

	genmc(m_lea, ax, mgenmem(dblock))

	copyblock(mgenireg(ax.reg), mgenireg(bx.reg), size)

	if px then
		genmc(m_lea, px, mgenmem(dblock))		!param points to temp
!	else
!		gen
	fi

!note: this is needed since there may be other blocks passed before the end
!of a CALL op, as those ax/bx regs would be tied up
!caller should ensure no workregs are in use

	freeworkregs(nil)
end

global proc fixmain=
!d is a main func with 2 params
!convert params to locald, add more locals needed for calling __getmainargs
	psymbol d:=currfunc, e
	psymbol dn, dargs, denv, dinfo
	mclopnd ax

	dn:=d.nextparam
	dargs:=dn.nextparam

!add 2 new locals
!	denv:=pc_makesymbol("$env", local_id)
	denv:=pc_makesymbol("$env", static_id)
	denv.mode:=tpref
	denv.size:=8
!DENV.USED:=1

!	dinfo:=pc_makesymbol("$info", local_id)
	dinfo:=pc_makesymbol("$info", static_id)
	dinfo.mode:=tpblock
	dinfo.size:=128
!DINFO.USED:=1

	setsegment('Z',8)
	genmc(m_labelx, mgenmemaddr(dinfo))
	genmc(m_resb, mgenint(128))
	genmc(m_labelx, mgenmemaddr(denv))
	genmc(m_resb, mgenint(8))
	setsegment('C',1)
	pc_addlocal(denv)
	pc_addlocal(dinfo)

!remove dn/dargs as params

	dn.nextparam:=dargs.nextparam:=d.nextparam:=nil
	d.nparams:=0
	dn.id:=local_id
	dn.used:=1
	dargs.id:=local_id
	dargs.used:=local_id
!
!add them as locals

	pc_addlocal(dargs)
	pc_addlocal(dn)

	genmc(m_push, ax:=mgenreg(r0))
	genmc(m_lea , ax, mgenmem(dinfo))
	DINFO.ADDROF:=1
	genmc(m_push, ax)
	genmc(m_sub, dstackopnd, mgenint(32))
	genmc(m_lea,  mgenreg(r10), mgenmem(dn))
	DN.ADDROF:=1
	genmc(m_lea,  mgenreg(r11), mgenmem(dargs))
	DARGS.ADDROF:=1
	genmc(m_lea,  mgenreg(r12), mgenmem(denv))
	DENV.ADDROF:=1
	clearreg(mgenreg(r13))
	genmc(m_call, mgenextname("__getmainargs*"))
!
	genmc(m_sub, dstackopnd, mgenint(48))

!do pcmdskip fixes
	if pcmdskip then
		genmc(m_sub, mgenmem(dn), mgenint(pcmdskip, tpi32))
		genmc(m_add, mgenmem(dargs), mgenint(pcmdskip*8))
	fi

end
