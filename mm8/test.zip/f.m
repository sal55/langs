int depth, maxdepth

proc main=
	for i to 40 do
		println i,fib(i)
	od
	cpl =maxdepth
end

func fib(int n)int=
int x

	if n<3 then
		1
	else 
		maxdepth max:= ++depth
		x:=fib(n-1)+fib(n-2)
		--depth
		x
	fi
end

