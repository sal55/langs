project =
	module pc_api
	module pc_decls

	module pc_diags
!	module pc_diags_dummy

	module pc_run
	module pc_runaux

	module pc_tables

	module mc_GenMCL_dummy
	module mc_GenSS_dummy
	module mc_Decls as md
	module mc_OBJdecls
	module mc_WriteASM_dummy
	module mc_WriteEXE_dummy
	module mc_WriteOBJ_dummy
	module mx_run_dummy

end

export byte pc_userunpcl=1			!ask host to default to -runpcl option

