
global ichar syslibname=""

!macro SHOW(m) = println m
macro SHOW(m) = eval 0

!main production options; passnames are also file extensions for outputs

global enumdata []ichar passnames =
!								Output (when this is the final step)
	(ma_pass,		"ma"),			! .ma     These are are special
	(getst_pass,	"list"),		! .list
	(getproj_pass,	"proj"),		! .prog
	(clang_pass,	"clang"),		! .c

	(pcl_pass,		"pcl"),			! .pcl
	(runpcl_pass,	"(int)"),		! interpret
	(mcl_pass,		"asm"),			! .asm
	(obj_pass,		"obj"),			! .obj (via .asm and aa)
	(dll_pass,		"dll"),			! .dll
	(exe_pass,		"exe"),			! .exe
	(mx_pass,		"mx"),			! .mx
	(run_pass,		"(run)"),		! run in-memory
end

!options used in debugging
global enumdata []ichar dpassnames =
	(dload_pass,	$),
	(dparse_pass,	$),
	(dfixup_pass,	$),
	(dname_pass,	$),
	(dtype_pass,	$),
	(dpcl_pass,		$),
	(dmcl_pass,		$),		!all-inclusive up to this point (includes all prev passes)
	(dss_pass,		$),		!only one of these 3 will be done
end

enumdata []ichar optionnames, []byte optionvalues =

!special outputs
	(ma_sw,			"ma",			ma_pass),
	(getst_sw,		"getst",		getst_pass),
	(getproj_sw,	"getproj",		getproj_pass),
	(clang_sw,		"c",			clang_pass),

!normal production outputs
	(pcl_sw,		"p",			pcl_pass),
	(runpcl_sw,		"i",			runpcl_pass),
	(asm_sw,		"a",			mcl_pass),
	(nasm_sw,		"nasm",			mcl_pass),
	(obj_sw,		"obj",			obj_pass),
	(dll_sw,		"dll",			dll_pass),
	(dll2_sw,		"d",			dll_pass),
	(exe_sw,		"exe",			exe_pass),		!default
	(mx_sw,			"mx",			mx_pass),
	(run_sw,		"r",			run_pass),		!default with ms.exe

!debugging options; these set debug mode; above are production mode
	(dload_sw,		"dload",		dload_pass),
	(dparse_sw,		"dparse",		dparse_pass),
	(dfixup_sw,		"dfixup",		dfixup_pass),
	(dname_sw,		"dname",		dname_pass),
	(dtype_sw,		"dtype",		dtype_pass),
	(dpcl_sw,		"dpcl",			dpcl_pass),
	(dmcl_sw,		"dmcl",			dmcl_pass),
	(dss_sw,		"dss",			dss_pass),

	(sys_sw,		"sys",			2),
	(minsys_sw,		"min",			1),
	(nosys_sw,		"nosys",		0),
	(clinux_sw,		"linux",		0),

	(noopt_sw,		"no",			0),
	(nopeephole_sw,	"nopeep",		0),
	(noregoptim_sw,	"noregs",		0),
	(opt0_sw,		"o0",			0),
	(opt1_sw,		"o1",			1),
	(opt2_sw,		"o2",			2),


!diagnostic outputs, only relevant for debug mode
	(ast1_sw,		"ast1",			0),
	(ast2_sw,		"ast2",			0),
	(ast3_sw,		"ast3",			0),
	(showc_sw,		"showc",		0),
	(showpcl_sw,	"showpcl",		0),
	(showasm_sw,	"showasm",		0),
	(st_sw,			"st",			0),
	(stflat_sw,		"stflat",		0),
	(types_sw,		"types",		0),
	(showss_sw,		"showss",		0),
	(showmodules_sw,"modules",		0),
	(shortnames_sw,	"shortnames",	0),

	(pst_sw,		"pst",			0),

	(time_sw,		"time",			0),
	(v_sw,			"v",			2),
	(vv_sw,			"vv",			3),
	(quiet_sw,		"q",			0),
	(csize_sw,		"cs",			1),
	(size_sw,		"ss",			2),
	(help_sw,		"h",			0),
	(help2_sw,		"help",			0),
	(ext_sw,		"ext",			0),
	(out_sw,		"o",			0),
	(outpath_sw,	"outpath",		0),
	(unused_sw,		"unused",		0),

	(norip_sw,		"norip",		0),
	(himem_sw,		"himem",		2),
	(showil_sw,		"showil",		1),
end


byte msfile

global const logfile="mx.log"

ichar outext=""				!for reporting of primary o/p file

global int startclock, endclock
global int cmdskip

global ichar inputfile

global int loadtime
global int parsetime
global int resolvetime
global int typetime
global int ctime
!global int pcltime
global int compiletime

global proc main2=
!STOP
!proc main=
	unit p,q,r
	int m,fileno,ntokens,t,tt

	startclock:=os_clock()
PSTARTCLOCK:=STARTCLOCK
	initdata()

	getinputoptions()

!CPL =FREGOPTIM
!CPL =FPEEPHOLE


	if prodmode then
		production_compiler()
	else
		debug_compiler()
	fi

	if fverbose=3 then println "Finished." fi
end

proc debug_compiler=

!	println "DEBUG COMPILATION"

	loadproject(inputfile)

	IF DPASSLEVEL=DPCL_PASS THEN PASSLEVEL:=PCL_PASS		!enable diags
	ELSIF DPASSLEVEL=DMCL_PASS THEN PASSLEVEL:=MCL_PASS
	FI

	do_parse(fshowast1) when dpasslevel>=dparse_pass

	do_name(fshowast2) when dpasslevel>=dname_pass

	do_type(fshowast3) when dpasslevel>=dtype_pass

	do_genpcl(fshowpcl or fshowpst) when dpasslevel>=dpcl_pass

	do_genmcl(fshowasm or ctarget) when dpasslevel>=dmcl_pass

	pcl_genss() when dpasslevel>=dss_pass

	showtimings() when fshowtiming

	showlogfile()

end

proc production_compiler=
!	println "Production:"
	showcompilemess()

! Do early passes common to all options

!BEEP(2000,20)
!CPL "PRODUCTION"

	loadproject(inputfile)

	do_parse()
	do_name()
	do_type()

! Special outputs can be done at this point
	do_writema(inputfile)	when passlevel=ma_pass			! terminates
	do_getinfo(inputfile)	when passlevel in [getst_pass, getproj_pass]		! terminates
	do_clang(inputfile)		when passlevel=clang_pass
	do_writeexports()		when passlevel=dll_pass

	do_genpcl(passlevel=pcl_pass)

	pcl_runpcl() when passlevel=runpcl_pass				!terminates

! Deal with chosen output kind

!CPL PASSNAMES[PASSLEVEL]

	if passlevel>=mcl_pass then
		do_genmcl(passlevel=mcl_pass or ctarget)
!		do_genmcl(passlevel=mcl_pass)

		case passlevel
		when obj_pass then
			pcl_writeobj(changeext(outfile, "obj"))	

		when exe_pass then
			pcl_writeexe(changeext(outfile, "exe"))	

		when dll_pass then
			pcl_writedll(changeext(outfile, "dll"))	

		when mx_pass then
			pcl_writemx(changeext(outfile, "mx"))	

		when run_pass then
			pcl_exec()
!			do_genss()
!			do_run()

		esac
	fi

!CPL =NST
!CPL =NPST
!CPL =NIF
!CPL =NWHEN
!CPL =NUNLESS
!CPL =NALLSYMS

!CPL =NUNITS:"S,"
!CPL =NPCL:"S,"
!CPL =PCLSEQNO
!CPL =MCLSEQNO
!CPL =NMCLOPND

!CPL =NALLCALLS
!CPL =NUSESTACK
!CPL =NUSEMIXEDSTACK

!CPL UNITREC.BYTES
!CPL PCLREC.BYTES
!CPL MCLREC.BYTES
!CPL =NALLSTRINGS
!CPL =NLBRACK
!CPL MCLOPNDREC.BYTES
!
	showtimings() when fshowtiming
!	showtimings() when fshowtiming
!	showtimings() when fshowtiming
end

proc showcompilemess=
	if fverbose>=1 and not msfile then
!		fprintln "Compiling # to #",inputfile,changeext(outfile,(ctarget|"c"|passnames[passlevel]))
		fprint "Compiling # to #",inputfile,changeext(outfile,(ctarget|"c"|outext))
!		print $,fregoptim, fpeephole
		println
	fi
end

proc do_parse(int flog=0)=
!	if fverbose=3 then println "PARSE" fi

	int tt:=clock()

	for i to nmodules do
		parsemodule(modules[i])
	od
	parsetime:=clock()-tt

	if prodmode or dpasslevel>=dfixup_pass then
!		if fverbose=3 then println "FIXUP" fi
		fixusertypes()
	fi

	fixstartprocs()
!
	if flog then showast("AST1") fi
end

proc do_name(int flog=0)=
!	if fverbose=3 then println "NAME" fi

	int tt:=clock()
	rx_typetable()

	for i:=2 to nmodules do
		rx_module(i)
	od
	rx_module(1)
	resolvetime:=clock()-tt

	if flog then showast("AST2") fi
end

proc do_type(int flog=0)=
!	if fverbose=3 then println "TYPE" fi

	int tt:=clock()
	tx_typetable()

	for i:=1 to nmodules do
		tx_module(i)
	od
	tx_allprocs()
	typetime:=clock()-tt

	if flog then showast("AST3") fi
end

!proc do_genc=
!!	if fverbose=3 then println "GENPCL" fi
!	int tt:=clock()
!	ichar file:=pcm_copyheapstring(changeext(outfile,"c"))
!
!!CPL "CALL CODEGEN CLANG..."
!	codegen_il(file)
!!CPL "DONE"
!
!	ctime:=clock()-tt
!
!!	println "WRITE C FILE:", changeext(outfile, "c"),"..."
!	println "WRITE C FILE:", file, DEST.LENGTH
!	writegsfile(file, dest)
!end

proc do_genpcl(int flog=0)=
!	if fverbose=3 then println "GENPCL" fi

	int tt:=clock()

	codegen_il(nil)

!	pcltime:=clock()-tt

!CPL =FREGOPTIM, =FPEEPHOLE

	pcl_reducetest() when fregoptim or fpeephole
	pcltime:=clock()-tt

	if flog then
		if fshowpcl or passlevel=pcl_pass then
!CPL "NOT WRITING PCL"
			pcl_writepcl(changeext(outfile, "pcl"))
		fi

		if fshowpst and passlevel=pcl_pass then		!for mcl+ it is o/p later
			pcl_writepst("PSYMTAB")
		fi

	fi

end

proc do_genmcl(int flog=0)=
!	if fverbose=3 then println "GENMCL" fi

	int tt:=clock()

	pcl_genmcl()
	mcltime:=clock()-tt

!CPL "GENMCL", =OUTEXT

	if flog then
!CPL "MCL1"
		pcl_writeasm(changeext(outfile, asmext))
!CPL "MCL2"
	fi

	if fshowpst and passlevel>pcl_pass then
		pcl_writepst("PSYMTAB")
	fi

end

proc initdata=
	imodule pm
	ifile pf

	pcm_init()
	lexsetup()
	initassemsymbols()
	init_tt_tables()
	initbblib()

	pm:=pcm_allocz(modulerec.bytes)

	pm.name:="PROGRAM"

	stprogram:=createdupldef(nil,addnamestr("$prog"),programid)
	pm.stmodule:=stprogram
	modules[0]:=pm

	igetmsourceinfo:=cast(mgetsourceinfo)
	idomcl_assem:=cast(domcl_assem)
	igethostfn:=cast(findhostfn)
	icheckasmlabel:=cast(checkasmlabel)

	REMOVE("PSYMTAB")

end

proc getinputoptions=
	int paramno,pmtype,sw,extlen
	ichar name,value,ext
	[300]char filespec

	if pc_userunpcl then
		passlevel:=runpcl_pass
		prodmode:=1
		fverbose:=0
	fi
	paramno:=1

	if eqstring(extractfile(os_gethostname()),"ms.exe") then
		msfile:=1
		fverbose:=0
		do_option(run_sw, "")
	fi

	while pmtype:=nextcmdparamnew(paramno,name,value,"m") do
		case pmtype
		when pm_option then

			convlcstring(name)
			for sw to optionnames.len do
				if eqstring(name,optionnames[sw]) then
					do_option(sw,value,paramno)
					exit
				fi
			else
				println "Unknown option:",name
				stop 99
			od
		when pm_sourcefile then
			if inputfile then
				loaderror("Specify one lead module only")
			fi
			convlcstring(name)
			inputfile:=pcm_copyheapstring(name)

!CPL =PASSNAMES[PASSLEVEL]

			if passlevel in [run_pass, runpcl_pass] then
				cmdskip:=paramno-1+$CMDSKIP
!CPL "EXITG1"
				exit
			fi

		when pm_libfile then
			loaderror("Lib files go in module headers")
		else
			loaderror("Invalid params")
		esac

	od

	if prodmode=debugmode=0 then
		if not ctarget then
			passlevel:=exe_pass
			outext:="exe"
		else
			passlevel:=mcl_pass
			outext:="c"
		fi
		prodmode:=1
	fi

	case passlevel
	when obj_pass, dll_pass then
		highmem:=2
	when mcl_pass then
		if assemtype='NASM' then highmem:=2 fi
	when mx_pass, run_pass then
		highmem:=0
	esac

	if inputfile=nil then
		showcaption()
		println "Usage:"
		println "   ",cmdparams[0]," prog[.m]  Compile prog.m to prog.exe"
		println "   ",cmdparams[0]," -h           Show all options"
		stop

	else
!default output
		outfile:=pcm_copyheapstring(inputfile)

		if destfilename then
			outfile:=destfilename
		fi

		if destfilepath then
			strcpy(filespec,destfilepath)
			strcat(extractfile(filespec), outfile)
			outfile:=pcm_copyheapstring(filespec)	
		fi
	fi

	ext:=extractext(inputfile)
	extlen:=strlen(ext)
	strcpy(filespec, changeext(cmdparams[0],ext))
	convlcstring(filespec)
	if eqstring(filespec, inputfile) and passlevel=exe_pass then
		strcpy(&filespec[1]+strlen(filespec)-extlen-1, "2.m")
		outfile:=pcm_copyheapstring(filespec)
		println "New dest=",changeext(outfile, "exe")
	fi

	pcl_setflags(highmem:highmem, shortnames:fshortnames)
	pcl_cmdskip(cmdskip)
	if msyslevel=2 then pfullsys:=1 fi

end

proc do_option(int sw, ichar value, int paramno=0)=
	static byte outused, outpathused

!CPL "DOOPTION", OPTIONNAMES[SW], PASSLEVEL

	if sw in ma_sw..run_sw then
		if prodmode then loaderror("dupl prod option:",OPTIONNAMES[SW]) fi
		passlevel:=optionvalues[sw]
		prodmode:=1
		outext:=passnames[passlevel]
		if passlevel=mcl_pass then
			outext:=asmext
		fi

		case sw
!		when asm_sw then
!			if assemtype<>'AA' or sw=nasm_sw and assemtype<>'NASM' then
!				loaderror("Wrong WRITEASM")
!			fi
		when runpcl_sw then			!in case occurs at end
			cmdskip:=paramno-1+$CMDSKIP
		esac

		return

	elsif sw in dload_sw..dss_sw then
		if debugmode then loaderror("dupl debug option") fi
		dpasslevel:=sw-dload_sw+1
		debugmode:=1
		return
	fi	

	case sw
	when ast1_sw then fshowast1:=1
	when ast2_sw then fshowast2:=1
	when ast3_sw then fshowast3:=1
	when showpcl_sw then fshowpcl:=1
	when showc_sw then fshowc:=1
	when showasm_sw then fshowasm:=1
	when st_sw then fshowst:=1
	when stflat_sw then fshowstflat:=1
	when pst_sw then fshowpst:=1
	when types_sw then fshowtypes:=1
	when showss_sw then fshowss:=1
	when showmodules_sw then fshowmodules:=1
	when clinux_sw then clinux:=1

	when sys_sw, minsys_sw, nosys_sw then msyslevel:=optionvalues[sw]

	when noopt_sw then fpeephole:=fregoptim:=0
	when nopeephole_sw then fpeephole:=0
	when noregoptim_sw then fregoptim:=0

	when time_sw then fshowtiming:=1
	when v_sw, vv_sw, quiet_sw then fverbose:=optionvalues[sw]
	when csize_sw, size_sw then pverbose:=optionvalues[sw]


	when help_sw, help2_sw then showhelp(); stop
	when ext_sw then dointlibs:=0

	when out_sw then
		if outpathused then loaderror("mixed out/path") fi
		destfilename:=pcm_copyheapstring(value)
		outused:=1

	when outpath_sw then
		if outused then loaderror("mixed out/path") fi
		if (value+strlen(value)-1)^ not in ['\\','/'] then
			loaderror("Path needs to end with \\ or /")
		fi
		destfilepath:=pcm_copyheapstring(value)
		outpathused:=1

	when unused_sw then fcheckunusedlocals:=1

	when shortnames_sw then fshortnames:=1

	when norip_sw, himem_sw then highmem:=optionvalues[sw]
	when showil_sw then fshowil:=1

	when opt0_sw then fregoptim:=fpeephole:=0
	when opt1_sw then fregoptim:=1; fpeephole:=0
	when opt2_sw then fregoptim:=1; fpeephole:=1


	end case

end

proc showcaption=
	println "M Compiler [M7.1]", $date, $time
end

global proc showhelp=
	println strinclude(langhelpfile)
end

proc do_writeexports=
	[300]char str

	strcpy(str, extractbasefile(outfile))
	writeexports(outfile, changeext(str, "dll"))
!	stop
end

func getoutfilename(ichar file,ext)ichar=
	return pcm_copyheapstring(changeext(file,ext))
end

proc fixstartprocs=
!make sure each module has a start proc
!make sure the lead module has a main proc
	imodule ms
	isubprog ps
	symbol d
	unit p, q
	int s

	for i to nsubprogs do
		ps:=subprogs[i]
		if ps.mainmodule=0 then
			ps.mainmodule:=ps.firstmodule
		fi
	od


	for i to nmodules do
		ms:=modules[i]
		if ms.ststart then
			subproghasstart[ms.subprogno]:=1
		fi
	od

	for i to nmodules do
		ms:=modules[i]
		if ms.ststart=nil then
			s:=ms.subprogno
			if subproghasstart[s] and subprogs[s].mainmodule=i then
				ms.ststart:=addstartproc(ms.stmodule,"start", program_scope,i)
			fi
		fi

	od
end

func addstartproc(symbol owner, ichar name, int scope,moduleno)symbol stproc=
	stproc:=getduplnameptr(owner,addnamestr(name),procid)
	stproc.scope:=scope
	stproc.moduleno:=moduleno
	stproc.subprogno:=moduletosub[moduleno]
	stproc.code:=makeblock(nil)
	adddef(owner,stproc)
	addtoproclist(stproc)

	return stproc
end

global proc do_clang(ichar filename)=
	[300]char str
	int status

	print @str, "mc", filename
	println "Invoking:", str
	status:=system(str)

	stop status

end

