global proc peephole=
	ref mclrec m, m2,m3
	int lab1,lab2

	if not fpeephole then return fi
!CPL "PEEP"

	m:=mccode.nextmcl

	while m, m:=m.nextmcl do 
		m2:=m.nextmcl
		m3:=m2.nextmcl

		case m.opcode
		when m_endx then
			exit

		when m_mov then
			case m2.opcode
			when m_mov then					!mov/mov
				if isreg0(m.a) and m.a=m2.b and endr0(m2) then		!mov r0,x/mov x,r0
					if isreg10(m2.a) then
					elsif isreg(m2.a) or isreg(m.b) then				!one x is a reg
						m.a:=m2.a
						deletemcl(m2)
					fi
				elsif isreg0(m.a) and m.a=m2.b and isreg10(m2.a) and m3.opcode=m_call and
						endr0(m3) then
					m.a:=m2.a
					deletemcl(m2)
				fi
			when m_test then				!mov/test
				if isreg0(m.a) and m.a=m2.a=m2.b and isreg(m.b) and endr0(m3) then		!mov r0,x/test r0,r0
					m.opcode:=m_test
					m.a:=m.b
					m:=deletemcl(m2)
				fi
			when m_cmp then					!mov r0, reg/cmp r0,x
				if isreg0(m.a) and m.a=m2.a and isreg(m.b) and endr0(m3) then
					m.opcode:=m_cmp
					m.a:=m.b
					m.b:=m2.b
					deletemcl(m2)
				fi
			when m_add, m_sub then
				if isreg(m.a) and m.a=m2.a and isreg(m.b) and isconst(m2.b) then
					m.opcode:=m_lea
					m.b:=mgenindex(areg:m.b.reg, offset: (m2.opcode=m_add|m2.b.value|-m2.b.value))
					deletemcl(m2)
				fi
			when m_inc, m_dec then
				if isreg(m.a) and m.a=m2.a and isreg(m.b) then
					m.opcode:=m_lea
					m.b:=mgenindex(areg:m.b.reg, offset: (m2.opcode=m_inc|1|-1))
					deletemcl(m2)
				fi
			when m_jmp then
				if isreg0(m.a) and isreg0(m2.a) then
					m.opcode:=m_jmp
					m.a:=m.b
					m.b:=nil
					deletemcl(m2)
				fi
			esac

		when m_andx then
			if m2.opcode=m_test then				!and r0../test r0,r0 -> and r0.. only
				if isreg0(m.a) and m.a=m2.a=m2.b and endr0(m3) then
					m:=deletemcl(m2)
				fi
			fi
		when m_xorx then
			if m2.opcode=m_mov then					!xor r0,r0; mov reg, r0
				if isreg0(m.a) and m.a=m.b and isreg(m2.a) and isreg0(m2.b) and endr0(m2) then
					m.a:=m.b:=m2.a
					m:=deletemcl(m2)
				fi
			fi

		when m_jmpcc then
			if m2.opcode=m_jmp and m3.opcode=m_labelx and m.a.labelno=m3.a.labelno and endr0(m) then
				m.cond:=asmrevcond[m.cond]
				m.a:=m2.a
				m:=deletemcl(m2)

			fi

!		when m_add then
!			if m2.opcode in [m_add, m_sub] then
!				if isreg(m.a) and m.a=m2.a and isreg(m.b) and isconst(m2.b) then
!STATIC INT AA
!!					m.opcode:=m_lea
!!					m.b:=mgenindex(areg:m.b.reg, offset: (m2.opcode=m_add|m2.b.value|-m2.b.value))
!!					deletemcl(m2)
!CPL "ADD/ADD/SUB NN",++AA
!				fi
!			fi
!
!!!		when m_jmp then			!this uses more bytes than it saves, when self-hosting
!!!			if m.a.mode=a_imm and m2.opcode=m_labelx and m.a.labelno=m2.a.labelno then
!!!				m:=deletemcl(m)
!!			FI

		esac
	od

end

func isreg(mclopnd a)int=
	return a.mode=a_reg
end

func isreg0(mclopnd a)int=
	if not a then return 0 fi
	if a.mode=a_reg and a.reg=r0 then return 1 fi
	return 0
end

func isreg10(mclopnd a)int=
	if not a then return 0 fi
	if a.mode=a_reg and a.reg=r10 then return 1 fi
	return 0
end

func isreg00(ref mclrec m)int=
	if isreg(m.a) and m.a=m.b then return 1 fi
	0
end

func isconst(mclopnd a)int=
	if not a then return 0 fi
	if a.mode=a_imm and a.valtype=intimm_val then
		return 1
	fi
	return 0
end

func sameoperand(mclopnd a,b)int=
	return memcmp(a,b,mclopndrec.bytes)=0
end

func sameregopnd(mclopnd a,b)int=
!check if same register operand
	unless a.mode=b.mode=a_reg then return 0 end
	return a.reg=b.reg
end

!func deletemcl(ref mclrec p, ichar comment=nil)ref mclrec =
func deletemcl(ref mclrec p)ref mclrec =
!delete p; return following instr
	ref mclrec a,b

	a:=p.lastmcl
	b:=p.nextmcl
	if a=nil or b=nil then merror("delmcl?") fi

!	if comment then
!		p.opcode:=m_comment
!		p.a:=mgenstring(pcm_copyheapstring(comment))
!	else
		a.nextmcl:=b
		b.lastmcl:=a
!	fi

	b
end

func endr0(ref mclrec m)int=
	return m.regfreed[r0]
end
