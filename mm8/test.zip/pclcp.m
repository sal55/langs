project =
	module pc_api
	module pc_decls

	module pc_diags
!	module pc_diags_dummy

!	module pc_run_dummy
	module pc_reduce

	module pc_tables

	module mc_GenC
	module mc_AuxC
	module mc_LibC

!	module mc_GenSS_dummy
!	module mc_Decls as md
!	module mc_OBJdecls

!	module mc_WriteASM_dummy

!	module mc_WriteEXE_dummy
!	module mc_WriteOBJ_dummy
!	module mc_WriteSS_dummy
!	module mx_run_dummy

end

export byte pc_userunpcl=0			!ask host to default to -runpcl option

