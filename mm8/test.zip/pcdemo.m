project =
!	module pc
	module pc_api
	module pc_decls

!	module pc_diags
	module pc_diags_dummy

!	module pc_run
!	module pc_runaux
	module pc_run_dummy

	module pc_tables

!	module mc_AuxMCL
!	module mc_GenMCL
	module mc_GenMCL_dummy

!	module mc_GenSS
	module mc_GenSS_dummy

!	module mc_LibMCL

	module mc_Decls
	module mc_OBJdecls
!	module mc_Optim

!	module mc_StackMCL

!	module mc_WriteASM
!	module mc_WriteNASM
	module mc_WriteASM_dummy

!	module mc_WriteEXE
	module mc_WriteEXE_dummy

!	module mc_WriteOBJ
	module mc_WriteOBJ_dummy

!	module mx_decls
!	module mx_run
!	module mx_lib
!	module mx_write
	module mx_run_dummy

end

proc main=
	ichar s
	psymbol dmain, dputs

	println "PCL STANDALONE"

	pcl_start("demo")

		dmain:=pc_makesymbol("main", export_id)
		dputs:=pc_makesymbol("puts", import_id)

		pc_defproc(dmain)
!pc_gen(klabel, genlabel(1))
!pc_gen(klabel, genlabel(23))
			pc_gen(kload, genstring("Hello, World run!"))
			pc_setmode(tpu64)

			pc_genxy(kcallp, 1,0, genmemaddr(dputs))

			pc_gen(kload, genint(0))
			pc_setmode(tpi64)
!pc_gen(kjump, genlabel(23))

			pc_gen(kstop)
			pc_gen(kretproc)

		pc_endproc()

		pc_addplib("msvcrt")			! Needed by most targets

	pcl_end()

!CPL =MLABELNO

! Any of the following can be used for the next stage
 
	pcl_setflags(verbose:1)

	pcl_writepcl("hello.pcl")			! Dump as PCL text
	CPL pcl_writepcl(NIL)

	pcl_runpcl()						! Run PCL via interpreter

	pcl_writeasm("hello.asm")			! Generate ASM for my AA assemble
	pcl_writeasm("hello.asm", 'NASM')	! Generate ASM for NASM

	pcl_writeexe("hello.exe")			! Write Windows PE executable
!
	pcl_setflags(highmem:2)				! needed if to be linked via gcc or ld
	pcl_writeobj("hello.obj")			! Write Windows COFF object file
!
	pcl_writemx("hello.mx")				! Write my private executable format

	pcl_exec(0)							! Run native code in-memory

end
