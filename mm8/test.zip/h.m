importdll msvcrt=
	proc puts(ichar)
	proc printf(ichar, ...)
end

export int $cmdskip			!0 unless set by READMCX/etc

proc main=
	puts("hello")
	puts("hello")
	puts("hello")

int a,b,c

end

int d
