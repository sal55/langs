project =
	module pc_api
	module pc_decls

	module pc_diags
!	module pc_diags_dummy

!	module pc_run_dummy
	module pc_reduce

	module pc_tables

	module mc_GenC
	module mc_AuxC
	module mc_LibC

!	module mc_GenSS_dummy
!
!	module mc_WriteEXE_dummy
!	module mc_WriteOBJ_dummy
!	module mc_WriteSS_dummy
!	module mx_run_dummy

end

global proc genss(int obj=0)=
end

export function writessdata(int fexe)ref strbuffer=
	nil
end

global proc writecoff(ichar outfile)=end

global proc writeexe(ichar outfile, int dodll)=
end

global proc runlibfile(ichar filename, int cmdskip)=
	abortprogram("No Run")
end

global proc writemcx(ichar filename)=
end

export proc pcl_runpcl=
end

export byte pc_userunpcl=0			!ask host to default to -runpcl option

