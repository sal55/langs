real x, y
int a

macro firstbyte = 0..7

proc main=
	PRINTLN "ABC"
	PRINTLN "DEF"

end

