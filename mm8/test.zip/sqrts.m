proc main =
	for i to 10 do
		println i, sqrt i
	od
end
