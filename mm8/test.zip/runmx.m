module runmxshow

module mx_decls
module mx_lib

!$sourcepath "/ax/"
module mc_disasm

!global  enumdata [0:]ichar segmentnames =
!	(no_seg=0,		$),
!	(code_seg,		$),
!	(idata_seg,		$),
!	(zdata_seg,		$),
!	(rodata_seg,	$),
!	(impdata_seg,	$),
!end

proc main=
	ref strbuffer ss
	ichar filename
	ref byte p
	ref librec plib
	int cmdskip, dorun

	dorun:=1
	for i to ncmdparams do
		filename:=cmdparams[i]
		if filename^='-' then
			if eqstring(filename,"-show") then
				dorun:=0
			else
				println "Unknown option:",filename
				stop 1
			fi
		else
			filename:=pcm_copyheapstring(addext(filename,"mx"))
			cmdskip:=i+$cmdskip
			exit
		fi
	else
		println "Usage:"
		fprintln "      #        filename[.mx]      Load and run .mx program", cmdparams[0]
		fprintln "      #  -show filename[.mx/.ml]  Load and display mx/ml file", cmdparams[0]
		stop 1
	od

CPL =$CMDSKIP
CPL =CMDSKIP

	initlogfile()

	plib:=loadmx(filename)
	fixuplib(plib)

	if dorun then
		runprogram(plib, cmdskip)
	else
		showlibs()
		closelogfile()
	fi

end

