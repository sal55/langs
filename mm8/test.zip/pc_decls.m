!decls

export type psymbol = ref pstrec

export record pstrec = $caligned
!global record pstrec = $caligned
!global record pstrec =
	ichar name
	psymbol next
	psymbol nextparam
	union
		psymbol nextlocal
		pcl pcdata				!istatics: point to first kdata op
	end
	psymbol owner
	psymbol generic				!locals/params: version in global ST

	ref procinforec info		!procs: info to help codegen	

	union
		pcl pcaddr				!for procs: entry point to function
		ref proc dlladdr		!for imported functions
		ivoid staddr			!var statics: address
		psymbol cprocowner		!C target:var statics: owner proc
	end
	ref fwdrec fwdrefs			!fwd ref chain

	byte id
	byte ksymbol				!0, or _rw code for reserved words (used by pp)
	byte opcode					!for opcode_rw
	byte subcode				!for jumpcc_rw/setcc_rw/type_rw

	i32 offset

	byte imported				!only for import_id
	byte exported				!only for proc_id/static_id
	byte mode
	byte isentry
	u32 size

	byte addrof
	byte nrefs
	byte reg
	byte atvar
	byte used					!0, or 1 to 255 (capped at 255)
	byte reftype
	byte segment
	byte hasdot

	i16 stindex
	i16 importindex
	i32 labelno

	byte flags:(asmused:1, chasstatics:1, dllexport:1)

!	byte asmused				!1 when proc contains asmcode
	byte dllindex				!for dllproc: which dll in dlltable

	byte nretvalues				!function: number of return values (0 for proc)
	byte varparams				!0 or N; variadic params

	byte isthreaded				!
	byte ishandler				!1 if a proc to be part of func tables
	byte ismain					!1 if a proc to be part of func tables
	byte SPARE

!----------------------------------

	byte nparams
	byte variadic				!local function that uses ... variadic params (for C)
	i16 nlocals
	i16 impindex
	i16 expindex
	u32 seqno

end

export type pcl = ref pclrec

EXPORT record pclrec =
!global record pclrec =
	byte opcode
	byte opndtype
	byte condcode						!for jumpcc/setcc
	byte mode

	u32 size

	union
		struct
			union
				i64	value
				r64	xvalue
				ichar	svalue			!also used for data
				int		labelno
				psymbol	def
				ivoid	asmcode
			end

			union						!two 32-bit params used according to opcode
				struct
					i32 x				!common access to these 1/2 extra attribs
					i32 y
				end

				struct					! (x,y) pointer ops
					i32 scale			! scale factor for offset
					i32 extra			! extra constant byte offset, already scaled
				end
				struct					! (x,y) call/etc
					i32 nargs			! number of args
					union
						i32 nvariadics	!call: 0, or arg # that is first variadic
						i32 nrealargs	!setcall: 1 if whole call sequence is simple
					end
				end
				struct					! (x,y) switch
					i32 minlab
					i32 maxlab
				end
				struct					! defproc/retproc/retfn
					i32 paramslots	! stack usage as 8-byte slots
					i32 localslots
				end

				i32 stepx				! (x) always +ve fixed step size for forup/fordown; also INCR
				i32 align
				i32 popone			! (x) jumpcc: leave X on stack
				i32 slicelwb			! (x) for .upb
				i32 inplace			! (x) for load, means &A operand is for inplace update
				u32 slength			! string length: includes any terminator

			end
		end
	end

	u32 pos:(sourceoffset:24, fileno:8)
	i32 dummy:(mode2:8, seqno:24)
![96]BYTE XXXX
end

export record fwdrec =
	ref fwdrec nextfwd
	i32 offset
	i16 reltype
	i16 seg
end

export type procinfo = ref procinforec

export record procinforec =
	byte pcldepth			!max pcl opnd depth (will include high-args)
	byte nparams			!copy of info in pstrec; may exclude not used?
	byte nlocals
	byte isleaf				!1 when there are no calls (explicit or implicit)
	byte nmaxargs			!0, or maxargs of any call (may be capped at 4)
	byte assemused			!1 if inline assembly used (can't optimise)
	byte mcldone			!
	byte hasblocks			!whether block modes are used (that means copyblock etc)
end

global procinfo pinfo

!global int frameoffset
!global int paramoffset
!global int framebytes

global const maxparams=32
global const maxlocals=256


!global int usedparams			!how many of pregs needed for used incoming params
!global int usedxparams			!how many of pxregs needed for used incoming params
!
!global int highreg				!highest D-reg used
!global int highxreg				!highest X-reg used
global int bspill, bxspill		!no. to spill
!global int bxspilloffset		!base frame offset of bxreg spill area

global byte r10used				!these may be set in pass2 when occupied by params
global byte r11used

!global int maxregvars			!how many locals would qualify for regvars
!global int maxxregvars			!how many locals would qualify for xregvars

global byte localshadow			!1 if local, proc-wide shadow space used for a call

export int mmpos

global psymbol psymboltable, psymboltablex

global psymbol currprog
export psymbol currfunc
global psymbol blockretname
global psymbol entryproc		!entry point function

strbuffer sbuffer
global ref strbuffer pdest=&sbuffer

global const maxplibfile=50
global [maxplibfile]ichar plibfiles
global [maxplibfile]u64 plibinst
global int nplibfiles

export ref func (int pos, ichar &filename, &sourceline)int igetmsourceinfo

global byte pcldone, mcldone, ssdone, objdone, exedone

export byte pverbose
global int pcmdskip
!global psymbol pdcmdskip			!reference to $cmdskip symbol

export int assemtype='AA'

GLOBAL INT PPSEQNO

!!GLOBAL CONST DOREDUCE=1
!GLOBAL CONST DOREDUCE=0

GLOBAL CONST REDUCELABELS=1
!GLOBAL CONST REDUCELABELS=0

export byte fpeephole = 1
export byte fregoptim = 1
export byte fnoconst  = 0
export byte fshowil   = 0
export byte flong64   = 0

export int pcltime,mcltime, sstime, objtime, exetime

EXPORT ICHAR $PMODULENAME

EXPORT [PCLNAMES.BOUNDS]INT PCLFLAGS

EXPORT INT PSTARTCLOCK

!export const ctarget=0
EXPORT INT NPCL
EXPORT INT NPST

