
export function writessdata(int fexe)ref strbuffer=
	gs_init(pdest)
GS_STRLN(PDEST,"HELLO/SS")
	showssdata(fexe)

	gs_line(pdest)
	return pdest
end

proc showssdata(int fexe)=
	pclerror("SS not done") when not ssdone

	gs_strln(pdest,(fexe|"EXE FORMAT"|"AFTER GENSS"))

!	showsections()

	gs_line(pdest)

!	showsectionrelocs2("Idata",ss_idatarelocs,ss_nidatarelocs)
!	showsectionrelocs2("Code",ss_coderelocs,ss_ncoderelocs)

	gs_str(pdest,"proc Section Zdata: ")
	gs_strint(pdest,ss_zdatalen)
	gs_line(pdest)

	showsectiondata(&sectiontable[dsect])
	showsectioncode(&sectiontable[csect])
	if fexe then
		showsectiondata(&sectiontable[isect])
	fi

	showsymboltable2()
	showimporttable()
	gs_strln(pdest,"END OF GENSS")

end

proc showsectiondata(ref sectionrec d)=
int i,k,length,bb
	[128]char str,str2
	ref byte p

	gs_str(pdest,"proc Section ")
	gs_str(pdest,d.name)
	gs_str(pdest," Size:")
	gs_strint(pdest,d.virtsize)
	gs_line(pdest)
	gs_line(pdest)

	k:=0
	if d.segtype<>impdata_seg then
		p:=bufferelemptr(d.data,0)
	else
		p:=d.bytedata
	fi
	length:=d.virtsize

	str[1]:=0

	ref byte baseaddr:=cast(imagebase+d.virtoffset)

	print @str2,baseaddr:"Z8H",,": "

	gs_str(pdest,str2)

	for i:=1 to length do
		bb:=p++^
		print @str2,bb:"z2H",," "
		gs_str(pdest,str2)

		if 32<=bb<=127 then
			str2[1]:=bb
			str2[2]:=0
			strcat(str,str2)
		else
			strcat(str,".")
		fi
		if ++k=16 or i=length then
			if k<16 then
				to 16-k do
					gs_str(pdest,"   ")
					strcat(str," ")
				od
			fi
			gs_str(pdest,"	[")
			gs_str(pdest,str)
			gs_strln(pdest,"]")
			k:=0
			str[1]:=0
			baseaddr+:=16
			print @str2,baseaddr:"z8h",,": "
			gs_str(pdest,str2)
		fi
	od
	if k=0 then
		gs_line(pdest)
	fi

	gs_line(pdest)
	if k then gs_line(pdest) fi
end

proc showsectioncode(ref sectionrec p)=
ref byte codeptr,codeend,codestart
	int length,offset
	ichar s
	[16]char str

	gs_strln(pdest, "proc Section Code")

	length:=p.virtsize
	codestart:=codeptr:=bufferelemptr(p.data,0)
	codeend:=codeptr+length

	ref byte baseaddr:=cast(imagebase+p.virtoffset)

!INT TT:=CLOCK(), N:=0
	while codeptr<codeend do
		offset:=codeptr-codestart
		s:=decodeinstr(codeptr,baseaddr+offset)
!++N
		exit when s=nil

		print @str,offset:"4",," "
		gs_str(pdest,str)

		gs_strln(pdest,s)
	od
!TT:=CLOCK()-TT
!CPL "DECODE TIME:",TT,N
!OS_GETCH()
	gs_line(pdest)
end

proc showsectionrelocs2(ichar caption,ref relocrec relocs, int nrelocs)=
	ref relocrec r

	gs_str(pdest,"proc Section Relocs: ")
	gs_str(pdest,caption)
	gs_str(pdest," ")
	gs_strint(pdest,nrelocs)
	gs_line(pdest)

	r:=relocs

	while r do

		gs_str(pdest,"Reloc: ")
		gs_str(pdest,relocnames[r.reloctype])
		gs_str(pdest," Offset: ")
		gs_strint(pdest,r.offset)
		gs_str(pdest," ST Index: ")
		gs_strint(pdest,r.stindex)
		gs_str(pdest," ")
		gs_str(pdest,ss_symboltable[r.stindex].name)
		gs_line(pdest)

		r:=r.nextreloc
	od
	gs_line(pdest)

end

proc gs_value(ichar caption, i64 value)=
	[256]char str

	strcpy(str,caption)
	strcat(str,":")
	ipadstr(str,20)
	gs_str(pdest,str)

	fprint @str,"0x# #",value:"H",value
	gs_strln(pdest,str)
end

proc showsymboltable2=

	gs_strln(pdest,"Proc Symbol Table")
	int i
	for i:=1 to ss_nsymbols do
		gs_strint(pdest,i)
		gs_str(pdest,": ")
		gs_strln(pdest,ss_symboltable[i].name)
	od
	gs_line(pdest)
end

proc showimporttable=
	[256]char str
	dllrec d
	importrec p


	gs_strln(pdest,"Proc Dll List")
	int i
	for i:=1 to ndlls do
		gs_strint(pdest,i)
		gs_str(pdest,": ")
		gs_str(pdest,dlltable[i].name)
		gs_str(pdest," ")
		gs_strint(pdest,dlltable[i].nprocs)
		gs_line(pdest)
		gs_value("		Name Table Offset",dlltable[i].nametableoffset)
		gs_value("		Addr Table Offset",dlltable[i].addrtableoffset)
		gs_value("		DLL Name Offset  ",dlltable[i].dllnameoffset)
	od
	gs_line(pdest)
	gs_strln(pdest,"Proc Import List")

	for i:=1 to nimports do
		p:=importtable[i]

		gs_strint(pdest,i)
		gs_str(pdest,": ")
		if p.libno then
			strcpy(str,p.name)
			ipadstr(str,16)
			gs_str(pdest,str)
			gs_str(pdest," (")
			gs_str(pdest,dlltable[p.libno].name)
			gs_strln(pdest,")")

			gs_value("	IAT Offset        ",p.iatoffset)
			gs_value("	Thunk Offset      ",p.thunkoffset)
			gs_value("	Hint/Name Offset  ",p.hintnameoffset)

		else
			strcpy(str,p.name)
			ipadstr(str,20)
			gs_str(pdest,str)
			gs_strln(pdest," (---)")
		fi
	od
	gs_line(pdest)
end

proc showsections=
	sectionrec s
	int i

	gs_strln(pdest,"proc Section Headersxxx")
	gs_line(pdest)

	for i:=1 to nsections do
		s:=sectiontable[i]

		gs_str(pdest,"Section ")
		gs_strint(pdest,i)
		gs_str(pdest,": ")
		gs_str(pdest,s.name)
		gs_str(pdest,"  (")
		gs_str(pdest,segmentnames[s.segtype])
		gs_strln(pdest,")")

		gs_value("    Raw Offset",s.rawoffset)
		gs_value("    Raw Size",s.rawsize)
		gs_value("    Virtual Offset",s.virtoffset)
		gs_value("    Virtual Size",s.virtsize)
		gs_value("    Nrelocs",s.nrelocs)
		gs_value("    Data",int(s.data))
		gs_line(pdest)

	od
end

