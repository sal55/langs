const n=10000

[n+2]byte data

proc main=
	int count:=0
	int j
!	ref[]byte data

	to 20'000 do

		for i:=1 to n do
			data[i]:=1
		od

		for i:=3 to n do
			if data[i] then
				++count
				j:=i+i
				while j<=n, j+:=i do
					if data[j] then
						data[j]:=0
					fi
				od
				
			fi
		od
	od

	println "Count =",count
end
