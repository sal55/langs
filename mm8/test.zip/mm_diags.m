int currlineno
int currfileno

strbuffer sbuffer
ref strbuffer dest=&sbuffer

const tab1="\t"
const tab2="\t\t"

!const fshowsymbols=1
const fshowsymbols=0

global proc printst(filehandle f,ref strec p,int level=0)=
	ref strec q

	printstrec(f,p,level)

	q:=p.deflist

	while q<>nil do
		printst(f,q,level+1)
		q:=q.nextdef
	od
end

proc printstrec(filehandle f,ref strec p,int level)=
	strec dd
	ref byte q
	strbuffer v
	ref strbuffer d:=&v
	int col,offset,n
	const tabstr="    "
	[256]char str

	gs_init(d)


!IF GETPCLMODE(P.MODE)<>TPBLOCK AND TTISBLOCK[P.MODE] THEN
!CPL "BLOCK MISMATCH", P.NAME
!FI
!


	print @str, p
	gs_str(d,str)
	gs_str(d," ")

	offset:=0
	to level do
		gs_str(d,tabstr)
		offset+:=4
	od
	gs_str(d,":")

	gs_leftstr(d,p.name,28-offset,'-')
	gs_leftstr(d,namenames[p.nameid],12,'.')

	col:=gs_getcol(d)
	dd:=p^


	gs_str(d,"[")
	if p.isimport then
		gs_str(d,"Imp ")
	else
		gs_str(d,SCOPENAMES[P.SCOPE])
		gs_str(d," ")
	fi

	if dd.isstatic then
		gs_str(d,"Stat")
	fi

	if dd.nameid=paramid and dd.parammode then
		gs_str(d,parammodenames[dd.parammode])
	fi

	if dd.align then
		gs_str(d,"@@")
		gs_strint(d,dd.align)
		gs_str(d," maxalign:")
		gs_strint(d,dd.maxalign)
		gs_str(d," ")
	fi
	if dd.optional then
		gs_str(d,"Opt ")
	fi
	if dd.varparams then
		gs_str(d,"Var:")
		gs_strint(d,dd.varparams)
		gs_str(d," ")
	fi

	if dd.moduleno then
		if dd.nameid<>subprogid then
			print @str,"Modno#",,dd.moduleno
		else
			print @str,"Subno#",,dd.subprogno
		fi
		gs_str(d,str)
	fi

	if dd.used then
		gs_str(d,"U ")
	fi

	if dd.isthreaded then
		gs_str(d,"Threaded ")
	fi


	gs_str(d,"]")
	gs_padto(d,col+10,'=')

	if p.owner then
		fprint @str,"(#)",p.owner.name
		gs_leftstr(d,str,18,'-')
	else
		gs_leftstr(d,"()",18,'-')
	fi

	case p.mode
	when tvoid then
		gs_str(d,"Void ")
	else
		GS_STRINT(D,P.MODE)
		GS_STR(D,":")

		gs_str(d,strmode(p.mode))
		gs_str(d," ")
	esac

	case p.nameid
	when fieldid,paramid then
		gs_str(d," Offset:")
		gs_strint(d,p.offset)
		if p.mode=tbitfield then
			gs_str(d," Bitoffset:")
			gs_strint(d,p.bitoffset)
			gs_str(d,":")
			gs_strint(d,p.bitfieldwidth)
		fi

		sprintf(str,"%.*s",int(p.uflags.ulength),&p.uflags.codes)
		print @str,p.uflags.ulength:"v",ichar(&p.uflags.codes):".*"
		gs_str(d," UFLAGS:")
		gs_str(d,str)
		gs_str(d,"-")
		gs_strint(d,p.uflags.ulength)

		if p.code then
			gs_str(d,"/:=")
			gs_strvar(d,strexpr(p.code))
		fi

!		if p.nameid=paramid and p.variadic then
!			gs_str(d,"...")
!		fi
	when procid then

		gs_str(d,"Index:")
		gs_strint(d,p.index)

		gs_str(d," Nret:")
		gs_strint(d,p.nretvalues)

	when dllprocid then
		gs_str(d,"Index/PCaddr:")
		gs_strint(d,p.index)
		if p.truename then
			gs_str(d," Truename:")
			gs_str(d,p.truename)
		fi

	when staticid then
		if p.code then
			gs_str(d,"=")
			gs_strvar(d,strexpr(p.code))
		fi

	when frameid then
		if p.code then
			gs_str(d,":=")
			gs_strvar(d,strexpr(p.code))
		fi

	when constid then
		gs_str(d,"Const:")
		gs_strvar(d,strexpr(p.code))

	when typeid then
		if p.baseclass then
			gs_str(d,"Baseclass:")
			GS_STR(D,"<HAS BASECLASS>")
		fi
!	when enumid then
!		gs_str(d,"Enum:")
!		gs_strint(d,p.index)
!	when dllmoduleid then
!		gs_str(d,"DLL#:")
!		gs_strint(d,p.dllindex)
	esac

	if p.atfield then
		gs_str(d," @")
		gs_str(d,p.equivfield.name)
		gs_str(d," +")
		gs_strint(d,p.equivoffset)
	fi
	if p.atvar then
		gs_strvar(d,strexpr(p.equivvar))
	fi

!gs_str(d," Module# ")
!gs_strint(d,p.moduleno)
!
	gs_str(d," Lineno: ???")
!gs_strint(d,p.lineno iand 16777215)

	gs_println(d,f)

	case p.nameid
	when constid,frameid,staticid,macroid then
		if p.code then
			printunit(p.code,dev:f)
		fi
	esac
end

global proc printstflat(filehandle f)=
symbol p
println @f,"GLOBAL SYMBOL TABLE:"

for i:=0 to hashtable.upb-1 do
	p:=hashtable[i]
	if p=nil then nextloop fi

!	IF P.NEXTDUPL=NIL THEN NEXTLOOP FI

	case p.symbol
	when namesym then
		println @f,i:"5",p,p.name,symbolnames[p.symbol],,":",,namenames[p.nameid]
		p:=p.nextdupl
		while p do
			print @f,"     ",p,p.name,symbolnames[p.symbol],,":",,namenames[p.nameid]
			if p.owner then
				fprint @f, " (From #:#)", p.owner.name, namenames[p.owner.nameid]
			fi

			println @f

			p:=p.nextdupl
		od
	esac
od
end

global proc printcode(filehandle f,ichar caption)=
ref strec p
ref procrec pp

pp:=proclist

while pp do
	p:=pp.def

	print @f,p.name,,"=",(p.scope|"Sub","Prog","Exp"|"Mod")
	if p.owner.nameid=typeid then
		print @f," in record",p.owner.name
	fi
	println @f
	printunit(p.code,0,"1",dev:f)
	println @f
	pp:=pp.nextproc
od
end

global proc printunit(ref unitrec p,int level=0,ichar prefix="*",filehandle dev=nil)=
!p is a tagrec
	ref unitrec q
	ref strec d
	int t
	ichar idname
	i64 a
	r32 x32
	static int cmpchain=0

	if p=nil then
		return
	fi

	if p.pos then
		currlineno:=getlineno(p.pos)
		currfileno:=p.fileno
	fi

	print @dev,p,":"
	print @dev,getprefix(level,prefix,p)

	idname:=jtagnames[p.tag]
	print @dev,idname,,": "

	case p.tag
	when jname then
		d:=p.def

		print @dev,d.name,namenames[d.nameid]

		if d.code then
			print @dev," {",,jtagnames[d.code.tag],,"}"
		fi

		print @dev," ",,getdottedname(d)!,q
		print @dev,(p.dottedname|" {Dotted}"|"")

		if p.c then
			print @dev," Lastcall:",p.c
		fi

		if p.addroffirst then
			print @dev," Addroffirst."
		fi

		print @dev," Moduleno:",p.moduleno

		if p.avcode then print @dev," AV:",char(p.avcode) fi

	PRINT @DEV,=P.INDEX


	when jlabeldef then
		println @dev,p.def.name

	when jconst then
		t:=p.mode
		a:=p.value
		if t=trefchar then
			if p.slength>256 then
				print @dev,"""",,"(LONGSTR)",""" *",,p.slength
			elsif p.slength then
				print @dev,"""",,p.svalue,,""" *",,p.slength
			else
				print @dev,""""""
			fi

		elsecase ttbasetype[t]
		when ti64,ti32,ti16,ti8 then print @dev,i64(a)
		when tu64,tu32,tu16,tu8 then print @dev,u64(a)
		when tc64,tc8 then print @dev,chr(a)

		when tr32, tr64 then
			print @dev,p.xvalue
		when tref then
			if p.value then
				print @dev,"#",,p.value,P.SLENGTH
			else
				print @dev,"NIL"
			fi
		when tbool then
			print @dev,(p.value|"True"|"False")
		when tarray then
			print @dev, "<ARRAY>",=P.STRTYPE,=P.SLENGTH
		else
			println =typename(t),typename(ttbasetype[t])
			PRINT @DEV,"<PRINTUNIT BAD CONST PROBABLY VOID"
		fi
		print @dev," ",,typename(t)
		if p.isastring then
!			print @dev," <isstr>"
			fprint @dev," <isstr>(#)",p.strtype
		fi

		if p.whenlabel then
			print @dev," *L",,p.whenlabel
		fi

	when jdecimal then
		print @dev,p.svalue,"Len:",p.slength

	when jtypeconst then
		print @dev,typename(p.mode),typename(p.value)

	when jbitfield then
		print @dev,bitfieldnames[p.bfcode]+3

	when jconvert,jtypepun then
		print @dev," Convmode:",strmode(p.convmode)

	when jmakelist then
		print @dev,"Len:",p.length," Makeax:",p.makearray

	when jdot then
		print @dev,"Offset:",p.offset

	when jindex, jptr then

	when jexit,jredo,jnext then
		print @dev,"#",,p.index

	when jsyscall then
		print @dev,sysfnnames[p.fnindex]+3

	when jassem then

	when jassemreg then

	when jassemxreg then

	when jassemmem then

	when jmakeset then
	when jcmpchain then
		for i to p.cmpgenop.len do
			if p.cmpgenop[i]=0 then exit fi
			print @dev,ccnames[p.cmpgenop[i]],," "
		od
	esac

	if p.isconst then
		print @dev," Is const"
	else
		print @dev," Not const"
	fi

	case p.tag
	when jbin, jbinto, junary, junaryto, jincr,
		jandl, jorl, jnotl, jistruel then
		if p.pclop then
			fprint @dev," Pcl<#>",pclnames[p.pclop]
		else
			fprint @dev," no-op"
		fi
	when jprop then
		fprint @dev, " Prop<#>", propnames[p.propcode]
	when jconvert then
		fprint @dev, " Conv<#>", convnames[p.convcode]
	when jcmp then
		fprint @dev," Pclcond<#>",ccnames[p.pclcond]
	esac

	println @dev

	for i to jsubs[p.tag] do
		printunitlist(dev,p.abc[i],level+1,strint(i))
	od
end

proc printunitlist(filehandle dev,ref unitrec p,int level=0,ichar prefix="*")=
	if p=nil then return fi

	while p do
		printunit(p,level,prefix,dev)
		p:=p.nextunit
	od
end

func getprefix(int level,ichar prefix,ref unitrec p)ichar=
!combine any lineno info with indent string, return string to be output at start of a line
	static [1024]char str
	[1024]char indentstr
	[16384]char modestr
	ichar isexpr

	indentstr[1]:=0
	if level>10 then level:=10 fi

	to level do
		strcat(indentstr,"- ")
	od

	isexpr:="S"
	if jisexpr[p.tag] then isexpr:="E" fi

	case p.tag
	when jif, jswitch, jcase, jselect then
		if p.mode=tvoid then
			isexpr:="S"
		fi
	esac

	fprint @modestr,"# #:#",isexpr,(p.resultflag|"RES"|"---"),strmode(p.mode)
	modestr[256]:=0

	strcat(modestr,"-----------------------------")
	modestr[17]:=' '
	modestr[18]:=0

	strcpy(str,getlineinfok())
	strcat(str,modestr)
	strcat(str,indentstr)
	strcat(str,prefix)
	if prefix^ then
		strcat(str," ")
	fi

	return str
end

func getlineinfok:ichar=			!GETLINEINFO
	static [40]char str

	fprint @str,"# # ",CURRFILENO:"Z2",currlineno:"z4"
	return str
end

global proc printmodelist(filehandle f)=
	int mbase
	static ichar tab="\t"

!	PRINTLN @F,=NTYPENAMES
!	FOR I TO NTYPENAMES DO
!		PRINTLN @F,I,TYPENAMES[I].DEF.NAME
!	OD
!	PRINTLN @F
!
	println @f,"MODELIST",ntypes

	for m:=0 to ntypes do
		println @f,m:"4",strmode(m)
		mbase:=ttbasetype[m]

		println @f,tab,"Basetype:",mbase,strmode(mbase)
		println @f,tab,"ttname:",ttname[m]
		println @f,tab,"ttnamedef:",ttnamedef[m],(ttnamedef[m]|ttnamedef[m].name|"-")
		println @f,tab,"Target:",strmode(tttarget[m])
		println @f,tab,"Size:",ttsize[m],"Sizeset",ttsizeset[m]
		fprintln @f,"# Bounds: #..#  Length:#",tab,ttlower[m],ttlower[m]+ttlength[m]-1,ttlength[m]
		if mbase=ttuple then
			print @f,tab,"Mult:"
			for i to ttlength[m] do print @f,strmode(ttmult[m,i]),," " od
			println @f
		fi
		println @f,tab,"Signed:",ttsigned[m]
		println @f,tab,"Isreal:",ttisreal[m]
		println @f,tab,"Isinteger:",ttisinteger[m]
		println @f,tab,"Isshort:",ttisshort[m]
		println @f,tab,"Isref:",ttisref[m]
		println @f,tab,"Isblock:",ttisblock[m]
		println @f
	od
end

global proc showprojectinfo(filehandle dev)=
	imodule pm
	isubprog ps
	static ichar tab="    "
	ichar s
	byte isfirst, ismain

	println @dev,"Project Structure:"
	println @dev,"---------------------------------------"
	println @dev,"Modules",nmodules
	for i to nmodules do
		pm:=modules[i]

		if i>1 and pm.subprogno<>modules[i-1].subprogno then
			println @dev
		fi
		ps:=subprogs[moduletosub[i]]

			isfirst:=ps.firstmodule=i
			ismain:=ps.mainmodule=i

			if isfirst and ismain then s:="hm"
			elsif isfirst then s:="h "
			elsif ismain then s:="m "
			else s:="  " 
			fi

			print @dev, tab,i:"2",s,
			pm.name:"16jl", "Sys:",pm.issyslib,
			"Sub:",subprogs[pm.subprogno].name,"Fileno:",pm.fileno

		if pm.stmacro then
			print @dev," Alias:",pm.stmacro.name
		fi
		if pm.stmain then
			print @dev,$,pm.stmain.name,":",scopenames[pm.stmain.scope],pm.stmain
		fi
		if pm.ststart then
			print @dev,$,pm.ststart.name,":",scopenames[pm.ststart.scope],pm.ststart
		fi

		println @dev
	od
	println @dev

	println @dev,"Subprograms",nsubprogs, =mainsubprogno
	for i to nsubprogs do
		ps:=subprogs[i]
		println @dev, tab,i,ps.name,"Sys:",ps.issyslib!,=PS.STSUBPROG

		if ps.firstmodule then
			print @dev, tab,tab
			for j:=ps.firstmodule to ps.lastmodule do
				print @dev, $,modules[j].name,"(",MODULES[J].STSUBPROG,")"
			od
			println @dev
		fi
	od
	println @dev

	println @dev,"Sourcefiles",nsourcefiles
	ifile pf
	for i to nsourcefiles do
		pf:=sources[i]
		fprintln @dev, "  #:  Name=# File=# Path=# Spec=# Size=#",
			i:"2",pf.name:"jl16", pf.filename:"jl18", pf.path:"20jl", pf.filespec:"30jl", pf.size:"7"
	od
	println @dev

	println @dev,"Link files",nlibfiles
	for i to nlibfiles do
		println @dev, tab, libfiles[i]:"16jl"
	od
	println @dev
end

global proc showlogfile=
	[256]char str
	filehandle logdev
	int size
	ref strbuffer ss

	if not debugmode then return fi

	logdev:=fopen(logfile,"w")

	if fshowmodules then showprojectinfo(logdev) fi
!
	if fshowasm and dpasslevel>=dmcl_pass then
		if ctarget then
			println @logdev,"PROC CLANG"
			addtolog(changeext(outfile, "c"),logdev)
		else
			println @logdev,"PROC ASSEMBLY"
			addtolog(changeext(outfile, asmext),logdev)
		fi
	fi

	if fshowpcl and dpasslevel>=dpcl_pass then
		addtolog(changeext(outfile, "pcl"),logdev)
	fi
!	if fshowc and dpasslevel>=dclang_pass then
!		addtolog(changeext(outfile, "c"),logdev)
!	fi
	if fshowpst and dpasslevel>=dpcl_pass then
		addtolog("PSYMTAB", logdev)
	fi

	if fshowast3 and dpasslevel>=dtype_pass then addtolog("AST3", logdev) fi
	if fshowast2 and dpasslevel>=dname_pass then addtolog("AST2", logdev) fi
	if fshowast1 and dpasslevel>=dparse_pass then addtolog("AST1", logdev) fi

	if fshowst then
		showsttree("SYMBOL TABLE",logdev)
	fi
	if fshowstflat then
		showstflat("FLAT SYMBOL TABLE",logdev)
	fi
!
	if fshowtypes then
		printmodelist(logdev)
	fi

	size:=getfilesize(logdev)
	fclose(logdev)

	if size then
CPL "PRESS KEY..."; if OS_GETCH()=27 then stop fi
		print @str,"\\m\\ed.bat ",logfile

		if checkfile("mm.m") then
			os_execwait(str,0,nil)
		else
			println "Diagnostic outputs written to",logfile
		fi
	fi
end

proc showstflat(ichar caption,filehandle f)=
	println @f,"PROC",caption
	printstflat(f)
	println @f
end

proc showsttree(ichar caption,filehandle f)=
	println @f,"PROC",caption
	printst(f,stprogram)
	println @f

	println @f, "Proc List:"
	ref procrec pp:=proclist
	while pp do
		symbol d:=pp.def
		fprintln @f,"#	#.# (#) Mod:",d,d.owner.name, d.name:"20jl", namenames[d.nameid],
			d.moduleno
		pp:=pp.nextproc
	od
	println @f,"End\n"

	println @f, "DLL Proc List:"
	for i to ndllproctable do
		d:=dllproctable[i]
		fprintln @f,"#	#.# (#) Mod:",d,d.owner.name, d.name:"20jl", namenames[d.nameid],
			d.moduleno
	od
	println @f,"End\n"
end

global proc showast(ichar filename)=
	filehandle f

	f:=fopen(filename,"w")
	return unless f

	println @f,"PROC",filename
	printcode(f,"")
	println @f
	fclose(f)
end

global proc printsymbol(ref tokenrec lp)=
	tokenrec l
	l:=lp^

	printf("%-18s",symbolnames[l.symbol])

	switch l.symbol
	when namesym then
		printstrn(l.symptr.name,l.symptr.namelen)

		if l.subcode then
			fprint " [#]",symbolnames[l.subcode]
		fi

	when intconstsym then
		case l.subcode
		when tint then print l.value,"int"
		when tword then print l.uvalue,"word"
		else print l.value
		esac

	when realconstsym then
		print l.xvalue

	when stringconstsym then
		print """"
		printstr(l.svalue)
		print """",strlen(l.svalue)

	when charconstsym then
		print "'"
		printstr(l.svalue)
		print "'"

	when assignsym,addrsym,ptrsym,rangesym,
		andlsym,orlsym,eqsym,cmpsym,addsym,subsym,
		mulsym,divsym,idivsym,iremsym,iandsym,iorsym,ixorsym,shlsym,shrsym,
		minsym,maxsym,powersym then
		print symbolnames[l.symbol]
	elsif l.subcode then
		fprint "SUBCODE:",l.subcode
!	fprint "#",symbolnames[l.subcode]
	end

	println $,=lx.fileno

end

proc showtime(ichar caption, int t)=
	fprintln "# # ms # %", caption:"12jl", t:"5", (t*100.0)/compiletime:"5.1jr"
end

global proc showtimings=
	endclock:=os_clock()
	compiletime:=endclock-startclock

	showtime("Load:",		loadtime)
	showtime("Parse:",		parsetime)
	showtime("Resolve:",	resolvetime)
	showtime("Type:",		typetime)
	showtime("PCL:",		pcltime)
	showtime("MCL:",		mcltime)
	showtime("SS:",			sstime)
	showtime("EXE:",		exetime)
	println "-----------------------------"
	showtime("Total:",		compiletime)
end

