const maxlabel=1 million

psymbol dentry=nil
!int labelno

[pclnames.bounds]byte isdirective

const maxlocals=1000
[maxlocals]psymbol localvars			!a proc's params and locals
int nlocals


global proc parsefile(ichar source)=
	int condcode

	startlex(source)
	pcl_start("demoxxx")


	do
		lex()

		case lx.symbol
		when eolsym then
		when namesym then
			case lx.ksymbol
			when opcode_rw then

				parseinstr(lx.symptr.opcode)

			when jumpcc_rw then
				parseinstr(kjumpcc, lx.symptr.opcode)
			when setcc_rw then
				parseinstr(ksetcc, lx.symptr.opcode)
			else
				serror("Instr expected")
			esac
		when labelsym then
			if lx.value not in 1..maxlabel then serror("Bad label no") fi
			mlabelno max:=lx.value
			pc_gen(klabel, genlabel(lx.value))
			lex()
			checkcolon(1)

		when eofsym then
			exit
		else
			serror("Opcode expected")
		esac

		if lx.symbol<>eolsym then serror("Extraneous tokens on line") fi

	od

	pcl_end()

end

proc parseinstr(int opcode, condcode=0)=
!instr format:
! opcode type1 [/type2] [/attr1 [attr2]] [[&]operand] [:[::]]
!current token is the opcode

	int x, y, size, size2
	byte mode, mode2, ntypes, nattrs, opndtype, needopnd, n
	pcl p
	psymbol d, e
	ref byte q, r

	lex()

	ntypes:=pclhastype[opcode]
	nattrs:=pclextra[opcode]
	needopnd:=pclhasopnd[opcode]
	mode:=mode2:=tpvoid
	x:=y:=size:=opndtype:=0
	p:=nil

	if ntypes then
		if lx.symbol=divsym then skipmode fi		!leave as void
		mode:=readmode(size)
		if ntypes=2 then
			checksymbol(divsym)
			lex()
			mode2:=readmode(size2)
		fi
	fi
skipmode:

	if nattrs then
		if lx.symbol<>divsym and opcode=kjumpcc then skip fi		!/popone=0 is assumed

		if lx.symbol=namesym and lx.ksymbol=type_rw then
			mode:=readmode(size)
		fi

		if lx.symbol<>divsym then skip fi			!assume /0

		checksymbol(divsym)
		lex()
		checksymbol(intsym)
		x:=lx.value
		y:=0
		lex()

		if lx.symbol=divsym then
			if nattrs<2 then serror("Extra attribute") fi
			lex()
			checksymbol(intsym)
			y:=lx.value
			lex()
		fi
skip:
	fi

	if isdirective[opcode] then
		dodirective(opcode, mode, size, x, y)
		return
	fi

	if needopnd then				!needs operand
!CPL "OPND", SYMBOLNAMES[LX.SYMBOL]

		opndtype:=symtoopnd[lx.symbol]
!CPL "OPND2", OPNDNAMES[OPNDTYPE]

		case opndtype
		when 0 then
			serror("Missing or bad operand")
		when mem_opnd, label_opnd, string_opnd, memaddr_opnd then
			if needopnd not in [opndtype, any_opnd] then
				serror("Incorrect operand type")
			fi
		esac						!else any allowed, or a mixture


		case lx.symbol
		when intsym then
			if mode=tpblock then
				if opcode<>kdata then serror("block data?") fi
				q:=r:=pcm_alloc(size)
				for i to size do
					checksymbol(intsym)
					r++^:=lx.value
					lex() when i<size
				od
				p:=gendata(q, size)
			else
				p:=genint(lx.value)
			fi

		when realsym then
			p:=genreal(lx.xvalue, mode)
		when stringsym then
			p:=genstring(lx.svalue)
		when namesym then
			d:=lookuplocal(lx.symptr)
			if d.ksymbol=inf_rw then
				p:=genreal(infinity, mode)
			else
				p:=genmem(d)
			fi
		when addrsym then
			lex()
			checksymbol(namesym)
	
			d:=lookuplocal(lx.symptr)
			p:=genmemaddr(d)

		when labelsym then
			mlabelno max:=lx.value
			p:=genlabel(lx.value)
		else
			serror("Bad opnd type")
		esac

		lex()

	fi

	pc_gen(opcode, p)
	pccurr.condcode:=condcode

	pc_setmode(mode, size)
	if ntypes=2 then
		pc_setmode2(mode2)
	fi

	pc_setxy(x, y)
	pccurr.sourceoffset:=lx.lineno
end

proc start=
	static[]byte directives=(
		kproc, kendproc, kistatic, kzstatic, klocal, kparam, krettype,
		kaddlib, kextproc, ktcproc, kvariadic)

	for x in directives do
		isdirective[x]:=1
	od
end

proc serror(ichar mess)=
	println "Syntax error:", mess, "on line", lx.lineno
	println
	stop 1
end

proc skiptoeol=
	while lx.symbol<>eolsym do
		lex()
	od
end

proc checksymbol(int expected)=
	[256]char str

	if lx.symbol<>expected then
		fprint @str, "# expected, not #", symbolnames[expected], symbolnames[lx.symbol]
		serror(str)
	fi
end

func readmode(int &size)int m=
!positioned at mode token
	psymbol d:=lx.symptr
	if lx.symbol<>namesym or d.ksymbol<>type_rw then serror("Type expected") fi

	m:=d.mode
	size:=psize[m]
	lex()

	if m=tpblock then
		checkcolon(1)
		checksymbol(intsym)
		size:=lx.value
		lex()
	fi

	return m
end

func checkcolon(int n)int m=
!should at a colon symbol; check that, plus any more up to n colons in
!all. Return the number seen
!1 colon: label or local symbol defined (or can separate block type from its size)
!2 colons: symbol exported
!3 colons: symbol is the entry point
!exit with following token current

	m:=0
	while lx.symbol=colonsym do
		++m
		lex()
	od

	if m=0 then serror("Colon expected") fi
	if m>n then serror("Too many colons") fi

	return m
end

func lookuplocal(psymbol d)psymbol=

	if currfunc=nil then return d fi

!Look up any as yet undefined symbol in local list
	for i to nlocals do
		if localvars[i].generic=d then
			return localvars[i]
		fi
	od
	d
end

global func checkundefined:int=
	ref[]byte labelmap
	pcl pc
	int labno
	byte errors:=0

	labelmap:=pcm_allocz(mlabelno)

	pc:=pcstart
	while pc<=pccurr, ++pc do

		if pc.opcode=klabel then
			labno:=pc.labelno
			if labelmap[labno] then
				println "Duplicate label: #:",labno
				errors:=0
			fi
			labelmap[labno]:=1
		fi
	od

	pc:=pcstart
	while pc<=pccurr, ++pc do

		if pc.opcode<>klabel then
			case pc.opndtype
			when mem_opnd, memaddr_opnd then
				if pc.def.id=null_id then
					fprintln "Undefined name: # on line #", pc.def.name, pc.sourceoffset
					errors:=1
				fi
				pc.def.used:=1
			when label_opnd then
				labno:=pc.labelno
				if labelmap[pc.labelno]=0 then
					fprintln "Undefined label: ## on line #", "#", pc.labelno, pc.sourceoffset
					errors:=1
				fi
			esac
		fi
	od

	pcm_free(labelmap, mlabelno)
	errors
end

proc dodirective(int opcode, mode, size, x, y)=
!a directive opcode has been seen. Line has been processed beyond
!mode and attributes, and current token is what follows (usually a name)
!deal with these special ops here
	psymbol d, e
	int n

!do ones that don't define a name first
	case opcode
	when kaddlib then
		checksymbol(stringsym)
		pc_addplib(lx.svalue)
		lex()
		return
	when kendproc then
		pc_endproc()
		return

	when krettype then
		if currfunc=nil then serror("rettype?") fi
		currfunc.mode:=mode
		currfunc.size:=size
		return

	when kvariadic then
		currfunc.variadic:=1
		return
    esac

!the first define a new name

	checksymbol(namesym)
	d:=lx.symptr
	lex()

	if opcode in [kparam, klocal] then
		if currfunc=nil then serror("Not in a proc") fi

!check for dupl local
		for i to nlocals do
			if localvars[i].generic=d then serror("Dupl local") fi
		od

!		e:=currfunc.nextparam
!		while e, e:=e.nextparam do if e.generic=d then serror("P:Dupl local") fi od
!		e:=currfunc.nextlocal
!		while e, e:=e.nextlocal do if e.generic=d then serror("L:Dupl local") fi od
!
		e:=pc_duplpst(d)
			
		if nlocals>=maxlocals then serror("Too many locals") fi
		localvars[++nlocals]:=e

		if opcode=kparam then
			e.id:=param_id
			pc_addparam(e)
		else
			e.id:=local_id
			pc_addlocal(e)
		fi
		e.mode:=mode
		e.size:=size

	else
		if currfunc then serror("Not allowed in proc") fi
		if d.id<>null_id then serror(addstr("Dupl name:",d.name)) fi

		nlocals:=0

		case opcode
		when kproc, ktcproc then
			n:=checkcolon(3)
			d.id:=proc_id
			if n>=2 then d.exported:=1 fi
			if n=3 then
				if dentry then serror("Dupl entry point") fi
				d.isentry:=1
				dentry:=d
			fi
			pc_defproc(d, mode, isentry:dentry<>nil, threaded:opcode=ktcproc)

		when kistatic, kzstatic then
			d.id:=static_id
			if checkcolon(2)=2 then
				d.exported:=1
			fi
			pc_gen(opcode, genmem(d))
			pc_setmode(mode, size)

		when kextproc then
			d.id:=import_id
			d.imported:=1
		else
			serror("Direct?")
		esac
	fi
end

