!export int assemtype='AA'

export ichar asmext="asm"

const fshowseq=1
!const fshowseq=0

!const useintelregs=1
const useintelregs=0

const showsizes=1
!const showsizes=0

!const showfreed=1
const showfreed=0

!const fextendednames=1			!include module name in qualified names
const fextendednames=0

[8, r0..r15]ichar nregnames

[r0..r15]psymbol regvars		!nil, or strec when it uses that reg
[r0..r15]psymbol xregvars

proc writemcl(int index,ref mclrec mcl)=

!	case mcl.opcode
	
	if mcl.opcode=m_comment and mcl.a.svalue^='?' then
	else
		strmcl(mcl)
		gs_line(pdest)
	fi
!	esac
end

global proc strmcl(ref mclrec mcl)=
	static [512]char str
	[128]char opcname
	mclopnd a,b
	int opcode,cond,sizepref
	ichar s,comment
	psymbol d

	opcode:=mcl.opcode
	str[1]:=0

	cond:=mcl.cond
	a:=mcl.a
	b:=mcl.b
	comment:=nil

	case opcode
	when m_procstart then
		asmstr(";Proc ")
		asmstr(a.def.name)
		currasmproc:=a.def
		clear regvars
		clear xregvars

		return

	when m_procend then
		asmstr(";End\n")
		currasmproc:=nil

		return

	when m_comment then
		asmchar(';')
		asmstr(a.svalue)
		return
	when m_endx then
		return

	when m_labelname then				!label name will be complete and will have colon(s)
		d:=a.def
		case a.valtype
		when def_val then
			asmstr(getdispname(d))
		when stringimm_val then
			asmstr(a.svalue)
			return
		else
			merror("strmcl/lab")
		esac

		asmstr(":")

		if d.exported then
			if eqstring(getbasename(d.name), d.name) then
				asmstr(":")
			else
				asmstr("\n`")
				asmstr(getbasename(d.name))
				asmstr("::")
			fi
		fi


		return

	when m_labelx then
		if a.valtype=label_val then
			fprint @str,"L#:",a.value
		else
			recase m_labelname
		fi
		asmstr(str)
		return

	when m_define then
		asmstr("    ")
		asmstr(a.svalue)
		asmstr(" = ")
		asmopnd(b)
		return

	when m_definereg then
		d:=a.def
		asmstr("    ")
		asmstr(getdispname(d))
		if ispfloat(d.mode) then
			xregvars[d.reg]:=d
		else
			regvars[d.reg]:=d
		fi

!		asmstr(a.svalue)
		asmstr(" = ")

		case b.mode
		when a_reg then
			asmstr(getregname(b.reg, b.size))

		else
			asmstr(getxregname(b.reg, b.size))
		esac
		return

!	WHEN M_TRACE THEN
!!		ASMSTR(SINCLUDE("c:\\px\\trace.aa"))
!		ASMSTR(SINCLUDE("c:trace.aa"))
!
!		RETURN

	esac

	case opcode
	when m_jmpcc then
		print @opcname,"j",,asmcondnames[cond]

	when m_setcc then
		print @opcname,"set",,asmcondnames[cond]

	when m_cmovcc then
		print @opcname,"cmov",,asmcondnames[cond]

	when m_andx then
		strcpy(opcname,"and")
	when m_orx then
		strcpy(opcname,"or")
	when m_xorx then
		strcpy(opcname,"xor")
	when m_notx then
		strcpy(opcname,"not")

	when m_ascii then
		strcpy(opcname, "dq")

	ELSIF OPCODE>M_HALT THEN
		STRCPY(OPCNAME,STRINT(OPCODE))

	else
		strcpy(opcname,mclnames[opcode]+2)
	esac

	ipadstr(opcname,(opcode=m_dq|4|10)," ")

	ipadstr(str,4)

	strcat(str,opcname)

	asmstr(str)

	if a and b then		!2 operands
		sizepref:=needsizeprefix(opcode,a,b)
!
		asmopnd(a,sizepref)
		asmstr(",	")
		asmopnd(b,sizepref)

		if mcl.c then
			asmstr(",")
			asmstr(strint(mcl.c))
		fi

	elsif a and a.mode then								!1 operand
		if opcode=m_call then
			asmopnd(a,0,opcode)
		else
			asmopnd(a,1,opcode)
		fi
	fi

	if showsizes then
		if a then
			asmstr("  ; ")
			asmstr(strint(a.size))
			if b then
				asmstr("/")
				asmstr(strint(b.size))
			fi
		fi
	fi

IF SHOWFREED THEN
BYTE FIRST:=1
	FOR R IN R0..R15 WHEN MCL.REGFREED[R] DO
		IF FIRST THEN
			FIRST:=0
			ASMSTR(" #======<")
		ELSE
			ASMSTR(" ")
		FI
		ASMSTR(GETREGNAME(R))
	OD
	IF NOT FIRST THEN
		ASMSTR(">")
	FI
FI

IF FSHOWSEQ THEN ASMSTR("	#"); ASMSTR(STRINT(MCL.SEQNO)) FI
end

global func strmclstr(ref mclrec m)ichar=
	gs_init(pdest)
	strmcl(m)
	return pdest.strptr
end

global func mstropnd(mclopnd a,int sizeprefix=0,opcode=0)ichar=
	static [512]char str
	[128]char str2
	ichar plus,t
	int offset,tc

	str[1]:=0

	case a.mode
	when a_reg then
		return strreg(a.reg, a.size)

	when a_imm then
		if opcode=m_dq and a.valtype=intimm_val then
			if a.value in 0..9 then
				strcat(str,strint(a.value))
			else
				strcat(str,"0x")
				strcat(str,strword(a.value,"H"))
			fi
		else
			strcpy(str,strvalue(a))
		fi

	when a_mem then
!		case a.valtype
!		when intimm_val then
!CPL "OPND/MEM/INT"
!			strcpy(str,strint(a.value))
!		when realimm_val then
!CPL "OPND/MEM/REALIMM"
!			strcpy(str,strreal(a.xvalue))
!		when realmem_val then
!CPL "OPND/MEM/REALMEM"
!			fprint @str,"M#",a.xvalue
!		esac
!CPL "OPND/MEM"

		strcat(str,getsizeprefix(a.size,sizeprefix))
		strcat(str,"[")

		plus:=""
		if a.reg then
			strcat(str,strreg(a.reg,8))
			plus:=" + "
		fi
		if a.regix then
			strcat(str,plus)
			strcat(str,strreg(a.regix,8))
			plus:=" + "

			if a.scale>1 then
				strcat(str,"*")
				strcat(str,strint(a.scale))
			fi
		fi

		if a.valtype in [def_val,label_val, temp_val] then
			if plus^ then
				strcat(str,plus)
			fi
			strcat(str,strvalue(a))
	    elsif offset:=a.offset then
			print @str2,offset:" + "
			strcat(str,str2)
		fi
		strcat(str,"]")

	when a_xreg then
		return strxreg(a.reg,a.size)

	else
		println "BAD OPND",A.MODE
		return "<BAD OPND>"
	esac

	return str
end

global func strvalue(mclopnd a)ichar=
	static [512]char str
	[128]char str2
	psymbol def
	i64 value,offset,length
	ichar ss

	def:=a.def
	value:=a.value

	strcpy(str,"")

	case a.valtype
	when def_val then
		strcat(str,getdispname(def))

	addoffset:
		if offset:=a.offset then
			print @str2,(offset>0|"+"|""),,offset
			strcat(str,str2)
		fi

	when intimm_val then
		strcat(str,strint(value))

	when realimm_val then
		print @str,a.xvalue:"20.20"

	when realmem_val then
		strcat(str,"M")
		strcat(str,strreal(a.xvalue))

	when stringimm_val then
		strcat(str,"""")
		strcat(str,a.svalue)
		strcat(str,"""")

	when name_val then
		strcat(str,a.svalue)

	when label_val then
		strcat(str,"L")
		strcat(str,strint(a.labelno))
		goto addoffset

	when temp_val then
		return gettempname(currasmproc,a.tempno)

	else
		merror("Stropnd?")
	esac

!STRCAT(STR, VALTYPENAMES[A.VALTYPE])
	return str

end

global proc asmopnd(mclopnd a,int sizeprefix=0,opcode=0)=
	asmstr(mstropnd(a,sizeprefix,opcode))
end

global func getregname(int reg,size=8)ichar=
	static [1..17]ichar prefix=("B","W","","A","","","","D","","","","","","","","Q","N")
	static [32]char str
	[16]char str2
	ichar rs
	int size2

	if useintelregs then
		return nregnames[size, reg]
	fi

	size2:=size
	if size2>16 then
		size2:=17
	FI

	case reg
	when rnone then return "-"
	when rframe then rs:="fp"
	when rstack then rs:="sp"
	else
		getstrint(reg-r0,str2)
		rs:=str2
	esac

	print @str,prefix[size2],,rs
	return str
end

global func getxregname(int reg,size=8)ichar=
	static [32]char str

	if reg=rnone then return "-" fi

	print @str,"XMM",,reg-xr0
	return str
end

proc asmstr(ichar s)=
	gs_str(pdest,s)
end

proc asmchar(int c)=
	gs_char(pdest,c)
end

global func getdispname(psymbol d)ichar=
	static [256]char str

	if d.reg then

		IF FEXTENDEDNAMES THEN
			fprint @str,"##R.#.#", (fpshortnames|""|"`"),(pfloat[d.mode]|"X"|""), $PMODULENAME,(fpshortnames|d.name|getfullname(d))
		else
			fprint @str,"##R.#", (fpshortnames|""|"`"),(pfloat[d.mode]|"X"|""), (fpshortnames|d.name|getfullname(d))
		fi

		return str
	fi

	if fpshortnames then
		return d.name
	else
		return getfullname(d,backtick:1)
	fi

end 

global func gettempname(psymbol d, int n)ichar=
	static [128]char str

	if fpshortnames or d=nil then
		print @str,"T",,n
	else
		fprint @str,"#.$T#",getdispname(d),n
	fi
	str
end

EXPORT func strreg(int reg, size=8)ichar=
	psymbol d

	d:=regvars[reg]
!D:=NIL

	if d and psize[d.mode]=size then
		return getdispname(d)
	fi
	getregname(reg,size)
end

func strxreg(int reg, size=8)ichar=
	psymbol d

	d:=xregvars[reg]

	if size=8 and d then
		getdispname(d)
	else
		getxregname(reg,size)
	fi
end

export func getassemstr:ref strbuffer=
!write all mcl code in system by scanning all procs
!mcl code is only stored per-proc
	psymbol d,e
	ref mclrec m
	[32]char str2,str3
	int i

	gs_init(pdest)
!
	asmstr(";   mm7\n")
	case phighmem
	when 1 then asmstr("    $userip\n")
	when 2 then asmstr("    $highmem\n")
	esac

	m:=mccode
	i:=1
	while m do
		writemcl(i,m)
		++i
		m:=m.nextmcl
	od

	return pdest
end

global func needsizeprefix(int opcode,mclopnd a,b)int=
	case opcode
	when m_movsx, m_movzx, m_cvtsi2ss, m_cvtsi2sd then
		return 1

	when m_cvtss2si,m_cvtsd2si, m_cvttss2si,m_cvttsd2si then
		return 1
	when m_shl, m_shr, m_sar then
		if a.mode=a_mem then return 1 fi
		return 0
	esac

	if a.mode=a_reg or a.mode=a_xreg or b.mode=a_reg or b.mode=a_xreg then
		return 0
	fi
	return 1
end

global func getsizeprefix(int size,enable=0)ichar=
	if not enable then return "" fi
	case size
	when 1 then return "byte "
	when 2 then return "u16 "
	when 4 then return "u32 "
	when 8 then return "u64 "
	esac
	return ""
end

proc start=
	byte flag

	assemtype:='AA'

	if useintelregs then
		for i in 1..8 when i in [1,2,4,8] do
			for r in r0..r15 do
				flag:=0
				for k in dregnames.bounds do
					if flag then
						if regsizes[k]=i and regindices[k]=r then
							nregnames[i, r]:=dregnames[k]
						fi
					elsif regsizes[k]=0 then
						flag:=1
					fi
				od
			od
		od
	fi
end
