global proc domcl_assem(unit pcode)=
	return when not pcode or pcode.tag<>jassem
end

global func checkasmlabel(unit p)int=
	0
end
