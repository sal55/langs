importdll msvcrt=
	proc puts(ichar)
	proc printf(ichar,...)
end

func bitsinbyte(int b)int=
	int c,m
	c:=0
	m:=1
	while m<256 do
		if b iand m then ++c fi
		 m<<:=1
	od

	return c
end

proc main=
	int n:=0
	to 1000 do
		for x:=1 to 350 do
			for y:=0 to 255 do
				n+:=bitsinbyte(y)
			od
		od
	od
!	println "N=",n
end

