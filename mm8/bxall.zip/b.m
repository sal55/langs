proc main=
	static []int data0=(1971,51,28,100,22, 2008,10,26,40,5, 78,347,1,0,848, 9,100,701,2014,23, 8,4355,7,60,99)
	const n=data0.len
	[n]int data
	int i,swapped

	println "Unsorted Data0:"
	for i to n do
		print data0[i],$
	od
	println

!	to 1 million do
!!	to 200'000 do
!
		for i:=1 to data0.upb do
billy:
			data[i]:=data0[i]
		od

		repeat
			swapped:=0
			for i:=1 to data.upb-1 do
				if data[i]>data[i+1] then
					swapped:=1
!INT T
!T:=DATA[I]
!DATA[I]:=DATA[I+1]
!DATA[I+1]:=T
!

					swap(data[i], data[i+1])
				fi
			od
		until not swapped
!	od

	println "Sorted Data:"
	for i:=1 to n do
		print data[i],$
	od
	println
end

