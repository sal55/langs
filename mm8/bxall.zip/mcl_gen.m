!macro mdivider = mcomment("-"*40)

INT PCLLENGTH
INT NPROCS

global proc genmcl=
	^strbuffer asmstr
	^procrec pp
	symbol d
	int tt

	return when mcldone

	tt:=os_clock()
!CPL "GENMCL"

	inithandlers()
	mclinit()

	mcomment("Generated ASM")
!RETURN

	dolibfiles()

!CPL "GENMCL", $LINENO
	pp:=staticlist

!CPL =STATICLIST

	while pp do
!CPL "GENMCL", $LINENO
		d:=pp.def
!CPL "DOSTATIC",D, D.NAME
!CPL "GENMCL", $LINENO
		dostaticvar(d)
!CPL "GENMCL", $LINENO
		pp:=pp.nextproc
	od
!CPL "GENMCL", $LINENO

	mcomment("")

!import list not needed for AA; only for NASM

!	for i to ndllproctable do
!		gendllproc(dllproctable[i])
!	od

!CPL =PROCLIST
	pp:=proclist
	while pp do
		d:=pp.def
		genprocmcl(d)
		pp:=pp.nextproc
	od

	genrealtable()
	genabsneg()
	genfunctiontables()
	genstringtable()

	genmc(m_endx)					!need as buffer in optimiser
	genmc(m_endx)

!	if fpeephole then
!		peephole()
!	end

	mcldone:=1

	mcltime:=os_clock()-tt

!CPL "AFTER MCL:", MCLTIME

!CPL $LINENO


end

global proc genprocmcl(symbol d) =
	mcl mstart

	currfunc:=d
	setsegment('C',1)

	genmc(m_procstart, genmemaddr(currfunc))
	genmc(m_labelname, genmemaddr(currfunc))
!CPL "GENPROC", CURRFUNC.NAME


	mcomment("?>>")
	mclprocentry:=mccodex

	do_proccode_a()						!initialise offsets etc

	mstart:=mccodex

	mcomment("?>>")
	mclprocentry:=mccodex

!	mdivider()

	currpcl:=d.pccode
	noperands:=0

	while currpcl, currpcl:=currpcl.next do
		convertpcl(currpcl)				!currpcl may be stepped in handler
		exit when currpcl=nil
	od

	if mclprocentry=mccodex then		!empty body: add dummy mcl op
		mcomment("---")					!injection of entry code goes wrong otherwise
	end

!	mdivider()

	do_proccode_b()						!do entry code (inject into start)
	do_proccode_c()						!do exit code

	genmc(m_procend)					!also tells optimiser when to stop

	if fpeephole then
		peephole(mstart)
	end

	if noperands then
		println currfunc.name,,": PCL stack not empty"
		mcomment("PCL stack not empty")
	end

PCLSET.[0]:=0
IF PCLSET THEN
CPL CURRFUNC.NAME, "PCLSET NOT EMPTY"
FI

!CPL "DONE", D.NAME
	currfunc:=nil

end

proc dolibfiles =
	mcomment("Lib files go here")
	mcomment("")
end

proc dostaticvar(symbol d) =

	return when d.isimport or d.equivvar
	return when fcff and d.scope=imported_scope

!CPL "STATIC VAR", D.NAME, D.LINENO, NAMENAMES[D.NAMEID], =D.CODE, STRMODE(D.MODE)

	if d.scope = program_scope and d.name^='$' then
		if eqstring(d.name,"$cmdskip") then
			d.scope:=export_scope				!export from mlib subprog
		end
	end

	if d.name^='$' and (d.name+1)^='$' then
		setsegment('C', 8)
	else
		setsegment((d.code|'I'|'Z'), getalignment(d.mode))
	end

	genmc(m_labelname, genmemaddr(d))

	if d.code then
		genidata(d.code)
	else
		genmc(m_resb, genint(ttsize[d.mode]))
	end
end

proc genidata(unit p)=
	[2000]byte data
	int t, tbase, offset, nbytes
	byte allbytes
	unit q, a
	symbol d
	^char s
	mclopnd dx

	t:=p.mode

!CPL "GENIDATA",JTAGNAMES[P.TAG], STRMODE(T)
	mmpos:=p.pos
	tbase:=ttbasetype[t]
	a:=p.a

!RETURN

	case p.tag
	when jconst then
		case tbase
		when tref then				!^or string
			if t=trefchar and p.isastring then
				gerror("idata/empty str?") unless p.svalue
				if p.strtype='B' then gerror("1:B-str?") end
				genmc(m_dq, genlabel(getstringindex(p.svalue, p.slength)))
			else
				gendataint(p.value)
			end

		when tr64 then
!			genmc(m_dq, genrealimm(p.xvalue, tr64))
			gendataint(p.value, tu64)

		when tr32 then
			r32 x32:=p.xvalue
			gendataint(u32@(x32), tu32)

		when tarray then			!should be data string
			if not fcff and p.strtype=0 then gerror("idata/array/not blockdata") end
			doblockdata(p.svalue, p.slength)

		else						!assume integer
			gendataint(p.value, t)

		end case

	when jmakelist then
		q:=a

		allbytes:=1
		nbytes:=0

		while q, q:=q.nextunit do
			if q.tag=jconst and q.mode=tu8 and nbytes<data.len then
				data[++nbytes]:=q.value
			else
				allbytes:=0
				exit
			end
		end

		if allbytes and nbytes then		!was all byte constants, not in data[1..nbytes]
			doblockdata(cast(&data), nbytes)
		else
			q:=a
			while q, q:=q.nextunit do
				genidata(q)
			od
		end

	when jname, jfuncname then
		d:=p.def
		offset:=0
doname:
		case d.nameid
		when staticid, procid, dllprocid then
			dx:=applyoffset(genmemaddr(d), offset)

		when labelid then
			if d.labelno=0 then d.labelno:=++mlabelno end
			dx:=genlabel(d.labelno)
		else

			MCOMMENT("Idata &frameXXX")
!			gerror("Idata &frameXXX")
		end case
		genmc(m_dq, dx)

	when jconvert then
		genidata(p.a)

	when jshorten then
		gendataint(a.value, t)

	when jaddrof then
		if a.tag<>jname then recase else end
		offset:=0
		if p.b then offset:=p.b.value end
		d:=a.def
		doname

	when jaddptr,jsubptr then
		if b.tag<>jconst then gerror("Complex ptr expr in static data") fi
		genidata(a,offset:b.value*p.ptrscale+offset)

	else
		gerror_s("IDATA: ", jtagnames[p.tag], p)

	end case
end

proc gendataint(int a, mode=ti64)=
	static []byte opctable =(m_db, m_dw, 0, m_dd, 0,0, 0, m_dq)

	genmc(opctable[ttsize[mode]], genint(a))
end

!proc doblockdata(unit p) =
proc doblockdata(^byte s, int n) =
!p contains jconst with array type; treat as data-string

	^u64 d:=cast(s)
	int nwords, r

	return when n=0

	nwords:=n/8

	to nwords do
		genmc(m_dq, genint(d++^))
	od

	r:=n-nwords*8
	if r then
		s:=cast(d)
		to r do
			genmc(m_db, genint(s++^))
		od
	end
	MCOMMENT("ENDDATA")

end

proc inithandlers=
	static byte initdone=0
	ichar name, s
	int n

	if initdone then return end

	n:=$getnprocs()

	for i to n do
		name:=$getprocname(i)
		if eqbytes(name,"px_",3) then
			for k in pclnames.bounds do
				s:=pclnames[k]
				if s^='k' then ++s fi				!some are kload, others just store
				if eqstring(s,name+3) then
					px_handlertable[k]:=$getprocaddr(i)
					exit
				end
			else
				merror("Invalid handler name:",name)
			od
		end
	od

	static [,2]byte dupltable = (

!mapping           =>
		(ktoboolf, 		ktoboolt),

		(kcallf,		kcallp),
		(kicallp,		kcallp),
		(kicallf,		kcallp),

		(kendmx,		kresetmx),

		(kidivto,		kidiv),
		(kiremto,		kirem)
		)

	for i to dupltable.len do
		px_handlertable[dupltable[i,1]]:=px_handlertable[dupltable[i,2]]
	end

	for i in px_handlertable.bounds do
		if not px_handlertable[i] then
			px_handlertable[i]:=cast(&unimpl)
		end
	od

	initdone:=1
end

global proc doshowpcl(pcl p)=
	[1256]char str

	return unless fshowinlinepcl

!	return when p.opcode in [kcomment, klabel]
	return when p.opcode in [kcomment, klabel, ksetcall, ksetarg]

	strcpy(str,"                       ")
	strcat(str,strpclstr(p, str.len))
	mcomment(PCM_COPYHEAPSTRING(str))
end

global proc unimpl(pcl p)=
	[100]char str
	fprint @str, "Unimpl: # (#)", pclnames[p.opcode], strmode(pmode)
	CPL STR
	mcomment(pcm_copyheapstring(str))
end

proc genfunctiontables=
	symbol d
	^procrec pp
	int nprocs:=0

	setfunctab()
	setsegment('I', 8)

	genmc(m_labelname, genmemaddr(pprocname))

	pp:=proclist
	while pp, pp:=pp.nextproc do
		d:=pp.def
		if d.ishandler then
			++nprocs
			genmc(m_dq, genlabel(getstringindex(d.name, strlen(d.name)+1)))
		end
	od

	genmc(m_labelname, genmemaddr(pprocaddr))

	pp:=proclist
	while pp, pp:=pp.nextproc do
		d:=pp.def
		if d.ishandler then
			genmc(m_dq, genmemaddr(d))
		end
	od

	genmc(m_labelname, genmemaddr(pnprocs))
	genmc(m_dq, genint(nprocs))
end
