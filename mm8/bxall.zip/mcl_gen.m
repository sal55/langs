!macro mdivider = mcomment("-"*40)

INT PCLLENGTH
INT NPROCS

global proc genmcl=
	^strbuffer asmstr
	psymbol d
	int tt

	return when mcldone

	tt:=os_clock()
!CPL "GENMCL"

	inithandlers()
	mclinit()
!CPL "GENMCL", $LINENO

	mcomment("Generated ASM")
!RETURN

	dolibfiles()
!CPL "GENMCL", $LINENO

!CPL "GENMCL", $LINENO
!CPL =STATICLIST
	d:=psymboltable
!CPL "GENMCL", $LINENO

	while d, d:=d.next do
!CPL "GENMCL", $LINENO, D.NAME
		if d.nameid=staticid then
!CPL "GENMCL", $LINENO, D.NAME
			dostaticvar(d)
!CPL "GENMCL", $LINENO
		fi
	end

!CPL "GENMCL", $LINENO
	mcomment("")

!import list not needed for AA; only for NASM

!	for i to ndllproctable do
!		gendllproc(dllproctable[i])
!	end

!CPL =PROCLIST
	d:=psymboltable

	while d, d:=d.next do
		if d.nameid=procid then
			genprocmcl(d)
		fi
	end

	genrealtable()
	genabsneg()
	genstringtable()
!
	genmc(m_endx)					!need as buffer in optimiser
	genmc(m_endx)

!	if fpeephole then
!		peephole()
!	end

	mcldone:=1

	mcltime:=os_clock()-tt

!CPL "AFTER MCL:", MCLTIME

!CPL $LINENO


end

global proc genprocmcl(psymbol d) =
	mcl mstart

	currfunc:=d
	setsegment('C',1)

	genmc(m_procstart, genmemaddr(currfunc))
	genmc(m_labelname, genmemaddr(currfunc))
!CPL "GENPROC", CURRFUNC.NAME


	mcomment("?>>")
	mclprocentry:=mccodex

	do_proccode_a()						!initialise offsets etc

	mstart:=mccodex

	mcomment("?>>")
	mclprocentry:=mccodex

!	mdivider()

	currpcl:=d.pccode
	noperands:=0

	while currpcl, currpcl:=currpcl.next do
		convertpcl(currpcl)				!currpcl may be stepped in handler
		exit when currpcl=nil
	end

	if mclprocentry=mccodex then		!empty body: add dummy mcl op
		mcomment("---")					!injection of entry code goes wrong otherwise
	end

!	mdivider()

	do_proccode_b()						!do entry code (inject into start)
	do_proccode_c()						!do exit code

	genmc(m_procend)					!also tells optimiser when to stop

	if fpeephole then
!*!		peephole(mstart)
	end

	if noperands then
		println currfunc.name,,": PCL stack not empty"
		mcomment("PCL stack not empty")
	end

PCLSET.[0]:=0
IF PCLSET THEN
CPL CURRFUNC.NAME, "PCLSET NOT EMPTY"
FI

!CPL "DONE", D.NAME
	currfunc:=nil

end

proc dolibfiles =
	mcomment("Lib files go here")
	mcomment("")
end

proc dostaticvar(psymbol d) =
	pcl pc

	return when d.isimport

!CPL "STATIC VAR", D.NAME

	if d.name^='$' and (d.name+1)^='$' then
		setsegment('C', 8)
	else
		setsegment((d.pccode|'I'|'Z'), getalignment(d.mode))
	end

	genmc(m_labelname, genmemaddr(d))

	if d.pccode then
!MCOMMENT("IDATA GOES HERE")
!		genidata(d.code)
		pc:=d.pccode

		while pc, pc:=pc.next do
			dodata(pc)
		end

	elsif d.size then
		genmc(m_resb, genint(d.size))
	end
end

proc dodata(pcl p) =
! Constant data. For block types, there can be multiple C values
	mclopnd ax
	int opc
!CPL "DODATA", PCLNAMES[P.OPCODE], STRMODE(P.MODE), =P.SIZE
!
!IF P.OPCODE=KCOMMENT THEN
!CPL "COMMENT:", P.SVALUE
!	MCOMMENT("DATA COMMENT??")
!	RETURN
!FI

!return

	if p.mode=tblock then
		do_blockdata(p)
		return
	fi

!CPL "PXDATA", = P.EXTRA, OPNDNAMES[P.OPNDTYPE]

	case p.opndtype
	when int_opnd then
		ax:=mgenint(p.value)
	when real_opnd then
		ax:=mgenrealimm(p.xvalue, p.mode)

	when string_opnd then
		ax:=genlabel(getstringindex(p.svalue, p.slength))

	when memaddr_opnd then
		ax:=genmemaddr(p.def)
		ax.offset:=p.extra
!CPL "SETTING OFFSET", AX.OFFSET, MSTROPND(AX)
	when label_opnd then
		ax:=genlabel(p.labelno)

	else
		merror("db/dq optype? #", opndnames[p.opndtype])
	esac

	case p.size
	when 1 then opc:=m_db
	when 2 then opc:=m_dw
	when 4 then opc:=m_dd
	when 8 then opc:=m_dq
	else
CPL =P.SIZE, =STRPMODE(P.MODE)
		merror("DATA/not 1248")
	esac
!
	genmc(opc,ax)

end

global proc do_blockdata(pcl p) =
	ref byte s
	ref u64 d
	int n,nqwords,nwords,r

	n:=p.size
	return when n=0

	nwords:=n/8

	d:=cast(p.svalue)
	to nwords do
		genmc(m_dq, mgenint(d++^))
	end

	r:=n-nwords*8
	if r then
		genstring_db(cast(d), r, 'B')
	fi
	MCOMMENT("ENDDATA")

end

proc inithandlers=
	static byte initdone=0
	ichar name, s
	int n

	if initdone then return end

	n:=$getnprocs()

	for i to n do
		name:=$getprocname(i)
		if eqbytes(name,"px_",3) then
			for k in pclnames.bounds do
				s:=pclnames[k]
				if s^='k' then ++s fi				!some are kload, others just store
				if eqstring(s,name+3) then
					px_handlertable[k]:=$getprocaddr(i)
					exit
				end
			else
				merror("Invalid handler name:",name)
			end
		end
	end

	static [,2]byte dupltable = (

!mapping           =>
		(ktoboolf, 		ktoboolt),

		(kcallf,		kcallp),
		(kicallp,		kcallp),
		(kicallf,		kcallp),

		(kendmx,		kresetmx),

		(kidivto,		kidiv),
		(kiremto,		kirem)
		)

	for i to dupltable.len do
		px_handlertable[dupltable[i,1]]:=px_handlertable[dupltable[i,2]]
	end

	for i in px_handlertable.bounds do
		if not px_handlertable[i] then
			px_handlertable[i]:=cast(&unimpl)
		end
	end

	initdone:=1
end

global proc doshowpcl(pcl p)=
	[1256]char str

!*!	return unless fshowinlinepcl

!	return when p.opcode in [kcomment, klabel]
	return when p.opcode in [kcomment, klabel, ksetcall, ksetarg]

	strcpy(str,"                       ")
	strcat(str,strpclstr(p, str.len))
	mcomment(PCM_COPYHEAPSTRING(str))
end

global proc unimpl(pcl p)=
	[100]char str
	fprint @str, "Unimpl: # (#)", pclnames[p.opcode], strmode(pmode)
	CPL STR
	mcomment(pcm_copyheapstring(str))
end
