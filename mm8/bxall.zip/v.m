importdll $xyz=
	func vbill(int)int
end

proc vcharlie=
end

global proc vdick=
end

export proc veric=
end

proc main=
end
