proc main=
	int a,b,t1, t2
	real x,y,z

	for ch in 0..255 do
	od

end
