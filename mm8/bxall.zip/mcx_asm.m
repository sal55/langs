const fshowseq=1
!const fshowseq=0

const showsizes=1
!const showsizes=0

!const showfreed=1
const showfreed=0

[r0..xr15]symbol regvars		!nil, or strec when it uses that reg

global int assemtype='AA'

strbuffer sbuffer
global ref strbuffer pdest=&sbuffer

global func writeasm:ref strbuffer=
!write all mcl code in system by scanning all procs
!mcl code is only stored per-proc
	symbol d, e
	ref mclrec m
	[32]char str2, str3
	int i

	gs_init(pdest)
!
	case highmem
	when 1 then asmstr("    $userip\n")
	when 2 then asmstr("    $highmem\n")
	esac

	m:=mccode
	i:=1
	while m do
		writemcl(i, m)
		++i
		m:=m.nextmcl
	od
	return pdest
end

proc writemcl(int index, ref mclrec mcl)=
	if mcl.opcode=m_comment and mcl.a.svalue^='?' then
	else
		strmcl(mcl)
!CPL "//"
		gs_line(pdest)
	fi
end

global proc strmcl(ref mclrec mcl)=
	static [512]char str
	[128]char opcname
	mclopnd a, b
	int opcode, cond, sizepref
	symbol d

	opcode:=mcl.opcode
	str[1]:=0

	cond:=mcl.cond
	a:=mcl.a
	b:=mcl.b

!if fshowseq then
!	asmstr(strint(mcl.seqno, "z5"))
!	asmstr(" ")
!fi
!CPL "STRMCL", MCLNAMES[OPCODE], A, B

	case opcode
	when m_procstart then

		asmstr(";Proc ")
		asmstr(a.def.name)
		currfunc:=a.def
		clear regvars

		return

	when m_procend then
		asmstr(";End\n")
		currfunc:=nil

		return

	when m_comment then
		if a.svalue^ then
			asmchar(';')
			asmstr(a.svalue)
		fi
		return
	when m_endx then
		return

	when m_labelname then				!label name will be complete and will have colon(s)
		d:=a.def
		case a.valtype
		when def_val then
			asmstr(getdispname(d))
		when string_val then
			asmstr(a.svalue)
			return
		else
			merror("strmcl/lab")
		esac

		asmstr(":")

		if d.scope=export_scope then
!			if eqstring(getbasename(d.name), d.name) then
!				asmstr(":")
!			else
				asmstr("\n`")
				asmstr(getbasename(d.name))
				asmstr("::")
!			fi
		fi

!ASMSTR(" ")
!ASMSTR(STRINT(INT(D), "H"))

		return

	when m_label then
		if a.valtype=label_val then
			fprint @str, "L#:", a.value
		else
			recase m_labelname
		fi
		asmstr(str)
		return

	when m_define then
		d:=a.def
		asmstr("    ")
		asmstr(getdispname(d))
		asmstr(" = ")
		asmint(d.offset)
		return

	when m_definereg then
		d:=a.def
		asmstr("    ")
		asmstr(getdispname(d))
		regvars[d.reg]:=d

		asmstr(" = ")
		asmstr(getregname(b.reg, b.size))
		return

	when m_definetemp then
		asmstr("    ")
		asmstr(mstropnd(a))
!		asmstr(gettempname(currfunc, a.tempno))
		asmstr(" = ")
		asmint(b.value)
		return

	when m_asciiz then
		asmstr("    db ")
		asmstr(mstropnd(a))
		asmstr(", 0")
		return


	esac

	case opcode
	when m_jmpcc then
		print @opcname, "j", ,asmcondnames[cond]

	when m_setcc then
		print @opcname, "set", ,asmcondnames[cond]

	when m_cmovcc then
		print @opcname, "cmov", ,asmcondnames[cond]

	when m_and then
		strcpy(opcname, "and")
	when m_or then
		strcpy(opcname, "or")
	when m_xor then
		strcpy(opcname, "xor")
	when m_not then
		strcpy(opcname, "not")

	ELSIF OPCODE>M_HALT THEN
		STRCPY(OPCNAME, STRINT(OPCODE))

	else
		strcpy(opcname, mclnames[opcode]+2)
	esac

!	ipadstr(opcname, (opcode=m_dq|4|10), " ")
	ipadstr(opcname, 10, " ")
	ipadstr(str, 4)

	strcat(str, opcname)

	asmstr(str)

	if a and b then		!2 operands
		sizepref:=needsizeprefix(opcode, a, b)
!
		asmopnd(a, sizepref)
		asmstr(", 	")
		asmopnd(b, sizepref)

		if mcl.c then
			asmstr(", ")
			asmstr(strint(mcl.c))
		fi

	elsif a and a.mode then								!1 operand
		if opcode=m_call then
			asmopnd(a, 0, opcode)
		else
			asmopnd(a, 1, opcode)
		fi
	fi

	if showsizes then
		if a then
			asmstr("  ; ")
			asmstr(strint(a.size))
			if b then
				asmstr("/")
				asmstr(strint(b.size))
			fi
		fi
	fi

	if fshowseq then
		asmstr(" ; ")
		asmstr(strint(mcl.seqno, "z5"))
	fi

end

global func strmclstr(ref mclrec m)ichar=
	gs_init(pdest)
	strmcl(m)
	return pdest.strptr
end

global func mstropnd(mclopnd a, int sizeprefix=0, opcode=0)ichar=
	static [512]char str
	[128]char str2
	ichar plus, t
	int offset, tc

!RETURN "<OPND>"

	str[1]:=0

	case a.mode
	when a_reg then
		return strreg(a.reg, a.size)

	when a_imm then
!CPL "OPND/IMM", VALTYPENAMES[A.VALTYPE]
		if opcode=m_dq and a.valtype=int_val then
!			if a.value in 0..9 then
				strcat(str, strint(a.value))
!			else
!				strcat(str, "0x")
!				strcat(str, strword(a.value, "H"))
!			fi
		else
			strcpy(str, strvalue(a))
		fi

	when a_mem then
!CPL "OPND/MEM", VALTYPENAMES[A.VALTYPE]
		strcat(str, getsizeprefix(a.size, sizeprefix))
		strcat(str, "[")

		plus:=""
		if a.reg then
			strcat(str, strreg(a.reg, 8))
			plus:=" + "
		fi
		if a.regix then
			strcat(str, plus)
			strcat(str, strreg(a.regix, 8))
			plus:=" + "

			if a.scale>1 then
				strcat(str, "*")
				strcat(str, strint(a.scale))
			fi
		fi

		if a.valtype in [def_val, label_val, temp_val] then
			if plus^ then
				strcat(str, plus)
			fi
			strcat(str, strvalue(a))
	    elsif offset:=a.offset then
			print @str2, offset:" + "
			strcat(str, str2)
		fi
		strcat(str, "]")

	else
		println "BAD OPND", A.MODE, =A
		return "<BAD OPND>"
	esac

	return str
end

global func strvalue(mclopnd a)ichar=
	static [512]char str
	[128]char str2
	symbol def
	i64 value, offset, length
	ichar ss

	def:=a.def
	value:=a.value

	strcpy(str, "")

	case a.valtype
	when def_val then
		strcat(str, getdispname(def))

	addoffset:
		if offset:=a.offset then
			print @str2, (offset>0|"+"|""), ,offset
			strcat(str, str2)
		fi

	when int_val then
		strcat(str, strint(value))

	when real_val then
		if a.size=8 then
			print @str, a.xvalue:"20.20"
		else
			print @str, r32(a.xvalue):"20.20"
		fi

!	when realmem_val then
!		strcat(str, "M")
!		strcat(str, strreal(a.xvalue))

	when string_val then
		strcat(str, """")
		strcat(str, a.svalue)
		strcat(str, """")

	when name_val then
		strcat(str, a.svalue)

	when label_val then
		strcat(str, "L")
		strcat(str, strint(a.labelno))
		goto addoffset

	when temp_val then
		return gettempname(currfunc, a.tempno)

	else
		merror("Stropnd?")
	esac

	return str
end

global proc asmopnd(mclopnd a, int sizeprefix=0, opcode=0)=
	asmstr(mstropnd(a, sizeprefix, opcode))
end

global func getregname(int reg, size=8)ichar=
	static [1..17]ichar prefix=("B", "W", "", "A", "", "", "", "D", "", "", "", "", "", "", "", "Q", "N")
	static [32]char str
	[16]char str2
	ichar rs
	int size2

!	if useintelregs then
!		return nregnames[size, reg]
!	fi

	size2:=size
	if size2>16 then
		size2:=17
	fi

	case reg
	when rnone then return "-"
	when rframe then rs:="fp"
	when rstack then rs:="sp"
	elsif reg>=xr0 then
		print @str, "XMM", ,reg-xr0
		return str

	else
		getstrint(reg-r0, str2)
		rs:=str2
	esac

	print @str, prefix[size2], ,rs
	return str
end

proc asmstr(ichar s)=
	gs_str(pdest, s)
end

proc asmint(int a)=
	asmstr(strint(a))
end

proc asmchar(int c)=
	gs_char(pdest, c)
end

global func getdispname(symbol d)ichar=
	static [256]char str

	if d.reg then
		fprint @str, "##R.#", (fshortnames|""|"`"), (stdfloat[d.mode]|"X"|""),
			 (fshortnames|d.name|getfullname(d))
		return str
	fi

	if fshortnames then
		return getbasename(d.name)
	else
		return getfullname(d, backtick:1)
	fi
end 

global func gettempname(symbol d, int n)ichar=
	static [128]char str

	if fshortnames or d=nil then
		print @str, "T", ,n
	else
		fprint @str, "#.$T#", getdispname(d), n
	fi
	str
end

global func strreg(int reg, size=8)ichar=
	symbol d

	d:=regvars[reg]

	if d and stdsize[ttbasetype[d.mode]]=size then
		return getdispname(d)
	fi
	getregname(reg, size)
end

global func needsizeprefix(int opcode, mclopnd a, b)int=
	case opcode
	when m_movsx, m_movzx, m_cvtsi2ss, m_cvtsi2sd then
		return 1

	when m_cvtss2si, m_cvtsd2si, m_cvttss2si, m_cvttsd2si then
		return 1
	when m_shl, m_shr, m_sar then
		if a.mode=a_mem then return 1 fi
		return 0
	esac

	if a.mode=a_reg or b.mode=a_reg then
		return 0
	fi
	return 1
end

global func getsizeprefix(int size, enable=0)ichar=
	static []ichar table=("byte ", "u16 ", "", "u32 ", "","","", "u64 ")
	if not enable or size not in 1..8 then
		""
	else
		table[size]
	fi
end

