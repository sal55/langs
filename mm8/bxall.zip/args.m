proc main=
CPL =NCMDPARAMS
CPL =CMDPARAMS

	if cmdparams then
		for i:=0 to ncmdparams do
			println i, cmdparams[i]
		od
	fi
end


