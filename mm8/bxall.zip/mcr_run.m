!Translate SS data directly into MCU block, then try and run that

global func writememlib(ichar filename)^librec plib=
!write ss to mcu
	int n, k
	librec lib

	clear lib

	ss_zdatalen:=roundtoblock(ss_zdatalen, 8)

	roundsegment(ss_code,8,0x90)
	roundsegment(ss_idata,8,0)

	lib.version:="0.1234"

	lib.filespec:=filename
	lib.libname:=pcm_copyheapstring(extractbasefile(filename))
	lib.libno:=1

	countsymbols()
	writerelocs(&lib)

	lib.zdatasize:=ss_zdatalen
	lib.codesize:=bufferlength(ss_code)
	lib.idatasize:=bufferlength(ss_idata)

	lib.codeptr:=bufferelemptr(ss_code,0)
	lib.idataptr:=bufferelemptr(ss_idata,0)

	int ndlls:=0, nlibs:=0
	for i to nlibfiles when libfiles[i]^<>'$' do
!		if libtypes[i]='D' then ++ndlls else ++nlibs end
		++ndlls
	od

	lib.ndlllibs:=ndlls
	lib.nlibs:=nlibs

	lib.dllnames:=pcm_alloc(ichar.bytes*ndlls)
	lib.libnames:=pcm_alloc(ichar.bytes*nlibs)

	k:=0
!	for i to nlibfiles when libfiles[i]^<>'$' and libtypes[i]='D' do
	for i to nlibfiles when libfiles[i]^<>'$' do
		lib.dllnames[++k]:=libfiles[i]
	od

!	k:=0
!	for i to nlibfiles when libfiles[i]^<>'$' and libtypes[i]='L' do
!		lib.libnames[++k]:=libfiles[i]
!	od

	addsymbols(&lib)
	plib:=pcm_allocnfz(librec.bytes)
	memcpy(plib, &lib, librec.bytes)	

	return plib
end

proc roundsegment(^dbuffer p, int align, value)=
	int length:=bufferlength(p)
	int newlength:=roundtoblock(length, align)

	buffercheck(p, align)

	to newlength-length do
		p.pcurr++^:=value
	od
end

proc writerelocs(^librec lib)=
	^relocrec oldr
	mcxreloc newr
	int n, k
	symbol d
	^u64 baseptr64
	^u32 baseptr32@baseptr64

	lib.nrelocs:=ss_nidatarelocs+ss_ncoderelocs
	lib.reloctable:=pcm_alloc(lib.nrelocs*mcxreloc.bytes)

	k:=0

	for i in code_seg..idata_seg do
		oldr:=(i=code_seg|ss_idatarelocs|ss_coderelocs)

		while oldr, oldr:=oldr.nextreloc do
			clear newr

			newr.offset:=oldr.offset
			newr.segment:=(i=code_seg|idata_seg|code_seg)

			d:=ss_symboltable[oldr.stindex]

			case oldr.reloctype
			when rel32_rel then
				if d.isimport then
					newr.stindex:=d.importindex
					newr.reloctype:=imprel32_rel
				else
					axerror("rel32/rel not imported")
				end
			when addr32_rel, addr64_rel then
				if d.isimport then
					newr.reloctype:=(oldr.reloctype=addr32_rel|impabs32_rel|impabs64_rel)
					newr.stindex:=d.importindex
				else
					if oldr.reloctype=addr32_rel then
						newr.reloctype:=locabs32_rel
					else
						newr.reloctype:=locabs64_rel
					end
					newr.targetsegment:=d.segment
				end
			else
				axerror("reloc?")
			end case

			lib.reloctable[++k]:=newr

		od
	od
end

proc addsymbols(^librec lib)=
	symbol d, stentry:=nil
	u64 epoffset:=-1
	int n, k
	ichar name


	lib.nimports:=nsymimports
	lib.nexports:=nsymexports
	lib.importnames:=pcm_alloc(nsymimports*ichar.bytes)
	lib.exports:=pcm_alloc(nsymexports*ichar.bytes)
	lib.exportsegs:=pcm_alloc(nsymexports)
	lib.exportoffsets:=pcm_alloc(nsymexports*u64.bytes)

	k:=0
	for i to ss_nsymbols when ss_symboltable[i].importindex do
		d:=ss_symboltable[i]
!CPL "ADDSYM", D.NAME
		lib.importnames[++k]:=(d.truename|d.truename|d.name)
	od

	k:=0
	for i to ss_nsymbols do
		d:=ss_symboltable[i]
!CPL =D.NAME, =D.EXPORTINDEX, =D.ISENTRY, SCOPENAMES[D.SCOPE]
		if d.exportindex then
			if d.isentry then
				stentry:=d
			end
			lib.exports[++k]:=d.name
			lib.exportsegs[k]:=d.segment
			lib.exportoffsets[k]:=d.offset
		end
	od

!CPL =STENTRY

	if stentry then
		lib.entryoffset:=stentry.offset
	else
		lib.entryoffset:=-1
CPL "NO MAIN FOUND", LIB.ENTRYOFFSET, LIB.ENTRYADDR
	end
end

global proc countsymbols=
	symbol d
	for i:=1 to ss_nsymbols do
		d:=ss_symboltable[i]
		if d.scope=export_scope then d.exportindex:=++nsymexports end
		if d.isimport then d.importindex:=++nsymimports end
	od
end

global proc runlibfile(ichar filename, int cmdskip)=
!LOADERROR("RUNLIBFILE")

	^librec plib

!CPL "RUN LIB"

	plib:=writememlib(filename)

	loadmemmcu(plib)
	fixuplib(plib)

!	if fshowmx then
!		LOADERROR("SHOWMX missing")
!!		initlogfile()
!!		showlibs()
!!		closelogfile()
!	else
		runprogram(plib, cmdskip)
!	end
end

