func collatz(int n)int =
	int steps:=0
	while n>1 do
		n := (n.even | n%2 | 3*n+1)
!		n := (n iand 1 = 0 | n%2 | 3*n+1)
		++steps
	od
	steps
end

proc main=
	int maxn:=0
	int maxsteps:=0
	int steps

	for i to 10 million do
		steps:=collatz(i)
!	cpl i:"3", steps:"7"

		if steps>maxsteps then
			maxsteps:=steps
			maxn:=i
			println i,steps
		fi
	od
end
