global const maxnestedloops	= 50

global [maxnestedloops, 4]int loopstack
global int loopindex							!current level of nested loop/switch blocks

global psymbol pnprocs, pprocname, pprocaddr

unitrec zero_unit
global unit pzero=&zero_unit

global int retindex
global pcl pcldoswx

macro divider = pcomment("-"*40)

global proc genpcl=
CPL "GENPCL"
	symbol d
	psymbol p

	d:=stlinear
	while d, d:=d.nextlinear do
		case d.nameid
		when staticid then
			p:=getpsymbol(d)
			paddsymbol(p)

			dostaticvar(d, p)

		when procid then
			p:=getpsymbol(d)
			paddsymbol(p)

			addlocals(d, p)

			doprocdef(d, p)

		end
	end
end

proc dostaticvar(symbol d, psymbol p)=

	if d.isimport then return fi

	if d.scope = program_scope and d.name^='$' then
		if eqstring(d.name, "$cmdskip") then
			d.scope:=export_scope				!export from mlib subprog
		fi
	fi

	return unless d.code

!init data exists; generate kdata PCL sequence

	pcl_start()

	pcomment("hello")

	genidata(d.code)

	p.pccode:=pcl_end()


!	if d.atvar=1 then
!		return
!	elsif d.code then
!		pgen(kistatic, genmem_d(d))
!		setmode(d.mode)
!		psetalign(getalignment(d.mode))
!		genidata(d.code)
!	else
!dozstatic:
!		pgen(kzstatic, genmem_d(d))
!		setmode(d.mode)
!		psetalign(getalignment(d.mode))
!	fi

end

proc addlocals(symbol d, psymbol p)=
	symbol e
	psymbol q
	int nlocals:=0, nparams:=0
	[pmaxparams]psymbol params
	[100]psymbol locals

	e:=d.deflist
	while e, e:=e.nextdef do
		case e.nameid
		when paramid then
!	Q:=		params[++nparams]:=getpsymbol(e)
	Q:=getpsymbol(e)
	PARAMS[++NPARAMS]:=Q
CPL "ADDPM", NPARAMS, E.NAME, Q.NAME

		when frameid then
			if nlocals>=locals.len then gerror("Too many locals") fi
			locals[++nlocals]:=getpsymbol(e)

		when staticid then
CPL "LOCAL/STATIC", e.name
		else
		end
	od

CPL =NPARAMS


	if nparams then
		p.nextparam:=q:=params[1]
		for i in 2..nparams do
			q.nextparam:=params[i]
			q:=params[i]
		od
	fi

	if nlocals then
		p.nextlocal:=q:=locals[1]
		for i in 2..nlocals do
			q.nextlocal:=locals[i]
			q:=locals[i]
		od
	fi
end

func getpsymbol(symbol d)psymbol p =
	symbol e
	[256]char str
	[16]symbol chain
	int n

	return nil when d=nil

	return d.pdef when d.pdef

	if d.equivvar then
		getpsymbol(e:=getequivdef(d))
		d.pdef:=e.pdef
		return e.pdef
	fi

	case d.nameid
	when frameid, paramid then
		strcpy(str, d.name)
	elsif d.isimport then
		strcpy(str, (d.truename|d.truename|d.name))

	else
		e:=d
		n:=0
		repeat
			chain[++n]:=e
			e:=e.owner
		until e=nil or e.nameid=programid

		strcpy(str, chain[n].name)
		for i:=n-1 downto 1 do
			strcat(str, ".")
			if chain[i].truename then
				strcat(str, chain[i].truename)
			else
				strcat(str, chain[i].name)
			fi
		od
	end

	d.pdef:=p:=pmakesymbol(str, d.nameid)

	p.mode:=getpclmode(d.mode)
	p.size:=ttsize[d.mode]

!	if d.scope=export_scope then p.exported:=1 fi
!	if d.nameid in [dllprocid, dllvarid] then p.imported:=1 fi
!	p.used:=d.used
!	p.labelno:=d.index
!	p.ishandler:=d.ishandler
!	p.isthreaded:=d.isthreaded
!
	p.varparams:=d.varparams
	return p
end

func getequivdef(symbol d)symbol=
!assume that d.atvar/d.equivvar are set
	unit p

	p:=d.equivvar
	case p.tag
	when jname then
		p.def
	when jconvert then
		p.a.def			!assume points to name
	else
		gerror("geteqv")
		nil
	esac
end

global proc setmode(int mode)=
	psetmode(getpclmode(mode), ttsize[mode])
end

global proc setmode2(int mode)=
	psetmode2(getpclmode(mode))
end

global proc setmode_u(unit p)=
	int mode:=p.mode

	psetmode(getpclmode(mode), ttsize[mode])
end

global proc genpushint(int a)=
	pgen(kload, pgenint(a))
	setmode(ti64)
end

global proc genpushreal(real x, int mode)=
	pgen(kload, pgenrealmem(x))
	setmode(mode)
end

global func genmem_u(unit p)pcl=
	return pgenmem(getpsymbol(p.def))
end

global func genmem_d(symbol d)pcl=
	return pgenmem(getpsymbol(d))
end

global func genmemaddr_d(symbol d)pcl=
	return pgenmemaddr(getpsymbol(d))
end

global proc genpushmem_d(symbol d)=
	pgen(kload, pgenmem(getpsymbol(d)))
end

global proc genpushmemaddr_d(symbol d)=
	pgen(kload, pgenmemaddr(getpsymbol(d)))
end

global proc genpushstring(ichar s, int length)=
	pgen(kload, pgenstring(s, length))
	setmode(tu64)
end

proc genidata(unit p)=
	[2000]byte data
	int t, tbase, offset, nbytes
	byte allbytes
	unit q, a
	symbol d
	^char s

	t:=p.mode

!CPL "GENIDATA", JTAGNAMES[P.TAG], STRMODE(T)
	mmpos:=p.pos
	tbase:=ttbasetype[t]
	a:=p.a

	case p.tag
	when jconst then
		if ttisref[t] then
			if t=trefchar then
				if p.svalue then
!CPL "GID/CONST1", P.SVALUE, p.strtype
					if p.strtype='B' then gerror("1:B-str?") fi
					pgen(kdata, pgenstring(p.svalue, p.slength))
				else
					pgen(kdata, pgenint(0))
				fi
			else
				pgen(kdata, pgenint(p.value))
			fi
			setmode(ti64)
		elsif ttisreal[t] then
!			pgen(kdata, pgenrealimm(p.xvalue, getpclmode(t)))
			pgen(kdata, pgenrealmem(p.xvalue))
			setmode(t)

		elsif ttbasetype[t]=tarray then
			IF P.STRTYPE=0 THEN GERROR("IDATA/ARRAY/NOT BLOCKDATA") FI
!CPL "GID/CONST2", P.SVALUE, p.strtype
			pgen(kdata, pgendata(p.svalue, p.slength))

		else						!assume int/word
			pgen(kdata, pgenint(p.value))
			setmode_u(p)
		fi

	when jmakelist then
		q:=p.a

		allbytes:=1
		nbytes:=0
		while q, q:=q.nextunit do
			if q.tag=jconst and q.mode=tu8 and nbytes<data.len then
				data[++nbytes]:=q.value
			else
				allbytes:=0
				exit
			end
		end

		if allbytes and nbytes then		!was all byte constants, not in data[1..nbytes]
			pgen(kdata, pgendata(pcm_copyheapstringn(cast(&data), nbytes), nbytes))
		else
			q:=p.a
			while q, q:=q.nextunit do
				genidata(q)
			od
		fi

	when jname then
		d:=p.def
		case d.nameid
		when staticid, procid, dllprocid then
			pgen(kdata, genmemaddr_d(d))
			if offset then
				psetscaleoff(1, offset)
			fi
!			if am='P' then
!				setmode(tu64)
!			else
!				setmode(t)
!			fi
		when labelid then
			if d.labelno=0 then d.labelno:=++mlabelno fi
			pgen(kdata, pgenlabel(d.labelno))
			setmode(ti64)
		else
			gerror("Idata &frameXXX")
		esac
		return
	when jconvert then
		genidata(p.a)
	when jshorten then
		pgen(kdata, pgenint(p.a.value))
		setmode(t)

	when jaddrof then
GERROR("GENIDATA/ADDROF")
!!		genidata(p.a, am:'P', offset:(p.b|p.b.value|0))
!		genidata(p.a, am:'P', offset:(p.b|p.b.value|0))
	else
		gerror_s("IDATA: ", jtagnames[p.tag], p)

	esac
end

proc doprocdef(symbol d, psymbol p) =
	imodule ms
	byte ismain:=0

	ms:=modules[d.moduleno]
	pcldoswx:=nil

!-----------------
	currfunc:=p
	pcl_start()
	mmpos:=d.pos

	if d=ms.stmain and moduletosub[d.moduleno]=mainsubprogno then
		ismain:=1
		entryproc:=p
		p.isentry:=1
		genmain(d)

	elsif d=ms.ststart then
		genstart(d)
	fi
!------------------


	retindex:=createfwdlabel()

	divider()

	if d.hasdoswx then
		pgen(kinitdswx)			!this op needed by C?
		pcldoswx:=pccurr			!code to be injected later after this instr
	fi

!	pcomment("<EVALBLOCk>")

	evalunit(d.code)
!CPL "PROC",$LINENO

	if ismain then
		genpushint(0)
		pgen(kstop)
		psetmode(ti64)
	fi

	divider()
	definefwdlabel(retindex)
	genreturn()

	p.pccode:=pcl_end()

!CPL "DONE genpcl", P.NAME, P.CODE, =p

end

proc genmain(symbol d)=
	symbol e
	for i to nsubprogs when i<>mainsubprogno do
		e:=modules[subprogs[i].mainmodule].ststart
		docallproc(e)
	od
	d:=modules[subprogs[mainsubprogno].mainmodule].ststart
	docallproc(d)
end

proc genstart(symbol d)=
	symbol e
	int lead:=0, m,s

	m:=d.moduleno
	s:=d.subprogno

	if s=mainsubprogno and d.moduleno=subprogs[s].mainmodule then
		LEAD:=1
	elsif d.moduleno=subprogs[s].firstmodule then
		LEAD:=2
	fi

	if lead then
		for i to nmodules when moduletosub[i]=s and i<>m do
			e:=modules[i].ststart
			docallproc(e)
		od
	fi
end

proc docallproc(symbol d)=
!call a simple proc, eg. start(), with no args
	return unless d
	pgen(ksetcall)
	psetnargs(0)

	pgen(kcallp, genmemaddr_d(d))
end

global proc genreturn=
!assume returning from currproc
	case currfunc.nretvalues
	when 0 then
		pgen(kretproc)
	when 1 then
		pgen(kretfn)
		psetmode(currfunc.mode)

	else
		pgenx(kretfn, currfunc.nretvalues)
	esac
end

global proc genpc_sysfn(int fnindex, unit a=nil,b=nil,c=nil)=
	genpc_sysproc(fnindex, a,b,c, 1)
end

!global proc genpc_sysproc(int fnindex, unit a=nil,b=nil,c=nil, int asfunc=0)=
!	GERROR("GENPCSYSPROC")
!end

global proc genpc_sysproc(int fnindex, unit a=nil,b=nil,c=nil, int asfunc=0)=
	int nargs:=0, opc
	symbol d
	pcl p
	opc:=0

	pgen(ksetcall)
	p:=pccurr

	pushsysarg(c, 3, nargs)
	pushsysarg(b, 2, nargs)
	pushsysarg(a, 1, nargs)
!
	p.nargs:=nargs

	d:=getsysfnhandler(fnindex)
	if d then
		pgen((asfunc|kcallf|kcallp), genmemaddr_d(d))
		psetnargs(nargs)
	else
!		pgen((asfunc|kcallf|kcallp), gennameaddr_d(sysfnnames[fnindex]+3))
		pgen((asfunc|kcallf|kcallp), pgenname(sysfnnames[fnindex]+3))
	end
	pccurr.nargs:=nargs
end

global proc pushsysarg(unit p, int n, &nargs) =
!return 0 or 1 args pushed
	if p then
		evalunit(p)
		pgen(ksetarg)
		setmode_u(p)
		pccurr.x:=n
		pccurr.y:=n			!ASSUMES ALL INTS; however this only important
							!for arm64, and only matters if more than 8 args
		++nargs
	end
end

global func getsysfnhandler(int fn)symbol p=
	[300]char str
	int report
	symbol d

	if sysfnhandlers[fn] then
		return sysfnhandlers[fn]
	end

	strcpy(str,"m$")
	strcat(str,sysfnnames[fn]+3)	!"sf_stop" => "m$stop"

	p:=stlinear
	while p, p:=p.nextlinear do
		if p.nameid=procid then
			if eqstring(p.name, str) then
				sysfnhandlers[fn]:=p
				return p
			end
		end
	end

	report:=passlevel>asm_pass
!	report:=1
!	report:=0

	if report then
		println "Sysfn not found:",str
	end

	if fn<>sf_unimpl then
		p:=getsysfnhandler(sf_unimpl)
		if p=nil and report then
			gerror("No m$unimpl")
		end
		return p
	end

	return nil
end


