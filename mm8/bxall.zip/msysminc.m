!import clib
!export type filehandle=ref void

const maxparam=128
export int nsysparams
export int ncmdparams
export int nenvstrings
export [maxparam]ichar sysparams
!export ref[]ichar cmdparams
export ref[0:]ichar cmdparams
export ref[]ichar envstrings

export int $cmdskip			!0 unless set by READMCX/etc

!importdll $cstd=
importdll msvcrt=
	func malloc	(u64)ref void
	proc free		(ref void)
!	func pow		(real,real)real
!
	func printf (ref char,...)i32
!	func fprintf (ref void,ref char,...)i32
	func puts (ref char)i32
	proc `exit(i32)
	func getchar	:i32
	proc memcpy		(ref void, ref void, word)
	proc memset		(ref void, i32, u64)
	func strlen		(ichar)u64
	func strcpy		(ichar,ichar)ichar
	func strcat		(ichar,ichar)ichar
	func strcmp		(ichar,ichar)i32

	func _strdup	(ichar)ichar
end

export macro strdup=_strdup

!export proc free(ref void) = end


int needgap

global proc m$print_startcon=
end

global proc m$print_end=
	needgap:=0
end

global proc m$print_ptr(ref void a,ichar fmtstyle=nil)=
	nextfmtchars()
	printf("%p",a)
	needgap:=1
end

global proc m$print_ptr_nf(u64 a)=
	nextfmtchars()
	printf("%p",a)
	needgap:=1
end
!
global proc m$print_i64(i64 a,ichar fmtstyle=nil)=
	nextfmtchars()
	printf("%lld",a)
	needgap:=1
end

!global proc m$print_i128(i64 a,ichar fmtstyle=nil)=
!	puts("<128>")
!!	nextfmtchars()
!!	printf("%lld",a)
!!	needgap:=1
!end

global proc m$print_i64_nf(i64 a)=
!puts("PRINTI64_nf")
	nextfmtchars()
	printf("%lld",a)
	needgap:=1
end

global proc m$print_u64(u64 a,ichar fmtstyle=nil)=
	nextfmtchars()
	printf("%llu",a)
	needgap:=1
end

global proc m$print_r64(real x,ichar fmtstyle=nil)=
	nextfmtchars()
	printf("%f",x)
	needgap:=1
end

global proc m$print_r32(real x,ichar fmtstyle=nil)=
	nextfmtchars()
	printf("%f",x)
	needgap:=1
end

!global proc m$print_c8(i64 a,ichar fmtstyle=nil)=
!	nextfmtchars()
!	printf("%c",a)
!	needgap:=1
!end
!
global proc m$print_str(ichar s, fmtstyle=nil)=
	nextfmtchars()
	printf("%s",s)
	needgap:=1
end

global proc m$print_str_nf(ichar s)=
	nextfmtchars()
	printf("%s",s)
	needgap:=1
end

global proc m$print_space=
	needgap:=0
	printf(" ")
end

global proc m$print_newline=
	needgap:=0
	printf("\n")
end

global proc m$unimpl=
	puts("Sysfn unimpl")
	stop 1
end

global proc m$print_nogap=
	needgap:=0
end

!global proc nextfmtchars(int lastx=0)=
global proc nextfmtchars=
	if needgap then
		printf(" ")
		needgap:=0
	fi
end

export proc m$init(int nargs, ref[]ichar args)=
	nsysparams:=nargs

	if nsysparams>maxparam then
		printf("Too many params\n")
		stop 1
	fi

	for i:=1 to nargs do
		sysparams[i]:=args[i]
	od

!assume nsysparams is >=1, since first is always the program name
	ncmdparams:=nsysparams-($cmdskip+1)
	cmdparams:=cast(&sysparams[$cmdskip+1])

	int j:=1
	nenvstrings:=0
!	while envstrings[j] do
!		++nenvstrings
!		++j
!	od

end

