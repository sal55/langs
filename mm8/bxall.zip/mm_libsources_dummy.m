global const fsyslibs = 0

global proc loadbuiltins=
end
