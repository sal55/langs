!project =
	module mm_cli

!	module mm_genc
!	module mm_libc
!	module mm_blockc

	module mm_genpcl
	module mm_libpcl
	module mm_blockpcl

	module mm_assem
!	module mm_assem_dummy
!	module mm_assemaux
	module mm_assemaux_dummy
	module mm_decls

!	module mm_diags
	module mm_diags_dummy
!
	module mm_export_dummy
!	module mm_exportq
!	module mm_exportm

	module mm_lex
	module mm_lib

	module mm_libsources
!	module mm_libsources_dummy
!
	module mm_modules
	module mm_name
	module mm_parse

	module mm_support
	module mm_tables
	module mm_type

	$sourcepath "c:/px/"
!	$sourcepath "c:/xxx/"
!	import pcl
	import pclint
!	import pclmin
!	import pclrunx

!	$sourcepath "c:/qx/"
!	import qc

!end

proc main=
	main2()
end

