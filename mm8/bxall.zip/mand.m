const bailout=16.0
const max_iterations=400

fun mandelbrot(x,y)=

	i:=0
	cr:=y-0.5
	zi:=zr:=0.0

	do
		++i
		temp:=zr*zi
		zr2:=sqr zr
		zi2:=sqr zi
		zr:=zr2-zi2+cr
		zi:=temp*2.0+x
		if zi2+zr2>bailout then
			return 1
		fi
		if i>max_iterations then
			return 0
		fi
	od
	return 0
end

sub main=
	const n=40

	for y:=-n to n do
		println
		for x:=-n to n do
			pix:=mandelbrot(x/real(n), y/real(n))
			print (pix|" "|"*")
		od
	od
end


