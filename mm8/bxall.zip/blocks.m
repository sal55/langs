importdll ccc=
!	clang proc charlie(date, point32)
	clang function charlie(date, point32)date
end

record date=(int d,m,y)
record point32=(int32 x,y)
!
!proc bill(date x)=
!	eval x
!end
!proc billr(date &x)=
!	eval x
!end
!!
!proc eric(date x, Point32 y)=
!	eval x
!end

!!
proc fred=
	date d,e,f
	point32 p,q

!	f:=charlie(d,p)
if d=f then fi


!	bill(d)
!	billr(d)
!	eric(d,p)
!!
!!	d:=e
!!eval d
!!BILL(D)
end
!



