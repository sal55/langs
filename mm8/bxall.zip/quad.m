!func solvequad(real a,b,c)real, real =
!
!	return ((+b+sqrt(b*b - 4*a*c))/2*a, (-b+sqrt(b*b - 4*a*c))/2*a)
!!
!end

!fun quad(real a,b,c)real =(+b+sqrt(b*b - 4*a*c))/2*a

func quad(real a,b,c)real x=

	x:=(+b+sqrt(b*b - 4*a*c))/2*a

	x
end

!proc main=
!	real x,y
!
!	(x, y) := solvequad(3, 2, 1)
!	
!	println x, y
!end
!
!
!
!
!
