!import clib

[4]real e1

real t, t1, t2, cpu1, time, x1, x2, x3, x4, x, y, z,
int j, k, l, i, ii

proc pa(ref[]real e) =
	TO 6 DO
		e[1] := (e[1] + e[2] + e[3] - e[4]) * t
		e[2] := (e[1] + e[2] - e[3] + e[4]) * t
		e[3] := (e[1] - e[2] + e[3] + e[4]) * t
		e[4] := (- e[1] + e[2] + e[3] + e[4]) / t2
	OD
end

proc po =
	e1[j] := e1[k]; e1[k] := e1[l]; e1[l] := e1[j]
end

proc p3(real &x, &y, &z)=
	x := t * (x + y); y := t * (x + y); z := (x + y) / t2
end

proc main=
	int cpu1
	int n2,n3,n4,n5,n6,n7,n8,n9,n10,n11

	cpu1 := clock()/1000
	const maxn = 10

	FOR cycles TO maxn DO ! Initialise constants !
		t := 0.499975; t1 := 0.50025; t2 := 2.0
! If i = 10 we have one million Whetstone instructions per cycle !
		i := 100; ii := i
		n2 := 12 * i
		n3 := 14 * i
		n4 := 345 * i
		n6 := 210 * i
		n7 := 32 * i
		n8 := 899 * i
		n9 := 616 * i
		n11 := 93 * i

! MODULE 1. Simple identifiers !
		x1 := 1.0; x2 := x3 := x4 := -1.0

! MODULE 2. Array elements !
		e1[1] := 1.0; e1[2] := e1[3] := e1[4] := -1.0
		TO n2 DO
			e1[1] := (e1[1] + e1[2] + e1[3] - e1[4]) * t
			e1[2] := (e1[1] + e1[2] - e1[3] + e1[4]) * t
			e1[3] := (e1[1] - e1[2] + e1[3] + e1[4]) * t
			e1[4] := (- e1[1] + e1[2] + e1[3] + e1[4]) * t
		OD

! MODULE 3. Array parameters !
		TO n3 DO pa(&e1) OD

! MODULE 4. Conditional jumps !
		j := 1
		TO n4 DO
			j:=(j = 1 | 2 | 3)
			j:=(j > 2 | 0 | 1)
			j:=(j < 1 | 1 | 0)
		OD

! MODULE 5. Omitted !

! MODULE 6. Integers !
		j := 1; k := 2; l := 3
		TO n6 DO
			j := j * (k - j) * (l - k)
			k := l * k - (l - j) * k
			l := (l - k) * (k + j)
			e1[l - 1] := j + k + l
			e1[k - 1] := j * k * l
		OD

! MODULE 7. Trigonometry !
		x := y := 0.5
		TO n7 DO
			x := t * atan (t2 * sin (x) * cos (x) /\
			(cos (x + y) + cos (x - y) - 1.0))
			y := t * atan (t2 * sin (y) * cos (y) /\
			(cos (x + y) + cos (x - y) - 1.0))
		OD

! MODULE 8. Calls !
		x := y := z := 1.0
		TO n8 DO p3(x, y, z) OD

! MODULE 9. Array references !
		j := 1; k := 2; l := 3
		e1[1] := 1.0; e1[2] := 2.0; e1[3] := 3.0
		TO n9 DO
			po()
		OD

! MODULE 11. Standard functions !
		x := 0.75
		TO n11 DO
			x := sqrt (exp (log (x) / t1))
		OD
		if cycles=maxn then
			time := (clock()/1000 - cpu1) / cycles
			println time, 1/(time/(ii/maxn))
		fi
	OD

end
