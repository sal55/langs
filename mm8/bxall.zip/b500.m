const n=500

proc main=
	[n]int data0, data
	int i,t,swapped

	for i to n do
		data0[i]:=mrandomrange(1,1000000)
	od

	println "Unsorted Data0:"
	for i to n when i<10 or i> (n-10) do
		print data0[i],$
	od
	println

	to 2000 do

		for i:=1 to data0.upb do
			data[i]:=data0[i]
		od

		repeat
			swapped:=0
			for i:=1 to data.upb-1 do
				if data[i]>data[i+1] then
					swapped:=1
					swap(data[i], data[i+1])
				fi
			od
		until not swapped
	od

	println "Sorted Data:"
	for i to n when i<10 or i> (n-10) do
		print data[i],$
	od
	println
end

