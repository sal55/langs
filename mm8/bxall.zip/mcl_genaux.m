

global int nsaveregs, nsavefregs		!number of integer/float non-vols to be saved
global int nspilled						!spilled int/float registers

global int framesize					!counts bytes in stack frame
!global int framebytes, frameoffset, paramoffset
global int paramstackoffset
global int paramspilloffset

symbol dblockarg

int nsavedregs, nsavedxregs
!global int retindex

[20]symbol nametable
int nnametable

record inforec=
	byte nargs			!regvar-eligible int args
	byte nxargs			!regvar-eligible float args
	byte nlocals		!regvar-eligible int locals
	byte nxlocals		!regvar-eligible int locals

	byte isleaf			!1 when there are no calls (explicit or implicit)
	byte maxargs		!maxargs either incoming or (via calls/rts) outgoing args
	byte hasblocks		!1 if code involves any blocks other than 16-byte ones
	byte spare			!1 if code involves any blocks other than 16-byte ones
end

inforec info
INT PCLCOUNT


global proc do_proccode_a=
	symbol d
	int reg, xreg, n, r, npregs, retmode, nextreg, nextxreg
	int nargregs, nargxregs, spare, nextargreg, nextargxreg

	clear pcltempflags
	nblocktemps:=0
	r10used:=r11used:=0
	usedset:=0
	regset:=usedset:=regvarset:=0

	pclset:=0
	nsavedregs:=nsavedxregs:=0
	nregvars:=nxregvars:=0

	nworkregs:=nbaseworkregs
	nworkxregs:=nbaseworkxregs

!MCOMMENT("PROCA")
	retmode:=getpclmode(currfunc.mode)

	if retmode=tblock then
		d:=makesymbol("$1x", paramid)
		d.mode:=currfunc.mode
		d.used:=1
		d.nextdef:=currfunc.deflist
		currfunc.deflist:=d
		d.owner:=currfunc
		blockretname:=d
	end

	retindex:=createfwdlabel()

!set up inforec; done after any extra arg for block returns has been done

!for now, add extra 2 int workregs manually
SCANPROCINFO()

	if not fregoptim then		!allow 5 workregs always
!		clear info				!set .isleaf to 0 etc
		workregs[++nworkregs]:=r3
		workregs[++nworkregs]:=r4
		return
	end

!optimising for regvars
!	scanprocinfo()

!CPL CURRFUNC.NAME,,":"
!CPL =PCLCOUNT
!CPL =INFO.NARGS, =INFO.NXARGS
!CPL =INFO.NLOCALS, =INFO.NXLOCALS
!CPL =INFO.ISLEAF
!CPL =INFO.MAXARGS
!CPL =INFO.HASBLOCKS
!CPL =FREGOPTIM

!set up extra 1 or 2 workregs
!INFO.HASBLOCKS:=1
	if info.hasblocks then			!need 2 extra
		nworkregs:=5
		if info.maxargs<=2 then		!both in pregs
			workregs[4]:=r13
			workregs[5]:=r12
			nregvars:=7
		else
user3r4:
			workregs[4]:=r3
			workregs[5]:=r4
			nregvars:=5
		end
	else							!only one extra needed
		nworkregs:=4
		if info.maxargs<=3 then
!CPL CURRFUNC.NAME,"USING R13"
			workregs[4]:=r13
			nregvars:=7
		else
			workregs[4]:=r3
			nregvars:=6
		end
	end

	nxregvars:=12-nworkxregs

!CPL CURRFUNC.NAME, =NWORKREGS, =NREGVARS, =NWORKXREGS, =NXREGVARS, =INFO.MAXARGS

!Allocate registers to params and locals

!	nextreg:=r9
	nextreg:=r9-nregvars+1
	nextxreg:=xr15
	nextargreg:=r10-1				!for leaf
	nextargxreg:=xr0-1				!for leaf

	nargregs:=2

	nargregs:=info.nargs			! 0-4
	spare:=nregvars-info.nlocals		! will be negative, or 0-nregvars
	if nargregs in 3..4 then
		if spare<3 then
			nargregs:=2
		elsif spare=3 then			!else allow all 3/4 argregs
			nargregs:=3
		end
	end

	nargxregs:=2					!just stick to first 2 for now

!CPL CURRFUNC.NAME:":"
!CPL $,=INFO.NARGS
!CPL $,=INFO.NLOCALS
!CPL $,=NREGVARS
!CPL $,=SPARE
!CPL $,=NARGREGS, =NREGVARS-NARGREGS

!IF EQSTRING(currfunc.name, "mandel") then	CPL "MANDEL SEEN"; NARGREGS:=0 end
!IF EQSTRING(currfunc.name, "mandel") then	CPL "MANDEL SEEN"; INFO.ISLEAF:=0 end
!IF EQSTRING(currfunc.name, "create_fractal") then	CPL "CREATEF SEEN"; NARGREGS:=0 end

!scan params first
	d:=currfunc.deflist
	while d, d:=d.nextdef do
		case d.nameid
		when paramid then
			if d.equivvar then nextloop end

			++nextargxreg
			++nextargreg

			if d.regcand and nargregs then
				if info.isleaf then
					regvarset.[nextargreg]:=1
					if nextargreg=r10 then r10used:=1 end
					if nextargreg=r11 then r11used:=1 end
					d.reg:=nextargreg
				else
					regvarset.[nextreg]:=1
					usedset.[nextreg]:=1
					d.reg:=nextreg

!					--nextreg
					++nextreg
					--nregvars
					--nargregs
				end

			elsif d.xregcand and nxregvars then
				if info.isleaf then
					regvarset.[nextargxreg]:=1
					d.reg:=nextargxreg
				else
					regvarset.[nextxreg]:=1
					usedset.[nextxreg]:=1
					d.reg:=nextxreg

					--nextxreg
					--nxregvars
					--nargxregs
				end

			end
		end case
	od
!CPL "DONE PM"

	d:=currfunc.deflist
	while d, d:=d.nextdef do
		case d.nameid
		when frameid then
			if d.equivvar then nextloop end

			if d.regcand and nregvars then
				regvarset.[nextreg]:=1
				usedset.[nextreg]:=1
				d.reg:=nextreg

!				--nextreg
				++nextreg

				--nregvars

			elsif d.xregcand and nxregvars then
				regvarset.[nextxreg]:=1
				usedset.[nextxreg]:=1
				d.reg:=nextxreg

				--nextxreg
				--nxregvars

			end
		end case
!CPL =D.NAME, D.REG
	od

end

global proc do_proccode_b=
! Stack layout (grows downwards)
!	| ...
!	| Pushed arg 6
!	| Pushed arg 5
!	| Shadow space 32-byte		For spilled args (always present even with 0-3 args)
!	| ----------
!	| Pushed return address		Via 'call'
!	| ----------				Above done in caller; below in callee
!	| Pushed nonvol workregs	If extend to R3 and above
!	| Pushed nonvol workxregs	If extend to XR6 and above
!	| ----------				Above done in caller; below in callee
!	| Pushed FP					Save FP
!	| ----------
!	! Local vars				All locals (when used)
!	| ----------
!	| Temps						All temps
!	| ----------
!	| 32-byte shadow space		For any calls made in this func
!	| [Stack adj]				Extra slot may be added to keep stack pointer 16-byte aligned

	int retmode, hasequiv, offset, size, reg
	int nsavedbytes, paramoffset
	mclopnd ax
	symbol d
	[100]char str, newname
	int r, n, ntemps, rr
	u64 oldusedset

	setmclentry(mclprocentry)
!CPL "PROCB1", CURRFUNC.NAME, USEDSET.[RFRAME], USEDSET


	framesize:=0
	dblockarg:=nil

	for r in r3..r9    when usedset.[r] do ++nsavedregs od
	for r in xr6..xr15 when usedset.[r] do ++nsavedxregs od

	nsavedbytes:=(nsavedregs+nsavedxregs)*8


!allocate offsets to args, and set defines

	paramoffset:=16+nsavedbytes		!between top of stackframe and 1st param is fp/retaddr/saved

	oldusedset:=usedset				!need to ignore rframe used in defines
	d:=currfunc.deflist
	while d, d:=d.nextdef do
		if d.equivvar then nextloop end
		size:=ttsize[d.mode]
		if d.mode=tblock then
			size:=d.size
		end

		case d.nameid
		when paramid then
			if d.reg then
				paramoffset+:=8
				defreg
			else
				d.offset:=paramoffset
				paramoffset+:=8
				genmc_def(m_define, d)
			end

		when frameid then
			if d.reg then
defreg:
				rr:=d.reg
				d.reg:=0
				genmc(m_definereg, genmem(d), mgenreg(rr, ttbasetype[d.mode]))
				d.reg:=rr
			else
				framesize+:=roundsizetg(size)
				d.offset:=-framesize
				genmc_def(m_define, d)
			end
		end case
	od

	ntemps:=0
	for i to maxoperands when pcltempflags[i] do
		++ntemps
		framesize+:=8
		ax:=pcltempopnds[i]
		ax.offset:=-framesize
		genmc(m_definetemp, genname(gettempname(currfunc,i)), genint(ax.offset))
	od

!CPL =FRAMESIZE, $LINENO

	usedset:=oldusedset

!CPL =INFO.ISLEAF
	if not info.isleaf then
		framesize+:=32									!shadow space
	end
	int adjust:=0
!CPL =FRAMESIZE, $LINENO

	if not usedset.[rframe] then					!rframe not pushed
		adjust:=8
	end

	unless (framesize+nsavedbytes+adjust+8) iand 8 then			!keep stack frame 16-byte aligned
		UNLESS INFO.ISLEAF THEN
			framesize+:=8
		END
	end
!CPL =FRAMESIZE, $LINENO

!CPL =FRAMESIZE

	savevolregs(nsavedregs, nsavedxregs)

!generate stack entry code proper:

!CPL "PROCB2", CURRFUNC.NAME, USEDSET.[RFRAME], USEDSET

	IF USEDSET.[RFRAME] THEN
		genmc(m_push, dframeopnd)
		genmc(m_mov, dframeopnd, dstackopnd)
	FI
	pushstack(framesize)

!spill any args to shadow space
	spillparams()

	resetmclentry()
end

global proc do_proccode_c=
	int offset
	mclopnd ax, bx

	genmc(m_label, genlabel(retindex))

	popstack(framesize)
	IF USEDSET.[RFRAME] THEN
		genmc(m_pop, dframeopnd)
	FI
	restorevolregs(nsavedregs, nsavedxregs)

	genmc(m_ret)
end

proc start=
	int r

!initialise program-wide workreg maps
!They will be augmented on a per-function basis
	r:=r0
	for i to nbaseworkregs do
		workregs[i]:=r++
	od

	r:=xr4
	for i to nbaseworkxregs do
		workxregs[i]:=r++
	od
end

proc spillparams=
	symbol d
	mclopnd ax
	int offset:=16, regoffset:=0, xregoffset, firstoffset, mode

	regoffset:=0

	d:=currfunc.deflist

	if currfunc.cvariadic then				!C proc def using ...
MERROR("SPILLPARAMS/VARIADIC")
!		firstoffset:=d.offset				!param offsets may be pushed up
!
!		for i:=currfunc.nparams to 3 do				!0-based; if nparams=2, loops over 2..3 as 0..1 are normal
!			ax:=genindex(areg:rframe, size:8, offset:i*8+firstoffset)
!			genmc(m_mov, ax, genreg(i+r10))
!		od
	end
!
	while d, d:=d.nextdef do
		if d.nameid=paramid then
			if regoffset>3 then exit end

!			if d.used or regoffset=0 then
			if d.used then
				mode:=getpclmode(d.mode)
				if not d.reg then
					ax:=genindex(areg:rframe, size:8, offset:d.offset)
					case mode
					when tr64 then
						genmc(m_movq, ax, genreg(regoffset+xr0))
					when tr32 then
						genmc(m_movd, changeopndsize(ax, 4), genxreg(regoffset+xr0, 4))
					else
						genmc(m_mov, ax, genreg(regoffset+r10))
					end case
				elsif d.reg>=xr4 then			!xregvar, not in-situ param
						genmc(m_movq, genxreg(d.reg), genxreg(regoffset+xr0))

				elsif d.reg<=r9 then			!regvar, not in-situ param
					genmc(m_mov, genreg(d.reg), genreg(regoffset+r10))
				end
			end

			offset+:=8
			++regoffset
		end
	od

end

proc savevolregs(int nregs, nxregs)=
	int reg
	mclopnd ax

	if nregs then
		for r in r3..r9 when usedset.[r] do
			genmc(m_push, genreg(r))
			exit unless --nregs
		od
	end

	if nxregs then
		ax:=genreg(r0)
		for r in xr6..xr15 when usedset.[r] do
			genmc(m_movq, ax, genreg(r))
			genmc(m_push, ax)
			exit unless --nxregs
		od
	end
end

proc restorevolregs(int nregs, nxregs)=
	mclopnd ax

	if nxregs then
		ax:=genreg(r10)
		for r:=xr15 downto xr6 when usedset.[r] do
			genmc(m_pop, ax)
			genmc(m_movq, genreg(r), ax)
			exit unless --nxregs
		od
	end

	if nregs then
		for r:=r9 downto r3 when usedset.[r] do
			genmc(m_pop, genreg(r))
			exit unless --nregs
		od
	end
end

proc gendq(int a)=
	genmc_int(m_dq, a)
end

global proc genabsneg=
	if lababs32+lababs64+labneg32+labneg64 then
		setsegment('I', 16)
	end

	if lababs32 then
		mcomment("lababs32")
		genmc_label(m_label, lababs32)
		gendq(0x7FFF'FFFF'7FFF'FFFF)
		gendq(0x7FFF'FFFF'7FFF'FFFF)
	end
	if lababs64 then
		mcomment("lababs64")
		genmc_label(m_label, lababs64)
		gendq(0x7FFF'FFFF'FFFF'FFFF)
		gendq(0x7FFF'FFFF'FFFF'FFFF)
	end

	if labneg32 then
		mcomment("labneg32")
		genmc_label(m_label, labneg32)
		gendq(0x8000'0000'8000'0000)
		gendq(0x8000'0000'8000'0000)
	end
	if labneg64 then
		mcomment("labneg64")
		genmc_label(m_label, labneg64)
		gendq(0x8000'0000'0000'0000)
		gendq(0x8000'0000'0000'0000)
	end

	if labzero then
		mcomment("labzero")
		genmc_label(m_label, labzero)
		gendq(0)
	end

	if labmask63 then
		mcomment("mask63/offset64")
		genmc_label(m_label, labmask63)
		gendq(0x7FFF'FFFF'FFFF'FFFF)
		genmc_label(m_label, laboffset64)
		gendq(0x43E0'0000'0000'0000)
	end
end

proc setmclentry(mcl p)=
!temporarily set mcl insertion before p

	mce_oldmccodex:=mccodex
	mccodex:=p
	mce_lastmcl:=p.lastmcl
	mce_nextmcl:=p.nextmcl
end

func resetmclentry:mcl pnew =
!restore mcl insertion point to normal
!restireturn mcl instruction that followed	
	mccodex.lastmcl:=mce_lastmcl
	mccodex.nextmcl:=mce_nextmcl
	pnew:=mccodex
	mccodex:=mce_oldmccodex
	pnew
end

proc setmclentryf(mcl p)=
!temporarily set mcl insertion before p

	mcf_oldmccodex:=mccodex
	mccodex:=p
	mcf_lastmcl:=p.lastmcl
	mcf_nextmcl:=p.nextmcl
end

func resetmclentryf:mcl pnew =
!restore mcl insertion point to normal
!restireturn mcl instruction that followed	
	mccodex.lastmcl:=mcf_lastmcl
	mccodex.nextmcl:=mcf_nextmcl
	pnew:=mccodex
	mccodex:=mcf_oldmccodex
	pnew
end

global proc copyblock(mclopnd ax,bx, int n)=
!ax, bx refer to memory; do ax:=bx for n bytes

	mclopnd rx, rcount
	int nwords, lab, oddbytes, offset, workreg, countreg, axreg

	if n=16 then
		rx:=genreg(gwrx())
		genmc(m_movdqu, rx, bx)
		genmc(m_movdqu, ax, rx)
		return
	end

	oddbytes:=n rem 8		!will be zero, or 1..7
	n-:=oddbytes			!n will always be a multiple of 8; n can be zero too
	nwords:=n/8				!number of u64s (ie. octobytes)

	rx:=genreg(gwri())		!work reg

	offset:=0
		ax:=makesimpleaddr(ax)
		bx:=makesimpleaddr(bx)

	if nwords in 1..4 then		!use unrolled code (no loop)
		ax:=changeopndsize(ax, targetsize)
		bx:=changeopndsize(bx, targetsize)

		to nwords do
			genmc(m_mov, rx, applyoffset(bx, offset))
			genmc(m_mov, applyoffset(ax, offset), rx)
			offset+:=8
		od

	elsif nwords then			!use a loop
		rcount:=genreg(gwri())
		lab:=++mlabelno

		ax.size:=8

		genmc(m_mov, rcount, mgenint(nwords))
		genmc(m_label, genlabel(lab))
		genmc(m_mov, rx, bx)
		genmc(m_mov, ax, rx)

		genmc(m_add, mgenreg(ax.reg), mgenint(targetsize))
		genmc(m_add, mgenreg(bx.reg), mgenint(targetsize))

		genmc(m_dec, rcount)
		genmc_cond(m_jmpcc, ne_cond, genlabel(lab))

		offset:=0
	end

	if oddbytes then
		n:=oddbytes						!1..7

		if n>=4 then
			rx:=changeopndsize(rx, 4)
			genmc(m_mov, rx, applyoffset(bx, offset, 4))
			genmc(m_mov, applyoffset(ax, offset, 4), rx)
			n-:=4
			offset+:=4
		end
		if n>=2 then
			rx:=changeopndsize(rx, 2)
			genmc(m_mov, rx, applyoffset(bx, offset, 2))
			genmc(m_mov, applyoffset(ax, offset, 2), rx)
			n-:=2
			offset+:=2
		end
		if n=1 then
			rx:=changeopndsize(rx, 1)
			genmc(m_mov, rx, applyoffset(bx, offset, 1))
			genmc(m_mov, applyoffset(ax, offset, 1), rx)
		end
	end
end

proc scanprocinfo=
	pcl pc
	symbol d
	int nargs, nparams, m

	clear info
	info.isleaf:=1
	pclcount:=0

	pc:=currfunc.pccode

	while pc, pc:=pc.next do
		++pclcount

		if pc.mode=tblock and pc.size<>16 then info.hasblocks:=1 end

		nargs:=pclargs[pc.opcode]
		if nargs then
			info.isleaf:=0
			if nargs=9 then nargs:=pc.nargs fi		!is a call
			info.maxargs max:= nargs
		end

		if pc.optype=memaddr_opnd then
			unless pc.opcode=kload and pc.inplace then
				pc.def.addrof:=1
			end
		end

	od

!need to potential regvars in 4 categories: int/float params/locals

	d:=currfunc.deflist
	nparams:=0

	while d, d:=d.nextdef do
		case d.nameid
		when paramid then
			if nparams<4 and d.used and not d.equivvar and not d.addrof then
				m:=getpclmode(d.mode)
				if stdint[m] then
					++info.nargs
					d.regcand:=1
				elsif stdfloat[m] then
					++info.nxargs
					d.xregcand:=1
				end
			end
			++nparams
		when frameid then
!CPL "SCAN", D.NAME,D.ADDROF
			if d.used and not d.equivvar and not d.addrof then
!CPL "SCAN2"
				m:=getpclmode(d.mode)
				if stdint[m] then
					++info.nlocals
					d.regcand:=1
				elsif stdfloat[m] then
					++info.nxlocals
!CPL "DOING XREGVAR"
					d.xregcand:=1
				end
			end
		end case
	od

	info.maxargs max:=nparams

	if currfunc.cvariadic then			!args must all be spilled
		info.nargs:=info.nxargs:=0
	end

END

