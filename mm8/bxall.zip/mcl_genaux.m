global int nsaveregs, nsavefregs		!number of integer/float non-vols to be saved
global int nspilled						!spilled int/float registers

global int framesize					!counts bytes in stack frame
!global int framebytes, frameoffset, paramoffset
global int paramstackoffset
global int paramspilloffset

symbol dblockarg

int nsavedregs, nsavedxregs
!global int retindex

[20]symbol nametable
int nnametable

global proc do_proccode_a=
	symbol d
	int reg, xreg, n, r, npregs, retmode

	clear pcltempflags
	nblocktemps:=0
	r10used:=r11used:=0
	usedset:=0

	workset:=0
	for r in r0..r9 do workset.[r]:=1 od			!int regs available
	for r in xr4..xr15 do workset.[r]:=1 od			!xregs

	regset:=usedset:=regvarset:=0

	PCLSET:=0

!CPL "-----------", USEDSET, CURRFUNC.NAME, =REGSET, =PCLSET

	nsavedregs:=nsavedxregs:=0

!MCOMMENT("PROCA")
	retmode:=getpclmode(currfunc.mode)

	if retmode=tblock then
		d:=makesymbol("$1x", paramid)
		d.mode:=currfunc.mode
		d.used:=1
		d.nextdef:=currfunc.deflist
		currfunc.deflist:=d
		d.owner:=currfunc
		blockretname:=d
!CPL "SET BLOCK

	fi

	retindex:=createfwdlabel()
end

global proc do_proccode_b=
! Stack layout (grows downwards)
!	| ...
!	| Pushed arg 6
!	| Pushed arg 5
!	| Shadow space 32-byte		For spilled args (always present even with 0-3 args)
!	| ----------
!	| Pushed return address		Via 'call'
!	| ----------				Above done in caller; below in callee
!	| Pushed nonvol workregs	If extend to R3 and above
!	| Pushed nonvol workxregs	If extend to XR6 and above
!	| ----------				Above done in caller; below in callee
!	| Pushed FP					Save FP
!	| ----------
!	! Local vars				All locals (when used)
!	| ----------
!	| Temps						All temps
!	| ----------
!	| 32-byte shadow space		For any calls made in this func
!	| [Stack adj]				Extra slot may be added to keep stack pointer 16-byte aligned

	int retmode, hasequiv, offset, size, reg
	int nsavedbytes, paramoffset
	mclopnd ax
	symbol d
	[100]char str, newname
	int r, n, ntemps

	setmclentry(mclprocentry)

	framesize:=0
	dblockarg:=nil

	for r in r3..r9    when usedset.[r] do ++nsavedregs od
	for r in xr6..xr15 when usedset.[r] do ++nsavedxregs od

	nsavedbytes:=(nsavedregs+nsavedxregs)*8

!allocate offsets to args, and set defines

	paramoffset:=16+nsavedbytes		!between top of stackframe and 1st param is fp/retaddr/saved

	d:=currfunc.deflist
	while d, d:=d.nextdef do
		case d.nameid
		when paramid then
!			if not d.reg then
				d.offset:=paramoffset
				paramoffset+:=8
!				if d.used then
					genmc_def(m_define, d)
!				elsif pcheckunusedlocals then
!					println "Unused param:", d.name, "in", currfunc.name
!				fi
!			else
!			fi

		when frameid then
!			if not d.used then
!				if pcheckunusedlocals then
!					println "Unused local:", d.name, "in", currfunc.name
!				fi
!				nextloop
!			fi

			size:=ttsize[d.mode]
			if d.mode=tblock then
				size:=d.size
			fi

			if d.equivvar then
			elsif not d.reg then
				framesize+:=roundsizetg(size)
				d.offset:=-framesize
				genmc_def(m_define, d)
			else
				int rr:=d.reg
				d.reg:=0
				genmc(m_definereg, genmem(d), mgenreg(rr, ttbasetype[d.mode]))
				d.reg:=rr
			fi
		esac
	od

	ntemps:=0
	for i to maxoperands when pcltempflags[i] do
		++ntemps
		framesize+:=8
		ax:=pcltempopnds[i]
		ax.offset:=-framesize
		genmc(m_definetemp, genname(gettempname(currfunc,i)), genint(ax.offset))
	od

	framesize+:=32									!shadow space

	unless (framesize+nsavedbytes+8) iand 8 then			!keep stack frame 16-byte aligned
		framesize+:=8
	end

	savevolregs(nsavedregs, nsavedxregs)

!generate stack entry code proper:

	genmc(m_push, dframeopnd)
	genmc(m_mov, dframeopnd, dstackopnd)
	pushstack(framesize)

!spill any args to shadow space
	spillparams()

	resetmclentry()
end

global proc do_proccode_c=
	int offset
	mclopnd ax, bx

	genmc(m_label, genlabel(retindex))

	popstack(framesize)
	genmc(m_pop, dframeopnd)
	restorevolregs(nsavedregs, nsavedxregs)

	genmc(m_ret)
end

proc spillparams=
	symbol d
	mclopnd ax
	int offset:=16, regoffset:=0, xregoffset, firstoffset

	regoffset:=0

	d:=currfunc.deflist

!	if currfunc.variadic then				!C proc def using ...
!		firstoffset:=d.offset				!param offsets may be pushed up
!
!		for i:=currfunc.nparams to 3 do				!0-based; if nparams=2, loops over 2..3 as 0..1 are normal
!			ax:=genindex(areg:rframe, size:8, offset:i*8+firstoffset)
!			genmc(m_mov, ax, genreg(i+r10))
!		od
!	fi
!
	while d, d:=d.nextdef do
		if d.nameid=paramid then
			if regoffset>3 then exit fi

			if d.used or regoffset=0 then
				ax:=genindex(areg:rframe, size:8, offset:d.offset)
				case d.mode
				when tr64 then
					genmc(m_movq, ax, genxreg(regoffset+xr0))
				when tr32 then
					genmc(m_movd, changeopndsize(ax, 4), genxreg(regoffset+xr0, 4))
				else
					genmc(m_mov, ax, genreg(regoffset+r10))
				esac
			fi

			offset+:=8
			++regoffset
		fi
	od

end

proc savevolregs(int nregs, nxregs)=
	int reg
	mclopnd ax

	if nregs then
		for r in r3..r9 when usedset.[r] do
			genmc(m_push, genreg(r))
			exit unless --nregs
		od
	fi

	if nxregs then
		ax:=genreg(r0)
		for r in xr6..xr15 when usedset.[r] do
			genmc(m_movq, ax, genreg(r))
			genmc(m_push, ax)
			exit unless --nxregs
		od
	fi
end

proc restorevolregs(int nregs, nxregs)=
	mclopnd ax

	if nxregs then
		ax:=genreg(r10)
		for r:=xr15 downto xr6 when usedset.[r] do
			genmc(m_pop, ax)
			genmc(m_movq, genreg(r), ax)
			exit unless --nxregs
		od
	fi

	if nregs then
		for r:=r9 downto r3 when usedset.[r] do
			genmc(m_pop, genreg(r))
			exit unless --nregs
		od
	fi
end

proc gendq(int a)=
	genmc_int(m_dq, a)
end

global proc genabsneg=
	if lababs32+lababs64+labneg32+labneg64 then
		setsegment('I', 16)
	fi

	if lababs32 then
		mcomment("lababs32")
		genmc_label(m_label, lababs32)
		gendq(0x7FFF'FFFF'7FFF'FFFF)
		gendq(0x7FFF'FFFF'7FFF'FFFF)
	fi
	if lababs64 then
		mcomment("lababs64")
		genmc_label(m_label, lababs64)
		gendq(0x7FFF'FFFF'FFFF'FFFF)
		gendq(0x7FFF'FFFF'FFFF'FFFF)
	fi

	if labneg32 then
		mcomment("labneg32")
		genmc_label(m_label, labneg32)
		gendq(0x8000'0000'8000'0000)
		gendq(0x8000'0000'8000'0000)
	fi
	if labneg64 then
		mcomment("labneg64")
		genmc_label(m_label, labneg64)
		gendq(0x8000'0000'0000'0000)
		gendq(0x8000'0000'0000'0000)
	fi

	if labzero then
		mcomment("labzero")
		genmc_label(m_label, labzero)
		gendq(0)
	fi

	if labmask63 then
		mcomment("mask63/offset64")
		genmc_label(m_label, labmask63)
		gendq(0x7FFF'FFFF'FFFF'FFFF)
		genmc_label(m_label, laboffset64)
		gendq(0x43E0'0000'0000'0000)
	fi
end

proc setmclentry(mcl p)=
!temporarily set mcl insertion before p

	mce_oldmccodex:=mccodex
	mccodex:=p
	mce_lastmcl:=p.lastmcl
	mce_nextmcl:=p.nextmcl
end

func resetmclentry:mcl pnew =
!restore mcl insertion point to normal
!restireturn mcl instruction that followed	
	mccodex.lastmcl:=mce_lastmcl
	mccodex.nextmcl:=mce_nextmcl
	pnew:=mccodex
	mccodex:=mce_oldmccodex
	pnew
end

proc setmclentryf(mcl p)=
!temporarily set mcl insertion before p

	mcf_oldmccodex:=mccodex
	mccodex:=p
	mcf_lastmcl:=p.lastmcl
	mcf_nextmcl:=p.nextmcl
end

func resetmclentryf:mcl pnew =
!restore mcl insertion point to normal
!restireturn mcl instruction that followed	
	mccodex.lastmcl:=mcf_lastmcl
	mccodex.nextmcl:=mcf_nextmcl
	pnew:=mccodex
	mccodex:=mcf_oldmccodex
	pnew
end

global proc copyblock(mclopnd ax,bx, int n)=
!ax, bx refer to memory; do ax:=bx for n bytes

	mclopnd rx, rcount
	int nwords, lab, oddbytes, offset, workreg, countreg, axreg

	if n=16 then
		rx:=genreg(gwrx())
		genmc(m_movdqu, rx, bx)
		genmc(m_movdqu, ax, rx)
		return
	fi

	oddbytes:=n rem 8		!will be zero, or 1..7
	n-:=oddbytes			!n will always be a multiple of 8; n can be zero too
	nwords:=n/8				!number of u64s (ie. octobytes)

	rx:=genreg(gwri())		!work reg

	offset:=0
		ax:=makesimpleaddr(ax)
		bx:=makesimpleaddr(bx)

	if nwords in 1..4 then		!use unrolled code (no loop)
		ax:=changeopndsize(ax, targetsize)
		bx:=changeopndsize(bx, targetsize)

		to nwords do
			genmc(m_mov, rx, applyoffset(bx, offset))
			genmc(m_mov, applyoffset(ax, offset), rx)
			offset+:=8
		od

	elsif nwords then			!use a loop
		rcount:=genreg(gwri())
		lab:=++mlabelno

		ax.size:=8

		genmc(m_mov, rcount, mgenint(nwords))
		genmc(m_label, genlabel(lab))
		genmc(m_mov, rx, bx)
		genmc(m_mov, ax, rx)

		genmc(m_add, mgenreg(ax.reg), mgenint(targetsize))
		genmc(m_add, mgenreg(bx.reg), mgenint(targetsize))

		genmc(m_dec, rcount)
		genmc_cond(m_jmpcc, ne_cond, genlabel(lab))

		offset:=0
	fi

	if oddbytes then
		n:=oddbytes						!1..7

		if n>=4 then
			rx:=changeopndsize(rx, 4)
			genmc(m_mov, rx, applyoffset(bx, offset, 4))
			genmc(m_mov, applyoffset(ax, offset, 4), rx)
			n-:=4
			offset+:=4
		fi
		if n>=2 then
			rx:=changeopndsize(rx, 2)
			genmc(m_mov, rx, applyoffset(bx, offset, 2))
			genmc(m_mov, applyoffset(ax, offset, 2), rx)
			n-:=2
			offset+:=2
		fi
		if n=1 then
			rx:=changeopndsize(rx, 1)
			genmc(m_mov, rx, applyoffset(bx, offset, 1))
			genmc(m_mov, applyoffset(ax, offset, 1), rx)
		fi
	fi
end

global func makesimpleaddr(mclopnd ax)mclopnd bx=
!assume ax is an ireg, but need a simple one with areg set but not ireg
	int newreg, reg, regix

	reg:=ax.reg
	regix:=ax.regix
	if reg=rframe then reg:=rnone fi

	if ax.mode<>a_mem then merror("MSA") fi

	if reg=rnone and regix=rnone then
		newreg:=gwri()
	elsif reg then				![reg] only; already simple
		return ax
	elsif regix then			![regix] only; may be scaled; use lea anyway
		newreg:=regix
	else						![reg+regix]
		newreg:=regix
	fi

	bx:=mgenireg(newreg)

	genmc(m_lea, genreg(newreg), ax)
	return bx
end
