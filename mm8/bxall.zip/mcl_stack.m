!PCL Operand Stack 

global func getopnd(int n, mode=pmode, reg=rnone)mclopnd ax =
!get access mode for operand n
	int oldreg, size
	mclopnd bx
	psymbol d

	pcl p:=pclopnds[n]
	pcsrec ps:=pclstack[n]

	size:=stdsize[mode]

!CPL "GETOPND", PS.REG, PS.TEMP

	if ps.reg then
		oldreg:=ps.reg
		if reg and oldreg<>reg then
			ax:=genreg(reg, size)
			bx:=genreg(oldreg, size)
			REGSET.[OLDREG]:=0
			PCLSET.[OLDREG]:=0
			PCLSET.[REG]:=1
			genmc(m_mov, ax, bx)
		else
			ax:=genreg(oldreg, size)
		end

	elsif ps.temp then
		ax:=mgentemp(n, mode)

	elsecase p.optype

	when mem_opnd then
		d:=p.def
!CPL "GET:MEMOPND", D.NAME
!		IF D.EQUIVVAR THEN
!			D:=D.EQUIVVAR.DEF
!		FI
! CPL "GETOPND/MEM/@" FI

		if mode=tblock and d.nameid<>paramid then
			mode:=tu64
			recase memaddr_opnd
		else
			ax:=genmem(p.def, size)
		end

	when memaddr_opnd then
		d:=p.def
!CPL "GET:MEMADDROPND", D.NAME, STRMODE(D.MODE), =ISBLOCK(D.MODE), =STRMODE(P.MODE)
!		if d.nameid=paramid and d.mode=tblock then		!pcl mode will be u64
		if d.nameid=paramid and d.mode=tblock then		!pcl mode will be u64
			ax:=genmem(d, size)
		else
!			ax:=genreg(getworkregc(mode, reg))

			ax:=gwrm(mode, reg)
			genmc(m_lea, ax, genmem(d, size))
		end

	when int_opnd then

		case size
		when 2 then
			p.value iand:=0xFFFF
		when 4 then
			p.value iand:=0xFFFF'FFFF
		end case

		bx:=genint(p.value, size)
		if p.value in i32.bounds then			!keep as immediate
			ax:=bx
		else
			ax:=gwrm(mode, reg)
			genmc(m_mov, ax, bx)
		end

	when real_opnd then
		ax:=genrealmem(p.xvalue, size)

	when string_opnd then
		ax:=gwrm(tu64, reg)
		genmc(m_lea, ax, genlabelmem(getstringindex(p.svalue, p.slength)))

	when label_opnd then
!		ax:=genreg(getworkireg(reg))
		ax:=gwrm(tu64, reg)

		genmc(m_lea, ax, genlabelmem(p.labelno))
!		else
!			GERROR("LABELDEF NOT DEF")
!		end
!
	else
error:
		merror("getopnd", opndnames[p.optype])
	end

	if ax.mode=a_reg then		!ensure correctly set to reg
		pclstack[n].reg:=ax.reg
		pclstack[n].temp:=0
		pclstack[n].code:=0
		pclset.[ax.reg]:=1
	end

	ax
end

global func loadopnd(int n, mode=pmode, reg=rnone)mclopnd ax =
!must return with value in register. But it can be in-situ if it is a regvar
!and no newreg is specified
	pcl p:=pclopnds[n]
	pcsrec ps
	psymbol d
	int reg0:=reg

	int size:=stdsize[mode]
	mclopnd bx

!CPL "LOAD1"
	ax:=getopnd(n, mode, reg)
!CPL "LOAD2"

	ps:=pclstack[n]
	if ps.reg then
		if regvarset.[ps.reg] then		!needs copying
!MCOMM("LOADOPND/REGVAR ", STRREG(PS.REG))
!CPL "LOADOPND/REGVAR", STRREG(PS.REG)
			finish
		end
		return ax
	end

!CPL "LOAD3"
!CPL "LOADOPNDR", STRREG(REG), =SIZE

	if reg=rnone then
		if pstdfloat[mode] then
			bx:=genxreg(reg:=gwrx(), size)
		else
			bx:=genreg(reg:=gwri(), size)
		end
	else
		bx:=genreg(reg, size)
	end

	if ps.temp then
		genmc(m_mov, bx, ax)

	elsecase p.optype
	when mem_opnd, real_opnd  then
		genmc(m_mov, bx, ax)

	when int_opnd then
		if ax.value=0 then
			clearreg(bx)
		else
			genmc(m_mov, bx, ax)
		end


	when memaddr_opnd then
		d:=p.def
		if d.nameid=paramid and d.mode=tblock then		!pcl mode will be u64
			ax:=genmem(d, size)
			genmc(m_mov, bx, ax)
		else
!			ax:=genreg(getworkregc(mode, reg))
			bx:=gwrm(mode, reg)
			genmc(m_lea, bx, genmem(d, size))
		end

	when string_opnd then
!		ax:=genreg(getworkireg())
!		genmc(m_lea, ax, genlabelmem(getstringindex(p.svalue)))
!
!	when label_opnd then
!		ax:=genreg(getworkireg())
!
!		genmc(m_lea, ax, genlabelmem(p.labelno))
!!		else
!!			GERROR("LABELDEF NOT DEF")
!!		end
!
	else
error:
		merror("loadopndr", opndnames[p.optype])
	end

	pclstack[n].reg:=reg
	pclstack[n].temp:=0
	pclstack[n].code:=0
	pclset.[reg]:=1

	ax:=bx
	int newreg

finish:
	reg:=ax.reg

!don't need a value if the reg is regvar belong to an in-situ argument
!other code will have taken care of this (mainly to do with using CL or RDX)

!	if regvarset.[reg] and reg not in r10..r13 and reg not in xr0..xr3 then			!need to copy elsewhere
	if regvarset.[reg] and reg<>reg0 then			!need to copy elsewhere
!	if regvarset.[reg]  then			!need to copy elsewhere
		bx:=gwrm(mode)
		newreg:=bx.reg

		genmc(m_mov, bx, ax)
	
		pclset.[reg]:=0
		pclset.[newreg]:=1

		pclstack[n].reg:=newreg
		bx
	else
		ax
	end
end

global func loadparam(int n, mode=pmode, reg)mclopnd ax =
	loadopnd(n, mode, reg)
end

global proc pushpcl(pcl pc)=
!Push a inline operand from pcl code to pcs
!addrof is 1 to apply & to name units, creating a memaddr opnd
	int n
	pcl p
	pcsrec ps
	psymbol d
!
	if noperands>=maxoperands then
		merror("PCL stack overflow")
	end

	n:=++noperands

!	if pc.optype=mem_opnd and (reg:=pc.def.reg) then
	if pc.optype=mem_opnd then
		d:=pc.def
!		if d.equivvar then
!			d:=d.equivvar.def
!		end

		if d.reg then
			ps.reg:=d.reg
			ps.temp:=ps.code:=0
			finish
		end
	end

	pclopnds[n]:=pc
	ps.code:=1
	ps.reg:=ps.temp:=0

finish:

	ps.mode:=pc.mode
	ps.count:=1

	pclstack[n]:=ps
!CPL "PUSHPCL", PCLSTACK[N].REG
end

global proc pushopnd(int n, mode)=
!Push opnd n to hardware stack then pop it from pcl stack
!The hardware stack is popped on return from a call

	mclopnd ax, bx
	pcl p:=pclopnds[n]
	pcsrec ps:=pclstack[n]

	if mode=tvoid then mode:=p.mode end

!First look for operands that can be directly pushed without using a register
	if ps.code then
		case p.optype
		when mem_opnd then
			if p.size=8 then
				ax:=genmem(p.def, p.size)
				pushit
			end

		when int_opnd then
			if p.value in i32.bounds then		!fits in d32 offset
!				ax:=genint(p.value, 4)
!				ax:=genint(p.value IAND 0XFFFFFFFF, 4)
				ax:=genint(p.value, TI64)
				pushit
			end

		when real_opnd then
			if p.size=8 then
				ax:=genrealmem(p.xvalue)
				pushit
			end
		end case
	end

!!need to go via register

	ax:=loadopnd(n, mode)

	if ax.reg>=xr0 then			!float register
		bx:=ax
!		ax:=genreg(getworkireg(), p.size)
		ax:=gwrm(pmode)
		genmc(m_mov, ax, bx)
	end

pushit:
	genmc(m_push, changeopndsize(ax,8))
	poppcl()
	++mstackdepth

end

!global func loadtoreg(mclopnd ax, int mode, reg)mclopnd=
!!if ax is not a register operand, then load it to given register
!!mode is needed to give type of register (float etc) and size
!!It is assumed that if ax /is/ in a register, that it is the correct one, or doesn't matter
!	mclopnd bx
!
!	if ax.mode=a_reg then			!might already be in reg
!		if not reg or ax.reg=reg then
!			return ax
!		end
!	end
!
!	bx:=getworkreg_rm(reg, mode)
!
!	loadtoreg_common(bx, ax)
!
!	bx
!end
!
!global func loadtoreg_m(mclopnd ax, int mode, reg)mclopnd=
!!same as loadtoreg but if already in a register, will move it to required one if needed
!	mclopnd bx
!
!	if ax.mode=a_reg then			!already in register
!		if ax.reg=reg then return ax fi			!in correct one
!	end
!
!!need loading/moving to given reg
!	bx:=genreg(reg, ttsize[mode])
!
!	loadtoreg_common(bx, ax)
!!	genmc(m_mov, bx, ax)
!	bx
!end

!proc loadtoreg_common(mclopnd bx, ax)=
!	if ax.mode=a_imm and ax.valtype=int_val and ax.value=0 then
!		bx:=changeopndsize(bx,4)
!		clearreg(bx)
!!		genmc(m_xorx, bx, bx)
!	
!	else
!		genmc(m_mov, bx, ax)
!	end
!
!end

global proc pushpcl_reg(int mode, reg=rnone)=
!Push a new, empty pcs slot located in given register
	int n
	pcsrec ps

	if noperands>=maxoperands then
		merror("PCL stack overflow")
	end

	if reg=rnone then reg:=gwr(mode) end

	n:=++noperands

	ps.all:=0
	ps.reg:=reg
	ps.count:=1
	ps.mode:=mode
	pclstack[n]:=ps

	regset.[reg]:=1
	pclset.[reg]:=1

end

global proc poppcl=
	int n:=noperands

	if n<=0 then merror("poppcl/underflow") end

	if pclstack[n].count>1 then
		--pclstack[n].count
		return
	end

	pclset.[pclstack[n].reg]:=0		!will clear bit 0 if no reg used

	--noperands
end

global proc duplpcl=
!ensure zz is in a register, duplicate into a new register
	int mode:=pclstack[zz].mode

	loadopnd(zz, mode)							!get zz to reg
!	pushpcl_reg(getworkreg(mode), mode)				!create new zz opnd, old is now yy
	pushpcl_reg(mode)							!create new zz opnd, old is now yy

!MCOMM("DUPLOP")
	genmc(m_mov, getopnd(zz, mode), getopnd(yy, mode))	!copy old to new
end

global func gwri(int r=rnone)int =
	if r then return r end

	to 10 do
		for i to nworkregs do
			r:=workregs[i]
			if regset.[r]=0 then
				regset.[r]:=1
				usedset ior:=regset
				return r
			end
		end
		savenextopnd()
	end
	merror("No more work regs")
	0
end

global func gwrx(int r=rnone)int=
	if r then return r end

	for i to nworkxregs do
		r:=workxregs[i]
		if regset.[r]=0 then
			regset.[r]:=1
!			usedset.[r]:=1
			usedset ior:=regset
			return r
		end
	end
	merror("No more work xregs")
	0
end

global func gwr(int mode=pmode, reg=rnone)int =
	if regvarset.[reg] then
		reg:=rnone
	end
!MERROR("GWR/REGVAR")
!FI

	if pstdfloat[mode] then
		gwrx(reg)
	else
		gwri(reg)
	end
end

global func gwrm(int mode=pmode, reg=rnone)mclopnd =

	if reg=rframe then reg:=rnone end

	mgenreg(gwr(mode, reg), mode)

!	if pstdfloat[mode] then
!		genxreg(gwrx(reg), stdsize[mode])
!	else
!		genreg(gwri(reg), stdsize[mode])
!	end
end

global proc saveopnd(int n, allregs=1)=
!if operand is in a volatile register, then save it in a temp
!allregs=1 to save both A and B regs (vol/nonval), which can include P regs if
!used as workregs; this is to save pne reg=opnd to a temp to free up a register
!allregs=0 to limit to A regs (possibly some P regs) only; normall for CALLs
!in order to preserve non-vol regs, as call will preserve the rest

!NOTE: operands that are unlikely to be unchanged from their value in
!pclrec, could be revert to unit_loc. Eg. immediates, addresses, or any
!variable that is immutable

	int reg, size
	mclopnd tx
	pcsrec ps:=pclstack[n]

	reg:=ps.reg

	if reg=rnone or regvarset.[reg] then return end

	size:=stdsize[ps.mode]

	if pstdint[ps.mode] then
		if allregs or reg not in r3..r9 then
!CPL "SAVEOPND", =ALLREGS, STRREG(REG)
			genmc(m_mov, gentemp(n, size), genreg(reg, size))
		end
	else
		if allregs or reg in xr0..xr5 then
			genmc(m_mov, gentemp(n, size), genxreg(reg, size))
		end
	end
	regset.[reg]:=0
	pclset.[reg]:=0

	ps.reg:=ps.code:=0
	ps.temp:=1
	pclstack[n]:=ps
end
!
global proc saveopnds(int n=0)=
!save all operands other than top n
!assume this is to do with calls
	for i:=1 to noperands-n do
		saveopnd(i,0)
	end
end

global proc savenextopnd=
!starting from the first loaded, look for and save first reg-based opnd
!this does A/B/P regs if used
	int reg

	for i:=1 to noperands do
		reg:=pclstack[i].reg

		if reg and not regvarset.[reg] and pstdint[pclstack[i].mode] then
			saveopnd(i,1)
			return
		end
	end
end

global proc movetoreg(int newreg)=
!move top of stack (assumed to be in reg) to newreg
!assumes integer reg
	int oldreg, size
	pcsrec ps

	loadopnd(zz, pclstack[zz].mode)

retry:

	ps:=pclstack[zz]
	oldreg:=ps.reg
	size:=stdsize[ps.mode]

	if oldreg=newreg then
		return
	end

	if pstdfloat[ps.mode] then
		if regset.[newreg] then
			MERROR("MOVE TO REG: XREG IN USE")
		end
	elsif regset.[newreg] then
		for i to noperands do
			if pstdint[ps.mode] and pclstack[i].reg=newreg then
				swapopnds(i,zz)
				genmc(m_xchg, genreg(oldreg), genreg(newreg))
				retry
			end
		end
	end

	genmc(m_mov, genreg(newreg, size), genreg(oldreg, size))

	pclstack[zz].reg:=newreg

!CPL "MOVETOREG"

	regset.[oldreg]:=0
	regset.[newreg]:=1
end

global proc swapopnds(int m,n)=
!exchange pcl stack operands
	pclrec t

	swap(pclopnds[m], pclopnds[n])
	swap(pclstack[m], pclstack[n])
end

global proc setnewzz(int mode, reg)=
!some value has been into into given register
!create replace pcl[zz] with that new operand
!assume pclcount was 1 and stays at 1
	pcsrec ps
!CPL "SETNEWZZ"

	ps:=pclstack[zz]

IF REGVARSET.[REG] THEN
MERROR("SETNEWZZ/REGVAR")
FI

	pclset.[ps.reg]:=0

	ps.reg:=reg
	ps.temp:=ps.code:=0
	ps.mode:=mode
	pclset.[reg]:=1

	pclstack[zz]:=ps
end

global func stropndstack(int indent=0)ichar=
	static [768]char str
	[512]char str2
	ichar s:=str, t
	pcl p
	pcsrec ps
	const w=20

!	if indent then
!		fprint @s, "="*20 + "#:(", NOPERANDS
!	else
!		fprint @s, "#:(", NOPERANDS
!	end

	strcpy(s, "")

	for i to noperands do
		p:=pclopnds[i]
		ps:=pclstack[i]

!STRCAT(S, "C:")
!STRCAT(S, STRINT(PS.COUNT))
!STRCAT(S, " ")
		if i=1 then
			strcat(s, " "*(w))
		else
			strcat(s, ";"+" "*w)
		end
		strcat(s, strint(i,"2"))
		strcat(s, " ")
		strcat(s, (noperands-i+1|"Z:", "Y:", "X:", "W:"|"  "))

		if ps.reg then
!			strcpy(str2, regnames[ps.reg])
			strcpy(str2, strreg(ps.reg))
!			if p.def then strcat(s, "*") end
!			if p and p.opndtype=mem_opnd then
!				strcat(s, "(")
!				strcat(s, p.def.name)
!!				strcat(s, strint(int(p)))
!				strcat(s, ")")
!			end

		elsif ps.temp then
			print @str2, "T",,i

		elsecase p.opndtype
		when int_opnd then
			print @str2, p.value

		when real_opnd then
			print @str2, p.xvalue

		when mem_opnd then
domem:
			print @str2, p.def.name

		when memaddr_opnd then
			print @str2, "&",,p.def.name

		when string_opnd then
			if p.slength<10 then
				strcpy(str2, """")
				newconvertstring(p.svalue, &str2[2], p.slength)
				strcat(str2, """")
			else
				strcpy(str2, """<string>""")
			end

		else
			print @str2, "<",,opndnames[p.opndtype],,">"
		end

		to 12-strlen(str2) do
			strcat(str2, " ")
		end
		strcat(s, str2)

		if ps.count>1 then
			strcat(s, "*")
			strcat(s, strint(ps.count))
			strcat(s, " ")
		else
			strcat(s, "   ")
		end


		strcat(s, strmode(ps.mode))
!		strcat(s, " ")
		strcat(s, "\n")
	end

	u64 rset

	for i in 1..2 do
		if i=1 then
			rset:=oldregset
			strcat(s, (noperands|";"|""))
			strcat(s, " "*w+" (")
		else
			rset:=regset
			strcat(s, ";"+" "*w+" (")
		end
		for r:=r0 to xr15 when i not in r10..xr3  do
			strcat(s, (rset.[r]|strreg(r)|"-"))
			if regvarset.[r] then
				strcat(s, "*")
			end
			if pclset.[r] then
				strcat(s, "p")
			end
			strcat(s, " ")

		end
		strcat(s,")\n")
	end
!!
!	STRCAT(S, ";"+" "*20 +" Freed:(")
!	for r in r0..r13 when mccodex.freedset.[r] do
!		strcat(s, strreg(r))
!		strcat(s, " ")
!	end
!	strcat(s,")")
!	strcat(s,mclnames[mccodex.opcode])
!	strcat(s,"\n")
!
!
!

!	strcat(s,") hwstack:")
!	strcat(s,strint(mstackdepth))
!	strcat(s," noperands:")
!	strcat(s,strint(noperands))
!	strcat(s," ncalldepth:")
!	strcat(s,strint(ncalldepth))
	return s
end

global proc showopndstack=
	mcomment(stropndstack(1))
end

!global func loadopndp(int n, mode)mclopnd =
!!turn given pcl opnd into a pointer. That is, load it into a reg if not
!!already there, and turn it into an IREG operand
!!This will only do simple pointers: one register, no index, and a zero offset
!!(Call can add an offset separately)
!	pclopnd p := &pstack[n]
!	mclopnd ax
!
!	case p.optype
!	when regptr_opnd then
!		gerror("makeptr?")
!	else
!		ax:=loadopndr(n, taddr)
!	end case
!
!!so, in a register
!	p.optype:=regptr_opnd
!!	p.reg2:=rnone
!!	p.offset:=0
!
!	mgenireg(p.reg, mode)
!end

global func loadopndpx(int scale=1, offset=0, mode)mclopnd =
!turn top two operands yy/zz, which are pointer/scaled index, into
!a single address mode represented by one new operands, zz'
!Also return that new address mode

!	pclopnd pa := &pstack[yy]
!	pclopnd pi := &pstack[zz]
!	mclopnd ax
!
!	case p.optype
!	when regptr_opnd then
!		gerror("makeptr?")
!	else
!		ax:=loadopndr(n, mode)
!	end case
!
!!so, in a register
!	p.optype:=regptr_opnd
!	p.reg2:=rnone
!	p.offset:=0
GERROR("LOADOPNDX NOT READY")
!
!	mgenimem(p.reg, pmode)
	nil
end

global proc storeopnd(pcl p, int n)=
!store opnd n (usually zz) to p which is always mem_opnd
	psymbol d
	mclopnd ax, bx
!
	d := p.def
!	if d.equivvar then
!		d:=d.equivvar.def
!	end

!CPL "STORE1"
	bx := loadopnd(n, p.mode)
!CPL "STORE2"
!
	if p.mode=tblock then
		ax:=genreg(gwri())
		genmc(m_lea, ax, genmem(d))
		ax:=genireg(ax.reg)

		bx:=genireg(bx.reg)
		copyblock(ax, bx, p.size)

	else
		bx:=changeopndsize(bx, p.size)
		if d.reg then
			ax:=mgenreg(d.reg, p.mode)
		else
			ax:=genmem(d, p.size)
		end
!IF AX.REG=BX.REG THEN Mcomm("STORE TO SAVE REG") FI
		if ax.reg<>bx.reg then
			genmc(m_mov, ax, bx)
		end
	end

!IF AX.REG=BX.REG THEN MERROR("STORE") FI

end

global proc freeworkregs=
!copy of code in convert pcl
	regset:=pclset

!	for i to noperands do
!		if pclstack[i].reg then
!			regset.[pclstack[i].reg]:=1
!		end
!	end
end

global func getopnd_ind(int n=noperands, mode=pmode, mem=0)mclopnd=
!Get access mode to operand which is to be used as a pointer elsewhere
!So it needs first to in a register, if not already
!mem=1 if allowed to return memory address mode, like [abc] or [dfp+abc]
	pcl p:=pclopnds[n]
	pcsrec ps:=pclstack[n]
	psymbol d

!CPL "GOI:"
!MEM:=0

!optimise for memaddr
	if mem and ps.code and p.opndtype=memaddr_opnd then
		d:=p.def
!CPL "GETOPIND/MEMADDR", D.NAME
		unless d.nameid=paramid and ttbasetype[d.mode]=tblock then
!MCLOPND AX

!			AX:=mgenmem(d, mode)
!!CPL "GOI2", MSTROPND(AX)
!			return AX
			return mgenmem(d, mode)
		end
	end

	unless ps.reg then
		loadopnd(n, tu64)			!ps may be out of date
	end

	return mgenireg(pclstack[n].reg, mode)
end

global func makeopndind(mclopnd a, int mode=pmode)mclopnd=
	mclopnd b

	if a.mode<>a_reg then
		merror("makeopndind")
	end

	return mgenireg(a.reg, mode)
end

global proc swapopndregs(int reg2)=
!top operand is in a register. Need to switch its reg with whatever is occupying
!reg2
!Note that swapondregs is best assumed to invalidate all existing mclopnds that
!refer to registers, as stuff if moved aound
!Also invalided are workregs that might use reg2, even if no mclopnd exists for it

	if not ispint(pclstack[zz].mode) then merror("SOR1") end

!assume int regs

	int reg1:=pclstack[zz].reg

	if reg1=reg2 then return end

	for i:=noperands-1 downto 1 do
		if pclstack[i].reg=reg2 then
			swap(pclstack[zz].reg, pclstack[i].reg)
			return
		end
	else
!pcl op not found that occupies reg2, so it is assumed to be a work register
!that is no longer needed. If it /is/ needed

		regset.[reg1]:=0				!make available (although done for next pcl op anyway)
		pclstack[zz].reg:=reg2
		pclset.[reg2]:=1
!		merror("swapopndregs/reg not found")
	end
end

global func getopnd_ind_simp(int n=noperands, mode=ti64)mclopnd ax=
!version of getopnd_ind which always returns [reg]
	ax:=loadopnd(n, mode)
	return mgenireg(ax.reg, mode)
end

global func getsharereg(int mode, mclopnd ax)int=
!if ax includes reg/regix, then try and use them
!return 0 if not reg available or not possibe
	byte reg:=ax.reg, regix:=ax.regix

	if ispfloat(mode) then return 0 end

!	if reg and (workset.[reg] or reg in r10..r13) then			!not a regvar
	if reg and not regvarset.[reg] then			!not a regvar
		return reg
	elsif regix and not regvarset.[regix] then
		return regix
	end

	return 0
end

global func getmemreg(mclopnd px)int reg=
!px is a memory addr mode like [d], [R], [R+d] etc. but the latter can also include Rframe
!return any main register used provided it is not Rframe. It does not use .regix
	if px.reg=rframe then
		rnone
	else
		px.reg				!will be rnone if not in use
	end
end

global func makesimpleaddr(mclopnd ax)mclopnd bx=
!assume ax is an ireg, but need a simple one with areg set but not ireg
	int newreg, reg, regix

	if ax.mode<>a_mem then merror("MSA") end

	reg:=ax.reg
	regix:=ax.regix
	if reg=rframe then reg:=rnone end

	if reg and regix=rnone and not regvarset.[reg] then		!already simple
		return ax
	end

!need a new register: try and reuse existing one
	if reg and not regvarset.[reg] then
		newreg:=reg
	elsif regix and not regvarset.[regix] then
		newreg:=regix
	else
		newreg:=gwri()
	end

	bx:=mgenireg(newreg)

	genmc(m_lea, genreg(newreg), ax)
	return bx
end
