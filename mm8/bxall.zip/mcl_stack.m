!PCL Operand Stack 

global func getopnd(int n, mode=pmode, reg=rnone)mclopnd ax =
!get access mode for operand n
	int oldreg, size
	mclopnd bx
	symbol d

	pcl p:=pclopnds[n]
	pcsrec ps:=pclstack[n]

	size:=stdsize[mode]

!CPL "GETOPND", PS.REG, PS.TEMP

	if ps.reg then
		oldreg:=ps.reg
		if reg and oldreg<>reg then
			ax:=genreg(reg, size)
			bx:=genreg(oldreg, size)
			PCLSET.[OLDREG]:=0
			PCLSET.[REG]:=1
			genmc(m_mov, ax, bx)
		else
			ax:=genreg(oldreg, size)
		fi

	elsif ps.temp then
		ax:=mgentemp(n, mode)

	elsecase p.optype

	when mem_opnd then
		d:=p.def
!CPL "GET:MEMOPND", D.NAME
		if mode=tblock and d.nameid<>paramid then
			mode:=tu64
			recase memaddr_opnd
		else
			ax:=genmem(p.def, size)
		fi

	when memaddr_opnd then
		d:=p.def
!CPL "GET:MEMADDROPND", D.NAME, STRMODE(D.MODE), =ISBLOCK(D.MODE), =STRMODE(P.MODE)
!		if d.nameid=paramid and d.mode=tblock then		!pcl mode will be u64
		if d.nameid=paramid and isblock(d.mode) then		!pcl mode will be u64
			ax:=genmem(d, size)
		else
!			ax:=genreg(getworkregc(mode, reg))

			ax:=gwrm(mode, reg)
			genmc(m_lea, ax, genmem(d, size))
		fi

	when int_opnd then

		case size
		when 2 then
			p.value iand:=0xFFFF
		when 4 then
			p.value iand:=0xFFFF'FFFF
		esac

		bx:=genint(p.value, size)
		if p.value in i32.bounds then			!keep as immediate
			ax:=bx
		else
			ax:=gwrm(mode, reg)
			genmc(m_mov, ax, bx)
		fi

	when real_opnd then
		ax:=genrealmem(p.xvalue, size)

	when string_opnd then
		ax:=gwrm(tu64, reg)
		genmc(m_lea, ax, genlabelmem(getstringindex(p.svalue)))

	when label_opnd then
!		ax:=genreg(getworkireg(reg))
		ax:=gwrm(tu64, reg)

		genmc(m_lea, ax, genlabelmem(p.labelno))
!		else
!			GERROR("LABELDEF NOT DEF")
!		fi
!
	else
error:
		merror("getopnd", opndnames[p.optype])
	fi

	if ax.mode=a_reg then		!ensure correctly set to reg
		pclstack[n].reg:=ax.reg
		pclstack[n].temp:=0
		pclstack[n].code:=0
		pclset.[ax.reg]:=1
	fi

	ax
end

global func loadopndr(int n, mode=pmode, reg=rnone)mclopnd ax =
!must return with value in register. But it can be in-situ if it is a regvar
!and no newreg is specified
	pcl p:=pclopnds[n]
	pcsrec ps
	symbol d

	int size:=stdsize[mode]
	mclopnd bx

	ax:=getopnd(n, mode, reg)

	ps:=pclstack[n]
	if ps.reg then
		return ax
	fi

!CPL "LOADOPNDR", STRREG(REG), =SIZE

	if reg=rnone then
		if stdfloat[mode] then
			bx:=genxreg(reg:=gwrx(), size)
		else
			bx:=genreg(reg:=gwri(), size)
		fi
	else
		bx:=genreg(reg, size)
	fi

	if ps.temp then
		genmc(m_mov, bx, ax)

	elsecase p.optype
	when mem_opnd, int_opnd, real_opnd  then
		genmc(m_mov, bx, ax)

	when memaddr_opnd then
		d:=p.def
		if d.nameid=paramid and isblock(d.mode) then		!pcl mode will be u64
			ax:=genmem(d, size)
			genmc(m_mov, bx, ax)
		else
!			ax:=genreg(getworkregc(mode, reg))
			bx:=gwrm(mode, reg)
			genmc(m_lea, bx, genmem(d, size))
		fi

	when string_opnd then
!		ax:=genreg(getworkireg())
!		genmc(m_lea, ax, genlabelmem(getstringindex(p.svalue)))
!
!	when label_opnd then
!		ax:=genreg(getworkireg())
!
!		genmc(m_lea, ax, genlabelmem(p.labelno))
!!		else
!!			GERROR("LABELDEF NOT DEF")
!!		fi
!
	else
error:
		merror("loadopndr", opndnames[p.optype])
	fi

	pclstack[n].reg:=reg
	pclstack[n].temp:=0
	pclstack[n].code:=0
	pclset.[reg]:=1

	bx
end

global func loadopndw(int n, mode=pmode)mclopnd ax =
!load opnd to reg where it will be written
!this only really affects regvars, and only when no dest is specified,
!as otherwise it will be copied there anyway
	mclopnd bx
	int oldreg, newreg

	ax:=loadopndr(n, mode)
	oldreg:=ax.reg

	if regvarset.[ax.reg] then			!need to copy elsewhere
!		newreg:=gwr(mode)
!		bx:=mgenreg(newreg, mode)
		bx:=gwrm(mode)
		genmc(m_mov, bx, ax)
		bx
	else
		ax
	fi
end

global func loadparam(int n, mode=pmode, reg)mclopnd ax =
	loadopndr(n, mode, reg)
end

!global func loadretval(int n, mode, reg)mclopnd ax =
!!Load operand to return register
!!reg will be r0 for most functions
!	ax:=getopnd(n, mode, reg)
!	ax:=loadtoreg_m(ax, mode, reg)
!	ax
!end

global proc pushopnd(int n, mode)=
!Push opnd n to hardware stack then pop it from pcl stack
!The hardware stack is popped on return from a call

	mclopnd ax, bx
	pcl p:=pclopnds[n]
	pcsrec ps:=pclstack[n]

	if mode=tvoid then mode:=p.mode fi

!First look for operands that can be directly pushed without using a register
	if ps.code then
		case p.optype
		when mem_opnd then
			if p.size=8 then
				ax:=genmem(p.def, p.size)
				pushit
			fi

		when int_opnd then
			if p.value in i32.bounds then		!fits in d32 offset
!				ax:=genint(p.value, 4)
!				ax:=genint(p.value IAND 0XFFFFFFFF, 4)
				ax:=genint(p.value, TI64)
				pushit
			fi

		when real_opnd then
			if p.size=8 then
				ax:=genrealmem(p.xvalue)
				pushit
			fi
		esac
	fi

!!need to go via register

	ax:=loadopndr(n, mode)

	if ax.reg>=xr0 then			!float register
		bx:=ax
!		ax:=genreg(getworkireg(), p.size)
		ax:=gwrm(pmode)
		genmc(m_mov, ax, bx)
	fi

pushit:
	genmc(m_push, changeopndsize(ax,8))
	poppcl()
	++mstackdepth

end

!global func loadtoreg(mclopnd ax, int mode, reg)mclopnd=
!!if ax is not a register operand, then load it to given register
!!mode is needed to give type of register (float etc) and size
!!It is assumed that if ax /is/ in a register, that it is the correct one, or doesn't matter
!	mclopnd bx
!
!	if ax.mode=a_reg then			!might already be in reg
!		if not reg or ax.reg=reg then
!			return ax
!		fi
!	fi
!
!	bx:=getworkreg_rm(reg, mode)
!
!	loadtoreg_common(bx, ax)
!
!	bx
!end
!
!global func loadtoreg_m(mclopnd ax, int mode, reg)mclopnd=
!!same as loadtoreg but if already in a register, will move it to required one if needed
!	mclopnd bx
!
!	if ax.mode=a_reg then			!already in register
!		if ax.reg=reg then return ax fi			!in correct one
!	fi
!
!!need loading/moving to given reg
!	bx:=genreg(reg, ttsize[mode])
!
!	loadtoreg_common(bx, ax)
!!	genmc(m_mov, bx, ax)
!	bx
!end

!proc loadtoreg_common(mclopnd bx, ax)=
!	if ax.mode=a_imm and ax.valtype=int_val and ax.value=0 then
!		bx:=changeopndsize(bx,4)
!		clearreg(bx)
!!		genmc(m_xorx, bx, bx)
!	
!	else
!		genmc(m_mov, bx, ax)
!	fi
!
!end


global proc pushpcl(pcl pc)=
!Push a inline operand from pcl code to pcs
!addrof is 1 to apply & to name units, creating a memaddr opnd
	int n
	pcl p
	pcsrec ps
!
	if noperands>=maxoperands then
		merror("PCL stack overflow")
	fi

	n:=++noperands

	pclopnds[n]:=pc

!	ps.all:=0

	ps.mode:=pc.mode
	ps.reg:=ps.temp:=0
	ps.code:=1
	ps.count:=1

	pclstack[n]:=ps
!CPL "PUSHPCL", PCLSTACK[N].REG
end

global proc pushpcl_reg(int mode, reg=rnone)=
!Push a new, empty pcs slot located in given register
	int n
	pcsrec ps

	if noperands>=maxoperands then
		merror("PCL stack overflow")
	fi

	if reg=rnone then reg:=gwr(mode) fi

	n:=++noperands

	ps.all:=0
	ps.reg:=reg
	ps.count:=1
	ps.mode:=mode
	pclstack[n]:=ps

	regset.[reg]:=1
	pclset.[reg]:=1

end

global proc poppcl=
	int n:=noperands

	if n<=0 then merror("poppcl/underflow") fi

	if pclstack[n].count>1 then
		--pclstack[n].count
		return
	fi

	pclset.[pclstack[n].reg]:=0		!will clear bit 0 if no reg used

	--noperands
end

global proc duplpcl=
!ensure zz is in a register, duplicate into a new register
	int mode:=pclstack[zz].mode

	loadopndr(zz, mode)							!get zz to reg
!	pushpcl_reg(getworkreg(mode), mode)				!create new zz opnd, old is now yy
	pushpcl_reg(mode)							!create new zz opnd, old is now yy

!MCOMM("DUPLOP")
	genmc(m_mov, getopnd(zz, mode), getopnd(yy, mode))	!copy old to new
end

global func gwri(int r=rnone)int =
	if r then return r fi

	to 10 do
		for r in r0..r13 do
			if workset.[r] and regset.[r]=0 then
				regset.[r]:=1
!CPL "USEDI", STRREG(R)
				usedset.[r]:=1
				return r
			fi
		od
		savenextopnd()
	od
	merror("No more work regs")
	0
end

global func gwrx(int r=rnone)int=
	if r then return r fi

	for r in xr4..xr15 do
		if workset.[r] and regset.[r]=0 then
			regset.[r]:=1
			usedset.[r]:=1
			return r
		fi
	od
	merror("No more work xregs")
	0
end

global func gwr(int mode=pmode, reg=rnone)int =
	if stdfloat[mode] then
		gwrx(reg)
	else
		gwri(reg)
	fi
end

global func gwrm(int mode=pmode, reg=rnone)mclopnd =

	if reg=rframe then reg:=rnone fi

	mgenreg(gwr(mode, reg), mode)

!	if stdfloat[mode] then
!		genxreg(gwrx(reg), stdsize[mode])
!	else
!		genreg(gwri(reg), stdsize[mode])
!	fi
end

global proc saveopnd(int n, allregs=1)=
!if operand is in a volatile register, then save it in a temp
!allregs=1 to save both A and B regs (vol/nonval), which can include P regs if
!used as workregs; this is to save pne reg=opnd to a temp to free up a register
!allregs=0 to limit to A regs (possibly some P regs) only; normall for CALLs
!in order to preserve non-vol regs, as call will preserve the rest

!NOTE: operands that are unlikely to be unchanged from their value in
!pclrec, could be revert to unit_loc. Eg. immediates, addresses, or any
!variable that is immutable

	int reg, size
	mclopnd tx
	pcsrec ps:=pclstack[n]

	reg:=ps.reg
	size:=stdsize[ps.mode]

	return unless reg

	if stdint[ps.mode] then
		if allregs or reg not in r3..r9 then
			genmc(m_mov, gentemp(n, size), genreg(reg, size))
		fi
	else
		if allregs or reg in xr0..xr5 then
			genmc(m_mov, gentemp(n, size), genxreg(reg, size))
		fi
	fi
	regset.[reg]:=0
	pclset.[reg]:=0

	ps.reg:=ps.code:=0
	ps.temp:=1
	pclstack[n]:=ps
end
!
global proc saveopnds(int n=0)=
!save all operands other than top n
!assume this is to do with calls
	for i:=1 to noperands-n do
		saveopnd(i,0)
	od
end

global proc savenextopnd=
!starting from the first loaded, look for and save first reg-based opnd
!this does A/B/P regs if used
	for i:=1 to noperands do
		if pclstack[i].reg and stdint[pclstack[i].mode] then
			saveopnd(i,1)
			return
		fi
	od
end

global proc movetoreg(int newreg)=
!move top of stack (assumed to be in reg) to newreg
!assumes integer reg
	int oldreg, size
	pcsrec ps

	loadopndr(zz, pclstack[zz].mode)

retry:

	ps:=pclstack[zz]
	oldreg:=ps.reg
	size:=stdsize[ps.mode]

	if oldreg=newreg then
		return
	fi

	if stdfloat[ps.mode] then
		if regset.[newreg] then
			MERROR("MOVE TO REG: XREG IN USE")
		fi
	elsif regset.[newreg] then
		for i to noperands do
			if stdint[ps.mode] and pclstack[i].reg=newreg then
				swapopnds(i,zz)
				genmc(m_xchg, genreg(oldreg), genreg(newreg))
				retry
			fi
		od
	fi

	genmc(m_mov, genreg(newreg, size), genreg(oldreg, size))

	pclstack[zz].reg:=newreg

!CPL "MOVETOREG"

	regset.[oldreg]:=0
	regset.[newreg]:=1
end

global proc swapopnds(int m,n)=
!exchange pcl stack operands
	pclrec t

	swap(pclopnds[m], pclopnds[n])
	swap(pclstack[m], pclstack[n])
end

global proc setnewzz(int mode, reg)=
!some value has been into into given register
!create replace pcl[zz] with that new operand
!assume pclcount was 1 and stays at 1
	pcsrec ps

	ps:=pclstack[zz]

	pclset.[ps.reg]:=0

	ps.reg:=reg
	ps.temp:=ps.code:=0
	ps.mode:=mode
	pclset.[reg]:=1

	pclstack[zz]:=ps
end

global func stropndstack(int indent=0)ichar=
	static [512]char str
	[512]char str2
	ichar s:=str, t
	pcl p
	pcsrec ps

	if indent then
		fprint @s, "="*20 + "#:(", NOPERANDS
	else
		fprint @s, "#:(", NOPERANDS
	fi

STRCAT(S, "@")

	for i to noperands do
		p:=pclopnds[i]
		ps:=pclstack[i]

!STRCAT(S, "C:")
!STRCAT(S, STRINT(PS.COUNT))
!STRCAT(S, " ")

		strcat(s, (noperands-i+1|"Z:", "Y:", "X:", "W:"|""))

		if ps.reg then
			strcat(s, regnames[ps.reg])
!			if p.def then strcat(s, "*") fi
!			if p and p.opndtype=mem_opnd then
!				strcat(s, "(")
!				strcat(s, p.def.name)
!!				strcat(s, strint(int(p)))
!				strcat(s, ")")
!			fi

		elsif ps.temp then
			strcat(s, "T")
			strcat(s, strint(i))

		elsecase p.opndtype
		when int_opnd then
			strcat(s, strint(p.value))

		when mem_opnd then
			strcat(s, p.def.name)
!
		else
			strcat(s, "(")
!int fs:=fshortnames
!fshortnames:=1
!			strcat(s, mstropnd(pclopnd[i]))
!fshortnames:=fs
			strcat(s, ")")
		fi

		if ps.count>1 then strcat(s, "@") fi
		strcat(s, "<")
		strcat(s, stdnames[ps.mode])
		strcat(s, ">")

		if i<noperands then strcat(s,", ") fi
	od
	strcat(s,") ")

	ipadstr(str, 50)

STRCAT(STR, STRINT(PCLSET,"H"))
STRCAT(STR, " ")


	strcat(s,"WR:(")
!	for r:=r0 to r9 when workregs[r] do
	for r:=r0 to r9  do
		strcat(s,(regset.[r]|"1 "|"0 "))
	od
	strcat(s,") ")

	strcat(s,"XWR:(")
	for r:=xr4 to xr15 do
		strcat(s,(regset.[r]|"1 "|"0 "))
	od

	strcat(s,") hwstack:")
	strcat(s,strint(mstackdepth))
	strcat(s," noperands:")
	strcat(s,strint(noperands))
!	strcat(s," ncalldepth:")
!	strcat(s,strint(ncalldepth))
	return s
end

global proc showopndstack=
	mcomment(stropndstack(1))
end

!global func loadopndp(int n, mode)mclopnd =
!!turn given pcl opnd into a pointer. That is, load it into a reg if not
!!already there, and turn it into an IREG operand
!!This will only do simple pointers: one register, no index, and a zero offset
!!(Call can add an offset separately)
!	pclopnd p := &pstack[n]
!	mclopnd ax
!
!	case p.optype
!	when regptr_opnd then
!		gerror("makeptr?")
!	else
!		ax:=loadopndr(n, taddr)
!	esac
!
!!so, in a register
!	p.optype:=regptr_opnd
!!	p.reg2:=rnone
!!	p.offset:=0
!
!	mgenireg(p.reg, mode)
!end

global func loadopndpx(int scale=1, offset=0, mode)mclopnd =
!turn top two operands yy/zz, which are pointer/scaled index, into
!a single address mode represented by one new operands, zz'
!Also return that new address mode

!	pclopnd pa := &pstack[yy]
!	pclopnd pi := &pstack[zz]
!	mclopnd ax
!
!	case p.optype
!	when regptr_opnd then
!		gerror("makeptr?")
!	else
!		ax:=loadopndr(n, mode)
!	esac
!
!!so, in a register
!	p.optype:=regptr_opnd
!	p.reg2:=rnone
!	p.offset:=0
GERROR("LOADOPNDX NOT READY")
!
!	mgenimem(p.reg, pmode)
	nil
end

global proc storeopnd(pcl p, int n)=
!store opnd n (usually zz) to p which is always mem_opnd
	symbol d		:= p.def
	mclopnd ax, bx	:= loadopndr(n, p.mode)

	if p.mode=tblock then
		ax:=genreg(gwri())
		genmc(m_lea, ax, genmem(d))
		ax:=genireg(ax.reg)

		bx:=genireg(bx.reg)
		copyblock(ax, bx, p.size)

	else
		bx:=changeopndsize(bx, p.size)
		if d.reg then
			ax:=mgenreg(d.reg, p.mode)
		else
			ax:=genmem(d, p.size)
		fi
		genmc(m_mov, ax, bx)
	fi

end

global proc freeworkregs=
!copy of code in convert pcl
	regset:=pclset

!	for i to noperands do
!		if pclstack[i].reg then
!			regset.[pclstack[i].reg]:=1
!		fi
!	od
end

global func getopnd_ind(int n=noperands, mode=pmode, mem=0)mclopnd=
!Get access mode to operand which is to be used as a pointer elsewhere
!So it needs first to in a register, if not already
!mem=1 if allowed to return memory address mode, like [abc] or [dfp+abc]
	pcl p:=pclopnds[n]
	pcsrec ps:=pclstack[n]
	symbol d

!MEM:=0

!optimise for memaddr
	if mem and ps.code and p.opndtype=memaddr_opnd then
!CPL "GETOPIND/MEMADDR"
		d:=p.def
		unless d.nameid=paramid and ttbasetype[d.mode]=tblock then
			return mgenmem(d, mode)
		end
	fi

	unless ps.reg then
		loadopndr(n, tu64)			!ps may be out of date
	end

	return mgenireg(pclstack[n].reg, mode)
end

global func makeopndind(mclopnd a, int mode=pmode)mclopnd=
	mclopnd b

	if a.mode<>a_reg then
		merror("makeopndind")
	fi

	return mgenireg(a.reg, mode)
end

global proc swapopndregs(int reg2)=
!top operand is in a register. Need to switch its reg with whatever is occupying
!reg2
!Note that swapondregs is best assumed to invalidate all existing mclopnds that
!refer to registers, as stuff if moved aound
!Also invalided are workregs that might use reg2, even if no mclopnd exists for it

	if not ispint(pclstack[zz].mode) then merror("SOR1") fi

!assume int regs

	int reg1:=pclstack[zz].reg

	if reg1=reg2 then return fi

	for i:=noperands-1 downto 1 do
		if pclstack[i].reg=reg2 then
			swap(pclstack[zz].reg, pclstack[i].reg)
			return
		fi
	else
!pcl op not found that occupies reg2, so it is assumed to be a work register
!that is no longer needed. If it /is/ needed

		regset.[reg1]:=0				!make available (although done for next pcl op anyway)
		pclstack[zz].reg:=reg2
		pclset.[reg2]:=1
!		merror("swapopndregs/reg not found")
	od
end

global func getopnd_ind_simp(int n=noperands, mode=ti64)mclopnd=
!version of getopnd_ind which always returns [reg]

	if not pclstack[n].reg then
		loadopndr(n, tu64)
	fi

	return mgenireg(pclstack[n].reg, mode)
end

global func getsharereg(int mode, mclopnd ax)int=
!if ax includes reg/regix, then try and use them
!return 0 if not reg available or not possibe
	byte reg:=ax.reg, regix:=ax.regix

	if ispfloat(mode) then return 0 fi

	if reg and (workset.[reg] or reg in r10..r13) then			!not a regvar
		return reg
	elsif regix and (workset.[regix] or reg in r10..r13) then
		return regix
	fi

	return 0
end

global func isblock(int mode)int=
!	stdpcl[ttbasetype[mode]]=tblock
	getpclmode(mode)=tblock
end
