proc main=
	int n

	n:=$getnprocs

	for i to n do
		println i, $getprocname(i), $getprocaddr(i)
	od


end


proc bill*=
	println "BILL"
end

proc fred*=
	println "FRED"
end
