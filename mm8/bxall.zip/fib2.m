importdll msvcrt=
	proc puts(ichar)
	proc printf(ichar,...)
end

func fib(int n)int=
	if n<3 then
		1
	else 
		fib(n-1)+fib(n-2)
	fi
end

proc main=
	for i to 42 do
		printf("%lld %lld\n", i,fib(i))
	od
end

