const n = 1'500'000
!const n = 150'000

proc t(real x)=
	[0..100]real pol
	real mu,pu,su
	int i,j

	mu := 10.0
	pu := 0.0

	to n do
		for j:=1 to 100 do
			pol[j] := mu := (mu + 2.0)*0.5
			mu := (mu + 2.0)*0.5
			pol[j] := mu
		end
		su := 0.0
		for j:=1 to 100 do
			su := x * su + pol[j]
		end
		pu := pu+su
	end
	println (pu)
END

proc main=
	t(0.2)
end
