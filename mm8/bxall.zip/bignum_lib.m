importdll bignum =
    type bignum = ref bignumrec
    record bignumrec = 
        ref [0:]i32 num
        i64 length
        i64 expon
        i32 neg
        i32 numtype
    end

    var [0..3]ichar fpnames

    const i64 zero_type = 0
    const i64 normal_type = 1
    const i64 inf_type = 2
    const i64 nan_type = 3

    func bn_init() => bignum
    proc bn_print(bignum a,i64 format=0)
    proc bn_println(bignum a,i64 format=0)
    func bn_alloc(i64 size) => ref void
    proc bn_free(bignum a)
    proc bn_setzero(bignum a)
    proc bn_move(bignum a,b)
    proc bn_dupl(bignum a,b)
    proc bn_setinf(bignum dest)
    proc bn_setnan(bignum dest)
    func bn_iszero(bignum a) => i64
    proc bn_negto(bignum a)
    proc bn_absto(bignum a)
    func bn_isint(bignum a) => i64
    func bn_getprec(bignum a) => i64
    proc bn_setprec(bignum a,i64 prec)
    func bn_getglobalprec() => i64
    proc bn_setglobalprec(i64 prec)
    func bn_makeint(i64 x) => bignum
    func bn_makefloat(r64 x) => bignum
    proc bn_ipower(bignum d,a,i64 n)
    func bn_equal(bignum a,b) => i64
    proc bn_addu(bignum dest,a,b)
    proc bn_idivu(bignum dest,a,b,rm=nil)
    func bn_makestr(ichar s,i64 length=0) => bignum
    func bn_tostring(bignum a,i64 fmt=0) => ichar
    func bn_add(bignum dest,a,b) => i64
    func bn_sub(bignum dest,a,b) => i64
    func bn_mul(bignum dest,a,b) => i64
    func bn_mulp(bignum dest,a,b,i64 prec) => i64
    func bn_div(bignum dest,a,b,i64 prec=0) => i64
    func bn_idiv(bignum dest,a,b) => i64
    func bn_idivrem(bignum dest,rm,a,b) => i64
    func bn_irem(bignum dest,a,b) => i64
    func bn_cmp(bignum a,b) => i64
    func bn_const(i64 value) => bignum
    func bn_sign(bignum a) => i64
    func bn_digits(bignum a) => i64
    func bn_toint(bignum a) => i64
    func bn_tofloat(bignum a) => r64
    proc bn_fix(bignum c,a)
end

