include "bb_types.m"

export type symbol    	= ref void

export type object   	= ref varrec
export type iobject   	= ref object

!export macro pr(a,b)	= (a<<16 ior b)

export const varsize  	 	 = varrec.bytes
export const shortvarsize    = shortvarrec.bytes

export record varrec =
!1st 8 bytes
	union
		struct
			word32 refcount
			union
				struct
					byte tag
					byte flags: (mutable:1)
					union
						word16 usertag
						word16 elemtag
					end
				end
				word32 tagx
			end
		end
		word64 a
	end

!second 8 bytes (and end of short objects)
	union
		int64		value
		real64		xvalue
		word64		uvalue
		ichar		strptr
		object		varptr
		ref byte	ptr
		ref[]int	num
		word64 b
	end

!3rd 8 bytes
	union
		struct
			word32 length
			union
				int32 lower32
				struct
					int16 lower16
					byte bitoffset
					byte intindex
				end
				struct
					int16 neg
					int16 numtype
				end
			end
		end
		int length64
		int lower64
		word64 c
	end

!4th 8 bytes (and end of long objects)
	union
		int64 alloc64
		object varptr2
		int64 upper64
		int32 expon
		struct
			word32 alloc32
			int32 dictitems
		end
		word64 d
	end
end

!export record flatvarrec =
!	u64 a, b, c, d
!
!	word32	refcount	@ a
!	byte	tag			@ a+4
!	byte	flags		@ a+5
!
!	byte	usertag		@ a+6
!	byte	elemtag		@ a+6
!	word32	tagx		@ tag
!	...
!end

export record shortvarrec =			!represents first half of varrec
	[16]byte dummy
end

!export record genfieldrec=
!	symbol def
!	ref genfieldrec nextdef
!end
!
!export const maxgenfield=1000
!export [maxgenfield]ref genfieldrec genfieldtable
!export int ngenfields

export [0..255]object chrtable				!remember single-character objects

export [-256..+256]object smallinttable		!for general int values at runtime
!export [0..+256]object inttable

export const maxintconst=1000
export [maxintconst]object intconsttable	!int constants in sourc code
export int nintconsts

varrec voidobj

global macro var_share(p) = (++p^.refcount; p)

export function m$void_new:object=
	&voidobj
end

proc start=
	object p

	voidobj.tag:=tvoid
	voidobj.refcount:=0x8000'0000

	for i in smallinttable.bounds do
		p:=shortobj_new(vint)
		p.value:=i
		smallinttable[i]:=p
	od

end

global function shortobj_new(int tag)object p=
	p:=pcm_alloc16()
	p.refcount:=1
	p.tagx:=tag
	p.value:=0

	return p
end

global function obj_new(int tag)object p=
!create new object descriptor, which all fields set to zero
!except refcount=1
!.objtype=0 => normal_obj

!CPL "OBJ.NEW",TTNAME[TAG]
	p:=pcm_alloc32()
	p.refcount:=1
	p.tagx:=tag
	p.value:=0
	p.c:=0
	p.d:=0
	return p
end

export proc m$var_unshare(object p)=
	if --(p.refcount)=0 then
		m$var_free(p)
	fi
end

!function var_share(object p)object=
!	++(p.refcount)
!	p
!end

export proc m$var_popmem(iobject p, object x)=
	m$var_unshare(p^)
	p^:=x
end

proc m$var_free(object p)=
	switch p.tag
	when vint,vreal, vrange then
!		cast(p,ref word)^:=word(int(freelist[1]))
!		freelist[1]:=cast(p)
		pcm_free16(p)

!	when tlist,trecord then
!		list_free(p)
!
!	when tarray then
!		array_free(p)
!
	when vstring then
		if p.length64 then
			pcm_free(p.strptr, p.alloc64)
		fi
		pcm_free32(p)
!!
!	when tref then
!		obj_unshare(p.uref.iobjptr^)
!
!	when trefpack then
!		if p.urefpack.objptr2 then
!			obj_unshare(p.urefpack.objptr2)
!		fi
!
	when tvoid then				!voids aren't freed
!
	else
		CPL "Can't Free",stdnames[p.tag]

	end switch
end

function m$int_make(int a)object p=
	if a<=smallinttable.upb and a>=smallinttable.lwb then
		return var_share(smallinttable[a])
	fi

!	if p:=object(freelist[1]) then		!Items of this block size available
!		freelist[1]:=ref word(int((freelist[1])^))
!	else
		p:=pcm_alloc16()
!	fi
	p.refcount:=1
	p.tagx:=vint
	p.value:=a

	return p
end

proc m$var_print(object p,ichar fmt)=
!	pcerror("VARPRINT NOT DONE")

	case p.tag
	when vint then
		m$print_i64_nf(p.value)
	when vstring then
		if p.length64 then
			m$print_strn(p.strptr,p.length64, fmt)
M$PRINT_I64_NF(P.REFCOUNT)
		fi
	when tvoid then
		m$print_str_nf("<void>")
	else
		m$print_str_nf("<printf?>")
	esac

	m$var_unshare(p)

end

global proc pcerror(ichar mess)=
	println "Var runtime error:",mess
	stop 1
end

function m$var_to_int(object p)int a=

	case p.tag
	when vint then a:=p.value
	else
		pcerror("vartoint?")
	esac

	m$var_unshare(p)
	return a
end

global function m$var_add(object x,y)object z=
!caller must ensure that x and y have compatible types
!sharing is not handled here

	if x.tag<>y.tag then
PCERROR("MIXED ADD")
!		return domixed_arith(x,y,cast(obj_add))
	fi

	switch x.tag
	when vint then
		z:=m$int_make(x.value+y.value)
!	when treal then
!		return real_make(x.xvalue+y.xvalue)

	when vstring then
		z:=string_add(x,y)

	else
PCERROR("ADD/T")
!		pcustype("ADD",x)
	end switch

	m$var_unshare(x)
	m$var_unshare(y)

	return z
end

global function m$string_make(ichar s)object=
!create a ivariant string from given string
!string will be copied to heap
	var ref char t
	int length:=strlen(s)

	if length=0 then
		return str_makex(t,0,0)
	else
		t:=pcm_alloc(length)
		memcpy(t,s,length)
		return str_makex(t,length,allocbytes)
	fi
end

global function str_makex(ichar s, int length,allocated)object=
!create a variant string from given string
!string is already on the heap
	var ref char t
	var object p

!	if length=-1 then
!		length:=strlen(s)
!	fi

	p:=obj_new(vstring)

	if length=0 then
		p.strptr:=nil
	else
		p.strptr:=s
		p.length64:=length
		p.alloc64:=allocated
	fi
	p.mutable:=1

	return p
end

function string_maken(int length)object=
!create an empty, uninitialised string of given length
	var object p

	p:=obj_new(vstring)

	if length then
		p.strptr:=pcm_alloc(length)
	fi
	p.mutable:=1
	p.length64:=length
	p.alloc64:=allocbytes
	return p
end

global function string_add(object a,b)object c=
	var int alen,blen

	alen:=a.length
	blen:=b.length

	if alen=0 then
		if blen then
			c:=var_share(b)
		else
			c:=m$string_make("")
		fi

	elsif blen=0 then		!x+"" use x unchanged
		c:=var_share(a)
	else 				!x+y: need to do some actual work!
		c:=string_maken(alen+blen)
		memcpy(c.strptr,a.strptr,alen)
		memcpy(c.strptr+alen,b.strptr,blen)
	fi
!CPL "ADDED STR",TTNAME[C.

	return c
end

