
func fact(int n)int =
	if n<=1 then
		1
	else
		n*fact(n-1)
	fi
end

proc main=
	println fact(12)
end
