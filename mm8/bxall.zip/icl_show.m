export proc pxshow=
	CPL "PX SHOW"
end
