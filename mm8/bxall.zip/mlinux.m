!import clib
!import mlib
!
!importlib cstd=
!	clang proc     sleep	(word32)
!end

record termios =
	i32 c_iflag
	i32 c_oflag
	i32 c_cflag
	i32 c_lflag
	char c_line
	[32]char c_cc				!at offset 17
	[3]byte filler
	i32 c_ispeed				!at offset 52
	i32 c_ospeed
end

!importdll dlstuff=
importdll msvcrt=
	func dlopen			(ichar, i32)ref void
	func dlsym			(ref void, ichar)ref void
	func tcgetattr		(i32, ref termios) i32
	func tcsetattr		(i32, i32, ref termios) i32
	func gettimeofday	(ref timeval, ref void) i32
	func gmtime_r  	   (ref i64, ref tm_rec) ref void
	proc stdin
	proc stdout
end
 
record timeval =
	i64 tv_sec
	i64 tv_usec
end

record tm_rec =
	i32 tm_sec
	i32 tm_min
	i32 tm_hour
	i32 tm_mday

	i32 tm_mon
	i32 tm_year
	i32 tm_wday
	i32 tm_yday
	i32 tm_isdst
	[20]byte padding
end

!this record is used by some apps, so these fields must be present
export record rsystemtime =
	i32 year
	i32 month
	i32 dayofweek
	i32 day
	i32 hour
	i32 minute
	i32 second
	int milliseconds
end

int init_flag=0


export proc os_init=
	init_flag:=1
end

export func os_execwait(ichar cmdline,int newconsole=0,ichar workdir=nil)int =
	return system(cmdline)
end

export func os_execcmd(ichar cmdline, int newconsole)int =
	return system(cmdline)
end

export func os_getch:int=
	const ICANON  = 2
	const ECHO    = 8
	const TCSANOW = 0
	const ISIG    = 1

	termios old,new
	char ch

	tcgetattr(0,&old)
	new:=old
	new.c_lflag iand:=inot ICANON
	new.c_lflag iand:=inot ECHO
	new.c_lflag iand:=inot ISIG

	tcsetattr(0,TCSANOW,&new)

	ch:=getchar()

	tcsetattr(0,TCSANOW,&old)

	return ch
end

export func os_kbhit:int=
	abortprogram("kbhit")
	return 0
end

export proc os_flushkeys=
	abortprogram("flushkeys")
end

export func os_getconsolein:ref void=
	return nil
end

export func os_getconsoleout:ref void=
	return nil
end

export func os_proginstance:ref void=
	abortprogram("PROGINST")
	return nil
end

export func os_getdllinst(ichar name)u64=
	const RTLD_LAZY=1
	ref void h

	h:=dlopen(name,RTLD_LAZY)

	if h=nil then
		if strcmp(name,"msvcrt")=0 then			!might be linux
			h:=dlopen("libc.so.6",RTLD_LAZY);
		fi
	fi

	return cast(h)
end

export func os_getdllprocaddr(int hlib,ichar name)ref void=
	ref void fnaddr

	if hlib=0 then
		return nil
	fi

	fnaddr:=dlsym(cast(int(hlib)), name)
	return fnaddr
end

export proc os_initwindows=
end

export func os_getchx:int=
	abortprogram("getchx")
	return 0
end

export func os_getos=>ichar=
!	if $targetbits=32 then
!		return "L32"
!	else
		return "L64"
!	fi
end

export func os_gethostsize=>int=
	return 64
end

export func os_iswindows:int=
	return 0
end

export func os_shellexec(ichar opc, file)int=
	abortprogram("SHELL EXEC")
	return 0
end

export proc  os_sleep(int a)=
!*!	sleep(a)
end

export func os_getstdin:filehandle =
	ref filehandle pf:=cast(stdin)
	return pf^
end

export func os_getstdout:filehandle =
	ref filehandle pf:=cast(stdout)
	return pf^
end

export func os_gethostname:ichar=
!	abortprogram("gethostname")
	return ""
end

export func os_getmpath:ichar=
!	abortprogram("getmpath")
	return ""
end

export proc os_exitprocess(int x)=
	stop
!	_exit(0)
!	ExitProcess(x)
end

export func os_clock:i64=
	if os_iswindows() then
		return clock()
	else
		return clock()/1000
	fi
end

export func os_ticks:i64=
	return clock()
end

export func os_getclockspersec:i64=
	return (os_iswindows()|1000|1000'000)
end

export proc os_setmesshandler(ref void addr)=
	abortprogram("SETMESSHANDLER")
!	wndproc_callbackfn:=addr
end

export func os_hpcounter:i64=
	return 1
end

export func os_hpfrequency:i64=
	return 1
end

export func os_filelastwritetime(ichar filename)i64=
	return 0
end

export proc os_getsystime(ref rsystemtime tm)=
	timeval tv
	tm_rec tmr


	gettimeofday(&tv, nil)
	gmtime_r(&tv.tv_sec, &tmr)

	tm.year := tmr.tm_year + 1900
	tm.month := tmr.tm_mon + 1
	tm.dayofweek := tmr.tm_wday + 1
	tm.day := tmr.tm_mday
	tm.hour := tmr.tm_hour
	tm.minute := tmr.tm_min
	tm.second := tmr.tm_sec
	tm.milliseconds := tv.tv_usec/1000
tm.month:=1			!avoid crashing the M compiler
end

export proc os_peek=
end

export func  os_allocexecmem(int n)ref byte=
	abortprogram("No allocexec")
	nil
end

export func dirlist(ichar filespec, ref[]ichar dest, int capacity, t=1)int=
	0
end
