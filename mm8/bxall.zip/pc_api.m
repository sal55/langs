!EXPORT INT PCLSEQNO
int STSEQNO

export pcl pcstart			!start of pcl block
export pcl pccurr			!point to current pcl op
export pcl pcend			!point to last allocated pclrec

!byte pcfixed				!whether code is fixed up
global int pclength

int initpcalloc=65536

global proc pc_gen(int opcode, mclopnd a=nil) =
	newpcl(opcode)
	pccurr.a:=a
end

global proc pc_genx(int opcode, int x, mclopnd a=nil) =
	newpcl(opcode)
	pccurr.x:=x
	pccurr.a:=a
end

global func newpcl(int opcode)pcl p =

	p:=pcm_allocnfz(pclrec.bytes)

	pccurr.next:=p
	pccurr:=p

	pccurr.opcode:=opcode
!	tccurr.pos:=mmpos
!	pccurr.seqno:=++pcseqno
	++pclength

	return pccurr
end

export proc pcl_start =
!reset tcstart/tccurr for new TCL sequence (new proc or new init data)
	pcstart:=pcm_allocnfz(pclrec.bytes)
	pcstart.opcode:=knop
	pccurr:=pcstart
!	pcseqno:=0
	pclength:=0
end

export func pcl_end:pcl pc=
!Terminate sequence; sets pcstart to nil so that pcl cannot be generated
!outside proc bodies etc
!But caller should copy tcstart value, or use its value returned here

	pc:=pcstart
	if pc.opcode=knop then
		pc.next
	else
		pc
	fi
end

export proc pc_setmode(int m)=
	pccurr.mode:=getpclmode(m)
	pccurr.size:=ttsize[m]

	if pclhastype[pccurr.opcode]=2 then
		pccurr.mode2:=pccurr.mode
	fi
end

export proc pc_setmode_u(unit p)=
	pc_setmode(p.mode)
end

export proc pc_setmode2(int m)=
	pccurr.mode2:=getpclmode(m)
end

export proc pc_comment(ichar s)=
!*!	return when fregoptim or fpeephole		!will get skipped anyway
!	RETURN WHEN DOREDUCE			!comments suppressed as they get in the way
!STATIC INT CCC
!CPL "COMMENT",++CCC
	pc_gen(kcomment, mgenstring(s))
end

export proc pc_setnargs(int n)=
	pccurr.nargs:=n
end

export proc pc_genix(int opcode, scale=1, offset=0) =
!originally intended for combinations of ptr ops to be combined into
!previous ones, but that has now been dropped.
!Instead any such reductions will be done in a separate pass, much simpler
	pcl p:=newpcl(opcode)
	p.scale:=scale
	p.extra:=offset
end

export proc pc_gencond(int opcode, cond, mclopnd a=nil) =
	pcl p:=newpcl(opcode)
	p.condcode:=cond
	p.a:=a
end

export proc pc_genxy(int opcode, int x, y, mclopnd a=nil) =
	pcl p:=newpcl(opcode)
	p.x:=x
	p.y:=y
	p.a:=a
end

export proc pc_setscaleoff(int scale, offset:=0)=
	pccurr.scale:=scale
	pccurr.extra:=offset
end
