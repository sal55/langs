!import clib
!export type filehandle=ref void

!importdll $cstd=
importdll msvcrt=
	func malloc	(u64)ref void
	proc free		(ref void)
!	func pow		(real,real)real
!
	func printf (ref char,...)i32
!	func fprintf (ref void,ref char,...)i32
	func puts (ref char)i32
	proc `exit(i32)
	func getchar	:i32
	proc memcpy		(ref void, ref void, word)
	proc memset		(ref void, i32, u64)
	func strlen		(ichar)u64
	func strcpy		(ichar,ichar)ichar
	func strcat		(ichar,ichar)ichar
	func strcmp		(ichar,ichar)i32

	func _strdup	(ichar)ichar
end

export macro strdup=_strdup

!export proc free(ref void) = end


int needgap

!proc start=
!	CPL "MIN/START"
!end


global proc m$print_startcon=
end

global proc m$print_end=
	needgap:=0
end

global proc m$print_ptr(u64 a,ichar fmtstyle=nil)=
!	nextfmtchars()
	printf("%p",a)
	needgap:=1
end

global proc m$print_ptr_nf(u64 a)=
	nextfmtchars()
	printf("%p",a)
	needgap:=1
end

global proc m$print_i64(i64 a,ichar fmtstyle=nil)=
	nextfmtchars()
	printf("%lld",a)
	needgap:=1
end

!global proc m$print_i128(i64 a,ichar fmtstyle=nil)=
!	puts("<128>")
!!	nextfmtchars()
!!	printf("%lld",a)
!!	needgap:=1
!end

global proc m$print_i64_nf(i64 a)=
!puts("PRINTI64_nf")
	nextfmtchars()
	printf("%lld",a)
	needgap:=1
end

global proc m$print_u64(u64 a,ichar fmtstyle=nil)=
	nextfmtchars()
	printf("%llu",a)
	needgap:=1
end

global proc m$print_r64(real x,ichar fmtstyle=nil)=
	nextfmtchars()
	printf("%f",x)
	needgap:=1
end

!global proc m$print_r32(real x,ichar fmtstyle=nil)=
global proc m$print_r32(r32 x,ichar fmtstyle=nil)=
	nextfmtchars()
	printf("%f",x)
	needgap:=1
end

!global proc m$print_c8(i64 a,ichar fmtstyle=nil)=
!	nextfmtchars()
!	printf("%c",a)
!	needgap:=1
!end

global proc m$print_str(ichar s, fmtstyle=nil)=
	nextfmtchars()
	printf("%s",s)
	needgap:=1
end

global proc m$print_str_nf(ichar s)=
	nextfmtchars()
	printf("%s",s)
	needgap:=1
end

global proc m$print_space=
	needgap:=0
	printf(" ")
end

global proc m$print_newline=
	needgap:=0
	printf("\n")
end

global proc m$unimpl=
	puts("Sysfn unimpl")
	stop 1
end

global proc m$print_nogap=
	needgap:=0
end

!global proc nextfmtchars(int lastx=0)=
global proc nextfmtchars=
	if needgap then
		printf(" ")
		needgap:=0
	fi
end

!global proc m$stop(int stopcode)=
!	`exit(stopcode)
!end
!
!global func strint(i64 a, ichar fmtstyle=nil)ichar=
!	return "?"
!end
!

!global function m$power_i64(i64 a,n)i64=
!	if n<0 then
!		return 0
!	elsif n=0 then
!		return 1
!	elsif n=1 then
!		return a
!	elsif (n iand 1)=0 then
!		return m$power_i64(sqr a,n/2)
!	else			!assume odd
!		return m$power_i64(sqr a,(n-1)/2)*a
!	fi
!end


