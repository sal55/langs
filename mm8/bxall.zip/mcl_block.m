!global const fshowinlinepcl=1
global const fshowinlinepcl=0

!global const fshowopndstack=1
global const fshowopndstack=0

!global const docalltrace=1
!global const docalltrace=0

GLOBAL INT DEBUG

!global int frameoffset, paramoffset
global int framebytes

[6]byte scondcodes=(eq_cond, ne_cond, lt_cond, le_cond, ge_cond, gt_cond)
[6]byte ucondcodes=(eq_cond, ne_cond, ltu_cond, leu_cond, geu_cond, gtu_cond)

global [pclnames.bounds]^proc(pcl) px_handlertable

!global macro ispint(m) = stdint[m]
!global macro ispfloat(m) = stdfloat[m]
!global macro ispwide(m) = stdwide[m]
!
global proc convertpcl(pcl p)=
	mcl lastmcl
!	pcl q

!	PRINTLN "    CONV",PCLNAMES[P.OPCODE], CURRFUNC.NAME

!	CPL STROPNDSTACK()

!FOR I TO NOPERANDS DO
!	IF PCLSTACK[I].COUNT=0 THEN
!CPL "COUNT=0:", I
!STOP
!	FI
!OD
!

	doshowpcl(p) when fshowinlinepcl

!CPL STROPNDSTACK()

	pmode:=p.mode
!*!	mmpos:=p.pos
!*!	ppseqno:=p.seqno
	lastmcl:=mccodex

	px_handlertable[p.opcode]^(p)

	oldregset:=regset

	if mccodex<>lastmcl then				!don't update is no mcl generated
		mccodex.freedset := regset ixor pclset
!CPL "SETFREED", MCCODEX, MCCODEX.FREEDSET
		lastmcl:=mccodex
	end


	regset:=pclset
	showopndstack() when fshowopndstack and currpcl.opcode not in [klabel, kcomment]

!clear all work regs including ones holding active temps
!CPL "DONE"
end

proc px_nop*(pcl p) =
!nop is sometimes used to replace deleted instructions like useless jumps

!	unimpl(p)
end

proc px_load*(pcl p) =
	pushpcl(p)
end

proc px_store*(pcl p) =

	storeopnd(p, zz)
	poppcl()
end

proc px_iload*(pcl p) =
! Z' := Z^
	mclopnd ax, px
	pcl nextpcl
	int reg
!CPL "ILOAD ----------------------", STRMODE(PMODE)


	if pmode<>tblock then

!		if pclloc[zz]=regvar_loc then
!			px:=mgenireg(pclreg[zz], pmode)
!		else
			px:=getopnd_ind(zz)
!		end

		nextpcl:=currpcl.next

		if nextpcl.opcode=kwiden then
!			ax:=getworkreg_rm(getsharereg(px, nextpcl.mode), nextpcl.mode)
			ax:=gwrm(nextpcl.mode, getsharereg(nextpcl.mode, px))

			genmc(ploadop[nextpcl.mode2], ax, px)
			setnewzz(nextpcl.mode, ax.reg)
			currpcl:=nextpcl
		else
!			ax:=mgenreg(getworkregc(getsharereg(px, pmode), pmode), pmode)
			ax:=gwrm(pmode, getsharereg(pmode, px))
			genmc(m_mov, ax, px)
			setnewzz(pmode, ax.reg)
		end

	else

!CPL "ILOADB1"
		px:=getopnd_ind_simp(zz)
!CPL "ILOADB2", MSTROPND(PX)

		ax:=gwrm(tu64, px.reg)
!CPL "ILOADB2", MSTROPND(AX)
		dolea(ax, px)
	end

end

proc px_iloadx*(pcl p) =
! Z' := (Y + Z*s + d)^
	pcl z, nextpcl
	mclopnd ax, bx, px, fx

	px:=do_addrmode(p)

!CPL "ILOADX", STRMODE(PMODE)
!CPL STROPNDSTACK()
	if pmode=tblock then
!MCOMM("ILOADX")
		ax:=gwrm(tu64, px.reg)
!		ax:=genreg(getworkregc(tu64, px.reg))
		dolea(ax, px)
		poppcl()
		setnewzz(tu64, ax.reg)

	else
		nextpcl:=currpcl.next

		if nextpcl.opcode=kwiden then
!			ax:=getworkreg_rm(getsharereg(px, nextpcl.mode), nextpcl.mode)
			ax:=gwrm(nextpcl.mode, getsharereg(nextpcl.mode, px))

			genmc(ploadop[nextpcl.mode2], ax, px)
			poppcl()
			setnewzz(nextpcl.mode, ax.reg)
			currpcl:=nextpcl
		else

!			ax:=getworkreg_rm(getsharereg(px, pmode), pmode)
			ax:=gwrm(pmode, getsharereg(pmode, px))

			genmc(m_mov, ax, px)
			poppcl()
			setnewzz(pmode, ax.reg)
		end

	end
end

proc px_istore*(pcl p) =
! Y^ := Z
	mclopnd bx, px
	int reg

	bx:=loadopnd(yy, pmode)				!rhs to store into lhs

	if reg:=pclstack[zz].reg then
		px:=mgenireg(reg, pmode)
	else
!		px:=getopnd_ind(zz, pmode)
		px:=getopnd_ind(zz, pmode, mem:1)
	end

	if pmode=tblock then
		px:=makesimpleaddr(px)
		bx:=makeopndind(bx, tu64)

		copyblock(px, bx, p.size)

	else
		genmc(m_mov, px, bx)
	end

	poppcl()
	poppcl()
end

proc px_istorex*(pcl p) =
! (Y + Z*s + d)^ := X
	mclopnd ax, cx, px
	pcl z

	cx:=loadopnd(xx, pmode)			!rhs
	px:=do_addrmode(p)

	if pmode=tblock then
		px:=makesimpleaddr(px)
		cx:=makeopndind(cx, tu64)
		copyblock(px, cx, p.size)

	else
		genmc(m_mov, px, cx)

	end

	poppcl()
	poppcl()
	poppcl()
end

proc px_storem*(pcl p) =
	unimpl(p)
end

proc px_dupl*(pcl p) =
!CPL "*******DUPL"
!	unimpl(p)
	duplpcl()
end

proc px_double*(pcl p) =
	if ncalldepth then
		duplpcl()
	else
		++pclstack[noperands].count
	end
end

proc px_swapstk*(pcl p) =
! (Z', Y') := (Z, Y)
!	swapopnds(yy, zz)
	swapopnds(noperands-p.x+1, noperands-p.y+1)
end

proc px_unload*(pcl p) =
	poppcl()
end

proc px_opnd*(pcl p) =
	unimpl(p)
end

proc px_type*(pcl p) =
	unimpl(p)
end

proc px_loadbit*(pcl p) =
! Z' := Y.[Z]
	mclopnd ax
	pcl z
	int i, m

	if z:=isimmint(zz) then
		i:=z.value
		m:=(i in 0..31|tu32|tu64)

		ax:=loadopnd(yy, m)
		if i then
			genmc(m_shr, ax, mgenint(i, m))

			goto skip when i=63

		end
	else
		ax:=loadopnd(yy, pmode)
		genmc(m_push, mgenreg(r10)) when r10used
		genmc(m_shr, ax, loadparam(zz, tu8, r10))
		genmc(m_pop, mgenreg(r10)) when r10used
	end

	genmc(m_and, changeopndsize(ax, 4), mgenint(1, tu32))

skip:
	poppcl()
end

proc px_loadbf*(pcl p) =
! Z' := X.[Y..Z]
	pcl y, z

	y:=isimmint(yy)
	z:=isimmint(zz)

	if y and z then
		do_loadbf_const(p, y.value, z.value)
	else
		do_loadbf_var(p)
	end
end

proc px_storebit*(pcl p) =
! Y^.[Z] := X
	do_storebit(p)
end

proc px_storebf*(pcl p) =
! X^.[Y..Z] := W
	do_storebf(p)
end

proc px_callp*(pcl p) =
	int nargs, nregargs, slots, isptr:=0, shadow:=0

	int blockret:=callblockret[ncalldepth]

	nargs:=p.nargs+blockret
	nregargs:=min(nargs, 4)

	if p.opcode in [kicallp, kicallf] then
		isptr:=1
	end

	do_pushlowargs(nregargs, p.nvariadics, isptr)

	slots:=0
	if nargs<=4 then
		if mstackdepth then
			slots+:=4
			pushslots(4)					!shadowspace
			SLOTS+:=CALLALIGN[NCALLDEPTH]
		else
			localshadow:=1
		end

	else
		slots:=nargs+callalign[ncalldepth]
		pushslots(4)						!shadowspace
	end

	if isptr then
		genmc(m_call, loadopnd(zz, tu64))
		poppcl()
	else
		genmc(m_call, genmemaddr(p.def))
	end

	to nregargs-BLOCKRET do
!CPL "CALL/POP", =NOPERANDS, =PCLSET:"H"
!CPL STROPNDSTACK()
		poppcl()
!CPL STROPNDSTACK()
	od

	if slots then
		popslots(slots)
	end

	if pmode then
		do_getretvalue(p)
	end

	--ncalldepth
end

proc px_retproc*(pcl p) =
	if mclprocentry=mccodex then		!empty body: add dummy mcl op
		mcomment("---")				!injection of entry code goes wrong otherwise
	end

!	do_proccode_b()
!	do_proccode_c()
end

proc px_retfn*(pcl p) =
	mclopnd ax, bx

	if pmode=tblock then
		bx:=genireg(r0)								!r0 points to local block value
		regset.[r0]:=1
		ax:=gwrm()
!CPL BLOCKRETNAME
		genmc(m_mov, ax, genmem(blockretname))
		ax:=genireg(ax.reg)
		copyblock(ax, bx, p.size)
		genmc(m_mov, mgenreg(r0, tu64), mgenmem(blockretname))
	end

	px_retproc(p)
end

!proc px_callf*(pcl p) =
!	unimpl(p)
!end
!
proc px_jump*(pcl p) =
	int labno:=p.labelno
	pcl q:=p.next

	while q.opcode=kcomment do q:=q.next od
	case q.opcode
	when klabel then
		if q.labelno=labno then return end
		q:=q.next
		if q.opcode=klabel and q.labelno=labno then return end
	when kjump then
		q.opcode:=knop
	end case

	genmc(m_jmp, genlabel(labno))
end

proc px_ijump*(pcl p) =
	genmc(m_jmp, getopnd(zz, tu64))
	poppcl()
end

proc px_jumpcc*(pcl p) =
! goto L when Y c Z; p=1: Z':=Y (b=0/1)
	int mcond
	mclopnd ax, bx, lx
	pcl z

	mcond:=ucondcodes[p.condcode]
	lx:=genlabel(p.labelno)

	if pmode=tblock then
MERROR("JUMPCC/BLOCK")
!		addimm(p.size)
!		swapopnds(1, 3)
!		domaths(nil, "memcmp*", 3)
!		genmc(m_cmp, mgenreg(r0, tp32), mgenint(0))
!		genmc_cond(m_jmpcc, mcond, lx)

	else

		ax:=loadopnd(yy)

		if ispint(pmode) then
			if (z:=isimmint(zz)) and z.value=0 and p.condcode in [eq_cc, ne_cc] then
				genmc(m_test, ax, ax)
			else
				bx:=getopnd(zz)
				if stdsigned[pmode] then
					mcond:=scondcodes[p.condcode]
				end
				genmc(m_cmp, ax, bx)
			end
		else
			bx:=getopnd(zz)
!MCOMM("A")
			genmc(m_comiss, ax, bx)
		end

		genmc_cond(m_jmpcc, mcond, lx)
		poppcl()

		unless p.popone then
			poppcl()
		end
	end
end

proc px_jumpt*(pcl p) =
! goto L when Z is true
	do_jumptruefalse(p, nz_cond)
end

proc px_jumpf*(pcl p) =
! goto L when Z is false
	do_jumptruefalse(p, z_cond)
end

proc px_jumpret*(pcl p) =
! goto L, common return point; deal with any ret value on stack

	if pmode=tvoid or noperands=0 then
		merror("Jumpret/no-arg")
	end

	loadparam(zz, pmode, (stdfloat[pmode]|xr0|r0))
	poppcl()

	px_jump(p)
end

proc px_jumpretm*(pcl p) =
	unimpl(p)
end

proc px_setcc*(pcl p) =
! Z' := Y cc Z
	int cond
	mclopnd ax, bx, cx

!	ax:=loadopnd(yy, pmode)
	AX:=LOADOPND(YY, PMODE)
	bx:=getopnd(zz, pmode)
	cond:=ucondcodes[p.condcode]

	if pmode=tblock then
		merror("setcc/block")

	elsif ispint(pmode) then
		if stdsigned[pmode] then
			cond:=scondcodes[p.condcode]
		end
		genmc(m_cmp, ax, bx)
		cx:=changeopndsize(ax, 1)

	else
!MCOMM("B")
		genmc(m_comiss, ax, bx)

		cx:=gwrm(tu8)
		setnewzz(ti64, cx.reg)
		swapopnds(yy, zz)
	end

	genmc_cond(m_setcc, cond, cx)
	genmc(m_movzx, changeopndsize(cx, 4), cx)

	poppcl()
end

proc px_stop*(pcl p) =
	loadparam(zz, tu64, r10)
	genmc(m_call, genextname("exit"))

	localshadow:=1
	poppcl()
end

proc px_to*(pcl p) =
	pcl q
	mclopnd ax

	q:=currpcl:=p.next

	ax:=mgenmem(q.def)
	genmc(m_dec, ax)
	genmc_cond(m_jmpcc, nz_cond, genlabel(p.labelno))
end

proc px_forup*(pcl p) =
! B+:=n; goto L when B<=C
	do_for(p, m_inc, m_add, le_cond)
end

proc px_fordown*(pcl p) =
! B-:=n; goto L when B>=C
	do_for(p, m_dec, m_sub, ge_cond)
end

proc px_iswap*(pcl p) =
	mclopnd ax, bx

	mclopnd px:=getopnd_ind(yy, mem:1)
	mclopnd qx:=getopnd_ind(zz, mem:1)

!	mclopnd px:=getopnd_ind(yy, mem:0)
!	mclopnd qx:=getopnd_ind(zz, mem:0)

	ax:=gwrm()
	bx:=gwrm()

	if pmode<>tblock then
		genmc(m_mov, ax, px)
		genmc(m_mov, bx, qx)
		genmc(m_mov, qx, ax)
		genmc(m_mov, px, bx)
	else
		merror("swap/block")
	end

	poppcl()
	poppcl()
end

proc px_switch*(pcl p) =
! L=jumptab; B=elselab; x/y=min/max values
	int minlab, maxlab, jumplab, elselab
	mclopnd ax, bx, ax2

	minlab:=p.minlab
	maxlab:=p.maxlab
	jumplab:=p.labelno
	currpcl:=p.next
	elselab:=currpcl.labelno

	ax:=loadopnd(zz)
	if p.size<8 then
		genmc(m_movsx, ax2:=changeopndsize(ax, 8), ax)
		ax:=ax2
	end

	if minlab<>0 then
		genmc(m_sub, ax, genint(minlab))
	end

	genmc(m_cmp, ax, genint(maxlab-minlab+1))
	genmc_cond(m_jmpcc, geu_cond, genlabel(elselab))

	if highmem=2 then
		bx:=gwrm(tu64)

		genmc(m_lea, bx, genlabelmem(jumplab))

		genmc(m_jmp, genindex(ireg:ax.reg, areg:bx.reg, scale:8))
	else
		genmc(m_jmp, genindex(ireg:ax.reg, scale:8, labno:jumplab))

	end

	poppcl()

!	setsegment('I')
end

proc px_switchu*(pcl p) =
! L=jumptab; B=elselab; x/y=min/max values
	int minlab, maxlab, jumplab, reg
	mclopnd ax, bx

	minlab:=p.minlab
	maxlab:=p.maxlab
	jumplab:=p.labelno

	ax:=loadopnd(zz, pmode)

	if highmem=2 then
		bx:=gwrm()

!		genmc(m_mov, bx, mgenlabel(jumplab))
		genmc(m_lea, bx, genlabelmem(jumplab))

		genmc(m_jmp, genindex(ireg:ax.reg, areg:reg, scale:8, offset:-minlab*8))
	else
		genmc(m_jmp, genindex(ireg:ax.reg, scale:8, labno:jumplab, offset:-minlab*8))
	end

	poppcl()
end

proc px_swlabel*(pcl p) =
! jumptable entry
	genmc(m_dq, genlabel(p.labelno))
end

!proc px_endsw*(pcl p) =
!! Mark end of switch jumptable
!	setsegment('C')
!end

proc px_clear*(pcl p) =
	mclopnd ax

	ax:=getopnd_ind_simp(zz, tu64)

!CPL "CLEAR BLOCK", MSTROPND(AX)

	clearblock(ax, p.size)
	poppcl()
end

proc px_add*(pcl p) =
	mclopnd ax, bx
	pcl z

	ax:=loadopnd(yy)

	if stdint[p.mode] then
		if (z:=isimmint(zz)) and z.value=1 then
			genmc(m_inc, ax)
		else
			bx:=getopnd(zz)
			genmc(m_add, ax, bx)
		end
	else
		bx:=getopnd(zz)
		genmc(m_addss, ax, bx)
	end

	poppcl()
end

proc px_sub*(pcl p) =
	mclopnd ax, bx
	pcl z

	ax:=loadopnd(yy)

	if stdint[pmode] then
		if (z:=isimmint(zz)) and z.value=1 then
			genmc(m_dec, ax)
		else
			bx:=getopnd(zz)
			genmc(m_sub, ax, bx)
		end
	else
		bx:=getopnd(zz)
		genmc(m_subss, ax, bx)
	end

	poppcl()
end

proc px_mul*(pcl p) =
! Z' := Y * Z
	mclopnd ax, bx
	pcl z

	ax:=loadopnd(yy)

	if stdint[pmode] then
		if z:=isimmint(zz) then
			mulimm(ax, z.value)

		else

!			bx:=getopnd(zz)
			bx:=loadopnd(zz)
			genmc(m_imul2, ax, bx)
		end

	else
		bx:=getopnd(zz)
		genmc(m_mulss, ax, bx)
	end

	poppcl()
end

proc px_div*(pcl p) =
	mclopnd ax, bx

	ax:=loadopnd(yy)
	bx:=getopnd(zz)
	genmc(m_divss, ax, bx)
	poppcl()
end

proc px_idiv*(pcl p) =
! Z' := Y % Z
	do_divrem(p, issigned:stdsigned[pmode], isdiv:1)
end

proc px_irem*(pcl p) =
! Z' := Y rem Z
	do_divrem(p, issigned:stdsigned[pmode], isdiv:0)
end

proc px_idivrem*(pcl p) =
! Z' := divrem(Y, Z)
	do_divrem(p, issigned:stdsigned[pmode], isdiv:2)
end

proc px_bitand*(pcl p) =
! Z' := Y iand Z
	do_bitwise(p, m_and)
end

proc px_bitor*(pcl p) =
! Z' := Y ior Z
	do_bitwise(p, m_or)
end

proc px_bitxor*(pcl p) =
! Z' := Y ixor Z
	do_bitwise(p, m_xor)
end

proc px_shl*(pcl p) =
! Z' := Y << Z
	do_shift(p, m_shl)
end

proc px_shr*(pcl p) =
! Z' := Y >> Z
	do_shift(p, (stdsigned[pmode]|m_sar|m_shr))
end

proc px_min*(pcl p) =
! Z' := min(Y, Z)
	if ispint(pmode) then
		do_max_int((stdsigned[pmode]|gt_cond|gtu_cond))
	else
		do_max_float(m_minss)
	end
end

proc px_max*(pcl p) =
! Z' := max(Y, Z)
	if ispint(pmode) then
		do_max_int((stdsigned[pmode]|lt_cond|ltu_cond))
	else
		do_max_float(m_maxss)
	end
end

proc px_addpx*(pcl p) =
! Z' := Y + Z*s + d
	mclopnd ax, cx

!P.MODE:=PMODE:=TPU64

!MCOMM("ADDPX1")
	cx:=do_addrmode(p)
!MCOMM("ADDPX2 CX=", MSTROPND(CX))

	if regvarset.[cx.reg] then
		ax:=gwrm(tu64)
	else
		ax:=gwrm(tu64, cx.reg)
	end
!MCOMM("ADDPX3 AX=", MSTROPND(AX))

	dolea(ax, cx)
!MCOMM("ADDPX4")
	poppcl()

	setnewzz(tu64, ax.reg)
end

proc px_subpx*(pcl p) =
! Z' := Y - Z*s + s
	int scale, extra, offset
	mclopnd ax, bx
	pcl z

	scale:=p.scale
	extra:=p.extra

	ax:=loadopnd(yy, tu64)

	if z:=isimmint(zz) then
		genmc(m_sub, ax, mgenint(z.value*scale+extra))
	else
!		bx:=loadopnd(zz, tu64)
		BX:=LOADOPND(ZZ, TU64)
		scale:=scaleindex(bx, scale)
		if scale>1 then
			mulimm(bx, scale)
		end
		genmc(m_sub, ax, bx)
		if extra then
			CPL =EXTRA
			MERROR("SUBREF/EXTRA")
!			genmc(m_add, ax, mgenint(extra))
		end
	end
	poppcl()
end

proc px_subp*(pcl p) =
! Z' := (Y - Z)/s
	mclopnd ax, bx
	int n

	ax:=loadopnd(yy)
	bx:=getopnd(zz)
	genmc(m_sub, ax, bx)

	if p.scale>1 then
		n:=ispoweroftwo(p.scale)
		if n then
			genmc(m_shr, ax, genint(n))
		else
			CPL P.SCALE
			MERROR("SUB/REF NOT POWER OF xx")
		end
	end

	poppcl()
end

proc px_neg*(pcl p) =
! Z' := -Z
	mclopnd ax

	ax:=loadopnd(zz)

	if ispint(pmode) then
		genmc(m_neg, ax)
	else
		do_negreal(ax, pmode)
	end
end

proc px_abs*(pcl p) =
! Z' := abs Z
	mclopnd ax, lx

	ax:=loadopnd(zz)

	if ispint(pmode) then
		genmc(m_cmp, ax, mgenint(0, pmode))

		genmc_cond(m_jmpcc, ge_cond, lx:=genlabel(++mlabelno))
		genmc(m_neg, ax)
		genmc(m_label, lx)

	else
		do_absreal(ax, pmode)
	end
end

proc px_bitnot*(pcl p) =
	mclopnd ax
	ax:=loadopnd(zz)
	genmc(m_not, ax)
end

proc px_not*(pcl p) =
	mclopnd ax
	ax:=loadopnd(zz)
	genmc(m_xor, changeopndsize(ax,1), mgenint(1, tu8))
end

proc px_toboolt*(pcl p) =
! Z' := istrue Z
	mclopnd ax, bx, cx
	byte pmode2:=p.mode2

	ax:=loadopnd(zz, pmode2)

	if ispfloat(pmode2) then
		bx:=gwrm(pmode2)
		cx:=gwrm(tu8)
		genmc(m_xorps, bx, bx)
!MCOMM("C")
		genmc(m_comiss, ax, bx)

		genmc_cond(m_setcc, (p.opcode=ktoboolt|ne_cond|eq_cond), cx)
		genmc(m_movzx, changeopndsize(cx, 4), cx)		!4 works for u32/u64
		setnewzz(pmode, cx.reg)

	else
		genmc(m_test, ax, ax)
		genmc_cond(m_setcc, (p.opcode=ktoboolt|ne_cond|eq_cond), bx:=changeopndsize(ax, 1))
		genmc(m_movzx, changeopndsize(ax, 4), bx)
		pclstack[xx].mode:=pmode
	end
end

proc px_sqr*(pcl p) =
	mclopnd ax
	int opc

	ax:=loadopnd(zz)

	if ispint(pmode) then
		opc:=m_imul2
	else
		opc:=m_mulss
	end
	genmc(opc, ax, ax)
end

proc px_sqrt*(pcl p) =
	mclopnd ax

	ax:=loadopnd(zz)
	genmc(m_sqrtss, ax, ax)
end

proc px_maths*(pcl p) =
	do_callrts(p, mathsnames[p.mathsop], 1)
end

proc px_maths2*(pcl p) =
	swapopnds(yy,zz)
	do_callrts(p, mathsnames[p.mathsop], 2)
end

proc px_sign*(pcl p) =
	unimpl(p)
end

proc px_power*(pcl p) =
! Z' := Y ** Z
	mclopnd ax, bx
	symbol d

	if ispint(pmode) then
		d:=findhostfn(kpower)
		unless d then merror("$power?") end
		swapopnds(yy, zz)
		do_callrts(p, nil, 2, d)
	else
		swapopnds(yy, zz)
		do_callrts(p, "pow", 2)
	end
end

proc px_incrto*(pcl p) =
! Z^ +:= n
	do_incr(p, m_inc, m_add)
end

proc px_decrto*(pcl p) =
! Z^ -:= n
	do_incr(p, m_dec, m_sub)
end

proc px_incrload*(pcl p) =
! Z' := (Z +:= n)^

	do_incrload(p, m_inc, m_add)
end

proc px_decrload*(pcl p) =
! Z' := (Z -:= n)^
	do_incrload(p, m_dec, m_sub)
end

proc px_loadincr*(pcl p) =
! Z' := Z++^ (difficult to express step)
	do_loadincr(p, m_inc, m_add)
end

proc px_loaddecr*(pcl p) =
! Z' := Z--^
	do_loadincr(p, m_dec, m_sub)
end

proc px_addto*(pcl p) =
! Z^ +:= Y
	do_binto(p, m_add, m_addss)
end

proc px_subto*(pcl p) =
! Z^ -:= Y
	do_binto(p, m_sub, m_subss)
end

proc px_multo*(pcl p) =
! Z^ *:= Y
	mclopnd ax, bx, cx
	pcl x

	if ispfloat(pmode) then
		do_binto_float(p, m_mulss)
		return
	end

	if p.size=1 then merror("multo/byte") end

	pushpcl_reg(ti64)

!operands are now Y^ *:= X with Z used as working value

!xx yy zz = addr rhs workreg
	ax:=getopnd_ind(yy, mem:1)
!	ax:=getopnd_ind(yy, mem:0)
	bx:=getopnd(xx)
	cx:=getopnd(zz)

	genmc(m_mov, cx, ax)

	if x:=isimmint(xx) then
		mulimm(cx, x.value)
	else
		genmc(m_imul2, cx, bx)
	end
	genmc(m_mov, ax, cx)

	poppcl()
	poppcl()
	poppcl()
end

proc px_bitandto*(pcl p) =
! Z^ iand:= Y
	do_binto(p, m_and, 0)
end

proc px_bitorto*(pcl p) =
! Z^ ior:= Y
	do_binto(p, m_or, 0)
end

proc px_bitxorto*(pcl p) =
! Z^ ixor:= Y
	do_binto(p, m_xor, 0)
end

proc px_shlto*(pcl p) =
! Z^ <<:= Y
	do_shiftnto(p, m_shl)
end

proc px_shrto*(pcl p) =
! Z^ >>:= Y
	do_shiftnto(p, (stdsigned[pmode]|m_sar|m_shr))
end

proc px_minto*(pcl p) =
! Z^ min:= Y
	if ispint(pmode) then
		do_maxto_int((stdsigned[pmode]|le_cond|leu_cond), pmode)
	else
		do_maxto_real(leu_cond, pmode)
	end
end

proc px_maxto*(pcl p) =
! Z^ max:= Y
	if ispint(pmode) then
		do_maxto_int((stdsigned[pmode]|ge_cond|geu_cond), pmode)
	else
		do_maxto_real(geu_cond, pmode)
	end
end

proc px_addpxto*(pcl p) =
! Z^ +:= Y
	mclopnd ax, bx
	pcl y

	ax:=getopnd_ind(zz, pmode, mem:1)
!	ax:=getopnd_ind(zz, pmode, mem:0)

	if y:=isimmint(yy) then
		genmc(m_add, ax, genint(y.value*p.scale))
	else
		bx:=loadopnd(yy, pmode)
		mulimm(bx, p.scale)
		genmc(m_add, ax, bx)
	end

	poppcl()
	poppcl()
end

proc px_subpxto*(pcl p) =
! Z^ -:= Y
	mclopnd ax, bx
	pcl y

	ax:=getopnd_ind(zz, mem:1)
!	ax:=getopnd_ind(zz, mem:0)

	if y:=isimmint(yy) then
!		genmc(m_sub, ax, mgenint(z.value*p.scale+p.extra))
		genmc(m_sub, ax, mgenint(y.value*p.scale))
	else
		bx:=loadopnd(yy)
		mulimm(bx, p.scale)
		genmc(m_sub, ax, bx)
		if p.extra then
			MERROR("SUBTOREF/EXTRA")
!			genmc(m_sub, ax, mgenint(extra))
		end
	end

	poppcl()
	poppcl()
end

proc px_divto*(pcl p) =
! Z^ /:= Y
	do_binto_float(p, m_divss)
end

proc px_negto*(pcl p) =
	unimpl(p)
end

proc px_absto*(pcl p) =
	unimpl(p)
end

proc px_bitnotto*(pcl p) =
	unimpl(p)
end

proc px_notto*(pcl p) =
	unimpl(p)
end

proc px_toboolto*(pcl p) =
	unimpl(p)
end

proc px_fix*(pcl p) =
! Z' := cast(Z, t) Real u to int t
	mclopnd fx, ax
!
	fx:=loadopnd(zz, p.mode2)
	pushpcl_reg(pmode)

	ax:=getopnd(zz, stdmin[pmode])
	genmc(m_cvttss2si+ispwide(p.mode2), ax, fx)

	swapopnds(yy, zz)
	poppcl()

	setnewzz(pmode, ax.reg)
end

proc px_float*(pcl p) =
! Z' := cast(Z, t) Int u to real t
	mclopnd ax, fx
	int lab, lab2
	byte pmode2:=p.mode2

	ax:=loadopnd(zz, pmode2)

	if stdsize[pmode2]<4 then merror("float/short") end

	if stdsigned[pmode2] then
		pushpcl_reg(pmode)
		fx:=getopnd(zz)

		genmc(m_cvtsi2ss+ispwide(pmode), fx, ax)
		swapopnds(yy, zz)

	elsif pmode2=tu64 then								!u64 to r32/r64
		pushpcl_reg(tr64)								!convert to r64 in all cases

		fx:=getopnd(zz, tr64)

		lab:=createfwdlabel()
		lab2:=createfwdlabel()

		genmc(m_cmp, ax, genint(0, ax.size))					!range of +ve i64?
		genmc_cond(m_jmpcc, lt_cond, genlabel(lab))
		genmc(m_cvtsi2sd, fx, ax)						!number is +ve i64
		genmc(m_jmp, genlabel(lab2))

		definefwdlabel(lab)

		if not labmask63 then
			labmask63:=++mlabelno
			laboffset64:=++mlabelno
		end
		genmc(m_and, ax, genlabelmem(labmask63))		!clear top bit of u64 (subtract 2**63)
		genmc(m_cvtsi2sd, fx, ax)						!now in +ve i64 range
		genmc(m_addsd, fx, genlabelmem(laboffset64))	!add back 2**63 as float

		mdefinefwdlabel(lab2)							!done conv to r64
reduce:
		if pmode=tr32 then								!for r64, reduce down
			genmc(m_cvtsd2ss, changeopndsize(fx, 4), fx)
			pclstack[zz].mode:=tr32
		end

		swapopnds(yy, zz)								!bring old int value to top
	else												!u32 to r32/r64
		pushpcl_reg(tr64)								!convert to r64 in all cases

		fx:=getopnd(zz, tr64)
		ax:=changeopndsize(ax, 8)						!eg A0 to D0

		genmc(m_cvtsi2sd, fx, ax)						!u64 (always in range) to r64

		goto reduce

	end

	poppcl()
end

proc px_truncate*(pcl p) =
! Z' := cast(Z, u) Mask to width of u, but type is widened to t
	mclopnd ax
	byte pmode2:=p.mode2

!	if p.size<8 then merror("trunc32") FI

	ax:=loadopnd(zz, pmode2)
	if p.size<>stdsize[pmode2] then
		genmc(ploadop[pmode2], changeopndsize(ax, p.size), ax)
	end
end

proc px_typepun*(pcl p) =
! Z' := t(u!(Z^))
	mclopnd ax, bx

	bx:=loadopnd(zz, p.mode2)
	ax:=gwrm()
	genmc(m_mov, ax, changeopndsize(bx, ax.size))

	setnewzz(pmode, ax.reg)
end

proc px_widen*(pcl p) =
! Z' := cast(Z, t) Mask to width of u, but type is widened to t
	mclopnd ax, bx

	if pmode=tu64 and p.mode2=tu32 then
		ax:=loadopnd(zz, tu32)
		if mccodex.opcode<>m_mov then
			genmc(m_mov, ax, ax)			!sets upper half to zero, just in case
		end
	else
		bx:=getopnd(zz, p.mode2)
		ax:=gwrm()
		genmc((stdsigned[p.mode2]|m_movsx|m_movzx), ax, bx)
		setnewzz(pmode, ax.reg)
	end
end

proc px_fwiden*(pcl p) =
	mclopnd fx
	fx:=loadopnd(zz, p.mode2)
	genmc(m_cvtss2sd, changeopndsize(fx, 8), fx)
	pclstack[zz].mode:=tr64
end

proc px_fnarrow*(pcl p) =
! Z' := cast(Z, t) r64 to r32
	mclopnd fx
	fx:=loadopnd(zz, p.mode2)
	genmc(m_cvtsd2ss, changeopndsize(fx, 4), fx)
	pclstack[zz].mode:=tr32
end

proc px_startmx*(pcl p) =
	saveopnds()
end

proc px_resetmx*(pcl p) =
! -
!	if ispfloat(pmode) then
!		merror("RESETMULT/XREG")
!	end

	movetoreg(r0)

	if p.opcode=kresetmx then
		poppcl()
	end

!RESET PCLSET
	PCLSET:=0
	FOR I TO NOPERANDS DO
		IF PCLSTACK[I].REG THEN
			PCLSET.[PCLSTACK[I].REG]:=1
		FI
	OD
!MCOMM("AFTER RESET/ENDMX")
!MCOMM(STROPNDSTACK())

end

proc px_initdswx*(pcl p) =
!	unimpl(p)
end

proc px_label*(pcl p) =
	genmc(m_label, genlabel(p.labelno))
end

proc px_labeldef*(pcl p) =
	[100]char str
	strcpy(str, p.def.name)
	strcat(str, ":")
	mcomment(str)
end

proc px_setcall*(pcl p) =
	saveopnds()

	if ncalldepth>=maxcalldepth then
		merror("Too many nested calls")
	end

	++ncalldepth

	if p.nargs<=4 then
		callalign[ncalldepth]:=mstackdepth.odd
	else
		callalign[ncalldepth]:=p.nargs.odd ixor mstackdepth.odd
	end

	callblockret[ncalldepth]:=pmode=tblock
	callblocksize[ncalldepth]:=p.size

	if callalign[ncalldepth] then
		pushslots(1)
	end
end

proc px_setarg*(pcl p) =
	int n

	n:=p.x+callblockret[ncalldepth]

	if n>4 then
		if pmode=tblock then
			copyblockarg(nil, p.size, n)
		end
		pushopnd(zz, pmode)
	elsif pmode=tblock then			!need to record its size
		callargsize[ncalldepth, n]:=p.size
	end
end

proc px_loadall*(pcl p) =
	unimpl(p)
end

proc px_eval*(pcl p) =
	loadopnd(zz)
	poppcl()
end

proc px_comment*(pcl p) =
	mcomment(p.svalue)
!	unimpl(p)
end

!proc px_setjmp*(pcl p)=
!	mclopnd ax,bx
!	int lab:=mcreatefwdlabel()
!
!	bx:=getopnd_ind(zz, tu64)
!
!	pushpcl_reg(tpref)
!
!	ax:=getopnd(zz, tu64)
!	genmc(m_mov, ax, genlabel(lab))
!	genmc(m_mov, bx, ax)
!	genmc(m_mov, applyoffset(bx,8), dstackopnd)
!	genmc(m_mov, applyoffset(bx,16), dframeopnd)
!	swapopnds(yy,zz)
!	poppcl()
!	clearreg(ax)
!
!!since this is the end of this op anway, free any workregs in advance (freeing
!!will be done again by convertpcl)
!	freeworkregs(p)
!	movetoreg(r0)
!	mdefinefwdlabel(lab)
!
!end
!
!proc px_longjmp*(pcl p)=
!	mclopnd ax,bx,cx
!
!	bx:=loadopnd(zz, tpref)		!ret value
!	ax:=getopnd_ind(yy, tpref)	!buffer
!
!	genmc(m_mov, dstackopnd, applyoffset(ax,8))
!	genmc(m_mov, dframeopnd, applyoffset(ax,16))
!
!!	addreg_d64()
!	pushpcl_reg(tpref)
!
!	cx:=getopnd(zz, tpref)
!
!	genmc(m_mov, cx, ax)		!load stored return address
!	swapopnds(xx, zz)
!	poppcl()					!addr of buffer
!
!	swapopndregs(r0)			!move ret value to r0
!	genmc(m_jmp, cx)			!
!	swapopnds(yy, zz)
!	poppcl()					!get rid of dest addr; leave ret value in r0
!end
!
!
!
