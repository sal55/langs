const maxnestedloops	= 50

[maxnestedloops,4]int loopstack
int loopindex							!current level of nested loop/switch blocks

!global int blocklevel

global proc evalunit(unit p)=
	unit a,b,c
	symbol d

	if p=nil then return fi
	mmpos:=p.pos

!CPL "EVALUNIT",JTAGNAMES[P.TAG]

	a:=p.a
	b:=p.b
	c:=p.c

	switch p.tag
	when jconst then
		do_const(p)

	when jname then
		d:=p.def

		if d.nameid=labelid then
			if d.index=0 then
				d.index:=++mlabelno
			fi
			if p.resultflag then
				dxstr("&&L")
				dxstr(strint(d.index))

!				dxstr("abc")
			else
				ccstr("goto ")
				ccstrsemi(genclabel(d.index,0))
			fi
		else
!			applymemmode(p)
			dxstr(getfullnamec(d))
		fi

	when jblock then				!assume an exprlist
		do_block(p)

	when jreturn then
		do_return(p,a)

	when jassign then
		do_assign(p,a,b)

!	when jassignms then
!		do_assignms(a,b)

!	when jassignmm      then do_assignmm(a,b)

	when jeval then
		evalunit(a)
		ccstrline(";")

	when jto then
		do_to(a,b,c)

	when jif then
!		if isexpr(p) and p.resultflag or p.compactif then
		if p.compactif then
			do_ifx(a,b,c)
		else
			do_if(a,b,c)
		fi

	when jforup, jfordown then
		do_forup(p,a,b,c)

	when jforall then
		do_forall(p,a,b,c)
!
!!	when jforallrev     then do_forall(p,a,b,c,1)

	when jwhile then
		do_while(a,b,c)

	when jrepeat then
		do_repeat(a,b)

	when jgoto then
		do_goto(a)

	when jlabeldef then
		d:=p.def
		if d.index=0 then
			d.index:=++mlabelno
		fi
		ccstr("//")
		ccstr(d.name)
		ccstrline(":")
		ccstrline(genclabel(d.index,1))
!
	when jredo, jnext, jexit then
		do_exit(p)

	when jdo then
		do_do(a)

	when jcase,jdocase then
		do_case(p,a,b,c)


	when jswitch, jdoswitch then
		do_switch(p,a,b,c)

	when jdoswitchu then
		gerror("DOSWITCHU not ready")

	when jdoswitchx then
		do_switchx(p,a,b,c, 0)

!!	when jrecase        then do_recase(p,a)
	when jswap then
		do_swap(a,b)
!
	when jselect then
		do_select(a,b,c)
!
	when jprint,jprintln, jfprint,jfprintln then
		do_print(p,a,b)

	when jread then
		do_read(p,a)

	when jreadln then
		do_readln(a)

	when jstop then
		ccstr("exit(")
		if a then
			evalunit(a)
		else
			dxchar('0')
		fi
		dxchar(')')

!	when jandl then
!		tx:=do_andl(p,a,b, reg)
!
!	when jorl then
!		tx:=do_orl(p,a,b, reg)
!!
!!	when jmakerange     then GENPC_COMMENT("MAKERANGE")
	when jcall then
		do_call(p,a,b, p.mode<>tvoid)
!!
!	when jcmp then
!		tx:=do_setcc(p,a,b, reg)
!
!	when jcmpchain then
!		tx:=do_setccchain(p,a, reg)
!!
	when jbin, jcmp then
		do_bin(p,a,b)

	when jandl, jorl then
		dxchar('(')
		evalunit(a)
		dxstr((p.tag=jandl|" && "|" || "))
		evalunit(b)
		dxchar(')')

!
	when jindex then
		do_index(p,a,b)

!	when jslice then
!		tx:=do_slice(p,a,b, reg)
!
	when jdotindex then
		do_supportcall("m$getdotindex",a,b)

	when jdotslice then
!PRINTUNIT(P)
		do_supportcall("m$getdotslice",a,b.a, b.b)
!		do_dotslice(a,b.a,b.b)

!
	when jdot then
!		applymemmode(p)
		evalunit(a)
		dxchar('.')
		evalunit(b)
!
	when jptr then
!		applymemmode(p)
		if a.tag=jaddrof then
			evalunit(a.a)
		else
			dxstr("(*")
			evalunit(a)
			dxchar(')')
		fi

!		tx:=do_ptr(p,a,1,reg)
!
	when jaddrof then
		case a.tag
		when jptr then
			evalunit(a.a)
		when jif then
			do_ifx(a.a,a.b,a.c, 1)
		when jcall then
			evalunit(a)
		else
			dxstr("&")
			evalunit(a)
		esac
	when jaddroffirst then
!		ccstr("(u8*)")
		evalunit(a)
!
	when jconvert then
		do_convert(p,a)
!
	when jtypepun then
		do_typepun(p,a)

	when jshorten then
		dxstr("(")
		dxstr(strmodec(p.mode))
		dxstr(")")
		evalunit(a)
!		tx:=loadunit(a,reg)

!	when jtypeconst then
!		tx:=genint(p.value)
!!
	when junary, jnotl then
		do_unary(p,a)
!
!	when jnotl then
!		tx:=do_notl(p,a, reg)
!
	when jistruel then
		dxstr("!!(")
		evalunit(a)
		dxstr(")")

	when jisfalsel then
		dxstr("!(")
		evalunit(a)
		dxstr(")")

	when jincr          then
		case p.pclop
		when kincrto, kincrload then
			ccstr("++(")
			evalunit(a)
			ccstr(")")
		when kdecrto, kdecrload then
			ccstr("--(")
			evalunit(a)
			ccstr(")")
		when kloadincr then
			ccstr("(")
			evalunit(a)
			ccstr(")++")
		else
			ccstr("(")
			evalunit(a)
			ccstr(")--")
		esac

	when jbinto then
		do_binto(p,a,b)

	when jsyscall then
		ccstr("msysc$m$")
		ccstr(sysfnnames[p.fnindex]+3)
		ccchar('(')
		if a then
			evalunit(a)
		fi
		ccchar(')')
!
	when jcvlineno      then
		ccint(getlineno(mmpos))

	when jclear then
		dxstr("memset(&(")
		evalunit(a)
		dxstr("),0,")
		dxint(ttsize[a.mode])
		dxchar(')')

	when jinrange then
		do_inrange(a,b.a,b.b)

	when jinset then
		do_inset(a,b.a)

	when jcmpchain then
		do_cmpchain(p)

	else
		gerror_s("Evalunit: ",jtagnames[p.tag])
	end switch

end

global proc evalstmt(unit p)=
	cctab(blocklevel)
	evalunit(p)
	if p.tag<>jblock then
		ccstrline(";")
	fi
end

global proc evalunitc(unit p)=
!if a block, turn into a comma-operator sequence
	unit q

	if p.tag<>jblock then
		evalunit(p)
		return
	fi

	dxchar('(')
	q:=p.a
	while q, q:=q.nextunit do
		if q<>p.a then
			dxstr(", ")
		fi
		evalunit(q)
	od

	dxchar(')')
end

proc evalblock(unit p, int braces=1)=
!p is either a block or a non-block
!always treat as a block
	unitrec r
	unit pnext

	if p.tag=jblock then
		do_block(p,braces)
	else
		r.tag:=jblock
		r.a:=p
		pnext:=p.nextunit
		p.nextunit:=nil				!some single blocks are chained to others,
									! but do not form a sequence (eg. forbody/else)
		do_block(&r,braces)	
		p.nextunit:=pnext

	fi
end

global proc do_block(unit p, int braces=1)=
	unit a:=p.a

	++blocklevel

	if braces then ccstrline("{") fi
	while a, a:=a.nextunit do
		evalstmt(a)
	od
	--blocklevel
	if braces then
		cctab(blocklevel)
		ccstrline("}")
	fi
end

global proc evalblocklab(unit p,int lab1,lab2, unit pincr=nil, int labincr=0, braces=1)=
!p is either a block or a non-block
!always treat as a block
	unitrec r
	unit pnext

	if p.tag=jblock then
		do_blocklab(p,lab1,lab2, pincr, labincr,braces)
	else
		r.tag:=jblock
		r.a:=p
		pnext:=p.nextunit
		p.nextunit:=nil				!some single blocks are chained to others,
									! but do not form a sequence (eg. forbody/else)
		do_blocklab(&r,lab1,lab2, pincr, labincr, braces)	
		p.nextunit:=pnext
	fi
end


global proc do_blocklab(unit p, int lab1,lab2, unit pincr, int labincr, braces=1)=
	unit a:=p.a

	if braces then ccstrline("{") fi

	if lab1 then
		dxlabel(lab1)
	fi

	++blocklevel
	while a do
		evalstmt(a)
		a:=a.nextunit
	od
	if lab2 then
		dxlabel(lab2)
	fi

	if pincr then
		evalstmt(pincr)
		definefwdlabel(labincr)
	fi

	--blocklevel
	if braces then
		cctab(blocklevel)
		ccstrline("}")
	fi
end

proc do_const(unit p)=
	[256]char str
	int64 a
	word64 u
	int m

	str[1]:=0
	m:=p.mode

!DXSTR("CONST"); RETURN


	if ttsigned[m] then
		a:=p.value
		case ttbasetype[p.mode]
		when ti8 then print @&.str,"(i8)",,a
		when ti16 then print @&.str,"(i16)",,a
		when ti32 then
			if a=int32.min then
				dxstr("(int32_t)(-2147483647-1)")
			else
				print @&.str,"(int32_t)",,a
			fi
		when ti64 then
			if a=int64.min then
				dxstr("(i64)(-9223372036854775807-1)")
			else
				fprint @&.str,"(i64)",a
			fi
		ELSE
	GERROR("CONST/INT")
		esac
	elsif ttisinteger[m] or m=tbool64 then
		u:=p.uvalue
		case ttbasetype[p.mode]
		when tu8 then fprint @&.str,"(u8)#u",u
		when tu16 then fprint @&.str,"(u16)#u",u
		when tu32 then fprint @&.str,"(u32)#u",u
		when tu64,tbool64 then fprint @&.str,"(u64)#u",u
		when tc8,tc64 then
			if u<32 or u>126 or u='\\' or u='\'' then
				fprint @&.str,"(u64)#u",u
			else
!				fprint @&.str,"'#'",u:"c"
				str[1]:=''''
				str[2]:=u
				str[3]:=''''
				str[4]:=0
			fi
		else
			gerror("const/word")
		esac

	elsif ttisref[m] then
		if p.tag=jconst and p.mode=trefchar and p.isastring then
			if p.svalue then
				cclongstr(p.svalue,p.slength)
				return
			else
				strcpy(&.str,"0")
			fi
		else
			print @&.str,p.value:"H"
		fi

	elsif ttisreal[m] then
		if ttbasetype[p.mode]=tr64 then
			fprint @&.str,"(double)",p.xvalue:".20g"
			if strchr(&.str,'.')=nil then
				strcat(&.str,".")
			fi
		else
			print @&.str,"(float)",,p.xvalue
		fi
	elsif ttbasetype[m]=tarray then
!CPL("DOCONST/ARRAY")
!PRINTUNIT(P)
		if p.strtype then
!CPL P.SLENGTH
!			DXSTR("ARRAY/STRDATA")
!DXSTR("<STRDATA>")
			cclongbin(p.svalue, p.slength)
		else
			gerror("doconst/array/str")
		fi

	else
		cpl =strmode(m),ttisref[m]
		gerror("doconst")
	fi

	dxstr(&.str)
end

proc do_return(unit P,a)=
!CPL "DO RET"
	if not a then
		ccstr("return")
	else
IF A.TAG=JCONVERT AND A.A.TAG=JBLOCK THEN
PRINTLN "RETURN CONV BLOCK"
FI
		ccstr("return ")
		evalunit(a)
	fi
end

proc do_assign(unit p,a,b)=

	case a.tag
	when jdotindex then
		evalunit(a.a)
		dxstr(" = ")
		do_supportcall("m$setdotindex",a.a,a.b,b)

	when jdotslice then
		evalunit(a.a)
		dxstr(" = ")
		do_supportcall("m$setdotslice",a.a,a.b.a, a.b.b, b)

	elsif ttbasetype[a.mode]=tarray then
		if p.resultflag then gerror("Block assign returning value?") fi
		do_blockcopy(a,b)
	else
		if p.resultflag then dxchar('(') fi
normalassign:
		evalunit(a)
		dxstr(" = ")
		evalunit(b)

		if p.resultflag then dxchar(')') fi
	esac

end

proc do_bin(unit p,a,b)=
	ichar opstr
	int pclop:=p.pclop

	if pclop=0 then pclop:=ksetcc fi

	case pclop
	when kmin,kmax then
		do_max(p,a,b)
		return
	when kpower then
		if ttisinteger[a.mode] then
			do_supportcall("m$power_i64",b,a)
		else
			domaths2("pow",a,b)
		fi
		return
	esac

	dxchar('(')
	evalunit(a)
	dxchar(' ')

	opstr:=getccopname(pclop, p.pclcond)
	if opstr=nil then
		gerror_s("No C binop:",pclnames[p.pclop])
	fi

	dxstr(opstr)
	dxchar(' ')
	evalunit(b)
	dxchar(')')
end

proc do_binto(unit p,a,b)=
	ichar opstr

	case p.pclop
	when kminto,kmaxto then
		do_maxto(p,a,b)
		return
	esac

	evalunit(a)

!	opstr:=getccopname(p.pclop, p.condcode)
	opstr:=getccopname(p.pclop, p.pclcond)
	if opstr=nil then
		gerror_s("No C bintoop:",pclnames[p.pclop])
	fi

	dxchar(' ')
	dxstr(opstr)
	dxchar(' ')
	evalunit(b)
end

proc do_unary(unit p,a)=
	ichar opstr

	case p.pclop
	when kabs then
		if ttisreal[a.mode] then
			opstr:="fabs"
		else
			opstr:="m$llabs"
		fi
	when ksqr then
		dxchar('(')
		evalunit(a)
		dxchar('*')
		evalunit(a)
		dxchar(')')
		return
	when ksqrt, ksin, kcos, ktan, kasin, kacos, katan, kexp,
			kfloor, kceil then
		opstr:=pclnames[p.pclop]

	when klog then
		opstr:="log"

	when klog10 then
		opstr:="log10"

!	when klen then
!		evalunit(a)
!		dxstr(".len")
!		return
!	when ksliceptr then
!		dxstr("((")
!		dxstr(strmodec(tttarget[a.mode]))
!		dxstr("*)")
!		evalunit(a)
!		ccstr(".ptr)")
!		return

	else
!		opstr:=getccopname(p.pclop, p.condcode)
		opstr:=getccopname(p.pclop, p.pclcond)
		if opstr=nil then
			gerror_s("No C unaryop:",pclnames[p.pclop])
		fi
	esac

	dxstr(opstr)
	dxchar('(')
	evalunit(a)
	dxchar(')')
end

proc do_convert(unit p,a)=
	[100]char str
	int oldmode:=p.convmode, newmode:=p.mode, mask

	case p.convcode
!	when kksoftconv then
!		evalunit(a)
	when kksoftconv, kkfloat, kkfix, kkfwiden, kkfnarrow, kkwiden then
		dxstr("(")
		dxstr(strmodec(newmode))
		dxstr(")")
		evalunit(a)

	when kktruncate then
		dxchar('(')
		dxstr(strmodec(newmode))
		dxchar(')')
		dxchar('(')
		dxstr(strmodec(oldmode))
		dxchar(')')
		evalunit(a)
	else
error:
		fprint @str,"#-># (#)",strmode(oldmode), strmode(newmode),pclnames[p.pclop]
		gerror_s("Convert ",str)
	esac
end

proc do_if(unit pcond, plist, pelse)=
	unit pcond0:=pcond

	while pcond, (pcond:=pcond.nextunit; plist:=plist.nextunit) do
		if pcond=pcond0 then
			ccstr("if (")
		else
			ccstr("else if (",blocklevel)
		fi
		evalunit(pcond)
		ccstr(") ")
		evalblock(plist)
	od

	if pelse then
		ccstr("else ",blocklevel)
		evalblock(pelse)
	fi
end

proc do_ifx(unit pcond, a, b, int addrof=0)=
	unit pcond0:=pcond

	dxchar('(')
	evalunit(pcond)
	dxstr(" ? ")
	if addrof then dxchar('&') fi
	if a.tag=jconvert then a:=a.a fi
	evalunit(a)
	dxstr(" : ")
	if addrof then dxchar('&') fi
	if b.tag=jconvert then b:=b.a fi
	evalunit(b)
	dxchar(')')
end

proc do_call(unit p,a,b, int isfn)=
	unit q

	if a.tag=jname then
		dxstr(getprocname(a.def))
	else
		dxchar('(')
		evalunit(a)
		dxchar(')')
	fi
	dxchar('(')

	q:=b
	while q do
		evalunit(q)
		q:=q^.nextunit
		if q then
			dxchar(',')
		fi
	od

	dxchar(')')
end

proc do_do(unit a)=
	int lab_abc,lab_d


	lab_abc:=definelabel()
	lab_d:=createfwdlabel()

	stacklooplabels(lab_abc, lab_abc, lab_d)
	ccstr("while (1) ")
	evalblock(a)

	definefwdlabel(lab_d)
	unstacklooplabels()
end

function definelabel:int=
	++mlabelno
	ccstr(genclabel(mlabelno,1))
	ccsendline()
	cctab(blocklevel)

	return mlabelno
end

function createfwdlabel:int=
	return ++mlabelno
end

proc definefwdlabel(int lab)=
	ccstr(genclabel(lab,1))
	ccsendline()
	cctab(blocklevel)
end

proc stacklooplabels(int a,b,c)=
	++loopindex
	if loopindex>maxnestedloops then
		gerror("Too many nested loops")
	fi

	loopstack[loopindex,1]:=a
	loopstack[loopindex,2]:=b
	loopstack[loopindex,3]:=c
end

proc unstacklooplabels=	!UNSTACKLOOPLABELS
	--loopindex
end

function findlooplabel(int k,n)int=
!k is 1,2,3,4 for label A,B,C,D
!n is a 1,2,3, etc, according to loop nesting index
	int i

	i:=loopindex-(n-1)		!point to entry
	if i<1 or i>loopindex then gerror("Bad loop index") fi

	return loopstack[i,k]
end

proc do_exit(unit p)=
	int k,n,index

	switch p.tag
	when jredo then k:=1
	when jnext then k:=2
	when jexit then k:=3
	end switch

	index:=p.index
	if index=0 then index:=loopindex fi

	n:=findlooplabel(k,index)
	if n=0 then
		gerror("Bad exit/loop index",p)
	else
		ccstr("goto ")
		ccstr(genclabel(n,0))
	fi
end

proc do_to(unit a,b,c)=
	int lab_b, lab_c, lab_d

	ccstr(getfullnamec(c.def))

	ccstr(" = ")
	ccstrsemiu(a)

	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()
	stacklooplabels(lab_b,lab_c,lab_d)

	cctab(blocklevel)
	ccstr("while (")
	ccstr(getfullnamec(c.def))
	ccstr("-- > 0) ")

	evalblocklab(b,lab_b,lab_c)			!main body

	definefwdlabel(lab_d)
	unstacklooplabels()
end

proc do_while(unit a,b, pincr)=
	int lab_b,lab_c,lab_d, lab_incr

	lab_b:=definelabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()

	if pincr then
		lab_incr:=createfwdlabel()
	else
		lab_incr:=lab_c
	fi

	stacklooplabels(lab_b, lab_c, lab_d)

	ccstr("while (")
	evalunit(a)
	ccstr(") ")

	evalblocklab(b,0,lab_c, pincr, lab_incr)

	definefwdlabel(lab_d)
	unstacklooplabels()
end

proc do_repeat(unit a,b)=
	int lab_ab, lab_c, lab_d

	lab_ab:=definelabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()

	stacklooplabels(lab_ab, lab_c, lab_d)

	ccstr("do ")

	evalblocklab(a,0,lab_c)

	ccstr("while (!",blocklevel)
	evalunit(b)
	ccstrline(");")

	definefwdlabel(lab_d)
	unstacklooplabels()
end


proc do_forup(unit p, pindex, pfrom, pbody)=
	int lab_b,lab_c,lab_d,down
	unit pto,pstep,pelse,px, ptoinit
	[512]char varstr

!proc do_for(unit p,pindex,pfrom, pbody, int down) =

	down:=p.tag=jfordown

	pto:=pfrom.nextunit
	pstep:=pto.nextunit
	pelse:=pbody.nextunit
	ptoinit:=pindex.nextunit

	if pto.tag=jptr then
		px:=pto.a
		symbol d
		if px.tag=jname and (d:=px.def).nameid=paramid and d.parammode=byref_param then
			gerror("Possibly using &param as for-loop limit")
		fi
	fi

	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()

	stacklooplabels(lab_b,lab_c,lab_d)

	if pindex.tag<>jname then gerror("for/name") fi

	if ptoinit then
		evalstmt(ptoinit)
		cctab(blocklevel)
	fi

	strcpy(&.varstr,getfullnamec(pindex.def))
	ccstr("for (")
	ccstr(&.varstr)
	ccchar('=')
	evalunit(pfrom)
	ccchar(';')
	ccstr(&.varstr)
	ccstr((down|">="|"<="))
	evalunit(pto)
	ccchar(';')

	if pstep then
		ccstr(&.varstr)
		ccstr((down|"-="|"+="))
		evalunit(pstep)
	else
		ccstr((down|"--"|"++"))
		ccstr(&.varstr)
	fi

	ccstr(") ")

	evalblocklab(pbody,lab_b,lab_c)				!do loop body

	if pelse then
!		ccsendline()
		cctab(blocklevel)
		evalblock(pelse)
	fi

	definefwdlabel(lab_d)

	unstacklooplabels()
end

proc do_forall(unit p,pindex,plist, pbody) =
!Structure:
!	forall
!		pindex -> plocal -> pfrom -> pto
!		plist -> passign
!		pbody -> [pelse]

	unit plocal, pfrom, pto, pelse, px, plimit, passign
	int lab_b,lab_c,lab_d,lab_e, lab_cmp
	int a,b,stepx, down:=0
	[512]char varstr

	plocal:=pindex.nextunit
	pfrom:=plocal.nextunit
	pto:=pfrom.nextunit
	passign:=plist.nextunit
	pelse:=pbody.nextunit

	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()
	lab_cmp:=createfwdlabel()

	if pelse then
		lab_e:=createfwdlabel()
	else
		lab_e:=lab_d
	fi

	stacklooplabels(lab_b, lab_c, lab_d)

	strcpy(&.varstr,getfullnamec(pindex.def))
	ccstr("for (")
	ccstr(&.varstr)
	ccchar('=')
	evalunit(pfrom)
	ccchar(';')
	ccstr(&.varstr)
	ccstr((down|">="|"<="))
	evalunit(pto)
	ccchar(';')

	ccstr((down|"--"|"++"))
	ccstr(&.varstr)
	ccstrline(") {")

	evalstmt(passign)
!	definefwdlabel(lab_b)

	evalblocklab(pbody,lab_b,lab_c,braces:0)				!do loop body
	ccstr("}",blocklevel)

	if pelse then
		ccsendline()
		evalblock(pelse)
	fi


	definefwdlabel(lab_d)
	unstacklooplabels()
end

proc dxlabel(int lab) =
	ccstr(genclabel(lab,1))
	ccsendline()
end

proc do_print(unit p,a,b) =
	unit q,r,s
	int m,widenop
	ichar fn

	if a then
		if ttbasetype[a.mode]<>tref then gerror("@dev no ref") fi
		case ttbasetype[tttarget[a.mode]]
		when tvoid then
			do_syscallproc("m$print_startfile",a)
		when tc8 then
			do_syscallproc("m$print_startstr",a)
		when tref then
			do_syscallproc("m$print_startptr",a)
		else
			gerror("@dev?")
		esac
	else
		do_syscallproc("m$print_startcon")
	fi

	q:=b

	case p.tag
	when jfprint,jfprintln then
		if ttbasetype[q.mode]<>tref or ttbasetype[tttarget[q.mode]]<>tc8 then
			gerror("string expected")
		fi
		do_syscallproc("m$print_setfmt",q)
		q:=p.c
	esac

	while q do
		s:=nil
		case q.tag
		when jfmtitem then
			s:=q.b
			r:=q.a
			m:=r.mode
		when jnogap then
			do_syscallproc("m$print_nogap")
			q:=q.nextunit
			nextloop
		when jspace then
			do_syscallproc("m$print_space")
			q:=q.nextunit
			nextloop
		else
			s:=nullunit
			r:=q
			m:=q.mode
		esac

		widenop:=0
		case ttbasetype[m]
		when ti64 then
			fn:="m$print_i64"
		when ti8,ti16,ti32 then
			fn:="m$print_i64"
		when tu64 then
			fn:="m$print_u64"
		when tu8,tu16,tu32 then
			fn:="m$print_u64"
		when tr32 then
			fn:="m$print_r64"
		when tr64 then
			fn:="m$print_r64"
		when tref then
			if tttarget[m]=tc8 or ttbasetype[tttarget[m]]=tarray and tttarget[tttarget[m]]=tc8 then
!			if tttarget[m]=tc8 or tttarget[m]=tarray and tttarget[tttarget[m]]=tc8 then
				fn:="m$print_str"
			else
				fn:="m$print_ptr"
			fi
		when tarray then
			GERROR("PRINTARRAY")
			q:=q.nextunit
		when trecord then
			GERROR("PRINTRECORD")
		when tc8,tc64 then
			fn:="m$print_c8"

		else
			gerror_s("PRINT/T=",strmode(m))
		esac

		if widenop then
			GERROR("WIDEN/PRINT")
		fi
		do_syscallproc(fn,r,s)
		q:=q.nextunit
	od

	case p.tag
	when jprintln,jfprintln then
		do_syscallproc("m$print_newline")
	esac
	do_syscallproc("m$print_end")

end

proc do_read(unit p,a) =
	int m
	m:=p.mode

	if a=nil then
		a:=createconstunit(0,ti64)
	fi

	if ttisinteger[m] then
		do_syscallproc("m$read_i64",a)
	elsif ttisreal[m] then
		do_syscallproc("m$read_r64",a)
	else
		GERROR("CAN'T READ THIS ITEM")
	fi
end

proc do_readln(unit a) =
	if a then
		if ttbasetype[a.mode]<>tref then gerror("@dev no ref") fi
		case ttbasetype[tttarget[a.mode]]
		when tvoid then
			do_syscallproc("m$read_fileline",a)
		when tu8,tc8 then
			do_syscallproc("m$read_strline",a)
		else
			gerror("rd@dev?")
		esac
	else
		do_syscallproc("m$read_conline")
	fi
end

proc do_index(unit p,a,pindex)=
	int lower
	int addr
	ichar astr
	ref char px

!	applymemmode(p)

	if ttbasetype[a.mode]=tslice then
		dxstr("((")
		dxstr(strmodec(tttarget[a.mode]))
		dxstr("*)")
		evalunit(a)
		ccstr(".ptr)")
	else
		evalunit(a)
	fi

	dxstr("[(")
	evalunit(pindex)
	dxchar(')')

	lower:=ttlower[a.mode]
	if lower>0 then
		dxchar('-')
		dxint(lower)
	elsif lower<0 then
		dxchar('+')
		dxint(abs lower)
	fi
	dxchar(']')
end

proc do_case(unit p,pindex,pwhenthen,pelse)=
	int loopsw
	int lab_abc,lab_d
	ichar indexstr
	unit w,wt

	loopsw:=p.tag=jdocase

	if loopsw then
		lab_abc:=definelabel()		!start of loop
		lab_d:=createfwdlabel()	!end of case/end of loop
		stacklooplabels(lab_abc,lab_abc,lab_d)
	fi

	wt:=pwhenthen

	indexstr:=nil		
	if wt=nil then doelse fi

	if pindex.tag<>jname then
		cctab(blocklevel)
		ccstr("{")
		ccstr(strmodec(pindex.mode))
		ccstr(" $temp = ")
		evalunitc(pindex)
		ccstrline(";")
		indexstr:="$temp"
	fi

	while wt do
		if wt=pwhenthen then
			ccstr("if (")
		else
			ccstr("else if (",blocklevel)
		fi

		w:=wt.a
		while w do
			if w<>wt.a then
				ccstr(" || ")
			fi
			if pindex then
				ccchar('(')
				if indexstr then
					ccstr(indexstr)
				else
					evalunit(pindex)
				fi
				ccstr("==")

				evalunit(w)
				ccchar(')')
			else
				evalunit(w)
			fi
			w:=w.nextunit
		od
		ccstr(") ")

		evalblock(wt.b)
		wt:=wt.nextunit
	od

	if pelse then

		ccstr("else ",blocklevel)
doelse:
		evalblock(pelse)
	fi

	if indexstr then
		ccstr("}",blocklevel)
	fi


	if loopsw then
		ccstr("goto ")
		ccstrsemi(genclabel(lab_abc))
		definefwdlabel(lab_d)
		unstacklooplabels()
	fi
end

proc do_switch(unit p,pindex,pwhenthen,pelse)=
	int loopsw
	int lab_a,lab_b,lab_c,lab_d, x,y,i
	unit w,wt

	loopsw:=p.tag=jdoswitch
	if loopsw then
		lab_a:=definelabel()
		lab_d:=createfwdlabel()
		stacklooplabels(lab_a,lab_a,lab_d)
	fi

	ccstr("switch (")
	evalunitc(pindex)
	ccstrline(") {")

!scan when statements, o/p statements
	wt:=pwhenthen

	while wt do
		w:=wt.a
		while w do		!for each when expression
			case w.tag
			when jmakerange then
				x:=w.a.value
				y:=w.b.value
			when jconst then
				x:=y:=w.value
			esac

			for i:=x to y do
				cctab(blocklevel)
				ccstr("case ")
				ccint(i)
				if wt.b=nil and i=y then
					ccstrline(":;// ")
				else
					ccstrline(":;")
				fi
			od
			w:=w.nextunit
		od

		++blocklevel
		cctab(blocklevel)
		evalblock(wt.b)
		cctab(blocklevel)
		ccstrsemi("break")
		--blocklevel
		wt:=wt.nextunit
	od

	if pelse then
		cctab(blocklevel)
		ccstr("default: ")
		evalblock(pelse)
	fi

	cctab(blocklevel)
	ccstrline("} //SW")

	if loopsw then
		ccstr("goto ")
		ccstrsemi(genclabel(lab_a))
		definefwdlabel(lab_d)
		unstacklooplabels()
	fi
end

global proc do_switchx(unit p,pindex,pwhenthen,pelse, INT DEFONLY)=
	const maxcaseval=1023
	[0..maxcaseval]byte flags
	int lab_a,lab_b,lab_c,lab_d, x,y,i
	int minval, maxval
	unit w,wt

	lab_a:=definelabel()
	lab_d:=createfwdlabel()
	stacklooplabels(lab_a,lab_a,lab_d)

!first pass collects values

	minval:=maxcaseval+1
	maxval:=-1

	clear flags

	wt:=pwhenthen

	while wt do
		w:=wt.a
		while w do		!for each when expression
			case w.tag
			when jmakerange then
				minval min:=w.a.value
				maxval max:=w.b.value
				for i in w.a.value..w.b.value do
					if i>maxcaseval then gerror("doswx1") fi
					flags[i]:=1
				od

			when jconst then
				minval min:=w.value
				maxval max:=w.value
				if w.value>maxcaseval then gerror("doswx2") fi
				flags[w.value]:=1
			esac
			w:=w.nextunit
		od
		wt:=wt.nextunit
	od

	IF DEFONLY THEN
		ccstr("static int* $jumptable[")
		ccint(maxval+1)
		ccstrline("] = {")
		for i in 0..maxval do
			cctab(blocklevel+1)
			if flags[i] then
				ccstr("&&LL")
				ccint(i)
			else
				ccstr("&&LLelse")
			fi
			if i<maxval then ccstr(",") fi
			ccstrline("")
		od
		cctab(blocklevel)
		ccstrline("};")

		ccstr("    ")
		ccstr(pindex.nextunit.def.name)
		ccstrline("=(void*)$jumptable;")
		ccstrline(";")

		RETURN
	FI

	cctab(blocklevel); ccstr("goto *"); evalunitc(pindex); ccstrline(";")
!scan when statements, o/p statements
	wt:=pwhenthen

	while wt do
		w:=wt.a
		while w do		!for each when expression
			case w.tag
			when jmakerange then
				x:=w.a.value
				y:=w.b.value
			when jconst then
				x:=y:=w.value
			esac

			for i:=x to y do
				cctab(blocklevel)
				ccstr("LL")
				ccint(i)
				ccstrline(":;")
			od
			w:=w.nextunit
		od

		++blocklevel
		cctab(blocklevel)
		evalblock(wt.b)

		cctab(blocklevel); ccstr("goto *"); evalunitc(pindex); ccstrline(";")
		--blocklevel
		wt:=wt.nextunit
	od

	if pelse then
		cctab(blocklevel)
		ccstr("LLelse: ")
		evalblock(pelse)
	fi

	cctab(blocklevel); ccstr("goto *"); evalunitc(pindex); ccstrline(";")

	definefwdlabel(lab_d)
	unstacklooplabels()
end

proc do_goto(unit a)=
	symbol d

	case a.tag
	when jname then
		d:=a.def
		if d.index=0 then
			d.index:=++mlabelno
		fi
		case d.nameid
		when labelid then
			ccstr("goto ")
			ccstrsemi(genclabel(d.index,0))
		else
			gerror_s("Not label/block name: %s",d.name)
		esac
	else
		ccstr("goto *")
		evalunit(a)
		ccstrsemi("")
!		gerror("Can't do goto with label pointer")
	esac
end

proc do_max(unit p,a,b)=
	if issimplec(a) and issimplec(b) then
		dxchar('(')
		evalunit(a)
		dxchar((p.pclop=kmin|'<'|'>'))
		evalunit(b)
		dxchar('?')
		evalunit(a)
		dxchar(':')
		evalunit(b)
		dxchar(')')
	else
		dxstr("m$")

		if ttisreal[a.mode] then
			dxchar('f')
		else
			dxchar('i')
		fi
		dxstr((p.pclop=kmin|"min("|"max("))
		evalunit(a)
		dxchar(',')
		evalunit(b)
		dxchar(')')
	fi
end

proc do_maxto(unit p,a,b)=
!a:=(a>b?a:b)

!quick and dirty version, operands may be evaluated up to 3 times

	evalunit(a)
	ccstr("=(")
	evalunit(a)
	ccchar((p.pclop=kminto|'<'|'>'))
	evalunit(b)
	ccchar('?')
	evalunit(a)
	ccchar(':')
	evalunit(b)
	ccstrsemi(")")
end

function isexpr(unit p)int=
	int expr

	expr:=0
	if jisexpr[p.tag] then expr:=1 fi

	case p.tag
	when jif, jswitch, jcase, jselect then
		if p.mode=tvoid then
			expr:=0
		fi
	esac
	return expr
end

proc do_swap(unit a,b)=

	ccstr("{")

	ccstr(strmodec(a.mode,"temp"))

	ccstr(" = ")
	evalunit(a)
	ccstr("; ")

	evalunit(a)
	ccstr(" = ")
	evalunit(b)
	ccstr("; ")

	evalunit(b)
	ccstr(" = temp; }")
end

proc do_inrange(unit a,b,c)=
	dxstr("(($rtemp=")
	evalunit(a)

	dxstr(", $rtemp >= ")
	evalunit(b)
	dxstr(" && ")
	dxstr("$rtemp <= ")
	evalunit(c)
	dxstr("))")
end

proc do_inset(unit a, p)=
	dxchar('(')

	while p, p:=p.nextunit do
		evalunit(a)
		dxstr(" == ")
		evalunit(p)
		if p.nextunit then
			dxstr(" || ")
		fi
	od
	dxchar(')')
end

proc do_cmpchain(unit p)=
	unit q:=p.a, r
	int i:=1

	dxchar('(')
	repeat
		if i>1 then dxstr(" && ") fi
		evalunit(q)
		r:=q.nextunit
		dxstr(getccopname(ksetcc, p.cmpgenop[i]))
		++i
		evalunit(r:=q.nextunit)
		q:=r

	until q.nextunit=nil

	dxchar(')')
end

proc do_blockcopy(unit a,b)=
	dxstr("memcpy(&")
	evalunit(a)

	if b.tag=jptr then		!ptr op cancelled out by &
		dxstr(",")
		evalunit(b.a)
	else
		dxstr(",&")
		evalunit(b)
	fi
	dxchar(',')
	dxint(ttsize[a.mode])
	dxchar(')')
end

proc do_select(unit pindex,plist,pdefault)=
	int i
	unit q

	q:=plist
	i:=1

	while q do
		dxchar('(')
		evalunit(pindex)
		dxstr("==")
		dxint(i)
		++i
		dxchar('?')
		evalunit(q)
		dxchar(':')
		q:=q.nextunit
	od
	evalunit(pdefault)
	to i-1 do
		dxchar(')')
	od
end

proc do_dotindex(unit a, i)=
	dxstr("call m$getdotindex(")
	evalunit(a)
	dxchar(',')
	evalunit(i)
	dxchar(')')
end

proc do_supportcall(ichar fnname, unit a,b=nil,c=nil,d=nil)=

	dxstr(getsyscallprefix())
	dxstr(fnname)
	dxchar('(')
	evalunit(a)
	if b then
		dxchar(',')
		evalunit(b)
		if c then
			dxchar(',')
			evalunit(c)
			if d then
				dxchar(',')
				evalunit(d)
			fi
		fi
	fi
	dxchar(')')
end

!proc applymemmode(unit p)=
!	if p.memmode then
!		dxchar('(')
!		dxstr(strmodec(p.mode))
!		dxchar(')')
!	fi
!end

proc domaths2(ichar name, unit a,b)=
	dxstr(name)
	dxchar('(')
	evalunit(a)
	dxchar(',')
	evalunit(b)
	dxchar(')')
end

proc do_typepun(unit p, a)=
	int amode:=a.mode, pmode:=p.mode

	if a.tag=jconst then
		if ttisinteger[amode]+ttisreal[amode] and 
			ttisinteger[pmode]+ttisreal[pmode] then
			a.mode:=pmode
			do_const(a)
		elsif ttisinteger[amode]+ttisreal[amode] and ttisref[pmode] then
			dxstr("(")
			dxstr(strmodec(pmode))
			dxstr(")")
			do_const(a)
		else
			gerror("@const")
		fi
	elsif a.tag=jname then
		dxstr("*(")
		dxstr(strmodec(pmode))
		dxstr("*)&")
		evalunit(a)
	else
		dxchar('(')
		dxstr(strmodec(pmode))
		dxchar(')')
		if ttisreal[amode] and ttisinteger[pmode] then
			do_supportcall("tp_r64toi64",a)
		elsif ttisinteger[amode] and ttisreal[pmode] then
			do_supportcall("tp_i64tor64",a)
		elsif ttisinteger[amode] and ttisref[pmode] then
			do_supportcall("tp_i64toref",a)
		elsif ttisref[amode] and ttisinteger[pmode] then
			do_supportcall("tp_reftoi64",a)
		else
			cpl strmode(pmode),"@",strmode(amode)
			gerror("Typepun?")
		fi
	fi
end
