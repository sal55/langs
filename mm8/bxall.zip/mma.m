!project =
	module mm_cli

	module mm_gentcl
	module mm_libtcl
	module mm_blocktcl

!	MODULE DUMMY
	MODULE TC_API
	MODULE TC_DECLS
	MODULE TC_DIAGS
	MODULE TC_TABLES

	module mm_decls

	module mm_diags
!	module mm_diags_dummy
!
	module mm_export_dummy
!	module mm_exportq
!	module mm_exportm

	module mm_lex
	module mm_lib

!	module mm_libsources
	module mm_libsources_dummy
!
	module mm_modules
	module mm_name
	module mm_parse

	module mm_support
	module mm_tables
	module mm_type

	module mc_decls_a		!arm64-generating API
	module mc_lib_a
	module mc_asm_a

	module mc_gen_a			!tcl -> mcl/arm64
	module mc_aux_a
	module mc_conv_a
	module mc_temp_a


!	$sourcepath "c:/px/"
!	$sourcepath "c:/xxx/"
!	import pcl
!	import pclmin
!	import pclrunx

!	$sourcepath "c:/qx/"
!	import qc

!end

!global type int8	= i8
!global type int16	= i16
!global type int32	= i32
!global type int64	= i64
!
!global type word8	= u8
!global type word16	= u16
!global type word32	= u32
!global type word64	= u64
!
!global type char64	= c64
!
!global type real32	= r32
!global type real64	= r64


proc main=
	main2()
end

