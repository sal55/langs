strbuffer sbuffer
ref strbuffer dest=&sbuffer


int currlineno

global proc printmodelist(filehandle f)=
end

global proc printst(filehandle f,ref strec p,int level=0)=
end

proc printstrec(filehandle f,ref strec p,int level)=
end

global proc printstflat(filehandle f)=
end

global proc printcode(filehandle f,ichar caption)=
end

global proc printunit(ref unitrec p,int level=0,ichar prefix="*",filehandle dev=nil)=
end

proc printunitlist(filehandle dev,ref unitrec p,int level=0,ichar prefix="*")=
end

global proc showprojectinfo(filehandle dev)=
end

global proc showlogfile=
CPL "NO DIAGS MODULE"
end

global proc showast(ichar filename)=
end

global proc printsymbol(ref tokenrec lp)=
end

global proc showtimings=
end

