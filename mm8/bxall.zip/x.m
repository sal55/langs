!import y

module xa
module xb

proc main=
	INT A,B,C

	A:=B+C
	PRINTLN "MAIN X"
end

proc start=
	PRINTLN "START X"
end



