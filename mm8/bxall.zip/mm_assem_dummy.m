global func readassemline:unit=
	lex()
	nil
!return assembleline(1)
end

global func readassemblock:unit=
	return nil
end

!global proc domcl_assem(unit pcode)=
!	return when not pcode or pcode.tag<>jassem
!end

!global func checkasmlabel(unit p)int=
!	unit q
!	symbol d
!
!	q:=p.a
!
!	if q and q.tag=jname then
!		d:=q.def
!		if d.nameid=labelid then return d.index fi
!	fi
!
!	0
!end

global proc initassemsymbols=
end

