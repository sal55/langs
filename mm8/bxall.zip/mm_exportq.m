strbuffer sbuffer
ref strbuffer dest=&sbuffer

const expscope=export_scope

global proc writeexports(ichar basefile, modulename)=
	ref strec d
	ref procrec pp
	filehandle f
	ichar outfile

	outfile:=pcm_copyheapstring(changeext(basefile,"q"))

	println "Writing exports file to",outfile

	gs_init(dest)
	for i:=tuser to ntypes do
		d:=ttnamedef[i]
		if d.scope=export_scope and d.name^<>'$' then

			case ttbasetype[i]
			when trecord then
				exportrecord(d)
			else
				wxstr("    global type ")
				wxstr(d.name)
				wxstr(" = ")
				wxstr(strmode(d.mode,0))
				wxline()
			esac
		fi
	od

	pp:=staticlist
	while pp, pp:=pp.nextproc do
		d:=pp.def
		if d.scope=export_scope then
!CPL =D.NAME
!			if not d.istabdata then gerror("Exporting statics to Q") fi
			exportstatic(d)
		fi
	od
	if staticlist then wxline() fi

	pp:=constlist
	while pp, pp:=pp.nextproc do
		d:=pp.def
		if d.scope=export_scope then
			exportconst(d)
		fi
	od
	if constlist then wxline() fi

!	wxstr((passlevel=dll_pass|"importdll "|"importlib "))
	wxstr("importdll ")
!	wxstr("importlib ")
	wxstr(modulename)
	wxstrln(" =")

	pp:=proclist
	while pp, pp:=pp.nextproc do
		d:=pp.def
		if d.scope=export_scope then
			exportproc(d)
		fi
	od

	wxstrln("end importdll")

	f:=fopen(outfile,"wb")
	gs_println(dest,f)
	fclose(f)
end

proc exportstatic(ref strec d)=
	unit p:=d.code, q
	[1024]char str

	return when d.code=nil

	return when p.tag<>jmakelist


!CPL "EXPORTS",P.LENGTH,"LOWER:",TTLOWER[P.MODE]
!PRINTUNIT(P)

	wxstr("global var ")
!	wxmode(d.mode)
!	wxstr(" ")
	wxstr(d.name)
	wxstr(" = (")
	wxstr(strint(ttlower[p.mode]))
	wxstrln(":\\")

	q:=p.a
	for i to p.length do
		wxstr("    ")
		case q.tag
		when jconst then
			case q.mode
			when ti64,tu8 then
				wxstr(strint(q.value))
			when trefchar then
				if strlen(q.svalue)>str.len/2 then gerror("expstr") fi
				wxstr("""")
				convertstring(q.svalue, str)
				wxstr(str)
				wxstr("""")
			ELSE
CPL =STRMODE(Q.MODE)
				GERROR("EXPLIST TYPE?")
			esac
			wxstrln(",")
		else
			gerror("explist?")
		esac
		q:=q.nextunit
	od
	wxstrln(")")
	wxline()
end

proc exportconst(ref strec d)=
	wxstr("global const ")
!	wxmode(d.mode)
!	wxstr(" ")
	wxstr(d.name)
	wxstr(" = ")
	jevalx2(dest,d.code)
	wxline()
end

proc exportproc(ref strec d)=
	ref strec e
	int currmode,needcomma

	wxstr("    ")
	wxstr((d.mode=tvoid|"proc "|"func "))
	wxstr(d.name)
	wxstr("(")

	e:=d.deflist
	needcomma:=0
	currmode:=tvoid

	while e do
		if e.nameid=paramid then
			if needcomma then wxstr(",") fi
			if e.parammode<>byref_param then
				if e.mode<>currmode then
					wxmode(e.mode)
					wxstr(" ")
					currmode:=e.mode
				fi
			else
				wxmode(tttarget[e.mode])
				wxstr(" &")
				currmode:=tvoid
			fi
			wxstr(e.name)
			if e.code then
				wxstr("=")
				if ttisref[e.mode] and e.code.tag=jconst and e.code.value=0 then
					wxstr("nil")
				else
					jevalx2(dest,e.code)
				fi
			fi
			needcomma:=1
		fi
		e:=e.nextdef
	od

	wxstr(")")
	if d.mode then
		wxstr(" => ")
		wxmode(d.mode)
	fi
	wxline()
end

proc wxstr(ichar s)=
	gs_str(dest,s)
end

proc wxstrln(ichar s)=
	gs_strln(dest,s)
end

proc wxline=
	gs_line(dest)
end

proc exportrecord(ref strec d)=
	ref strec e
	ref char flags
	int flag,indent
	const tab="    "

	e:=d.deflist

	wxstr("global type ")
	wxstr(d.name)
	wxstr(" = struct ")
	wxline()

	indent:=1

	while e do
		if e.nameid=fieldid then
			flags:=cast(&e.uflags)
			docase flags^
			when 'S' then
				to indent do wxstr(tab) od
				wxstrln("struct")
				++indent
				++flags
			when 'U' then
				to indent do wxstr(tab) od
				wxstrln("union")
				++indent
				++flags
			else
				exit
			end docase

			to indent do wxstr(tab) od
			wxmode(e.mode)
			wxstr(" ")
			wxstrln(e.name)

			do
				flag:=flags++^
				case flag
				when '*'  then
				when 'E' then
					--indent
					to indent do wxstr(tab) od
					wxstrln("end")
				else
					exit
				esac
			od
		fi

		e:=e.nextdef
	od

	wxstrln("end")
	wxline()
end

proc wxmode(int mode)=
	ichar name
	if mode>=tuser then
		name:=ttnamedef[mode].name
		if name^<>'$' then
			wxstr(name)
			return
		fi
	fi
	wxstr(strmode(mode,0))
end
