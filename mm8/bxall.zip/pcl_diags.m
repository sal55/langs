const fshowpclseqno=1
!const fshowpclseqno=0

strbuffer sbuffer
^strbuffer dest=&sbuffer
int destlinestart

const tab1="    "
const tab2="        "

ref[]byte labeltab

int pclseqno

global ichar longstring					!used in stropnd
global int longstringlen

global proc strpcl(pcl p)=
	[256]char str
	int opcode, n,x,y
	psymbol d, e

	const showformatted=1

	opcode:=p.opcode

!	if fshowpclseqno then
!		psstr(string(pclseqno, "z5"))
!		psstr("  ")
!	end

!CPL "STRPCL", PCLNAMES[P.OPCODE]

!PSSTR("<PCL>")
!PSINT(INT(P.A))
!PSSTR( " ")

!PSSTR(OPNDNAMES[P.OPNDTYPE])

!psstr(strint(getlineno(p.pos),"4"))
!psstr(" ")

	case opcode
	when klabel then
		strlabel(p.labelno,1)

		IF P.POPONE THEN
			PSSTR(" NOT USED")
		FI

		return
	when klabeldef then
		psstr("! ")
		psstr(p.def.name)
		psstr(":")
		return
	when kcomment then
		if p.svalue^ then
			psstr("!")
			psstr(p.svalue)
		ELSE
			PSSTR("! - - -")
		end
		return

	end case

	psstr(tab1)
skiptab:


	case opcode
	when kjumpcc then
		strcpy(str, "jump")
		strcat(str, ccnames[p.condcode])
!		if p.popone then
!			strcat(str, "/1")
!		end
	when ksetcc then
		strcpy(str, "set")
		strcat(str, ccnames[p.condcode])
	when kmaths, kmaths2 then
!		strcpy(str, "maths.")
		strcpy(str, "m.")
		strcat(str, mathsnames[p.mathsop])
	else
		strcpy(str, pclnames[opcode])
	end case

	gs_leftstr(dest,str,9)

	str[1]:=0
	if p.mode then
		strcat(str, strpmode(p.mode, p.size))

		if pclhastype[opcode]=2 then
			strcat(str, "/")
			strcat(str, strmode(p.mode2))
		end
		STRCAT(STR, " ")
	end
	gs_leftstr(dest,str,4)

	str[1]:=0
	n:=pclextra[opcode]
	if n then
		x:=p.x; y:=p.y
		if x or n=2 then			!don't show single 0 value
			strcat(str, "/")
			strcat(str, strint(p.x))
		end

		if n=2 and y then
			strcat(str, "/")
			strcat(str, strint(y))
		end
		STRCAT(STR, " ")
	fi	
	gs_leftstr(dest,str,5)

	if p.opndtype then
		psstr(" ")
		psopnd(p)
	end
	pstabto(40)

	if fshowpclseqno then
		psstr("! ")
		psstr(strint(pclseqno,"z5"))
		psstr("  ")
	end
end

global func strpclstr(pcl p, int buffsize)ichar=
	gs_free(dest)
	gs_init(dest)
	destlinestart:=0
	strpcl(p)
	gs_char(dest,0)

	if dest.length>=buffsize then return "<BIGSTR>" end

	dest.strptr
end

global func writeallpcl:^strbuffer=
!write all pcl code in system by scanning all procs
!pcl code is only stored per-proc
	psymbol d

	labeltab:=pcm_allocz(mlabelno)			!indexed 1..labelno

	gs_init(dest)
	destlinestart:=dest.length

	gs_strln(dest, "!PROC PCL")

!CPL "WRITEALL", =PROCLIST
!	PC_COMMENT("HELLO")
!	PC_COMMENT("HELLO")
!	PC_COMMENT("HELLO")
!
	d:=psymboltable

	while d, d:=d.next do
		if d.nameid=procid then
			currfunc:=d

			psprocsig(d)
			psprocbody(d)

			psstrline("End")
			psline()
		end
	end

	pcm_free(labeltab, mlabelno)

	return dest
end

proc psstr(ichar s)=
	gs_str(dest,s)
end

proc psstrline(ichar s)=
	gs_str(dest,s)
	gs_line(dest)
end

proc psline=
	gs_line(dest)
end

proc psint(int a)=
	gs_str(dest,strint(a))
end

proc psname(psymbol d)=
	gs_str(dest,getfullname(d))
end

proc psprocsig(psymbol d)=
	psymbol e
	byte comma:=0
	int lastmode:=tvoid, m, lastsize:=0, size

	psstr("Proc ")
	psstr(d.name)
	psstr("(")

	e:=d.nextparam

	while e, e:=e.nextparam do
		if comma then psstr(", ") end
		if e.mode<>lastmode then
			lastmode:=e.mode
			lastsize:=e.size
			psstr(strpmode(lastmode, lastsize))
			psstr(" ")
		end
		psstr(e.name)

		comma:=1
	end
	psstr(")")

	if d.mode then
		psstr(strpmode(d.mode, d.size))
	end
	psstrline(" =")


	e:=d.nextlocal
	comma:=0
	while e, e:=e.nextlocal do
!		if e.nameid in [frameid, staticid] then
		psstr(tab1)
		psstr(strpmode(e.mode, e.size))
		psstr(" ")
		psstrline(e.name)
		comma:=1
	end
	if comma then psline() end
end

proc psprocbody(psymbol d)=
	pcl p

	p:=d.pccode
	return unless p

!do first pass populating label table

	while p, p:=p.next do
		if p.opcode<>klabel then
			if p.opndtype=label_opnd then
				labeltab[p.labelno]:=1
			end
		end
	end

	p:=d.pccode
	destlinestart:=dest.length
	pclseqno:=0

	while p, p:=p.next do
		++pclseqno

UNLESS P.OPCODE IN [KSETCALL, KSETARG] THEN
		strpcl(p)
		gs_line(dest)
END
		destlinestart:=dest.length
	end

	psline()
end

global proc strlabel(int labelno,colon=0)=
	psstr("L")
	psint(labelno)
	if colon then
		psstr(":")
	end
	psstr(" ")
end

global proc pstabto(int n)=
	int col:=dest.length-destlinestart
	while n>col do psstr(" "); ++col end
end

proc psopnd(pcl p)=
	static[512]char str
!	static[32]char str
	int length
	psymbol d
	static ichar longstring

	if p=nil then
		return
	end

	case p.opndtype
	when int_opnd then
		psint(p.value)
	when real_opnd then
		if p.xvalue=infinity then
!			fprint @str,"0x#",word@(p.xvalue):"h"
			fprint @str,"infinity"
		else
			print @str,p.xvalue:"e16.16"
		end
		psstr(str)

	when string_opnd then
		length:=p.slength
		if length<str.len/2 then
			psstr("""")
			newconvertstring(p.svalue, str, length)

			psstr(str)
			psstr("""*")
			psint(p.slength)

		else

			if longstring then
				pcm_free(longstring,longstringlen)
			end
			longstringlen:=length*2
			longstring:=pcm_alloc(longstringlen)
			longstring^:='"'
			length:=convertstring(p.svalue, longstring+1)
			(longstring+length+1)^:='"'
			(longstring+length+2)^:=0
			PSSTR(LONGSTRING)
		end

	when mem_opnd then
		d:=p.def
		psstr(p.def.name)

	when memaddr_opnd then
		psstr("&")
		recase mem_opnd

	when label_opnd then
		fprint @str,"## ","#",p.labelno
		psstr(str)

	when no_opnd then
		return

!	when data_opnd then
!		fprint @str,"<Data * # (#)>", p.size,p.svalue
!		psstr(str)
!
	else
		psstr("<PCLOPND?>")
	end case
end

EXPORT func newconvertstring(ichar s, t, int length)int=
!convert string s, that can contain control characters, into escaped form
!return new string in t, so that ABC"DEF is returned as ABC\"DEF
!length is that of s; final length may be up to 4 times as long

!returns actual length of t
	int c
	ichar t0:=t
	[16]char str

	to length do
		case c:=s++^
		when '"' then
			t++^:='\\'
			t++^:='"'
		when 10 then
			t++^:='\\'
			t++^:='n'
		when 13 then
			t++^:='\\'
			t++^:='r'
		when 9 then
			t++^:='\\'
			t++^:='t'
		when '\\' then
			t++^:='\\'
			t++^:='\\'
!		when 0 then
!			t++^:='\\'
!			t++^:='x'
!			t++^:='0'
!			t++^:='0'
!		when 7,8,26,27 then
!			t++^:='<'
!			t++^:=c/10+'0'
!			t++^:=(c rem 10)+'0'
!			t++^:='>'
		elsif c in 32..126 then
			t++^:=c
		else
!			t++^:='\\'			!hex
!			t++^:='x'
!			print @str,c:"z2h"
!			t++^:=str[1]
!			t++^:=str[2]

			t++^:='\\'			!octal
!			t++^:='x'
			print @str,c:"z3x8"
			t++^:=str[1]
			t++^:=str[2]
			t++^:=str[3]
		end case
	end

	t^:=0

	return t-t0
end

global func writepst:ref strbuffer=
	psymbol d, e

	gs_init(dest)

	psstrline("PCL Libs")
	for i to nplibfiles do
		psstrline(plibfiles[i])
	end
	psline()

	psstrline("PROC PC Symbol table")
	psline()

	d:=psymboltable

	while d, d:=d.next do
!CPL "PST", D.NAME
			writepsymbol(d, "25jl")
!
			if d.nameid in [procid, dllprocid] then
!CPL "PROC:", D.NAME
				e:=d.nextparam
				while e, e:=e.nextparam do
					psstr("    ")
					writepsymbol(e, "21jl")
				end

				e:=d.nextlocal
				while e, e:=e.nextlocal do
					psstr("    ")
					writepsymbol(e, "21jl")
				end
			fi
PSLINE()
!		fi
	end
!CPL "DONE PST"
	psline()

	return dest
end

proc writepsymbol(psymbol d, ichar fmt)=
	byte localfile:=0
	[256]char str

	print @str, d.seqno:"4", namenames[d.nameid]
	psstr(str)
	to 8-strlen(namenames[d.nameid]) do psstr(" ") end

	str[1]:=0

	print @str, d.name:fmt
	psstr(str)

	psstr(strpmode(d.mode, d.size))

	if d.nameid=procid then
		psstr(" Pm:")
		psint(d.nparams)
		psstr(" Loc:")
		psint(d.nlocals)
	fi

	if d.isexport then psstr(" Exp") fi
	if d.isimport then psstr(" Imp") fi
	if d.varparams then psstr(" Var:"); psint(d.varparams) fi
!*!	if d.reg then psstr(" "); psstr(regnames[d.reg]) fi
!	if d.hasdot then psstr(" Dot") fi
	if d.isentry then psstr(" ENTRY PT") fi

!	if d.nameid=procid then psstr(" .PCCODE ="); PSSTR(STRINT(CAST(D.PCCODE),"H")) fi
	if d.pccode and d.nameid<>procid then
		psstr(" .PCCODE ="); PSSTR(STRINT(CAST(D.PCCODE),"H"))
		psline()
		writepcldata(d.pccode)
	fi

	psline()
end

proc writepcldata(pcl p)=
	destlinestart:=dest.length
	pclseqno:=0

	while p, p:=p.next do
		strpcl(p)
		gs_line(dest)
		destlinestart:=dest.length
	end

	psline()
end
