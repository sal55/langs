module msys
module mlib
module mclib
module mwindows
module mwindllc

!proc start=
!	CPL "MSYSWIN/START"
!END
