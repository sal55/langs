importdll ee=
	func fred(real)real
end

proc main=
	println fred(100)
end
