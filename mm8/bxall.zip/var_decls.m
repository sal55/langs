!global type symbol    	= ref strec
global type symbol    	= ref void

global type object   	= ref varrec
global type iobject   	= ref object

global macro pr(a,b)	= (a<<16 ior b)

global const varsize  	 	 = varrec.bytes
global const shortvarsize    = shortvarrec.bytes

global record varrec =
!1st 8 bytes
	union
		struct
			word32 refcount
			union
				struct
					byte tag
					byte flags
					union
						word16 usertag
						word16 elemtag
					end
				end
				word32 tagx
			end
		end
		word64 a
	end

!second 8 bytes (and end of short objects)
	union
		int64		value
		real64		xvalue
		word64		uvalue
		ichar		strptr
		object		varptr
		ref byte	ptr
		ref[]int	num
		word64 b
	end

!3rd 8 bytes
	union
		struct
			word32 length
			union
				int32 lower32
				struct
					int16 lower16
					byte bitoffset
					byte intindex
				end
				struct
					int16 neg
					int16 numtype
				end
			end
		end
		int length64
		int lower64
		word64 c
	end

!4th 8 bytes (and end of long objects)
	union
		int64 alloc64
		object varptr2
		int64 upper64
		int32 expon
		struct
			word32 alloc32
			int32 dictitems
		end
		word64 d
	end
end

!global record flatvarrec =
!	u64 a, b, c, d
!
!	word32	refcount	@ a
!	byte	tag			@ a+4
!	byte	flags		@ a+5
!
!	byte	usertag		@ a+6
!	byte	elemtag		@ a+6
!	word32	tagx		@ tag
!	...
!end

global record shortvarrec =			!represents first half of varrec
	[16]byte dummy
end

global record genfieldrec=
	symbol def
	ref genfieldrec nextdef
end

global const maxgenfield=1000
global [maxgenfield]ref genfieldrec genfieldtable
global int ngenfields

global [0..255]object chrtable				!remember single-character objects

global [-256..+256]object smallinttable		!for general int values at runtime
!global [0..+256]object inttable

global const maxintconst=1000
global [maxintconst]object intconsttable	!int constants in sourc code
global int nintconsts

