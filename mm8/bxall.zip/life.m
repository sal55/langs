! life.py -- Conway's Game of Life in Python (version 2)

const n = 40
const m = 80
const g = 66000

[n,m]int b

proc display([n,m]int &b)=
	for i to n do
		for j to m do
			print (b[i,j]|"*"|" ")
		od
		println
	od
end

proc main=
	static [n,m]int nextb
	[n,m]int temp
	int up,down,left,right,count

	b[20,42] := 1
	b[21,41] := 1
	b[22,41] := 1
	b[23,41] := 1
	b[23,42] := 1
	b[23,43] := 1
	b[23,44] := 1
	b[20,45] := 1

	println "Before:"
	display(b)

	for k to g do
		for i to n do
			up := (i<>1|i-1|n)
			down := (i<>n|i+1|1)
			for j to m do
				left := (j<>1|j-1|m)
				right := (j<>m|j+1|1)

				count:= (\
					b[up,   left ] +\
					b[up,   j     ] +\
					b[up,   right] +\
					b[i,    right] +\
					b[down, right] +\
					b[down, j     ] +\
					b[down, left ] +\
					b[i,    left ] )
					nextb[i,j] := (count=2|b[i,j]|(count=3|1|0))
			od
		od
		temp:=b
		b:=nextb
		nextb:=temp
	od
	print "After", g, "generations:"
	display(b)
end
