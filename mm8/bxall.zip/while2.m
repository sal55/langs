importdll msvcrt=
	proc puts(ichar)
	proc printf(ichar,...)
end

proc main=
	int i
	i:=0
	while i<300 million do
		++i
	od

	printf("%lld\n", i);

end
