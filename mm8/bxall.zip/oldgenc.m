
const showpclcode=1
!const showpclcode=0
!const showstackptr=1
const showstackptr=0

const maxoperands=20

global int noperands

global macro zz = noperands
global macro yy = noperands-1
global macro xx = noperands-2
global macro ww = noperands-3

pcl currpcl, nextpcl

global int localmax				!max operands in this function

global const int maxcallargs=20
global const int maxnestedcall=10
global [maxnestedcall, maxcallargs]byte argmodes
global [maxnestedcall, maxcallargs]byte argstack
global [maxnestedcall, maxcallargs]u32  argsizes
global int nccalldepth

int seqno

global proc genmcl(ichar filename)=
	pcl pc

CPL "GEN LINEAR C"
	filehandle f

	gs_init(cdest)
	ccinitline()

	cccomment("Generated C")
	gs_strln(cdest,"#include ""pclhdr.h""")
	gs_line(cdest)

!*!	gendecls()

	pc:=pcstart
	noperands:=localmax:=0

	while pc<=pccurr, ++pc do
		seqno:=pc.seqno
		pc:=convertpcl(pc)			!may update pc is extra ops are consumed
	od

	if noperands then
		CPL("End prog: stack not empty")
	fi

CPL "WRITING",filename
	f:=fopen(filename,"wb")
	gs_println(cdest, f)

	fclose(f)

end

func convertpcl(pcl p)pcl =
!	[1256]char str
!	ichar ss
	int m

!	if showstackptr then
!		ccstr("//                   [")
!		ccint(noperands)
!		ccstr("]")
!		for i to noperands do
!			ccchar(' ')
!			ccstr(pstdnames[stackmodes[i]])
!		od
!		ccsendline()
!	fi

	if showpclcode then
!		ccstr("//                   ")
		ccstr("                   //")
		ccint(noperands)
		ccstr(": ")
		ccstrline(strpclstr(p))
	fi

	dopcl(p)
end

func dopcl(pcl pc)pcl =

!CPL "DOPCL", PCLNAMES[PC.OPCODE]

	switch pc.opcode
	when knop then
		unimpl

	when kload then
		if noperands>=maxoperands then
			cerror("Opnd stack overflow")
		fi
		++noperands
		localmax max:=noperands
		cctab()

		case pc.mode
		when tpblock then
			if pc.opndtype<>mem_opnd then cerror("pushblk/not mem") fi
			ccstacklv(zz, tpu64)
			ccstr(" = &")
			ccopnd(pc)
			ccsemi()
!			setstackmodet(tpu64)

		else
			ccstacklv(zz, pc.mode)
			ccstr(" = ")
			ccopnd(pc)
			ccsemi()
!			setstackmode(pc)
		esac

	when kiload then
		unimpl

	when kiloadx then
		unimpl

	when kstore then
		if pc.mode=tpblock then
			cerror("store block")
		else
			cctab()
			ccopnd(pc,1)
			ccstr(" = ")
			ccstack(zz, pc.mode)
			ccsemi()
		fi
		popcc()

	when kistore then
		unimpl

	when kistorex then
		unimpl

	when kdupl then
		unimpl

	when kdouble then
		unimpl

	when kswapstk then
		unimpl

	when kunload then
		popcc()

	when kopnd then
		unimpl

	when ktype then
		unimpl

	when kloadbit then
		unimpl

	when kloadbf then
		unimpl

	when kstorebit then
		unimpl

	when kstorebf then
		unimpl

	when kcallp then
		do_call(pc)
		--nccalldepth

	when kcallf then
		if pc.mode=tpblock then
			cerror("block = F()")
		else
			cctab()
			ccstacklv(zz-pc.nargs+1, pc.mode)
			ccstr(" = ")
			do_call(pc)
		fi
		--nccalldepth
		++noperands


	when kretproc then
		cctab()
		ccstrline("return;")

	when kicallp then
		--nccalldepth
		unimpl

	when kicallf then
		--nccalldepth
		unimpl

	when kretfn then
		cctab()
		ccstr("return ")
		ccstack(zz, pc.mode);
		ccstrline(";")
		popcc()

	when kjump then
		unimpl

	when kijump then
		unimpl

	when kjumpcc then
		unimpl

	when kjumpt then
		unimpl

	when kjumpf then
		unimpl

	when kjumpret then
		unimpl

	when kjumpretm then
		unimpl

	when ksetcc then
		unimpl

	when kstop then
		unimpl

	when kto then
		unimpl

	when kforup then
		unimpl

	when kfordown then
		unimpl

	when kiswap then
		unimpl

	when kswitch then
		unimpl

	when kswitchu then
		unimpl

	when kswlabel then
		unimpl

	when kendsw then
		unimpl

	when kclear then
		unimpl

	when kassem then
		unimpl

	when kadd then
		dobinop(pc, "+")

	when ksub then
		dobinop(pc, "-")

	when kmul then
		dobinop(pc, "*")

	when kdiv then
		unimpl

	when kidiv then
		unimpl

	when kirem then
		unimpl

	when kidivrem then
		unimpl

	when kbitand then
		unimpl

	when kbitor then
		unimpl

	when kbitxor then
		unimpl

	when kshl then
		unimpl

	when kshr then
		unimpl

	when kmin then
		unimpl

	when kmax then
		unimpl

	when kaddpx then
		unimpl

	when ksubpx then
		unimpl

	when ksubp then
		unimpl

	when kneg then
		unimpl

	when kabs then
		unimpl

	when kbitnot then
		unimpl

	when knot then
		unimpl

	when ktoboolt then
		unimpl

	when ktoboolf then
		unimpl

	when ksqr then
		unimpl

	when ksqrt then
		unimpl

	when ksin then
		unimpl

	when kcos then
		unimpl

	when ktan then
		unimpl

	when kasin then
		unimpl

	when kacos then
		unimpl

	when katan then
		unimpl

	when klog then
		unimpl

	when klog10 then
		unimpl

	when kexp then
		unimpl

	when kround then
		unimpl

	when kfloor then
		unimpl

	when kceil then
		unimpl

	when ksign then
		unimpl

	when katan2 then
		unimpl

	when kpower then
		unimpl

	when kfmod then
		unimpl

	when kincrto then
		unimpl

	when kdecrto then
		unimpl

	when kincrload then
		unimpl

	when kdecrload then
		unimpl

	when kloadincr then
		unimpl

	when kloaddecr then
		unimpl

	when kaddto then
		unimpl

	when ksubto then
		unimpl

	when kmulto then
		unimpl

	when kdivto then
		unimpl

	when kidivto then
		unimpl

	when kiremto then
		unimpl

	when kbitandto then
		unimpl

	when kbitorto then
		unimpl

	when kbitxorto then
		unimpl

	when kshlto then
		unimpl

	when kshrto then
		unimpl

	when kminto then
		unimpl

	when kmaxto then
		unimpl

	when kaddpxto then
		unimpl

	when ksubpxto then
		unimpl

	when knegto then
		unimpl

	when kabsto then
		unimpl

	when kbitnotto then
		unimpl

	when knotto then
		unimpl

	when ktoboolto then
		unimpl

	when ktypepun then
		unimpl

	when kfloat then
		unimpl

	when kfix then
		unimpl

	when ktruncate then
		unimpl

	when kwiden then
		unimpl

	when kfwiden then
		unimpl

	when kfnarrow then
		unimpl

	when kstartmx then
		unimpl

	when kresetmx then
		unimpl

	when kendmx then
		unimpl

	when kproc then
		do_procdef(pc)
		localmax:=0
		noperands:=0

	when ktcproc then
		unimpl

	when kendproc then
		IF NOPERANDS THEN
CCCOMMENT(ADDSTR("******** STACK NOT EMPTY:", STRINT(NOPERANDS)))
!CCCOMMENT("HELLO")
		FI

		ccstrline("}\n")
!		if noperands then
!			CPL "ENDPROC: operand stack not empty"
!
!		fi


	when kistatic then
		unimpl

	when kzstatic then
		unimpl

	when kdata then
		unimpl

	when kparam then
		unimpl

	when klocal then
		unimpl

	when krettype then
		unimpl

	when kvariadic then
		unimpl

	when kaddlib then
		unimpl

	when kextproc then
		unimpl

	when klabel then
		cclabel(pc.labelno)
		ccstrline(":;")
!		unimpl

	when klabeldef then
		unimpl

	when ksetjmp then
		unimpl

	when klongjmp then
		unimpl

	when ksetcall then
		if nccalldepth>=maxnestedcall then cerror("Setcall overflow") fi
		++nccalldepth

	when ksetarg then
		if pc.x>maxcallargs then cerror("Setarg: too many args") fi
!CPL "SETARG", PC.X

		argmodes[nccalldepth, pc.x]:=pc.mode
		argsizes[nccalldepth, pc.x]:=pc.size
		argstack[nccalldepth, pc.x]:=noperands		!index into pcl stack

	when kloadall then
		unimpl

	when keval then
		unimpl

	when kcomment then
		unimpl

	when kendprog then
		cccomment("End of Generated C")

	when kstoresl then
		unimpl

	when kstoresld then
		unimpl

	when ksliceupb then
		unimpl

	when kslicelen then
		unimpl

	when ksliceptr then
		unimpl

	else
unimpl:
		ccstr("Unimpl: ")
		ccstrline(pclnames[pc.opcode])

	end switch

	return pc				!usually return same one, or last consumed if several

end
