export proc charlie=
!	println "BILL",bill
	printf("CHARLIE %p\n", charlie)
end

importdll msvcrt=
	proc puts(ichar)
	proc printf(ichar,...)
end

proc main=
end
