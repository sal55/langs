proc main=
	int i
	i:=0
	while i<1000 million do
!	while i< 100 do
		++i
	od

	println i

end
