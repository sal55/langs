func fred(i64)int=
0
end


proc main=
	int a,b,c,d
	real x,y,z

	fred(123456789876543210)

end
