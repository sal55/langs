global proc var_loadpacked(ref void p,int t,pvariant dest, object ownerobj=nil) =
! p is a direct pointer to a packed type of type t.
! Extract target and store in varrec dest, which should have been freed.
!ownerobj is nil, or points to an array obj of which an element is being accessed
!this is mainly for arrays of structs
	int length
	pvariant q,r
	ref int pp
	object s
	ref char ss

!CPL "LOADPACKED",STRMODE(T)

!	switch t
	switch ttbasetype[t]
	when tpi8 then
		dest.tagx:=tint
		dest.value:=ref i8(p)^

	when tpi16 then
		dest.tagx:=tint
		dest.value:=ref i16(p)^

	when tpi32 then
		dest.tagx:=tint
		dest.value:=ref int32(p)^

	when tpi64,tint then
		dest.tagx:=tint
		dest.value:=ref i64(p)^

	when tpu8 then
		dest.tagx:=tint
		dest.value:=ref byte(p)^

	when tpu16 then
		dest.tagx:=tint
		dest.value:=ref u16(p)^

	when tpu32 then
		dest.tagx:=tint		!BETTER I64
		dest.value:=ref u32(p)^

	when tpu64 then
		dest.tagx:=tword		!BETTER I64
		dest.value:=ref u32(p)^

	when tpr64 then
		dest.tagx:=treal
		dest.xvalue:=ref r64(p)^

	when tpr32 then
		dest.tagx:=treal
		dest.xvalue:=ref r32(p)^

	when tpstringc then
		dest.tagx:=tstring ior hasrefmask
		length:=ttlength[t]
		if length>=2 then		!normal fixed string
			length:=getfslength(p,length)
		else				!assume string basetype: char target (length can be 0)
			length:=1
		fi
!		s:=make_strslicexobj(p,length)
		s:=obj_make_strslicexobj(p,length)
		dest.objptr:=s

	when tpstringz then		!zero-terminated string
		dest.tagx:=tstring ior hasrefmask
		ss:=p
		to ttlength[t] do
			exit when ss^=0
			++ss
		od

		s:=obj_make_strslicexobj(p,ss-ref char(p))
		dest.objptr:=s

	elsecase ttbasetype[t]
	when trefpack,tpref then
		dest.tagx:=trefpack
		dest.uref.ptr:=cast(ref i64(p)^)
		dest.uref.elemtag:=tttarget[t]

!	when tpstruct then
	when tstruct then
		s:=obj_new()
		s.mutable:=1
		s.ustruct.ptr:=p
!	dostruct::
		dest.objptr:=s
		dest.tagx:=tstruct ior hasrefmask
		dest.usertag:=t
		if ownerobj then
			s.objtype:=slice_obj
			s.ustruct.objptr2:=ownerobj
			++ownerobj.refcount
		else
			s.objtype:=extslice_obj
		fi
	when tcarray then
!global function obj_newarray(int elemtype, lower,length)object p=
		s:=obj_newarray(tttarget[t],ttlower[t],ttlength[t])
		s.mutable:=1
		s.uarray.ptr:=p
		dest.objptr:=s
		dest.tagx:=tcarray ior hasrefmask
		dest.usertag:=t
!		if ownerobj then
!			s.objtype:=slice_obj
!			s.ustruct.objptr2:=ownerobj
!			++ownerobj.refcount
!		else
			s.objtype:=extslice_obj
!		fi
	else
		pcmxtypestt("loadpacked",ttbasetype[t],t)
	endswitch
end

!dummy

