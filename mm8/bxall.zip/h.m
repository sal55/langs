importdll msvcrt=
	proc puts(ichar)
	proc printf(ichar,...)
end

proc main=

	int a

	a:=123456
	a:=0x123456

	puts("hello")
!	printf("hello %d\n",  1234)
!	printf(1234, "hello %d\n")

!	for i to 10 do
!		printf("%lld\n", i)
!	od

end

