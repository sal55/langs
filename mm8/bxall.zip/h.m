importdll msvcrt=
	proc puts(ichar)
	proc printf(ichar, ...)
end

proc main=
	puts("hello")
	puts("hello")
	puts("hello")

int a,b,c

end

int d
