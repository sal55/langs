
export record rsystemtime =
	u16 year
	u16 month
	u16 dayofweek
	u16 day
	u16 hour
	u16 minute
	u16 second
	u16 milliseconds
end

export proc os_init=
end

export func os_execwait(ichar cmdline,int newconsole=0,ichar workdir=nil)int =
	0
end

export func os_execcmd(ichar cmdline, int newconsole=0)int =
	0
end

export func os_getch:int=
	0
end

export func os_kbhit:int=
	0
end

export func os_getdllinst(ichar name)u64=
	0
end

export func os_getdllprocaddr(int hinst,ichar name)ref void=
	nil
end

export proc os_initwindows=
end

export proc os_gxregisterclass(ichar classname)=
end

!global function mainwndproc (
!		wt_handle hwnd, wt_uint message, wt_wparam wParam, wt_lparam lParam)int=
!	0
!end

export proc os_setmesshandler(ref void addr)=
end

export func os_getchx:int=
	27
end

export func os_getos=>ichar=
	return "NOOS"
end

export func os_gethostsize=>int=
	return 64
end

export func os_shellexec(ichar opc, file)int=
	return system(file)
end

export proc os_sleep(int a)=
!	Sleep(a)
end

export func os_getstdin:filehandle =
	return fopen("con","rb")
end

export func os_getstdout:filehandle =
	return fopen("con","wb")
end

export func os_gethostname:ichar=
	"?"
end

export func os_getmpath:ichar=
!BART
!	return "C:\\m\\"
	return F"C:\m\" !ABC
!	return "C:@@@@\\m\\" !ABC
end

export func os_clock:i64=
	clock()
end

export func os_ticks:i64=
	clock()
end

export func os_iswindows:int=
	return 1
end

export proc os_getsystime(ref void)=
end

export proc os_peek=
end

export func os_allocexecmem(int n)ref byte=
	nil
end

export func dirlist(ichar filespec, ref[]ichar dest, int capacity, t=1)int=
	0
end

export func os_hpcounter:int a =
!return counter such that successive calls indicate duration in msec
	0
end

export func os_hpfreq:int a =
	0
end

