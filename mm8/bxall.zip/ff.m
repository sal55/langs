proc main=
	cpl fib(10)
end

func fib(int n)int=
	if n <= 1 then
		return n
	fi

	int a := 0
	int b := 1
	int i := 0

	while i < n - 1 do
!		int temp := a
!		a := b
!		b := temp + b
		(a, b) := (b, a + b)
		++i
	od

	return b

end

!func fib(int n)int=
!	int a, b
!
!	if n <= 1 then
!		n
!	else
!		a := 0
!		b := 1
!
!		to n - 1 do
!			(a, b) := (b, a + b)
!		od
!
!		b
!	fi
!end

