record Vector =
	real x
	real y
	real z
end

proc main=
	vector a, b

!	a:=b

	a:=vec(10,20,30)
!!	vec(10,20)
!!	vec(10,20)
!
!	cpl a.x
!	cpl a.y
!	cpl a.z
	printvec("A", a)
end

proc printvec(ichar cap, vector p)=
	println cap,,":", p.x, p.y, p.z
end

function vec(real x, y, z)Vector r=
	r.x := x
	r.y := y
	r.z := z
	return r
end


