proc main=
	int a,b,c,d,i
	real x,y,z

	[2]int aa:=(i64@(3.4), 0)


!	[]int xx:=(10, i64@(real(3.4)))


end
