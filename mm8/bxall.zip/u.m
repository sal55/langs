record date=
	int d,m,y
end

proc main=
	date dd, ee

	dd:=ee


end
