proc main=
	int a,b,c,d,i
	real x,y,z

!	a:=b+c*4567

	a:=b+1

!	puts("hello")
end
