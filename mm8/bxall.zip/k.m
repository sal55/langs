[0..20631]word Q
word carry  = 36243678541
word xcng   = 12367890123456
word xs     = 521288629546311
int indx   = Q.len

function refill:word =
	word h,z

	for i in Q.bounds do
		h := carry iand 1
		z := (Q[i]<<41)>>1 + (Q[i]<<39)>>1 + carry>>1
		carry :=  Q[i]>>23 + Q[i]>>25 + z>>63
		Q[i] := inot (z<<1+h)
	od
	indx:=1
	Q[Q.lwb]
end

function kiss:word =
	supr()+cng()+xxs()
end

function supr:word s=
	if indx <= Q.upb then
		Q[indx++]
	else
		refill()
	fi
end

function xxs:word =
	xs :=xs ixor xs<<13
	xs :=xs ixor xs>>17
	xs :=xs ixor xs<<43
end

function cng:word =
	xcng:=word(6906969069) * xcng + word(123)
end

proc main=
	word x
	const n=150

	for i in Q.bounds do
		Q[i] := cng() + xxs()
	od

	for i to n do
		x:=kiss()
	od

!	println "Does x=4013566000157423768"		!n=1 billion
!	println "Does x=773711063393322406"			!n=100 million
	println "Does x=13955816525102729738"		!n=150 million
	println "     x=",,x
end
