proc main=
	int a,b,c,d
	real x,y,z


	a:=b/128

	a/:=128

	a:=b rem 128

	a rem:= 128

end
