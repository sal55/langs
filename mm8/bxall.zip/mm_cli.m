
global ichar syslibname=""

!macro SHOW(m) = println m
macro SHOW(m) = eval 0

!main production options; passnames are also file extensions for outputs

global enumdata []ichar passnames =
!								Output (when this is the final step)
	(load_pass,		$),
	(parse_pass,	$),
	(fixup_pass,	$),
	(name_pass,		$),
	(type_pass,		$),

	(ma_pass,		"ma"),			! .ma     These are are special
	(getst_pass,	"list"),		! .list
	(getproj_pass,	"proj"),		! .prog

	(pcl_pass,		"pcl"),			! .pcl (?)
	(mcl_pass,		"asm"),			! .asm
	(asm_pass,		"asm"),			! .asm
	(obj_pass,		"obj"),			! .obj (via .asm and aa)
	(dll_pass,		"dll"),			! .dll
	(exe_pass,		"exe"),			! .exe
	(mx_pass,		"mx"),			! .mx
	(run_pass,		"(run)"),		! run in-memory
end

enumdata []ichar optionnames, []byte optionvalues =

!special outputs
	(ma_sw,			"ma",			ma_pass),
	(getst_sw,		"getst",		getst_pass),
	(getproj_sw,	"getproj",		getproj_pass),

!normal production outputs
	(load_sw,		"load",			load_pass),
	(parse_sw,		"parse",		parse_pass),
	(fixup_sw,		"fixup",		fixup_pass),
	(name_sw,		"name",			name_pass),
	(type_sw,		"type",			type_pass),
	(pcl_sw,		"p",			pcl_pass),
	(mcl_sw,		"mcl",			mcl_pass),
	(asm_sw,		"a",			asm_pass),
	(obj_sw,		"obj",			obj_pass),
	(dll_sw,		"dll",			dll_pass),
	(dll2_sw,		"d",			dll_pass),
	(exe_sw,		"exe",			exe_pass),		!default
	(mx_sw,			"mx",			mx_pass),
	(run_sw,		"r",			run_pass),		!default with ms.exe

	(sys_sw,		"sys",			2),
	(minsys_sw,		"min",			1),
	(nosys_sw,		"nosys",		0),
	(clinux_sw,		"linux",		0),

	(noopt_sw,		"no",			0),
	(nopeephole_sw,	"nopeep",		0),
	(noregoptim_sw,	"noregs",		0),
	(peephole_sw,	"peep",			0),
	(regoptim_sw,	"regs",			0),
	(opt0_sw,		"o0",			0),
	(opt1_sw,		"o1",			1),
	(opt2_sw,		"o2",			2),
	(opt3_sw,		"o3",			3),

!diagnostic outputs
	(ast1_sw,		"ast1",			0),
	(ast2_sw,		"ast2",			0),
	(ast3_sw,		"ast3",			0),
	(showpcl_sw,	"showpcl",		0),
	(showasm_sw,	"showasm",		0),
	(st_sw,			"st",			0),
	(stflat_sw,		"stflat",		0),
	(types_sw,		"types",		0),
	(showmodules_sw,"modules",		0),
	(pst_sw,		"pst",			0),

	(shortnames_sw,	"shortnames",	0),


	(time_sw,		"time",			0),
	(v_sw,			"v",			2),
	(vv_sw,			"vv",			3),
	(quiet_sw,		"q",			0),

	(csize_sw,		"cs",			1),
	(esize_sw,		"es",			2),
	(size_sw,		"ss",			3),

	(help_sw,		"h",			0),
	(help2_sw,		"help",			0),
	(ext_sw,		"ext",			0),
	(out_sw,		"o",			0),
	(outpath_sw,	"outpath",		0),
	(unused_sw,		"unused",		0),

	(norip_sw,		"norip",		0),
	(himem_sw,		"himem",		2),
end


byte msfile

global const logfile="mx.log"

ichar outext=""				!for reporting of primary o/p file

global int startclock, endclock
global int cmdskip

global ichar inputfile

global int loadtime
global int parsetime
global int resolvetime
global int typetime
global int ctime
global int compiletime

global proc main=
!STOP
!proc main=
	unit p,q,r
	int m,fileno,ntokens,t,tt

!cpl "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
!
CPL =STREC.BYTES
CPL =PSTREC.BYTES
!CPL =MCLREC.BYTES
!CPL =unitrec.bytes
!CPL =MCLOPNDREC.bytes
!CPL =JTAGNAMES.LEN
!CPL =pclrec.bytes
!CPL =pclopndrec.bytes

!for s in pclnames do
!	fprintln "proc px_#*(pcl p) =", s
!	println "\tunimpl(p)"
!	println "end"
!	println
!end

!for s in jtagnames do
!	fprintln "\twhen j# then", s
!	fprintln "\t\ttx := do_#(p)", s
!	println
!end
!
	startclock:=os_clock()
	initdata()

	getinputoptions()

!CPL =FREGOPTIM
!CPL =FPEEPHOLE
!CPL =HIGHMEM

	showcompilemess()

! Do early passes common to all options

	loadproject(inputfile)

	do_parse()
	do_name()
	do_type()

! Special outputs can be done at this point
	do_writema(inputfile)	when passlevel=ma_pass			! terminates
	do_getinfo(inputfile)	when passlevel in [getst_pass, getproj_pass]		! terminates
	do_writeexports()		when passlevel=dll_pass

!CPL =PASSNAMES[PASSLEVEL]

	case passlevel
	when pcl_pass then
		do_genpcl()

	when mcl_pass, asm_pass then
!CPL $LINENO
		do_genmcl()
!CPL $LINENO

	when obj_pass then
		do_writeobj()	

	when exe_pass then
		do_writeexe()	

	when dll_pass then
		do_writedll()	

	when mx_pass then
		do_writemx()	

	when run_pass then
		do_run()

	end case

	showsurveys()

!CPL $LINENO
	do_outputs()
!CPL $LINENO
	showlogfile()

!CPL $LINENO
	showtimings() when fshowtiming

	if fverbose=3 then println "Finished." end

end

proc showcompilemess=
	if fverbose>=1 and not msfile then
		fprint "Compiling # to #",inputfile,changeext(outfile,(ctarget|"c"|passnames[passlevel]))
		print $,fregoptim, fpeephole
		println
	end
end

proc do_parse=
!	if fverbose=3 then println "PARSE" end

	return unless passlevel>=parse_pass

	int tt:=clock()

	for i to nmodules do
		parsemodule(modules[i])
	end
	parsetime:=clock()-tt

	if passlevel>=fixup_pass then
!		if fverbose=3 then println "FIXUP" end
		fixusertypes()
	end

	fixstartprocs()
!
	if fshowast1 then showast("AST1") end
end

proc do_name=
!	if fverbose=3 then println "NAME" end
	return unless passlevel>=name_pass

	int tt:=clock()
	rx_typetable()

	for i:=2 to nmodules do
		rx_module(i)
	end
	rx_module(1)
	resolvetime:=clock()-tt

	if fshowast2 then showast("AST2") end
end

proc do_type=
!	if fverbose=3 then println "TYPE" end

	return unless passlevel>=type_pass
	int tt:=clock()
	tx_typetable()

	for i:=1 to nmodules do
		tx_module(i)
	end
	tx_allprocs()
	typetime:=clock()-tt
	if fshowast3 then showast("AST3") end
end

proc initdata=
	imodule pm
	ifile pf

	pcm_init()
	lexsetup()
	init_tt_tables()
	initbblib()

	pm:=pcm_allocz(modulerec.bytes)

	pm.name:="PROGRAM"

	stprogram:=createdupldef(nil,addnamestr("$prog"),programid)
	pm.stmodule:=stprogram
	modules[0]:=pm

!*!	igetmsourceinfo:=cast(mgetsourceinfo)

!	idomcl_assem:=cast(domcl_assem)
!	igethostfn:=cast(findhostfn)
	if assemtype='GAS' then highmem:=2 end



end

proc getinputoptions=
	int paramno,pmtype,sw,extlen
	ichar name,value,ext
	[300]char filespec

!	if tc_useruntcl then
!		passlevel:=runtcl_pass
!		fverbose:=0
!	end
	paramno:=1

	if eqstring(extractfile(os_gethostname()),"ms.exe") then
		msfile:=1
		fverbose:=0
FREGOPTIM:=1
		do_option(run_sw, "")
	end

	while pmtype:=nextcmdparamnew(paramno,name,value,"m") do
		case pmtype
		when pm_option then

			convlcstring(name)
			for sw to optionnames.len do
				if eqstring(name,optionnames[sw]) then
					do_option(sw,value,paramno)
					exit
				end
			else
				println "Unknown option:",name
				stop 99
			end
		when pm_sourcefile then
			if inputfile then
				loaderror("Specify one lead module only")
			end
			convlcstring(name)
			inputfile:=pcm_copyheapstring(name)

!CPL =PASSNAMES[PASSLEVEL]

			if passlevel= run_pass then
				cmdskip:=paramno-1+$CMDSKIP
!CPL "EXITG1"
				exit
			end

		when pm_libfile then
			loaderror("Lib files go in module headers")
		else
			loaderror("Invalid params")
		end case

	end

	if passlevel=0 then
		if not ctarget then
			passlevel:=exe_pass
			outext:="exe"
		else
			passlevel:=mcl_pass
			outext:="c"
		end
	end

	case passlevel
	when obj_pass, dll_pass then
		highmem:=2
	when mcl_pass then
!*!		if assemtype='NASM' then highmem:=2 end
	when mx_pass, run_pass then
		highmem:=0
	end case

	if inputfile=nil then
		showcaption()
		println "Usage:"
		println "   ",cmdparams[0]," prog[.m]     Compile prog.m to prog.exe"
		println "   ",cmdparams[0]," -h           Show all options"
		stop

	else
!default output
		outfile:=pcm_copyheapstring(inputfile)

		if destfilename then
			outfile:=destfilename
		end

		if destfilepath then
			strcpy(filespec,destfilepath)
			strcat(extractfile(filespec), outfile)
			outfile:=pcm_copyheapstring(filespec)	
		end
	end

	ext:=extractext(inputfile)
	extlen:=strlen(ext)
	strcpy(filespec, changeext(cmdparams[0],ext))
	convlcstring(filespec)
	if eqstring(filespec, inputfile) and passlevel=exe_pass then
		strcpy(&filespec[1]+strlen(filespec)-extlen-1, "2.m")
		outfile:=pcm_copyheapstring(filespec)
		println "New dest=",outfile
	end

!*!	tcl_setflags(highmem:highmem, shortnames:fshortnames)
!*!	tcl_cmdskip(cmdskip)
!*!	if msyslevel=2 then pfullsys:=1 end

end

proc do_option(int sw, ichar value, int paramno=0)=
	static byte outused, outpathused
	byte newpass

!CPL "DOOPTION", OPTIONNAMES[SW], PASSLEVEL

	if sw in ma_sw..run_sw then
		newpass:=optionvalues[sw]
		if passlevel and newpass<>passlevel then
			loaderror("Conflicting pass:", optionnames[sw])
		end
		passlevel:=newpass
		outext:=passnames[sw]

		return
	end

	if sw in ast1_sw..pst_sw then
		fshowdiags:=1
	end

	case sw
	when ast1_sw then fshowast1:=1
	when ast2_sw then fshowast2:=1
	when ast3_sw then fshowast3:=1
	when showasm_sw then fshowasm:=1
	when showpcl_sw then fshowpcl:=1
	when st_sw then fshowst:=1
	when pst_sw then fshowpst:=1
	when stflat_sw then fshowstflat:=1
	when types_sw then fshowtypes:=1
	when showmodules_sw then fshowmodules:=1

	when clinux_sw then clinux:=1

	when sys_sw, minsys_sw, nosys_sw then msyslevel:=optionvalues[sw]

	when noopt_sw then fpeephole:=fregoptim:=0
	when nopeephole_sw then fpeephole:=0
	when noregoptim_sw then fregoptim:=0
	when peephole_sw then fpeephole:=1
	when regoptim_sw then fregoptim:=1

	when time_sw then fshowtiming:=1
	when v_sw, vv_sw, quiet_sw then fverbose:=optionvalues[sw]
	when csize_sw, esize_sw, size_sw then fcodesize:=optionvalues[sw]

	when help_sw, help2_sw then showhelp(); stop
	when ext_sw then dointlibs:=0

	when out_sw then
		if outpathused then loaderror("mixed out/path") end
		destfilename:=pcm_copyheapstring(value)
		outused:=1

	when outpath_sw then
		if outused then loaderror("mixed out/path") end
		if (value+strlen(value)-1)^ not in ['\\','/'] then
			loaderror("Path needs to end with \\ or /")
		end
		destfilepath:=pcm_copyheapstring(value)
		outpathused:=1

	when unused_sw then fcheckunusedlocals:=1

	when shortnames_sw then fshortnames:=1

	when norip_sw, himem_sw then highmem:=optionvalues[sw]

	when opt0_sw then fregoptim:=fpeephole:=0
	when opt1_sw then fregoptim:=1; fpeephole:=0
	when opt2_sw then fregoptim:=0; fpeephole:=1
	when opt3_sw then fregoptim:=1; fpeephole:=1

	end case

end

proc showcaption=
	println "M Compiler [M8.0]", $date, $time
end

global proc showhelp=
	println strinclude(langhelpfile)
end

proc do_writeexports=
	[300]char str

	strcpy(str, extractbasefile(outfile))
	writeexports(outfile, changeext(str, "dll"))
!	stop
end

func getoutfilename(ichar file,ext)ichar=
	return pcm_copyheapstring(changeext(file,ext))
end

proc fixstartprocs=
!make sure each module has a start proc
!make sure the lead module has a main proc
	imodule ms
	isubprog ps
	symbol d
	unit p, q
	int s

	for i to nsubprogs do
		ps:=subprogs[i]
		if ps.mainmodule=0 then
			ps.mainmodule:=ps.firstmodule
		end
	end


	for i to nmodules do
		ms:=modules[i]
		if ms.ststart then
			subproghasstart[ms.subprogno]:=1
		end
	end

	for i to nmodules do
		ms:=modules[i]
		if ms.ststart=nil then
			s:=ms.subprogno
			if subproghasstart[s] and subprogs[s].mainmodule=i then
				ms.ststart:=addstartproc(ms.stmodule,"start", program_scope,i)
!				ms.ststart.pclinfo:=pcm_allocnfz(pclinforec.bytes)
			end
		end

	end
end

func addstartproc(symbol owner, ichar name, int scope,moduleno)symbol stproc=
	stproc:=getduplnameptr(owner,addnamestr(name),procid)
	stproc.scope:=scope
	stproc.moduleno:=moduleno
	stproc.subprogno:=moduletosub[moduleno]
	stproc.code:=makeblock(nil)
	adddef(owner,stproc)
	addlinear(stproc)

	return stproc
end

PROC SHOWSURVEYS=
!
!CPL "Read Units:   ", NREADUNITS:"s,12jr"
!CPL "Tower levels: ", NTOWER:"S,12JR"
!CPL "Early returns:", NEARLYRET:"S,12JR"
!CPL "All Bins:     ", NALLBINS:"S,12JR"
!!CPL "All Adds:     ", NALLADDS:"S,12JR"
!CPL "Simple Bins:  ", NSIMPLEBINS:"S,12JR"
!
!CPL =NALLUNITS
!CPL =NCONSTUNITS
!CPL =NNAMEUNITS
!CPL =NSOLOUNITS, NSOLOUNITS-(NCONSTUNITS+NNAMEUNITS)
!CPL =NONEUNITS
!CPL =NUNITS0
!CPL =NUNITS1
!CPL =NUNITS2
!CPL =NUNITS3

!CPL =MLABELNO

!CPL =NALLEXPR
!CPL =NFASTEXPR

!CPL =NALLGENPCHIST[0]
!CPL =NALLGENPCHIST[1]
!CPL =NALLGENPCHIST[2]
!CPL =NALLGENPCHIST[3]
END

proc do_genpcl=
!CPL "GENPCL/////"
	if not pclpresent then loaderror("No PCL") end
	genpcl()
end

proc do_genmcl=

	if not mclpresent then loaderror("No MCL") end

	genpcl()

!CPL "SS", $lineno
	genmcl()
!CPL "SS", $lineno
end

proc do_writeobj=
	CPL "WRITEOBJ NOT READY"
end

proc do_writeexe=
	^strbuffer ss

	genpcl()
	genmcl()
	
CPL "GENSS:"
	genss()

CPL "WRITEEXE:"
!os_getch()
	writeexe(changeext(outfile, "exe"), 0)
!	CPL "WRITEEXE NOT READY"
end

proc do_writedll=
	^strbuffer ss

	genpcl()
	genmcl()
	
	genss()

!CPL "WRITEDLL:"
!os_getch()
	writeexe(changeext(outfile, "dll"), 1)
!	CPL "WRITEEXE NOT READY"
end

proc do_writemx=
!	CPL "WRITEMX NOT READY"
	genpcl()
	genmcl()
	
	genss()

	writemcx(changeext(outfile, "mx"))
!	CPL "WRITEEXE NOT READY"
end

proc dowritepcl=
	ichar filename
	^strbuffer pclstr
	filehandle f

	pclstr:=writeallpcl()

	filename:="PCL"

	if fverbose>=2 then println "Writing PCL" end

	f:=fopen(filename, "w")
	gs_println(pclstr, f)
	fclose(f)

	gs_free(pclstr)
end

proc dowritepst=
	ichar filename
	^strbuffer pststr
	filehandle f

!CPL "WRITING PST"
	pststr:=writepst()

	filename:="PST"

	if fverbose>=2 then println "Writing PST" end

	f:=fopen(filename, "w")
	gs_println(pststr, f)
	fclose(f)

	gs_free(pststr)
end

proc dowriteasm=
	ichar filename
	^strbuffer asmstr
	filehandle f

!CPL "-----------WRITE MCL"

!	if assemtype='NASM' then
!		phighmem:=2
!	end

	asmstr:=writeasm()

	STOP when asmstr=nil

	filename:=changeext(outfile, "asm")

	if fverbose>=2 then println "Writing ASM", filename end

	f:=fopen(filename, "w")
	gs_println(asmstr, f)
	fclose(f)

	gs_free(asmstr)
end

proc do_run=
!this to run native code, not interpreter
!	loaderror("No RUN")

	genpcl()

	genmcl()
	genss()
	runlibfile("dummy", cmdskip)

end

proc do_outputs=
!Any diagnostic or requested textual outputs
!These will be written to a dedicated file here
!If appearing in a composite log file, then they are appended ther
!Some stuff like 'showproject info' is only done there, direct to logfile
!CPL "DOOUT------------", =FSHOWPCL, =passlevel, =PCL_PASS

	if fshowpcl and passlevel>=pcl_pass then
		dowritepcl()
	end

!'mcl'/'fshowasm' is also used for C target from backend, so adjust file exts
	if fshowasm and passlevel>=mcl_pass or passlevel=asm_pass then
!		CPL "WRITEMCL"
		dowriteasm()
	end

	if fshowpst and passlevel>=pcl_pass then
		dowritepst()

	end

!	if fshowast3 then showast("AST3") end
!	if fshowss and passlevel>=obj_pass then
!
!	end

end
