global function str_makex(ichar s, int length,allocated)object=
!create a variant string from given string
!string is already on the heap
	ref char t
	object p

!	if length=-1 then
!		length:=strlen(s)
!	fi

	p:=obj_new(vstring)

	if length=0 then
		p.strptr:=nil
	else
		p.strptr:=s
		p.length:=length
		p.alloc64:=allocated
	fi
	p.mutable:=1

	return p
end

function string_maken(int length)object=
!create an empty, uninitialised string of given length
	object p

	p:=obj_new(vstring)

	if length then
		p.strptr:=pcm_alloc(length)
	fi
	p.mutable:=1
	p.length:=length
	p.alloc64:=allocbytes
	return p
end

global function string_add(object a,b)object c=
	int alen,blen

	alen:=a.length
	blen:=b.length

	if alen=0 then
		if blen then
			c:=var_share(b)
		else
			c:=string_make("")
		fi

	elsif blen=0 then		!x+"" use x unchanged
		c:=var_share(a)
	else 				!x+y: need to do some actual work!
		c:=string_maken(alen+blen)
		memcpy(c.strptr,a.strptr,alen)
		memcpy(c.strptr+alen,b.strptr,blen)
	fi
!CPL "ADDED STR",TTNAME[C.

	return c
end

global function string_equal(object x,y)int =
!return 1 if strings in x,y are equal, otherwise 0
	int n,res
	object px,py

	if x=y then
		res:=1
	else
		n:=x.length
		if n<>y.length then
			res:=0
		elsif n=0 then
			res:=1
		else
			res:=cmpstringn(x.strptr,y.strptr,n)=0
		fi
	fi

!	var_unshare(x)
!	var_unshare(y)

	return res
end

global function string_compare(object x,y)int =
!return -1/0/+1
	return cmpstring_len(x.strptr, y.strptr, x.length, y.length)
end

function cmpstring_len(ref char s,t,int slen,tlen)int =
!compare the given strings with these lengths, and return -1,0,1

	if slen=0 then
		if tlen=0 then
			return 0		!empty:empty
		else
			return -1		!empty:str
		fi
	elsif tlen=0 then	!str:empty
		return 1
	else
		if slen=tlen then
			if slen=1 then
				if s^<t^ then return -1
				elsif s^>t^ then return 1
				else
					return 0
				fi
			fi
			return cmpstringn(s,t,slen)
		else
			return cmpstring(convCstring(s,slen),convCstring(t,tlen))
		fi
	fi
!0
end

function convCstring(ref char svalue,int length)ref char =
! a contains a string object which is a NON-zero-terminated string.
! Set up a pointer to a proper zero-terminated one and return that.
! This uses a ring of 3 static string objects it will only work for strings up to
! a certain length, and only if not more than 3 are needed for any single call.

	const strbufflen=2000
	static [0:strbufflen]char strbuffer1
	static [0:strbufflen]char strbuffer2
	static [0:strbufflen]char strbuffer3
	static int strindex=0		!index of current buffer: cycles between 0,1,2
	static [0:]ref [0:]char table=(
		&strbuffer1,&strbuffer2,&strbuffer3)
!	&strbuffer4,&strbuffer5,&strbuffer6)
	ref[0:]char p

	if length>=strbufflen then
		pcerror("ConvCstring>=2000")
	fi

	if svalue=nil then
		return ""
	fi

	if ++strindex=table.len then
		strindex:=0
	fi
	p:=table[strindex]
	memcpy(p,svalue,length)
!	(p+length)^:=0
	p^[length]:=0
	return cast(p)
!NIL
end

global function string_dupl(object a)object c=
	int length:=a.length
	ichar s
!CPL "DUPL STR"

	if length then
		s:=pcm_alloc(length)
		memcpy(s, a.strptr, length)
		return str_makex(s, length, allocbytes)
	else
		return str_makex(nil, 0, 0)
	fi
end
