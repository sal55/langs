proc main=
	filehandle f

	if ncmdparams=0 then stop fi
	print cmdparams[1],,": "

	f:=fopen(cmdparams[1],"rb")
	println getfilesize(f):"s,"
	fclose(f)

end
