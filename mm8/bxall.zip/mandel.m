const bailout=16.0
const max_iterations=5000

function mandelbrot(real x,y)int=
	int i
	real cr,ci,zi,zr,temp
	real zi2,zr2

	i:=0
	cr:=y-0.5
	zi:=zr:=0.0

	do
		++i
		temp:=zr*zi
		zr2:=sqr zr
		zi2:=sqr zi
		zr:=zr2-zi2+cr
		zi:=temp*2.0+x
		if zi2+zr2>bailout then
			return 1
		fi
		if i>max_iterations then
			return 0
		fi
	od
	return 0
end

proc main=
	int x,y,n

!	to 2 do
		for y:=-39 to 38 do
			println
			for x:=-39 to 39 do
				n:=mandelbrot(x/40.0,y/40.0)
				print (n|" "|"*")
			od
		od
!	od
end


