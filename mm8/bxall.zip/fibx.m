proc main=
int i:=38
	println i,fib(i)
end

func fib(int n)int=
	if n<3 then
		1
	else 
		fib(n-1)+fib(n-2)
	fi
end

