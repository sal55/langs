array[0..20631]word Q
word carry  = 36243678541
word xcng   = 12367890123456
word xs     = 521288629546311
int indx   = Q.len

function refill:word =
	word h,z

	for i in Q.bounds do
			h := carry iand 1
			z := (Q[i]<<41)>>1 + (Q[i]<<39)>>1 + carry>>1
			carry :=  Q[i]>>23 + Q[i]>>25 + z>>63
			Q[i] := inot (z<<1+h)
	od
	indx:=1
	Q[Q.lwb]
end

macro kiss =	supr+cng+xxs

macro supr =
	if indx <= Q.upb then
		Q[indx++]
	else
		refill()
	fi

macro xxs = (	xs :=xs ixor xs<<13;	xs :=xs ixor xs>>17;	xs :=xs ixor xs<<43)

macro cng=xcng:=word(6906969069) * xcng + word(123)

proc main=
	word x

	for i in Q.bounds do
		Q[i] := cng + xxs
	od

!	to 10'000 do
	to 100 million do
		x:=kiss
	od

	println "Does x=4013566000157423768"
	println "     x=",,x
end
