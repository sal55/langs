func fib(int n)int=
	if n<3 then
		1
	else 
		fib(n-1)+fib(n-2)
	fi
end

proc main=
	for i to 39 do
		println i,fib(i)
	od
	println
	println
end


