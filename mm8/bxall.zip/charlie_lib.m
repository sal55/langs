importdll charlie =
    proc charlie()
    proc main()
end importlib

