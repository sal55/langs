const dollar="$"

!global int mlineno

!global unit nilunit
global int blocklevel

global const cbufferlen=4096				!needs to be same size as exprbuffer
[cbufferlen]char clinebuffer
global ref char clineptr, clineend

global proc cccomment(ichar s=nil)=
!comment that is appended to current line
	ccstr("/* ")
	ccstr(s)
	ccstr(" */")
	ccsendline()
end

global proc ccblank=
	ccsendline()
end

global proc cclinecomment(ichar s)=
	cccomment(s)
end

global proc ccchar(int c)=
	clineptr^:=c
	++clineptr
end

global proc cctab(int level=0)=
	to level*4 do
		clineptr++^:=' '
	od
end

global proc ccstr(ref char s,int level=0)=
	if level then
		cctab(level)
	fi

	while s^ do
		clineptr++^:=s++^
	od
end

global proc ccstrline(ichar cstr)=
	ccstr(cstr)
	ccsendline()
end

global proc ccstrsemi(ichar cstr)=
	ccstr(cstr)
	ccchar(';')
	ccsendline()
end

global proc ccstrsemiu(unit p)=
	evalunit(p)
	ccchar(';')
	ccsendline()
end

global proc ccsendline=
	clineptr^:=0
	gs_strln(dest,&.clinebuffer)
	ccinitline()
end

global proc ccint(int a)=
	ccstr(strint(a))
end

global proc ccinitline=
	clineptr:=&.clinebuffer
	clineend:=clineptr+cbufferlen-1
end

global function strmodec(int m,ichar name="",int addtab=1)ichar=
	static [1024]char str
	ref char oldlineptr

	oldlineptr:=clineptr
	clineptr:=&.str

	strmodec2(m,name,addtab)
	clineptr^:=0

	clineptr:=oldlineptr
	return &.str
end

global proc strmodec2(int m,ichar name="",int addtab=1)=
!convert type p (which is a kunit) into a C-typespec string
!When a name is associated with the type (decl etc), this must be supplied, as a complex
!type will be wrapped around the name
	ichar suffix,sp,spsuffix
	[1024]char str
	[1024]char buffer
	int target

	if name and name^ then
		suffix:=name
		strcpy(&.str," ")
		strcat(&.str,name)
		spsuffix:=&.str
		sp:="  "
		case name^
		when '[','(','*' then
	lab1:
!			sp:=" "
			sp:=""
		else
			if not addtab then goto lab1 fi
		esac
	else
		sp:=suffix:=spsuffix:=""
	fi

	case ttbasetype[m]
	when ti32,tu32,ti64,tu64,tr32,tr64,tvoid then
		ccstr(strmodex(m))
		ccstr(spsuffix)
	when tref then
		case ttbasetype[tttarget[m]]
		when tproc then
			if tttarget[m]=tproc then			!placeholder version
				ccstr("REF PROC")
				ccstr(suffix)
			else
				ccstr(strprocsig(ttnamedef[m],suffix,0))
			fi
		when tlabel then
			ccstr("int *")
			ccstr(spsuffix)
		else
			target:=tttarget[m]
			if ttbasetype[target]=tarray then
	!			sprintf(&.buffer,"(*%s)",suffix)
				fprint @&.buffer,"(*#)",suffix
			else
				fprint @&.buffer,"*##",sp,suffix
			fi
			strmodec2(target,&.buffer)
		esac

	when tarray then
		if ttlength[m] then
	!		sprintf(&.buffer, "%s[%lld]",suffix,ttlength[m])
			fprint @&.buffer, "#[#]",suffix,ttlength[m]
		else
	!		sprintf(&.buffer, "%s[]",suffix)
			print @&.buffer,suffix,,"[]"
		fi
	
		strmodec2(tttarget[m],&.buffer)
	when trecord then
	
		ccstr("struct ")
		ccstr(getfullnamec(ttnamedef[m]))
		ccstr(spsuffix)

	when tslice then
		ccstr("Slice ")
		ccstr(spsuffix)
	else
		ccstr(strmodex(m))
		ccstr(spsuffix)
	esac
end

function strmodex(int m)ichar=
!return friendlier names for standard types
	case ttbasetype[m]
	when ti32 then return "i32"
	when ti64 then return "i64"
	when ti8 then return  "i8"
	when ti16 then return "i16"
	when tu32 then return "u32"
	when tu64 then return "u64"
	when tu8 then return  "byte"
	when tu16 then return "u16"
	when tr32 then return "r32"
	when tr64 then return "r64"
	when tc8 then return "u8"
	when tc64 then return "u64"
	else
		return strmode(m)
	esac
	return ""
end

global function strprocsig(symbol p,ichar name=nil,int showparamnames=1)ichar=
	[512]char paramstr
	[512]char buffer
	symbol pm
	int rettype
	ichar stdcall,scallback

	pm:=p.paramlist			!paramlist
	rettype:=p.mode

	strcpy(&.paramstr,"(")

	if pm then
		while pm do
			strcat(&.paramstr, strmodec(pm.mode,(showparamnames|pm.name|""),0))
			pm:=pm.nextparam
			if pm then
				strcat(&.paramstr,",")
			fi
		od
		if p.varparams then
			if p.paramlist then
				strcat(&.paramstr,",")
			fi
			strcat(&.paramstr,"...")
		fi
		strcat(&.paramstr,")")
	else
!		if p.varparams then
!			strcat(&.paramstr,"...B")
!		else
			strcat(&.paramstr,"void)")
!		fi
	fi

	stdcall:=""

!	if p.iscallback then
!		scallback:="gcc_callback"
!	else
		scallback:=""
!	fi

	if name=nil then
		print @&.buffer,stdcall,,getprocname(p),,&.paramstr
	else
		fprint @&.buffer,"#(#*#)#",scallback,stdcall,name,&.paramstr
	fi
	return pcm_copyheapstring(strmodec(rettype,&.buffer,not showparamnames))
end

global function getprocname(symbol d)ichar=
	ichar name

	name:=d.name

	case d.nameid
	when dllprocid, dllvarid then
		if d.truename then return d.truename fi
		return name
	else
		return getfullnamec(d)
	esac
	return ""
end

global function getfullnamec(symbol d)ichar=
	getfullnamec2(d)
end

global function getfullnamec2(symbol d)ichar=
	static [256]char str
	[256]char str2
	int n

	case d.nameid
	when procid, staticid, typeid, constid then
		case d.owner.nameid
		when moduleid then
			strcpy(&.str,d.owner.name)
			strcat(&.str,dollar)
			strcat(&.str,d.name)
			return &.str
		when procid then
			if d.nameid=typeid then
				strcpy(&.str,d.owner.owner.name)
				strcat(&.str,dollar)
				strcat(&.str,d.owner.name)
				strcat(&.str,dollar)
				strcat(&.str,d.name)
				return &.str
			fi
		esac
	esac

	if d.truename then return d.truename fi
	return d.name
end

global function genclabel(int n,colon=0)ichar=
	static [16]char str
	print @&.str,"L",,n,(colon|":;"|"")
	return &.str
end

global proc genrecorddef(int m)=
!export record or struct
	static int seqno=0
	symbol q
	int indent,index,nref,target
	[8]byte flags
	byte f
	ichar name
	symbol d

	d:=ttnamedef[m]
	name:=d.name

	if d.align then
		ccstrline("#pragma pack(8)")
	fi

	ccstr("struct ")
	ccstr(getfullnamec(d))
	ccstrline(" {")

	indent:=1

	q:=d.deflist

	while q do
		memcpy(&flags,&q.uflags,8)
		index:=1
		flags[8]:=0
	
		case q.nameid
		when fieldid then
			while (f:=flags[index])='S' or f='U' do
				++index
				cctab(indent)
				ccstrline((f='S'|"struct {"|"union {"))
				++indent
			od
	
			case ttbasetype[q.mode]
			when tref then
				target:=tttarget[q.mode]
				nref:=1
				while ttbasetype[target]=tref do
					target:=tttarget[target]
					++nref
				od
				if target=m then
					cctab(indent)
					ccstr("struct ")
	!				ccstr(name)
					ccstr(getfullnamec(d))
					to nref do ccchar('*') od
					ccchar(' ')
					ccstrsemi(q.name)
	
				else
					goto normal
				fi
			when tbitfield then

			else
	normal:
				cctab(indent)
				ccstrsemi(strmodec(q.mode,q.name))
			esac

			if flags[index]='*' then ++index fi
			while flags[index]='E' do
				--indent
				++index
				cctab(indent)
				ccstrsemi("}")
			od
		else
			gerror("Non-field in struct")
		esac
		q:=q.nextdef
	od

	ccstrsemi("}")
	if d.align then
		ccstrline("#pragma pack(1)")
	fi
	ccblank()
end

global proc genrecordfwd(int m)=
	ccstr("struct ")
	ccstrsemi(getfullnamec(ttnamedef[m]))
end

global proc do_initdata(unit p,int docomma=0,level=0)=
!output initialisation data for a var
!p is the .code value
!dosemi=1 to write a final semicolon and end the line

	if p=nil then return fi

	if p.tag<>jmakelist then
!CPL "IDATA"; PRINTUNIT(P)

		if p.tag=jconst and p.mode=trefchar and p.isastring then
	
			if p.slength=0 then
				ccstr("(byte*)""""")
			else
				cclongstr(p.svalue,p.slength)
			fi
		else
			evalunit(p)
		fi
		if docomma then
			ccchar(',')
		fi
		return
	fi

!makelist is a special case
	do_makelist(p.a,p.length,docomma,level+1)
end

global proc cclongstr(ref char svalue, int length)=
!svalue is a raw string that needs conversion to C escape codes, so might get longer
	if clineptr+length*2>=clineend then		!might overflow buffer
		ccsendline()
		gs_str(dest,strstringc(svalue,length))
	else
		dxstr(strstringc(svalue,length))
	fi
end

global proc cclongbin(ref char svalue, int length)=
!svalue is a raw string that needs conversion to C escape codes, so might get longer
	ccstrline("{")
	for i to length do
		ccstr(strint(svalue^),1)
		ccstrline(",")
		++svalue
	od
!	ccstrline("};")
	ccstr("}")

end

proc do_makelist(unit a, int length, docomma,level=0)=
	int oneperline,n
	unit p,q

	p:=a

	if length<=10 and a.tag<>jmakelist then				!keep on one line
		ccstr("{")
		while p do
			q:=p.nextunit
			do_initdata(p, q<>nil, level)
			p:=q
		od
	else
		ccstrline("{")
		while p do
			q:=p.nextunit
			to level do
				ccstr("    ")
			od
			do_initdata(p, q<>nil, level)
			p:=q
			ccstrline("")
		od
	fi

	ccchar('}')

	if docomma then
		ccchar(',')
	fi
end

global function issimplec(unit p)int=
!return 1 if unit p is simple
!this is used for min/max etc where I need to know if a term has side effects
!This is complex, so just do simplest possible check
	case p.tag
	when jconst, jname then
		return 1
	esac
	return 0
end

global function strstringc(ichar s, int length)ichar=
!string table generated in ax pass, so is just text
!this is target-specific, so should really be moved
	int i, state, c, a,col

	const maxstrlen=512
	static [maxstrlen*2]char str
	ref char dest, t

	if length>maxstrlen then
		dest:=pcm_alloc(length*2)
	else
		dest:=&.str
	fi
	t:=dest

	strcpy(t,"(byte*)")
	t+:=strlen(t)

	t++^:='"'

	while c:=s++^ do
		case c
		when '"' then t++^:='\\'; t++^:='\"'
		when 10 then t++^:='\\'; t++^:='n'
		when 13 then t++^:='\\'; t++^:='r'
		when 9 then t++^:='\\'; t++^:='t'
		when '\\' then t++^:='\\'; t++^:='\\'
		else
			if c<32 then
				t++^:='\\'
				t++^:=c>>6+'0'
				t++^:=(c>>3 iand 7)+'0'
				t++^:=(c iand 7)+'0'
			else
				t++^:=c
			fi
		esac
	od
	t++^:='"'
	t^:=0

	return dest
end

global proc do_syscallproc(ichar fnname,unit a=nil,b=nil)=
	[32]char str

	dxstr(getsyscallprefix())
	dxstr(fnname)
	dxstr("(")
	if a then
		evalsysparam(a)
		if b then
			dxstr(",")
			evalsysparam(b)
		fi
	fi
	dxstr(");")
	ccsendline()
	cctab(blocklevel)
end

proc evalsysparam(unit a)=
	case a
	when nil then
	when nullunit then
		dxstr("NULL")
!!	when zerounit then
!!		dxstr("0")
	else
		evalunit(a)
	esac
end

global proc dxstr(ichar str)=
	while str^ do
		clineptr^:=str^
		++clineptr
		++str
	od
end

global proc dxchar(int ch)=
	clineptr++^:=ch
end

global proc dxint(int a)=
	dxstr(strint(a))
end

global func getccopname(int pclop, int cond=0)ichar=
	tabledata []byte ccpclops, []ichar ccopnames =
		(kadd,			"+"),
		(ksub,			"-"),
		(kmul,			"*"),
		(kdiv,			"/"),
		(kidiv,			"/"),
		(kirem,			"%"),
		(kbitand,		"&"),
		(kbitor,		"|"),
		(kbitxor,		"^"),
		(kshl,			"<<"),
		(kshr,			">>"),
!		(kandl,			"&&"),
!		(korl,			"||"),
		(kaddpx,		"+"),
		(ksubpx,		"-"),
		(ksubp,			"-"),

		(kneg,			"-"),
		(kbitnot,		"~"),
		(knot,			"!"),

		(kaddto,		"+="),
		(ksubto,		"-="),
		(kmulto,		"*="),
		(kdivto,		"/="),
		(kidivto,		"/="),
		(kiremto,		"%="),
		(kbitandto,		"&="),
		(kbitorto,		"|="),
		(kbitxorto,		"^="),
		(kshlto,		"<<="),
		(kshrto,		">>="),
!		(kandlto,		"&&="),
!		(korlto,		"||="),
		(kaddpxto,		"+="),
		(ksubpxto,		"-="),
	end

!	if pclop in [kcmp, ksetcc] then
	if pclop = ksetcc then
		return case cond
			when eq_cc then "=="
			when ne_cc then "!="
			when lt_cc then "<"
			when le_cc then "<="
			when gt_cc then ">"
			else		 ">="
			esac
	fi

	for i to ccpclops.len do
		if ccpclops[i]=pclop then
			return ccopnames[i]
		fi
	od
	nil

end

global func getsyscallprefix:ichar=
	case msyslevel
	when 0 then
		""
	when 1 then
		"msysminc$"
	else
		"msysc$"
	esac
end
