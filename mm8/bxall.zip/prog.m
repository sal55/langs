module Y as Z

record Y =
	fun foo:ichar = "This is the real Foo."
end
!fun foo:ichar = "No /I'm/ Foo!"

proc main =
	println Y.foo()
	println Z.foo()
end
