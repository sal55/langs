!const n=1'500'000
const n=250'000
[n]real tt

proc main=

	for j to 150 do
		for i to n do
			tt[i]:=sqrt(real(i))+j
		od
	od

	for i to 20 do
		println tt[i]
	od

end
