proc main=
	println main
end
