importdll bill =

    proc bill()
    proc main()
end importlib

