proc main=
	int i
	i:=0
!	while i<1000 million do
	while i< 100 MILLION do
		i:=i+1
	od

	println i

end
