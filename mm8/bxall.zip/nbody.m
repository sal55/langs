record body=
	real x, y, z
	real	vx, vy, vz
	real	mass
end

!const pi = 3.141592653589793
const solarMass = 4.0*pi*pi
const daysPerYear = 365.24

[]body b=(
	body( 0, 0, 0,  0, 0, 0,  solarMass ),
! Jupiter
	body (    4.84143144246472090e+00,
			 -1.16032004402742839e+00,
			 -1.03622044471123109e-01,
			  1.66007664274403694e-03 * daysPerYear,
			  7.69901118419740425e-03 * daysPerYear,
			 -6.90460016972063023e-05 * daysPerYear,
		      9.54791938424326609e-04 * solarMass ),
!Saturn
	body (     8.34336671824457987e+00,
			   4.12479856412430479e+00,
			  -4.03523417114321381e-01,
			  -2.76742510726862411e-03 * daysPerYear,
			   4.99852801234917238e-03 * daysPerYear,
			   2.30417297573763929e-05 * daysPerYear,
		       2.85885980666130812e-04 * solarMass ),
!Uranus
	body (     1.28943695621391310e+01,
			  -1.51111514016986312e+01,
			  -2.23307578892655734e-01,
			   2.96460137564761618e-03 * daysPerYear,
			   2.37847173959480950e-03 * daysPerYear,
			  -2.96589568540237556e-05 * daysPerYear,
			   4.36624404335156298e-05 * solarMass ),
!Neptune
!	body (     1.53796971148509165e+01,
	body (     153796971148509165e+01,
			  -2.59193146099879641e+01,
			   1.79258772950371181e-01,
			   2.68067772490389322e-03 * daysPerYear,
			   1.62824170038242295e-03 * daysPerYear,
			  -9.51592254519715870e-05 * daysPerYear,
		       5.15138902046611451e-05 * solarMass ))

proc offsetMomentum=
real px,py,pz
int i
px:=py:=pz:=0.0
for i := 1+1 to b.len do
	px := px - b[i].vx * b[i].mass
	py := py - b[i].vy * b[i].mass
	pz := pz - b[i].vz * b[i].mass
od
b[1].vx := px / solarMass
b[1].vy := py / solarMass
b[1].vz := pz / solarMass
end

function distance(int i,j)real=
return sqrt(sqr(b[i].x-b[j].x) + sqr(b[i].y-b[j].y) +sqr(b[i].z-b[j].z))
end

function energy:real=
real result := 0.0
int i,j

for i := 1 to b.len do
	result := result + b[i].mass * (sqr(b[i].vx) + sqr(b[i].vy) + sqr(b[i].vz)) / 2
	for j := i+1 to b.len do
		result := result - b[i].mass * b[j].mass / distance(i,j)
	od
od
return result
end

proc advance(real dt)=
int i,j
ref body bi,bj
real dx,dy,dz,mag

bi:=&b[1]
for i := 1 to b.len-1 do
		bj := bi
		for j := i+1 to b.len do
			++bj
			dx := bi.x - bj.x
			dy := bi.y - bj.y
			dz := bi.z - bj.z
			mag := dt / (sqrt(sqr(dx)+sqr(dy)+sqr(dz))*(sqr(dx)+sqr(dy)+sqr(dz)))

			bi.vx := bi.vx - dx * bj.mass * mag
			bi.vy := bi.vy - dy * bj.mass * mag
			bi.vz := bi.vz - dz * bj.mass * mag
			bj.vx := bj.vx + dx * bi.mass * mag
			bj.vy := bj.vy + dy * bi.mass * mag
			bj.vz := bj.vz + dz * bi.mass * mag
		od
		++bi
od
bi:=&b[1]
for i := 1 to b.len do
		bi.x := bi.x + dt * bi.vx
		bi.y := bi.y + dt * bi.vy
		bi.z := bi.z + dt * bi.vz
		++bi
od
end

proc main=
int i,n
	offsetMomentum()
!	printf("%9.9f\n",energy())
	println energy():".10"
!	n:=1 million
!	n:=250'000
	n:=4'000'000
!	n:=1
	for i := 1 to n do advance(0.01) od
	println energy():".10"
!	printf("%9.9f\n",energy())

end

