const fshowpclseqno=1
!const fshowpclseqno=0

strbuffer sbuffer
ref strbuffer dest=&sbuffer
int destlinestart

const tab1="    "
const tab2="        "

ref[]byte labeltab

int pclseqno

global proc strpcl(pcl p)=
	[256]char str
	int opcode, n,x,y
	symbol d, e
	mclopnd a

	const showformatted=1

	opcode:=p.opcode
	a:=p.a

!	if fshowpclseqno then
!		psstr(string(pclseqno, "z5"))
!		psstr("  ")
!	fi

!CPL "STRPCL", PCLNAMES[P.OPCODE]

!PSSTR("<PCL>")
!PSINT(INT(P.A))
!PSSTR( " ")

!PSSTR(OPNDNAMES[P.OPNDTYPE])

!psstr(strint(getlineno(p.pos),"4"))
!psstr(" ")

	case opcode
	when klabel then
		strlabel(a.labelno,1)

		IF P.POPONE THEN
			PSSTR(" NOT USED")
		FI

		return
	when klabeldef then
		psstr("! ")
		psstr(a.def.name)
		psstr(":")
		return
	when kcomment then
		if a.svalue^ then
			psstr("!")
			psstr(a.svalue)
		ELSE
			PSSTR("! - - -")
		fi
		return

	esac

	psstr(tab1)
skiptab:


	case opcode
	when kjumpcc then
		strcpy(str, "jump")
		strcat(str, ccnames[p.condcode])
!		if p.popone then
!			strcat(str, "/1")
!		fi
	when ksetcc then
		strcpy(str, "set")
		strcat(str, ccnames[p.condcode])
	else
		strcpy(str, pclnames[opcode])
	esac

	gs_leftstr(dest,str,9)

	str[1]:=0
	if p.mode then
		strcat(str, strmode(p.mode))

		if pclhastype[opcode]=2 then
			strcat(str, "/")
			strcat(str, strmode(p.mode2))
		fi
		STRCAT(STR, " ")
	fi
	gs_leftstr(dest,str,4)

	fprint @str,"[#] ", p.spindex:"2"
	psstr(str)

	str[1]:=0
	n:=pclextra[opcode]
	if n then
		x:=p.x; y:=p.y
		if x or n=2 then			!don't show single 0 value
			strcat(str, "/")
			strcat(str, strint(p.x))
		fi

		if n=2 and y then
			strcat(str, "/")
			strcat(str, strint(y))
		fi
		STRCAT(STR, " ")
	fi	
	gs_leftstr(dest,str,5)

	if a then
		psstr(" ")
		psstr(mstropnd(a))
	fi
	pstabto(40)

	if fshowpclseqno then
		psstr("! ")
		psstr(strint(pclseqno,"z5"))
		psstr("  ")
	fi
end

global func strpclstr(pcl p, int buffsize)ichar=
	gs_free(dest)
	gs_init(dest)
	destlinestart:=0
	strpcl(p)
	gs_char(dest,0)

	if dest.length>=buffsize then return "<BIGSTR>" fi

	dest.strptr
end

global func writeallpcl:ref strbuffer=
!write all pcl code in system by scanning all procs
!pcl code is only stored per-proc
	ref procrec pp
	symbol d

	labeltab:=pcm_allocz(mlabelno)			!indexed 1..labelno

	gs_init(dest)
	destlinestart:=dest.length

	gs_strln(dest, "!PROC PCL")


	pp:=proclist
	while pp, pp:=pp.nextproc do
		currfunc:=d:=pp.def

		psprocsig(d)
		psprocbody(d)

		psstrline("End")
		psline()
	od


	pcm_free(labeltab, mlabelno)

	return dest
end

proc psstr(ichar s)=
	gs_str(dest,s)
end

proc psstrline(ichar s)=
	gs_str(dest,s)
	gs_line(dest)
end

proc psline=
	gs_line(dest)
end

proc psint(int a)=
	gs_str(dest,strint(a))
end

proc psname(symbol d)=
	gs_str(dest,getfullname(d))
end

proc psprocsig(symbol d)=
	symbol e
	byte comma:=0
	int lastmode:=tvoid, m, lastsize, size

	psstr("Proc ")
	psstr(d.name)
	psstr("(")

	e:=d.deflist

	while e, e:=e.nextdef do
		if e.nameid=paramid then
			if comma then psstr(", ") fi
			if e.mode<>lastmode then
				lastmode:=e.mode
				psstr(strmode(lastmode))
				psstr(" ")
			fi
			psstr(e.name)

			comma:=1
		fi
	od
	psstr(")")

	if d.mode then
		psstr(strmode(d.mode))
	fi
	psstrline(" =")


	e:=d.deflist
	comma:=0
	while e, e:=e.nextdef do
		if e.nameid in [frameid, staticid] then
			psstr(tab1)
			psstr(strmode(e.mode))
			psstr(" ")
			psstrline(e.name)
			comma:=1
		fi
	od
	if comma then psline() fi
end

proc psprocbody(symbol d)=
	pcl p
	mclopnd a
	int lastsp:=0

	p:=d.pclinfo.code

	return unless p

!do first pass populating label table

	while p, p:=p.next do
		if p.opcode<>klabel then
			a:=p.a
			if a and a.valtype=label_val then
				labeltab[a.labelno]:=1
			fi
		fi
	od

	p:=d.pclinfo.code
	destlinestart:=dest.length
	pclseqno:=0

	while p, p:=p.next do
		++pclseqno
		lastsp:=p.spindex

!UNLESS P.OPCODE IN [KSETCALL, KSETARG] THEN
		strpcl(p)
		gs_line(dest)
!END
		destlinestart:=dest.length
	od

	psstr("Last SP:")
	psint(lastsp)
	psline()
end

global proc strlabel(int labelno,colon=0)=
	psstr("L")
	psint(labelno)
	if colon then
		psstr(":")
	fi
	psstr(" ")
end

global proc pstabto(int n)=
	int col:=dest.length-destlinestart
	while n>col do psstr(" "); ++col od
end

