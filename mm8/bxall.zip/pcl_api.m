!EXPORT INT PCLSEQNO
int STSEQNO

global pcl pcstart			!start of pcl block
global pcl pccurr			!point to current pcl op
global pcl pcend			!point to last allocated pclrec

!byte pcfixed				!whether code is fixed up
global int pclength

global pcl pcmin, pcmax		!limits of pcl code generated for program

int initpcalloc=65536

global proc pgen(int opcode, pcl p=nil) =
	if p=nil then p:=newpcl() end
	p.opcode:=opcode
end

global proc pgenx(int opcode, int x, pcl p=nil) =
	if p=nil then p:=newpcl() end
	p.opcode:=opcode
	pccurr.x:=x
end

global func newpcl:pcl p =

	p:=pcm_allocnfz(pclrec.bytes)

	pccurr.next:=p
	pccurr:=p

	++pclength

	return pccurr
end

global proc pcl_start =
!reset tcstart/tccurr for new TCL sequence (new proc or new init data)
	pcstart:=pcm_allocnfz(pclrec.bytes)
	pcstart.opcode:=knop
	pccurr:=pcstart
!	pcseqno:=0
	pclength:=0

	pcmin min:=pcstart

end

global func pcl_end:pcl pc=
!Terminate sequence; sets pcstart to nil so that pcl cannot be generated
!outside proc bodies etc
!But caller should copy tcstart value, or use its value returned here

	pcmax max:=pccurr
	pc:=pcstart
	if pc.opcode=knop then
		pc.next
	else
		pc
	end
end

global proc psetmode(int m, size=0)=
	pccurr.mode:=m
	if size=0 then size:=pstdsize[m] fi
	pccurr.size:=size

	if pclhastype[pccurr.opcode]=2 then
		pccurr.mode2:=pccurr.mode
	end
end

global proc psetmode2(int m)=
	pccurr.mode2:=m
end

global proc pcomment(ichar s)=
!*!	return when fregoptim or fpeephole		!will get skipped anyway
!	RETURN WHEN DOREDUCE			!comments suppressed as they get in the way
!STATIC INT CCC
!CPL "COMMENT",++CCC
	pgen(kcomment, pgenstring(s))
end

global proc psetnargs(int n)=
	pccurr.nargs:=n
end

global proc pgenix(int opcode, scale=1, offset=0) =
!originally intended for combinations of ptr ops to be combined into
!previous ones, but that has now been dropped.
!Instead any such reductions will be done in a separate pass, much simpler
	pcl p:=newpcl()
	p.opcode:=opcode
	p.scale:=scale
	p.extra:=offset
end

global proc pgencond(int opcode, cond, pcl p=nil) =
	if p=nil then p:=newpcl() end
	p.opcode:=opcode
	p.condcode:=cond
end

global proc pgenxy(int opcode, int x, y, pcl p=nil) =
	if p=nil then p:=newpcl() end
	p.opcode:=opcode
	p.x:=x
	p.y:=y
end

global proc psetscaleoff(int scale, offset:=0)=
	pccurr.scale:=scale
	pccurr.extra:=offset
end

global func pgenint(int a)pcl p=
	p:=newpcl()
	p.value:=a
	p.opndtype:=int_opnd
	return p
end

global func pgenrealmem(real x)pcl p=
	p:=newpcl()
	p.xvalue:=x
	p.opndtype:=real_opnd
	return p
end

!global func pgenrealimm(real x)pcl p=
!	p:=newpcl()
!	p.xvalue:=x
!	p.opndtype:=realimm_opnd
!	return p
!end

global func pgenstring(ichar s, int length=-1)pcl p=
	p:=newpcl()

	if length<0 then
		length:=strlen(s)+1
	end

	p.svalue:=pcm_copyheapstringn(s,length)		!will add an extra zero

	p.slength:=length
	p.opndtype:=string_opnd
	return p
end

global func pgenlabel(int a)pcl p=
	p:=newpcl()
	p.labelno:=a

	p.opndtype:=label_opnd
	return p
end

global func pgenmem(psymbol d)pcl p=

	p:=newpcl()

	p.def:=d

	p.opndtype:=mem_opnd
	return p
end

global func pgenmemaddr(psymbol d)pcl p=
	p:=newpcl()
	p.def:=d

!	IF D.EQUIVVAR THEN
!		P.DEF:=D.EQUIVVAR.DEF
!	FI


	p.opndtype:=memaddr_opnd
	return p
end

global proc pgencomment(ichar s)=
	return when fregoptim or fpeephole		!will get skipped anyway
!	RETURN WHEN DOREDUCE			!comments suppressed as they get in the way
!STATIC INT CCC
!CPL "COMMENT", ++CCC
	pgen(kcomment, pgenstring(s))
end

global func pgenname(ichar s)pcl=
	return pgenmem(pmakesymbol(s))
end

global func pgennameaddr(ichar s)pcl=
	return pgenmemaddr(pmakesymbol(s))
end

global func addstr(ichar s, t)ichar=
	static [256]char str
	strcpy(str, s)
	strcat(str, t)
	str
end

global proc stacklooplabels(int a,b,c)=
!don't check for loop depth as that has been done during parsing
	++loopindex
	if loopindex>maxnestedloops then
		gerror("Too many nested loops")
	end

	loopstack[loopindex,1]:=a
	loopstack[loopindex,2]:=b
	loopstack[loopindex,3]:=c

end

global func findlooplabel(int k,n)int=
!k is 1,2,3 for label A,B,C
!n is a 1,2,3, according to loop nesting index
	int i

	i:=loopindex-(n-1)		!point to entry
	if i<1 or i>loopindex then gerror("Bad loop index") end
	return loopstack[i,k]
end

global func newpstrec:psymbol p=

	p:=pcm_allocnfz(pstrec.bytes)
!
!	p.pos:=lx.pos
!	p.moduleno:=currmoduleno
!	p.subprogno:=moduletosub[currmoduleno]
	return p
end

global func pmakesymbol(ichar s, int id=nullid)psymbol d=
	d:=newpstrec()
	d.name:=pcm_copyheapstring(s)

	d.nameid:=id

	d.seqno:=++stseqno

!	if id=staticid then
!		paddsymbol(d)
!	end
	d
end

global func createfwdlabel:int =
	return ++mlabelno
end

global func definelabel:int =
	pgen(klabel, pgenlabel(++mlabelno))
	return mlabelno
end

global proc definefwdlabel(int lab) =
	pgen(klabel, pgenlabel(lab))
end

global proc paddsymbol(psymbol d)=
!CPL "ADDSYMBOL", D.NAME
	if psymboltable=nil then
		psymboltable:=psymboltablex:=d
	else
		psymboltablex.next:=d
		psymboltablex:=d
	fi
end

global func getfullname(psymbol d, int backtick=0)ichar=
!create fully qualified name into caller's dest buffer
	static [256]char str

	str[1]:=0
	if backtick then
		strcpy(str, "`")
	end

	if d.isimport then
		if backtick then
			strcat(str, d.name)
			strcat(str, "*")
		else
			strcat(str, d.name)
		end
		return str
	end

	if d.nameid in [frameid, paramid] then
		strcat(str, currfunc.name)
		strcat(str, ".")
	fi

	strcat(str, d.name)
end

export func pgendata(ref byte s, int length)pcl p=
	p:=newpcl()
	p.svalue:=s			! assume already saved on heap
	p.opndtype:=data_opnd
	p.mode:=tblock
	p.size:=length

	return p
end

global func reversecond(int cc)int=
!reverse conditional operator
	case cc
	when eq_cc then cc:=ne_cc
	when ne_cc then cc:=eq_cc
	when lt_cc then cc:=ge_cc
	when le_cc then cc:=gt_cc
	when ge_cc then cc:=lt_cc
	when gt_cc then cc:=le_cc
	esac

	return cc
end

global func reversecond_order(int cc)int=
	case cc
	when eq_cc then cc:=eq_cc
	when ne_cc then cc:=ne_cc
	when lt_cc then cc:=gt_cc
	when le_cc then cc:=ge_cc
	when ge_cc then cc:=le_cc
	when gt_cc then cc:=lt_cc
	esac

	return cc
end

global proc setfunctab=
	if pnprocs=nil then
		pnprocs:=pmakesymbol("$nprocs", staticid)
!CPL "SET PNPROCS", PNPROCS
		pnprocs.mode:=ti64
		pprocname:=pmakesymbol("$procname", staticid)
		pprocaddr:=pmakesymbol("$procaddr", staticid)

		paddsymbol(pnprocs)
		paddsymbol(pprocname)
		paddsymbol(pprocaddr)

	end
end

global proc scanprocs=
	const maxprocs=1000
	[maxprocs]psymbol proctable
	int nprocs:=0
	psymbol d

	d:=psymboltable
	while d, d:=d.next do
		if d.nameid=procid and d.ishandler then
			if nprocs>=maxprocs then gerror("PCL proctab overflow") fi
			proctable[++nprocs]:=d
		fi
	end

	if nprocs=0 and pnprocs=nil then
		pnprocs:=pmakesymbol("$nprocs", staticid)
		pnprocs.mode:=ti64
		goto finish
	fi

	setfunctab()

!CPL "SCANP", =PNPROCS, =PPROCADDR


!	pgen(kistatic, genmem(pprocaddr))
	pprocaddr.mode:=tblock
	pprocaddr.size:=nprocs*8

	pcl_start()
	for i to nprocs do
		pgen(kdata, pgenmemaddr(proctable[i]))
		psetmode(tu64)
	end
	pprocaddr.pccode:=pcl_end()

	pprocname.mode:=tblock
	pprocname.size:=nprocs*8

	pcl_start()
	for i to nprocs do
		pgen(kdata, pgenstring(getbasename(proctable[i].name)))
		psetmode(tu64)
	end
	pprocname.pccode:=pcl_end()

finish:
!	pgen(kistatic, genmem(pnprocs))
!	psetmode(ti64)
	pcl_start()
	pgen(kdata, pgenint(nprocs))
	psetmode(ti64)
	pnprocs.pccode:=pcl_end()
end

global func getbasename(ichar s)ichar t=
	t:=s+strlen(s)-1
	while t>s and (t-1)^<>'.' do
		--t
	end

	return t
end

export proc pc_addplib(ichar name)=
	if nplibfiles>=maxplibfile then gerror("Too many libs") fi

	plibfiles[++nplibfiles]:=pcm_copyheapstring(changeext(name, ""))
end

