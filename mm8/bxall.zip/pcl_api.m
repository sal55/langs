!EXPORT INT PCLSEQNO
int STSEQNO

global pcl pcstart			!start of pcl block
global pcl pccurr			!point to current pcl op
global pcl pcend			!point to last allocated pclrec

!byte pcfixed				!whether code is fixed up
global int pclength

global pcl pcmin, pcmax		!limits of pcl code generated for program

int initpcalloc=65536

global proc pc_gen(int opcode, pcl p=nil) =
	if p=nil then p:=newpcl() fi
	p.opcode:=opcode
end

global proc pc_genx(int opcode, int x, pcl p=nil) =
	if p=nil then p:=newpcl() fi
	p.opcode:=opcode
	pccurr.x:=x
end

global func newpcl:pcl p =

	p:=pcm_allocnfz(pclrec.bytes)

	pccurr.next:=p
	pccurr:=p

	++pclength

	return pccurr
end

global proc pcl_start =
!reset tcstart/tccurr for new TCL sequence (new proc or new init data)
	pcstart:=pcm_allocnfz(pclrec.bytes)
	pcstart.opcode:=knop
	pccurr:=pcstart
!	pcseqno:=0
	pclength:=0

	pcmin min:=pcstart

end

global func pcl_end:pcl pc=
!Terminate sequence; sets pcstart to nil so that pcl cannot be generated
!outside proc bodies etc
!But caller should copy tcstart value, or use its value returned here

	pcmax max:=pccurr
	pc:=pcstart
	if pc.opcode=knop then
		pc.next
	else
		pc
	fi
end

global proc pc_setmode(int m)=
	pccurr.mode:=getpclmode(m)
	pccurr.size:=ttsize[m]

	if pclhastype[pccurr.opcode]=2 then
		pccurr.mode2:=pccurr.mode
	fi
end

global proc pc_setmode_u(unit p)=
	pc_setmode(p.mode)
end

global proc pc_setmode2(int m)=
	pccurr.mode2:=getpclmode(m)
end

global proc pc_comment(ichar s)=
!*!	return when fregoptim or fpeephole		!will get skipped anyway
!	RETURN WHEN DOREDUCE			!comments suppressed as they get in the way
!STATIC INT CCC
!CPL "COMMENT",++CCC
	pc_gen(kcomment, pgenstring(s))
end

global proc pc_setnargs(int n)=
	pccurr.nargs:=n
end

global proc pc_genix(int opcode, scale=1, offset=0) =
!originally intended for combinations of ptr ops to be combined into
!previous ones, but that has now been dropped.
!Instead any such reductions will be done in a separate pass, much simpler
	pcl p:=newpcl()
	p.opcode:=opcode
	p.scale:=scale
	p.extra:=offset
end

global proc pc_gencond(int opcode, cond, pcl p=nil) =
	if p=nil then p:=newpcl() fi
	p.opcode:=opcode
	p.condcode:=cond
end

global proc pc_genxy(int opcode, int x, y, pcl p=nil) =
	if p=nil then p:=newpcl() fi
	p.opcode:=opcode
	p.x:=x
	p.y:=y
end

global proc pc_setscaleoff(int scale, offset:=0)=
	pccurr.scale:=scale
	pccurr.extra:=offset
end

global func pgenint(int a)pcl p=
	p:=newpcl()
	p.value:=a
	p.opndtype:=int_opnd
	return p
end

global func pgenrealmem(real x)pcl p=
	p:=newpcl()
	p.xvalue:=x
	p.opndtype:=real_opnd
	return p
end

!global func pgenrealimm(real x)pcl p=
!	p:=newpcl()
!	p.xvalue:=x
!	p.opndtype:=realimm_opnd
!	return p
!end

global func pgenstring(ichar s)pcl p=
	p:=newpcl()
	p.svalue:=pcm_copyheapstring(s)
	p.opndtype:=string_opnd
	return p
end

global func pgenlabel(int a)pcl p=
	p:=newpcl()
	p.labelno:=a

	p.opndtype:=label_opnd
	return p
end

global func pgenmem(symbol d)pcl p=

	p:=newpcl()

	p.def:=d

	p.opndtype:=mem_opnd
	return p
end

global func pgenmemaddr(symbol d)pcl p=
	p:=newpcl()
	p.def:=d

	p.opndtype:=memaddr_opnd
	return p
end

global proc pgencomment(ichar s)=
	return when fregoptim or fpeephole		!will get skipped anyway
!	RETURN WHEN DOREDUCE			!comments suppressed as they get in the way
!STATIC INT CCC
!CPL "COMMENT", ++CCC
	pc_gen(kcomment, pgenstring(s))
end

global func pgenname(ichar s)pcl=
	return pgenmem(makesymbol(s))
end

global func pgennameaddr(ichar s)pcl=
	return pgenmemaddr(makesymbol(s))
end

global func addstr(ichar s, t)ichar=
	static [256]char str
	strcpy(str, s)
	strcat(str, t)
	str
end

global proc stacklooplabels(int a,b,c)=
!don't check for loop depth as that has been done during parsing
	++loopindex
	if loopindex>maxnestedloops then
		gerror("Too many nested loops")
	fi

	loopstack[loopindex,1]:=a
	loopstack[loopindex,2]:=b
	loopstack[loopindex,3]:=c

end

global func findlooplabel(int k,n)int=
!k is 1,2,3 for label A,B,C
!n is a 1,2,3, according to loop nesting index
	int i

	i:=loopindex-(n-1)		!point to entry
	if i<1 or i>loopindex then gerror("Bad loop index") fi
	return loopstack[i,k]
end

global proc genpc_sysfn(int fnindex, unit a=nil,b=nil,c=nil)=
	genpc_sysproc(fnindex, a,b,c, 1)
end

global proc genpc_sysproc(int fnindex, unit a=nil,b=nil,c=nil, int asfunc=0)=
	int nargs:=0, opc
	symbol d
	pcl p
	opc:=0

	pc_gen(ksetcall)
	p:=pccurr

	pushsysarg(c, 3, nargs)
	pushsysarg(b, 2, nargs)
	pushsysarg(a, 1, nargs)
!
	p.nargs:=nargs

	d:=getsysfnhandler(fnindex)
	if d then
		pc_gen((asfunc|kcallf|kcallp), pgenmemaddr(d))
		pc_setnargs(nargs)
	else
!		pc_gen((asfunc|kcallf|kcallp), gennameaddr(sysfnnames[fnindex]+3))
		pc_gen((asfunc|kcallf|kcallp), pgenname(sysfnnames[fnindex]+3))
	fi
	pccurr.nargs:=nargs
end

global proc pushsysarg(unit p, int n, &nargs) =
!return 0 or 1 args pushed
	if p then
		evalunit(p)
		pc_gen(ksetarg)
		pc_setmode_u(p)
		pccurr.x:=n
		pccurr.y:=n			!ASSUMES ALL INTS; however this only important
							!for arm64, and only matters if more than 8 args
		++nargs
	fi
end

global func getsysfnhandler(int fn)symbol p=
	[300]char str
	int report

	if sysfnhandlers[fn] then
		return sysfnhandlers[fn]
	fi

	strcpy(str,"m$")
	strcat(str,sysfnnames[fn]+3)	!"sf_stop" => "m$stop"

	ref procrec pp:=proclist
	while pp, pp:=pp.nextproc do
		if eqstring(pp.def.name, str) then
			sysfnhandlers[fn]:=pp.def
			return pp.def
		fi
	od

!	report:=passlevel>asm_pass
	report:=1
	report:=0

	if report then
		println "Sysfn not found:",str
	fi
	if fn<>sf_unimpl then
		p:=getsysfnhandler(sf_unimpl)
		if p=nil and report then
			gerror("No m$unimpl")
		fi
		return p
	fi

	return nil
end

global proc setfunctab=
	if pnprocs=nil then
		pnprocs:=makesymbol("$nprocs", nullid)
!CPL "SET PNPROCS", PNPROCS
		pnprocs.mode:=ti64
		pprocname:=makesymbol("$procname", nullid)
		pprocaddr:=makesymbol("$procaddr", nullid)
	fi
end

global func makesymbol(ichar s, int id=nullid)symbol d=
	d:=newstrec()
	d.name:=pcm_copyheapstring(s)

	d.nameid:=id

	if id=staticid then
		addstatic(d)
	fi
	d
end

global func getfullname(symbol d, int backtick=0)ichar=
!create fully qualified name into caller's dest buffer
	static [256]char str
	int n:=0
	symbol e:=d
	ichar name

!	if fpshortnames then return d.name fi

	str[1]:=0
	if backtick then
		strcpy(str, "`")
	fi

!	if d.imported then
	if d.isimport then
		name:=(d.truename|d.truename|d.name)
		if backtick then
			strcat(str, name)
			strcat(str, "*")
		else
			strcat(str, name)
		fi
		return str
	fi

!STRCAT(STR, "GF:")
!CPL

	if d.equivvar then
!PRINTUNIT(D.EQUIVVAR)

		d:=d.equivvar.def
	fi


!CPL =D.NAME, =D.OWNER
	if d.owner then
		if d.owner.nameid=procid then
			strcat(str, d.owner.owner.name)
			strcat(str, ".")
		fi
		strcat(str, d.owner.name)
		strcat(str, ".")
	fi
	strcat(str, d.name)
!!	if d.nameid in [frameid, paramid] then
!!IF CURRFUNC=NIL THEN
!!ABORTPROGRAM("CURRFUNC=0\N\N")
!!FI
!!		strcat(str, currfunc.name)
!!		strcat(str, ".")
!		strcat(str, d.name)
!		return str
!	fi
!
!	if backtick then
!		strcat(str, d.name)
!	else
!		return d.name
!	fi
end
