importdll msvcrt=
	proc puts(ichar)
	proc printf(ichar,...)
end

function ack(int m,n)int=
	if m=0 then
		n+1
	elsif n=0 then
		ack(m-1,1)
	else
		ack(m-1,ack(m,n-1))
	fi
end

proc main=
	printf("A= %lld\n",ack(3,12))
end
