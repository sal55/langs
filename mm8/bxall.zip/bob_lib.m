importdll bob =

    proc bob()
end importlib

