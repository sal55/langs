record rt = $caligned
	char A
	[0:10,0:20]int32 B
	char c
end

record st = $caligned
	int32 X
	real64 Y
	rt Z
end

!func foo(ref[0:]st s)ref int32=
!	&s[1].Z.B[5][13]
!!	&s[1].Z.B[5][13]
!end

record date=
	int d,m,y
end
[10]int xx


proc F=
	rt x
	int i
	date dd

!	eval  x.B[2,3]
!	eval xx[3]
!	eval dd.m

	dd.m:=777
	xx[3]:=777

end





!struct RT {
!  char A;
!  int B[10][20];
!  char C;
!};
!struct ST {
!  int X;
!  double Y;
!  struct RT Z;
!};
!
!int *foo(struct ST *s) {
!  return &s[1].Z.B[5][13];
!} 
