const nn = 200 million
!const nn = 100 million
!const nn = 50 million
!const nn = 100

ref[]u32 indata
ref[]u32 outdata

func swapends(int a)int=
	assem
		mov rax, [a]
!		bswap rax
		not rax
	end
end

!macro byteswap(a) =
!	assem
!		mov rax,[a]
!		bswap rax
!		mov [a],rax
!	end

proc swaplots(ref[]u32 indata, outdata, int n)=
	for i to n do
		outdata[i]:=swapends(indata[i])
!		outdata[i]:=byteswap indata[i]
!		outdata[i]:=inot indata[i]
!		a:=indata[i]
!		a:=assem mov rax,[a]; bswap rax; end
!		outdata[i]:=a!byteswap(a)
	od
end

proc main=
	int tm
	u32 a := 0x1122334455667788

!	assem
!		inc rax
!		bswap rax
!
!	end

	indata:=pcm_alloc(u32.bytes*nn)
	outdata:=pcm_alloc(u32.bytes*nn)

	for i to nn do
		indata[i]:=0x1122334455667788
	od

	tm:=clock()
!	to 100 do
		swaplots(indata, outdata, nn)
!	od
	tm:=clock()-tm

	for i to nn when i<10 or i>nn-10 do
		println i,outdata[i]:"h"
	od
	println =tm

end
