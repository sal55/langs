[0..7]int row
int s

proc main=

!CPL "ROW=",ROW

!	to 7000 do
	to 1 do
		mainx(1)
	od
end

function safe(int x,y)int=
	int i,a

CP "SAFE:",X," ",Y
for i in row.bounds do CP $,ROW[I] OD; CPL

	for i:=1 to y do
		a:=row[y-i]
		if a=x or a=x-i or a=x+i then
CPL "NOT SAFE"
			return 0
		fi


! if row[y-i]=x or row[y-i]=x-i or row[y-i]=x+i then return false fi
	od
CPL "SAFE"
	return 1
end

proc putboard=
	int x,y

	++s
	println "\wSolution",s

	for y:=0 to 7 do
		for x:=0 to 7 do
			print ((x=row[y]|"| Q "|"|   "))
		od
		println "|\n---------------------------------"
	od
end

proc mainx(int y)=
	int x

ROW[0]:=1
ROW[2]:=2
SAFE(2,2)


!cpl
!CPL "MAIN",Y
!	for x:=0 to 7 do
!CPL =X,=Y
!		row[y-1]:=x
!CPL "\nTESTSAFE", X, Y-1
!		if safe(x,y-1) then
!CPL "WAS SAFE", X,Y-1
!			if y<8 then
!				mainx(y+1)
!			else
!				putboard()
!			fi
!ELSE
! CPL "NOT SAFE", X,Y-1
!		fi
!	od
end
