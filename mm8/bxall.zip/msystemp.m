!import clib
!export type filehandle=ref void

importdll $cstd=
	func malloc	(word64)ref void
	proc free		(ref void)
!	func pow		(real,real)real
!
	func printf (ref char,...)int32
!	func fprintf (ref void,ref char,...)int32
	func puts (ref char)int32
	proc `exit(int32)
	func getchar	:int32
	proc memcpy		(ref void, ref void, word)
	proc memset		(ref void, int32, u64)
	func strlen		(ichar)u64
end

!export proc free(ref void) = end


int needgap

global proc m$print_startcon=
end

global proc m$print_end=
	needgap:=0
end

!global proc m$print_ptr(u64 a,ichar fmtstyle=nil)=
!!	nextfmtchars()
!	printf("%p",a)
!	needgap:=1
!end

global proc m$print_ptr_nf(u64 a)=
	nextfmtchars()
	printf("%p",a)
	needgap:=1
end
!
!global proc m$print_i64(int64 a,ichar fmtstyle=nil)=
!	nextfmtchars()
!	printf("%lld",a)
!	needgap:=1
!end

!global proc m$print_i128(int64 a,ichar fmtstyle=nil)=
!	puts("<128>")
!!	nextfmtchars()
!!	printf("%lld",a)
!!	needgap:=1
!end

global proc m$print_i64_nf(int64 a)=
!puts("PRINTI64_nf")
	nextfmtchars()
	printf("%lld",a)
	needgap:=1
end

!global proc m$print_u64(word64 a,ichar fmtstyle=nil)=
!	nextfmtchars()
!	printf("%llu",a)
!	needgap:=1
!end
!
global proc m$print_r64(real x,ichar fmtstyle=nil)=
	nextfmtchars()
	printf("%f",x)
	needgap:=1
end

!global proc m$print_c8(int64 a,ichar fmtstyle=nil)=
!	nextfmtchars()
!	printf("%c",a)
!	needgap:=1
!end
!
!global proc m$print_str(ichar s, fmtstyle=nil)=
!	nextfmtchars()
!	printf("%s",s)
!	needgap:=1
!end

global proc m$print_str_nf(ichar s)=
	nextfmtchars()
	printf("%s",s)
	needgap:=1
end

global proc m$print_space=
	needgap:=0
	printf(" ")
end

global proc m$print_newline=
	needgap:=0
	printf("\n")
end

global proc m$unimpl=
	puts("Sysfn unimpl")
	stop 1
end

!global proc m$print_nogap=
!	needgap:=0
!end
!
!global proc nextfmtchars(int lastx=0)=
global proc nextfmtchars=
	if needgap then
		printf(" ")
		needgap:=0
	fi
end

!global proc m$stop(int stopcode)=
!	`exit(stopcode)
!end
!
!global func strint(int64 a, ichar fmtstyle=nil)ichar=
!	return "?"
!end
!
export proc billy=
	CPL "BILLY"
end
