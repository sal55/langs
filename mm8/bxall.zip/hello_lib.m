importdll hello =
    var i64 ghi

    proc main()
end

