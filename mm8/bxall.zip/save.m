record date=
	int d,m,y
end

[10]date xx

proc main=
	date dd
	int i

	dd:=xx[i]



end
