importdll jpeg =
    var i64 bart

    proc main()
    func loadjpeg(ichar file,i64 &width,i64 &height) => ref u8
    proc freejpeg(ref u8 p)
    proc jtest()
end importlib

