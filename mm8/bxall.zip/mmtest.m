!project =
	module mm_cli
	module mm_blockpcl
	module mm_assem
	module mm_decls

	module mm_diags
!	module mm_diags_dummy

	module mm_export_dummy
!	module mm_exportq
!	module mm_exportm

	module mm_genpcl
	module mm_lex
	module mm_lib
	module mm_libpcl

!	module mm_libsources
	module mm_libsources_dummy

	module mm_modules
	module mm_name
	module mm_parse
	module mm_pcl
	module mm_support
	module mm_tables
	module mm_type
!	module mm_types

!x64 and exe backend

	module mc_genmcl
	module mc_genss
	module mc_libmcl
	module mc_decls as md
	module mc_objdecls
	module mc_optim
	module mc_stackmcl
	module mc_writeexe

!	module mc_writess
!	module mc_disasm

!'run' and mx/ml backend


!	module mx_run
!	import mx_lib

!	module mx_run_dummy

!Experimental PXL stuff
!	import pcl
!	module px_pxl
!	module px_show


!end

proc main=
	main2()
end

