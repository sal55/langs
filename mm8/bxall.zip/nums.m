!Solve Countdown Numbers Puzzle
!import clib
!import msys

!type node=struct(int value; int opcode; ref aaref,bbref)
!type node=struct
record node=
	int value
	int opcode
	ref node aaref,bbref
end

const nterms=6
!const nterms=3

const allresults=1
const maxsolutions=1000000
!macro maxsolutions=10
!macro maxsolutions=1

int done

enumdata = addop,subop,mulop,divop,sub2op,div2op
end

int level
int attempts,solutions,rejects
[1..nterms]int numbers=(50,25,10,7,4,5)

proc main=
int target:=629

![1..nterms]int numbers=(10,5,3)
!int target=12

to 20 do
	solvepuzzle(&numbers,target++)
od
end

proc solvepuzzle(ref[]int numbers,int target)=
[1..nterms]node nos

attempts:=0
solutions:=0
rejects:=0

!nos:=()

for i:=1 to nterms do
	nos[i].value:=numbers^[i]
	nos[i].opcode:=0
	nos[i].aaref:=nil
	nos[i].bbref:=nil
od

done:=0
level:=1
testlist(&nos,nterms,target)
!reportmessage("No solution found")

if solutions=0 then
	println "No solutions found",attempts
else
	println "Solutions=",solutions
fi
println "Attempts=",attempts," Rejects=",rejects," Total=",attempts+rejects
end

proc testlist(ref[]node nos,int n,target)=
!nos is a list of (x,a,b,opc) items
!test whether any are the target
int i,j,k,m,i2,j2,a,b,value,opc
[1..nterms]node newnos

if done then return fi

++attempts
for i:=1 to n do
	if nos^[i].value=target then
		++solutions
		if solutions=maxsolutions then done:=1; return fi
	fi
od

!no solution, scan extra possible pairs
if n=1 then			!terminal reached, backtrack
	return
fi

for i:=1 to n-1 do
	for j:=i+1 to n do		!pair will be nos[i] and nos[j]

		m:=0
		for k:=1 to n do
			if k<>i and k<>j then	!add items not forming the new pair
				m+:=1
				newnos[m]:=nos^[k]
			fi
		od

		m+:=1
		i2:=i; j2:=j
		a:=nos^[i2].value; b:=nos^[j2].value

		for opc:=addop to div2op do
			switch opc
			when addop then
				if a=0 or b=0 then ++rejects; nextloop fi
				value:=a+b
			when subop then
				if a ior b=0 then ++rejects; nextloop fi
				value:=a-b
			when mulop then
				if a<=1 or b<=1 then
					++rejects
					nextloop
				fi
				value:=a*b
			when divop then
				if b<=1 then ++rejects; nextloop fi
				value:=a/b
				if a rem b<>0 then ++rejects; nextloop fi
			when sub2op then
				i2:=j; j2:=i
				if a ior b=0 then ++rejects; nextloop fi
				value:=b-a

			when div2op then
				i2:=j; j2:=i
				if a<=1 then ++rejects; nextloop fi
				value:=b/a
				if b rem a<>0 then ++rejects; nextloop fi
WHEN 10..20 THEN
			end switch

			newnos[m].value:=value
			newnos[m].opcode:=opc
			newnos[m].aaref:=&nos^[i2]
			newnos[m].bbref:=&nos^[j2]

			level+:=1
			testlist(&newnos,m,target)
			level-:=1
		od
	od
od
end
