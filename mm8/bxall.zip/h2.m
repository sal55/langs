importdll msvcrt=
	proc puts(ichar)
	proc printf(ichar,...)
end

proc main=

	for i to 10 do
		printf("Hi there %lld\n", i)
	od

end

