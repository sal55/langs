macro x=(y+y)

proc main=
	int y,a
!
!	println =a

	a:=x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x))))))))))))
!	a:=x+(x+(x+(x+(x+(x+(x+(x+(x+(x)))))))))
end

!function f(int a,b,c,d,e,f,g)T=
!	T y:=10
!	g:=a+b
!
!!	a:=x+(x+(x+(x+(x+(x+(x+(x+(x+(x)))))))))
!	y:=x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x))))))))))))
!!	y:=x+(x+(x+(x+(x+(x+(x+(x+(x+(x+(x))))))))))
!	y
!end
!
