!const nn=2500
const nn=3

function eval_a(int i,j)real=
	return 1.0/((i+j)*(i+j+1)/2+i+1)
end

proc eval_a_times_u(int n, []real &u,&au)=
	real w,x,y,z

	for i to n do
		au[i]:=0.0
		for j to n do

			x:=au[i]
			y:=eval_a(i-1, j-1)
			z:=u[j]

billy:
			w:=au[i]+eval_a(i, j)
freddy:
!			w:=x+eval_a(i, j)
			au[i]:=w
!			au[i]:=au[i]+eval_a(i-1,j-1)*u[j]
		od
	od
end

proc main=
	[0..nn]real u,v
	real vbv,vv

	for i to nn do
		u[i]:=1.0
		v[i]:=1.0
	od

	for i to 10 do
!		eval_ata_times_u(nn,u,v)
		eval_a_times_u(nn,u,v)
!		eval_ata_times_u(nn,v,u)
	od

CPL =U[1]
CPL =V[1]

	vbv:=0.0
	vv:=0.0
	for i to nn do
		vbv:=vbv+u[i]*v[i]
		vv:=vv+v[i]*v[i]
	od

	println "Resultx =",sqrt(vbv/vv)

end
