!include "mm_types.m"

global enumdata []ichar sysfnnames, []byte sysfnparams, []byte sysfnres =
	(sf_init,				$,	0,	0),
	(sf_print_startfile,	$,	0,	0),
	(sf_print_startstr,		$,	0,	0),
	(sf_print_startptr,		$,	0,	0),
	(sf_print_startcon,		$,	0,	0),
	(sf_print_setfmt,		$,	0,	0),
	(sf_print_nogap,		$,	0,	0),
	(sf_print_space,		$,	0,	0),
	(sf_print_i64,			$,	0,	0),
	(sf_print_i64_nf,		$,	0,	0),
	(sf_print_u64,			$,	0,	0),
	(sf_print_r64,			$,	0,	0),
	(sf_print_r32,			$,	0,	0),
	(sf_print_str,			$,	0,	0),
	(sf_print_str_nf,		$,	0,	0),
	(sf_print_strsl,		$,	0,	0),
	(sf_print_ptr,			$,	0,	0),
	(sf_print_ptr_nf,		$,	0,	0),
	(sf_print_c8,			$,	0,	0),
	(sf_print_bool,			$,	0,	0),
!	(sf_print_var,			$,	0,	0),
	(sf_print_newline,		$,	0,	0),
	(sf_print_end,			$,	0,	0),
	(sf_read_i64,			$,	0,	0),
	(sf_read_r64,			$,	0,	0),
	(sf_read_str,			$,	0,	0),
	(sf_read_fileline,		$,	0,	0),
	(sf_read_strline,		$,	0,	0),
	(sf_read_conline,		$,	0,	0),

	(sf_getnprocs,			$,	0,	1),		!access funcs
	(sf_getprocname,		$,	0,	1),
	(sf_getprocaddr,		$,	0,	1),

	(sf_power_i64,			$,	0,	1),
	(sf_unimpl,				$,	0,	1),

end
!
global [sysfnnames.len]symbol sysfnhandlers

!global [sysfnnames.len]int sysfnproclabels

!global int mmpos
!global byte fshowpst


!!---
global enumdata [0:]ichar jtagnames,
				   [0:]byte jsubs, [0:]byte jisexpr, [0:]byte jsolo =
!Basic units; these don't follow normal rules of params needing to be units or lists
!jisexpr=1/2 when unit returns a value; 1 means unary, 2 binary op,
! 3 means returns a value, but is not a unary or binary op
!jsolo = 1 means unit is allowed standalone without its value being used

!Key
!   A B C		Indicate single subnodes
!   A*			Etc, means a subnode can be a list
!   A+			Etc, means a list with one or two extra elements, so A2, A3

!                       N Expr  Solo
	(jnull=0,		$+1,	0,	3,	0), ! Place holder unit: means 'param no present' when used where a param is expected
	(jconst,		$+1,	0,	3,	0), ! int/real/string/range in .value/.xvalue/.svalue etc
	(jname,			$+1,	0,	3,	0), ! .def = ST entry
	(jblock,		$+1,	1,	0,	1), ! A*
	(jstrinclude,	$+1,	1,	3,	0), ! A; should be const string

!Logical Operators

	(jandl,			$+1,	2,	2,	0), ! A and B; A/B must be bools otherwise ISTRUE applied
	(jorl,			$+1,	2,	2,	0), ! A or B

	(jnotl,			$+1,	1,	1,	0), ! not A; A must be a bool (compiler generates jisfalsel if not)
	(jistruel,		$+1,	1,	1,	0), ! istrue A  zero/not-zero => 0/1
	(jisfalsel,		$+1,	1,	1,	0), ! isfalse A zero/not-zero => 1/0

!Expressions and Operators

	(jmakelist,		$+1,	2,	3,	0), ! (B: A*); B is lower bound; .length=# elements
	(jmakerange,	$+1,	2,	3,	0), ! A..B
	(jmakeset,		$+1,	1,	3,	0), ! [A*]; .length=# elements
	(jmakeslice,	$+1,	2,	3,	0), ! slice(A, B) A=ptr, B=length
	(jreturnmult,	$+1,	1,	0,	0), ! A*; uses .length; (set in TX from return/makelist

	(jkeyword,		$+1,	2,	3,	0), ! def=st entry
	(jdim,			$+1,	2,	3,	0), ! [A:] or [A:B] (set array dims by length)
	(jassign,		$+1,	2,	3,	1), ! A := B
	(jassignmm,		$+1,	2,	3,	1), ! (A*) := (B*); .length
	(jassignms,		$+1,	2,	3,	1), ! (A*) := B; .length
	(jassignmdrem,	$+1,	2,	3,	1), ! (A+) := B; B should be x divrem y 
	(jcall,			$+1,	2,	3,	1), ! A(B*)

	(jcmp,			$+1,	2,	2,	0), ! A cc B
	(jcmpchain,		$+1,	2,	1,	0), ! A* uses .cmpgenop/.cmpmode
	(jbin,			$+1,	2,	2,	0), ! A op B
	(junary,		$+1,	2,	1,	0), ! op A
	(jprop,			$+1,	2,	1,	0), ! prop A
	(jbinto,		$+1,	2,	2,	0), ! A op:= b
	(junaryto,		$+1,	1,	1,	0), ! op:= A
	(jincr,			$+1,	1,	3,	0), ! op A, A op

	(jinrange,		$+1,	2,	2,	0), ! A in B (B is range)
	(jinset,		$+1,	2,	2,	0), ! A in B (B is set)

	(jindex,		$+1,	2,	3,	0), ! A[B]
	(jslice,		$+1,	2,	3,	0), ! A[B..C]

	(jdot,			$+1,	2,	3,	0), ! A.B (B usu name); uses .offset in later stages
	(jdotindex,		$+1,	2,	3,	0), ! A.[B]
	(jdotslice,		$+1,	2,	3,	0), ! A.[B] (B must be jmakerange)

	(jptr,			$+1,	1,	3,	0), ! A^
	(jaddrof,		$+1,	2,	3,	0), ! &A

!NOTE conversion handling in the frontend needs to be reviewed, especially
!type punning

	(jconvert,		$+1,	1,	3,	0), ! Used internally; becomes specific mode in tx pass

	(jshorten,		$+1,	1,	3,	0), ! A; convert type of A to type of this node;
										! seems to be used in init data only; must be compile-time
	(jautocast,		$+1,	1,	3,	0), ! A (changed to jconvert by tx pass)
	(jtypepun,		$+1,	1,	3,	0), ! THIS NEEDS REVISING
	(jwiden,		$+1,	1,	3,	0), !
	(jfwiden,		$+1,	1,	3,	0), !
	(jfnarrow,		$+1,	1,	3,	0), !
	(jfix,			$+1,	1,	3,	0), !
	(jfloat,		$+1,	1,	3,	0), !
	(jtruncate,		$+1,	1,	3,	0), !
	(jtoboolt,		$+1,	1,	3,	0), !

	(jtypeconst,	$+1,	0,	3,	0), ! .value is the type code. The node itself has type i64
	(joperator,		$+1,	0,	3,	0), ! Uses .pclop

	(jbitwidth,		$+1,	1,	1,	0), ! A.bitwidth
	(jbytesize,		$+1,	1,	1,	0), ! A.bytes
	(jtypestr,		$+1,	0,	1,	0), ! A.typestr
	(jbitfield,		$+1,	1,	3,	0), ! A.odd etc (uses .bfcode)

	(jminvalue,		$+1,	1,	3,	0), ! A.min
	(jmaxvalue,		$+1,	1,	3,	0), ! A.max

	(jcompilervar,	$+1,	0,	3,	0), ! Uses .cvindex to denote compiler var)
	(jfmtitem,		$+1,	2,	3,	0), ! A:B within print items
	(jnogap,		$+1,	0,	3,	0), ! 
	(jspace,		$+1,	0,	3,	0), ! 

!Statements

	(jreturn,		$+1,	1,	0,	0), ! return [A]
	(jsyscall,		$+1,	1,	3,	1), ! FN(A*); .fnindex = sysfn no.

	(jto,			$+1,	3,	0,	0), ! to A do B od
	(jif,			$+1,	3,	3,	1), ! if A then B [else C] fi
	(jforup,		$+1,	3,	0,	0), ! for A := B+     to B2 [by B3] do C+ [else C2] od
	(jfordown,		$+1,	3,	0,	0), ! for A := B+ downto B2 [by B3] do C+ [else C2] od
	(jforall,		$+1,	3,	0,	0), ! for[all] [i,]x in L do body [else e] od
									!    A1=i; A2=x; A3=L.lwb; A4=L.upb; B=L; B2={x:=L[I];C1=body; C2=E
	(jforallrev,	$+1,	3,	0,	0), ! Same but with inrev
	(jwhile,		$+1,	3,	0,	1), ! while A [,C] do B od
	(jrepeat,		$+1,	2,	0,	1), ! repeat A until B
	(jgoto,			$+1,	1,	0,	1), ! goto A
	(jlabeldef,		$+1,	0,	0,	0), ! A:
	(jexit,			$+1,	0,	0,	1), ! exit     .loopindex
	(jredo,			$+1,	0,	0,	1), ! redoloop .loopindex
	(jnext,			$+1,	0,	0,	1), ! nextloop .loopindex
	(jdo,			$+1,	1,	0,	1), ! do A od
	(jcase,			$+1,	3,	3,	1), ! case A <B* = whenthen chain> [else C] end
	(jdocase,		$+1,	3,	0,	1), ! Same as case
	(jwhenthen,		$+1,	2,	0,	0), ! when A* then B (part of internal case/switch)

	(jswitch,		$+1,	3,	3,	1), ! Same as case
	(jdoswitch,		$+1,	3,	0,	1), ! Same as case
	(jdoswitchu,	$+1,	3,	0,	1), ! Same as case
	(jdoswitchx,	$+1,	3,	0,	1), ! Same as case
	(jswap,			$+1,	2,	0,	1), ! swap(A, B)
	(jselect,		$+1,	3,	3,	1), ! (A | B* | C)
	(jrecase,		$+1,	1,	0,	0), ! recase A; must be const

	(jprint,		$+1,	2,	0,	1), ! print   [@A,] B*
	(jprintln,		$+1,	2,	0,	1), ! println [@A,] B*
	(jfprint,		$+1,	3,	0,	1), ! print   [@A,] B, C*   B is fmtstr
	(jfprintln,		$+1,	3,	0,	1), ! println [@A,] B, C*   B is fmtstr
	(jread,			$+1,	2,	0,	1), ! read A*
	(jreadln,		$+1,	2,	0,	1), ! readln [@A] (items are in separate jread node)
	(jstop,			$+1,	1,	0,	0), ! stop [A]
	(jeval,			$+1,	1,	3,	1), ! eval A
	(jclear,		$+1,	1,	1,	1), ! clear A
end

global enumdata []ichar bitfieldnames=
	(bf_msb,		$),
	(bf_lsb,		$),
	(bf_msbit,		$),
	(bf_lsbit,		$),
	(bf_msw,		$),
	(bf_lsw,		$),
	(bf_odd,		$),
	(bf_even,		$),
end

global enumdata []ichar cvnames =
	(cv_lineno,		$),
	(cv_strlineno,	$),
	(cv_modulename,	$),
	(cv_filename,	$),
	(cv_func	,	$),
	(cv_date,		$),
	(cv_time,		$),
	(cv_version,	$),
	(cv_typename,	$),
	(cv_nil,		$),
	(cv_pi,			$),
	(cv_infinity,	$),
	(cv_true,		$),
	(cv_false,		$),
end

!!---
global enumdata []ichar symbolnames, []byte symbolgenops, []byte exprstarter,
 []byte symboladdmul =

!First half are basic tokens returned by lexreadtoken()
!                                genops       expr
	(dotsym,			".",		0,			0,	0),
	(commasym,			",",		0,			0,	0),
	(semisym,			";",		0,			0,	0),
	(colonsym,			":",		0,			0,	0),
	(sendtosym,			"=>",		0,			0,	0),
	(pipesym,			"->",		0,			0,	0),
	(lbracksym,			"(",		0,			1,	0),
	(rbracksym,			")",		0,			0,	0),
	(lsqsym,			"[",		0,			1,	0),
	(rsqsym,			"]",		0,			0,	0),
	(lcurlysym,			"{",		0,			0,	0),
	(rcurlysym,			"}",		0,			0,	0),
	(ptrsym,			"^",		0,			1,	0),
	(barsym,			"|",		0,			0,	0),
	(atsym,				"@",		0,			0,	0),
	(addrsym,			"&",		0,			1,	0),
	(ellipsissym,		"...",		0,			0,	0),

	(assignsym,			":=",		0,			0,	0),
	(rangesym,			"..",		0,			0,	0),
	(addsym,			"+",		kadd,		1,	'A'),
	(subsym,			"-",		ksub,		1,	'A'),
	(mulsym,			"*",		kmul,		0,	'M'),
	(divsym,			"/",		kdiv,		0,	'M'),
	(idivsym,			"%",		kidiv,		0,	'M'),
	(iremsym,			"rem",		kirem,		0,	'M'),
	(idivremsym,		"divrem",	kidivrem,	0,	'M'),
	(iandsym,			"iand",		kbitand,	0,	'A'),
	(iorsym,			"ior",		kbitor,		0,	'A'),
	(ixorsym,			"ixor",		kbitxor,	0,	'A'),
	(shlsym,			"<<",		kshl,		0,	'M'),
	(shrsym,			">>",		kshr,		0,	'M'),
	(minsym,			"in",		kmin,		1,	'A'),
	(maxsym,			"max",		kmax,		1,	'A'),
	(andlsym,			"and",		0,			0,	0),
	(orlsym,			"or",		0,			0,	0),
	(xorlsym,			"xor",		0,			0,	0),

	(eqsym,				"=",		0,			1,	0),
	(cmpsym,			"cmp",		0,			1,	0),
	(powersym,			"**",		kpower,		0,	0),
	(insym,				"in",		0,			0,	0),
	(notinsym,			"notin",	0,			0,	0),
	(inrevsym,			"inrev",	0,			0,	0),

	(notlsym,			"not",		knot,		1,	0),
	(istruelsym,		"istrue",	0,			1,	0),
	(inotsym,			"inot",		kbitnot,	1,	0),
	(abssym,			"abs",		kabs,		1,	0),
	(signsym,			"sign",		ksign,		1,	0),
	(sqrtsym,			"sqrt",		ksqrt,		1,	0),
	(sqrsym,			"sqr",		ksqr,		1,	0),

	(propsym,			$,			0,			0,	0),
	(mathsopsym,		$,			0,			1,	0),		! sin etc
	(maths2opsym,		$,			0,			1,	0),		! atan2 etc

	(bitfieldsym,		$,			0,			0,	0),		! Special bit selections
	(eolsym,			$,			0,			0,	0),		! End of line
	(eofsym,			$,			0,			0,	0),		! Eof seen
	(rawxnamesym,		$,			0,			0,	0),		! unassigned name, case-sensitive, that is never a reserved word
	(incrsym,			$,			0,			1,	0),		! 1/2 = ++/--; later may add +2 for x++/x--
	(intconstsym,		$,			0,			1,	0),		! 123 32 bits signed
	(realconstsym,		$,			0,			1,	0),		! 123.4 64 bits
	(charconstsym,		$,			0,			1,	0),		! 'A' or 'ABCD'
	(stringconstsym,	$,			0,			1,	0),		! "ABC"

!Second half are tokens that can be yielded after a name lookup:
	(unitnamesym,		$,			0,			0,	0),		! 
	(namesym,			$,			0,			1,	0),		! identifier symbol
	(kincludesym,		$,			0,			0,	0),		! INCLUDE
	(kstrincludesym,	$,			0,			1,	0),		! SINCLUDE/BINCLUDE

	(stdtypesym,		$,			0,			1,	0),		! INT, CHAR etc
	(kicharsym,			$,			0,			1,	0),		! ICHAR IVOID
	(kifsym,			$,			0,			1,	0),		! 
	(kthensym,			$,			0,			0,	0),		! 
	(kelsifsym,			$,			0,			0,	0),		! 
	(kelsesym,			$,			0,			0,	0),		! 
	(kelsecasesym,		$,			0,			0,	0),		! 
	(kelseswitchsym,	$,			0,			0,	0),		! 
	(kendsym,			$,			0,			0,	0),		! 
	(kunlesssym,		$,			0,			0,	0),		! 
	(kcasesym,			$,			0,			1,	0),		! CASE
	(kdocasesym,		$,			0,			0,	0),		! DOCASE
	(krecasesym,		$,			0,			0,	0),		! RECASE
	(kwhensym,			$,			0,			0,	0),		! 
	(kforsym,			$,			0,			0,	0),		! FOR
	(ktosym,			$,			0,			0,	0),		! TO/DOWNTO
	(kbysym,			$,			0,			0,	0),		! 
	(kdosym,			$,			0,			0,	0),		! 
	(kwhilesym,			$,			0,			0,	0),		! 
	(krepeatsym,		$,			0,			0,	0),		! 
	(kuntilsym,			$,			0,			0,	0),		! 
	(kreturnsym,		$,			0,			0,	0),		! 
	(kstopsym,			$,			0,			0,	0),		! 
	(kloopsym,			$,			0,			0,	0),		! EXIT/NEXT/LOOP/REDO/RESTART
	(kgotosym,			$,			0,			0,	0),		! GO/GOTO
	(kswitchsym,		$,			0,			0,	0),		! SWITCH
	(kdoswitchsym,		$,			0,			0,	0),		! DOSWITCH
	(kprintsym,			$,			0,			0,	0),		! PRINT/PRINTLN/FPRINT/FPRINTLN
	(kreadsym,			$,			0,			0,	0),		! READ/READLN
	(kprocsym,			$,			0,			0,	0),		! PROC
	(kfuncsym,			$,			0,			0,	0),		! FUNCTION
	(klabelsym,			$,			0,			0,	0),		! LABEL
	(krecordsym,		$,			0,			0,	0),		! RECORD
	(kstructsym,		$,			0,			0,	0),		! STRUCT
	(kunionsym,			$,			0,			0,	0),		! UNION
	(kimportmodulesym,	$,			0,			0,	0),		! IMPORTDLL/IMPORTMODULE
	(kprojectsym,		$,			0,			0,	0),		! PROJECT
	(ktypesym,			$,			0,			0,	0),		! TYPE
	(krefsym,			$,			0,			1,	0),		! REF
	(kvoidsym,			$,			0,			1,	0),		! VOID
	(kvarsym,			$,			0,			0,	0),		! MUT
	(kletsym,			$,			0,			0,	0),		! LET
	(kslicesym,			$,			0,			0,	0),		! SLICE/SLICE2D
	(kmacrosym,			$,			0,			0,	0),		! MACRO
	(kconstsym,			$,			0,			0,	0),		! 
	(kclearsym,			$,			0,			0,	0),		! CLEAR
	(kheadersym,		$,			0,			0,	0),		! MODULE
	(kglobalsym,		$,			0,			0,	0),		! global
	(kstaticsym,		$,			0,			0,	0),		! STATIC

	(kcastsym,			$,			0,			1,	0),		! CAST
	(compilervarsym,	$,			0,			1,	0),		! $lineno etc
	(dollarsym,			$,			0,			1,	0),		! to be used for current array upperbound; also tabledata names
	(kevalsym,			$,			0,			0,	0),		! EVAL
	(ktabledatasym,		$,			0,			0,	0),		! tabledata
	(kclampsym,			$,			0,			1,	0),			! CLAMP
	(kswapsym,			$,			0,			0,	0),		! SWAP
	(ksyscallsym,		$,			0,			1,	0),		! $getprocname etc
end

global enumdata []ichar headerdirnames =
	(hdr_module,		$),
	(hdr_import,		$),
	(hdr_sourcepath,	$),
	(hdr_linkdll,		$),
end

global enumdata [0:]ichar scopenames=
	(Module_scope=0,	"Local"), ! 		!module
	(subprog_scope,		"Global"), ! 		!inter-subprog
	(program_scope,		"Program"), ! 		!inter-module
	(export_scope,		"Export"), ! 		!inter-program
end

global enumdata =
	million_unit,
	billion_unit,
end

global enumdata [0:]ichar namenames=
	(nullid=0,		$),		!Not assigned
	(programid,		$),		!Main root
	(subprogid,		$),
	(moduleid,		$),		!Current or imported module
	(dllmoduleid,	$),		!
	(typeid,		$),		!Type name in type, proc or module
	(procid,		$),		!Proc/method/func/op name
	(dllprocid,		$),		!Dll Proc/func name
	(dllvarid,		$),		!Dll variable name
	(constid,		$),		!Named constant in type, proc or module
	(staticid,		$),		!Static in type or proc or module
	(frameid,		$),		!Local var
	(paramid,		$),		!Local param
	(fieldid,		$),		!Field of Record or Class
	(labelid,		$),		!Label name in proc only
	(macroid,		$),		!Name of macro
	(macroparamid,	$),		!Macro formal parameter name
	(linkid,		$),		!Name in class defined in a base class
end

global enumdata []ichar propnames =
	(kksliceptr,	$),
	(kklen,			$),
	(kklwb,			$),
	(kkupb,			$),
	(kkbounds,		$),
	(kkbitwidth,	$),
	(kkbytesize,	$),
	(kktypestr,		$),
	(kkminval,		$),
	(kkmaxval,		$),
end

!!---
global tabledata []ichar stnames, []byte stsymbols, []i16 stsubcodes=

	("if",			kifsym,			jif),
	("then",		kthensym,		0),
	("elsif",		kelsifsym,		jif),
	("else",		kelsesym,		0),
	("elsecase",	kelsecasesym,	jcase),
	("elseswitch",	kelseswitchsym,	jswitch),
	("case",		kcasesym,		jcase),
	("docase",		kdocasesym,		jdocase),
	("recase",		krecasesym,		jrecase),
	("when",		kwhensym,		0),
	("for",			kforsym,		0),
	("to",			ktosym,			0),
	("downto",		ktosym,			1),
	("by",			kbysym,			0),
	("do",			kdosym,			0),
	("end",			kendsym,		0),
	("while",		kwhilesym,		0),
	("repeat",		krepeatsym,		0),
	("until",		kuntilsym,		0),
	("return",		kreturnsym,		0),
	("stop",		kstopsym,		0),
	("redoloop",	kloopsym,		jredo),
	("nextloop",	kloopsym,		jnext),
	("exit",		kloopsym,		jexit),
	("goto",		kgotosym,		0),
	("switch",		kswitchsym,		jswitch),
	("doswitch",	kdoswitchsym,	jdoswitch),
	("doswitchu",	kdoswitchsym,	jdoswitchu),
	("doswitchx",	kdoswitchsym,	jdoswitchx),
	("tabledata",	ktabledatasym,	0),
	("enumdata",	ktabledatasym,	1),
	("clamp",		kclampsym,		0),
	("eval",		kevalsym,		0),
	("print",		kprintsym,		jprint),
	("println",		kprintsym,		jprintln),
	("fprint",		kprintsym,		jfprint),
	("fprintln",	kprintsym,		jfprintln),

	("cp",			kprintsym,		jprint),
	("cpl",			kprintsym,		jprintln),

	("read",		kreadsym,		jread),
	("readln",		kreadsym,		jreadln),
	("cast",		kcastsym,		jconvert),

	("function",	kfuncsym,	0),
	("func",		kfuncsym,	0),
	("proc",		kprocsym,		0),
	("fun",			kfuncsym,	1),

	("type",		ktypesym,		0),
	("record",		krecordsym,		0),
	("struct",		kstructsym,		0),
	("union",		kunionsym,		0),
	("ref",			krefsym,		0),
	("var",			kvarsym,		0),
	("let",			kletsym,		0),

	("include",		kincludesym,	0),
	("binclude",	kstrincludesym,	'B'),
	("sinclude",	kstrincludesym,	'S'),
	("strinclude",	kstrincludesym,	'S'),

	("macro",		kmacrosym,		0),

	("static",		kstaticsym,		0),
	
	("const",		kconstsym,		0),

	("$getnprocs",		ksyscallsym,	sf_getnprocs),
	("$getprocname",	ksyscallsym,	sf_getprocname),
	("$getprocaddr",	ksyscallsym,	sf_getprocaddr),

	("importdll",	kimportmodulesym,	0),
	("project",		kprojectsym,		0),
	("unless",		kunlesssym,			0),

	("global",		kglobalsym,		subprog_scope),
	("export",		kglobalsym,		export_scope),

	("swap",		kswapsym,		0),

	("void",		kvoidsym,		0),
	("int",			stdtypesym,		tint),
	("word",		stdtypesym,		tword),
	("real",		stdtypesym,		treal),

	("ichar",		kicharsym,		tc8),
	("ivoid",		kicharsym,		tvoid),

	("i8",			stdtypesym,		ti8),
	("i16",			stdtypesym,		ti16),
	("i32",			stdtypesym,		ti32),
	("i64",			stdtypesym,		ti64),

	("r32",			stdtypesym,		tr32),
	("r64",			stdtypesym,		tr64),

	("byte",		stdtypesym,		tu8),
	("u8",			stdtypesym,		tu8),
	("u16",			stdtypesym,		tu16),
	("u32",			stdtypesym,		tu32),
	("u64",			stdtypesym,		tu64),

	("char",		stdtypesym,		tc8),
	("c8",			stdtypesym,		tc8),
	("c64",			stdtypesym,		tc64),

	("bool64",		stdtypesym,		tbool64),
	("bool",		stdtypesym,		tbool64),
	("bool8",		stdtypesym,		tbool8),

	("label",		stdtypesym,		tlabel),

	("slice",		kslicesym,		tslice),

	("million",		unitnamesym,	million_unit),
	("billion",		unitnamesym,	billion_unit),

	("$lineno",		compilervarsym,	cv_lineno),
	("$strlineno",	compilervarsym,	cv_strlineno),
	("$filename",	compilervarsym,	cv_filename),
	("$modulename",	compilervarsym,	cv_modulename),
	("$function",	compilervarsym,	cv_func),
	("$date",		compilervarsym,	cv_date),
	("$time",		compilervarsym,	cv_time),
	("$version",	compilervarsym,	cv_version),
	("$typename",	compilervarsym,	cv_typename),
	("nil",			compilervarsym,	cv_nil),
	("pi",			compilervarsym,	cv_pi),
	("true",		compilervarsym,	cv_true),
	("false",		compilervarsym,	cv_false),
	("infinity",	compilervarsym,	cv_infinity),
	("$",			dollarsym,		0),

	("and",			andlsym,		0),
	("or",			orlsym,			0),
	("xor",			xorlsym,		0),
	("iand",		iandsym,		0),
	("ior",			iorsym,			0),
	("ixor",		ixorsym,		0),
	("in",			insym,			0),
	("notin",		notinsym,		1),
	("inrev",		inrevsym,		0),
	("rem",			iremsym,		0),
	("divrem",		idivremsym,		0),
	("min",			minsym,			0),
	("max",			maxsym,			0),

	("not",			notlsym,		0),
	("inot",		inotsym,		0),
	("istrue",		istruelsym,		0),
	("abs",			abssym,			kabs),

	("sqr",			sqrsym,			0),
	("sqrt",		sqrtsym,		0),
	("sign",		signsym,		0),

	("sin",			mathsopsym,		maths_sin),
	("cos",			mathsopsym,		maths_cos),
	("tan",			mathsopsym,		maths_tan),
	("asin",		mathsopsym,		maths_asin),
	("acos",		mathsopsym,		maths_acos),
	("atan",		mathsopsym,		maths_atan),
	("log",			mathsopsym,		maths_log),
	("log10",		mathsopsym,		maths_log10),
	("exp",			mathsopsym,		maths_exp),
	("round",		mathsopsym,		maths_round),
	("floor",		mathsopsym,		maths_floor),
	("ceil",		mathsopsym,		maths_ceil),

	("atan2",		maths2opsym,	maths_atan2),
	("fmod",		maths2opsym,	maths_fmod),

	("sliceptr",	propsym,		kksliceptr),
	("len",			propsym,		kklen),
	("lwb",			propsym,		kklwb),
	("upb",			propsym,		kkupb),
	("bounds",		propsym,		kkbounds),
	("bitwidth",	propsym,		kkbitwidth),
	("bytes",		propsym,		kkbytesize),
	("typestr",		propsym,		kktypestr),

	("msb",			bitfieldsym,	bf_msb),
	("lsb",			bitfieldsym,	bf_lsb),
	("msbit",		bitfieldsym,	bf_msbit),
	("lsbit",		bitfieldsym,	bf_lsbit),
	("msw",			bitfieldsym,	bf_msw),
	("lsw",			bitfieldsym,	bf_lsw),
	("odd",			bitfieldsym,	bf_odd),
	("even",		bitfieldsym,	bf_even),

	("fi",			kendsym,		kifsym),
	("esac",		kendsym,		kcasesym),
	("od",			kendsym,		kdosym),

	("$caligned",	atsym,			1),
	("clear",		kclearsym,		0),

	("module",		kheadersym,		hdr_module),
	("import",		kheadersym,		hdr_import),
	("$sourcepath",	kheadersym,		hdr_sourcepath),
	("linkdll",		kheadersym,		hdr_linkdll),
end

global enumdata [0:]ichar convnames =
	(kkerror=0,     $),
	(kkfloat,       $),
	(kkfix,         $),
	(kktruncate,    $),
	(kkwiden,       $),
	(kkfwiden,      $),
	(kkfnarrow,     $),
	(kksoftconv,    $),
	(kktoboolt,     $),
	(kkharderr,     $),

	(kksofttrun,    $),
	(kkichar2sl,    $),
	(kkax2slice,    $),
	(kkcx2ichar,    $),
end

global enumdata [0:]ichar ccnames, [0:]ichar ccshortnames =
	(no_cc=0,	"xx",	"?"),
	(eq_cc,		"eq",	" = "),
	(ne_cc,		"ne",	" <> "),
	(lt_cc,		"lt",	" < "),
	(le_cc,		"le",	" <= "),
	(ge_cc,		"ge",	" >= "),
	(gt_cc,		"gt",	" > "),
end

global enumdata [0:]ichar mathsnames =
	(none_m = 0,		$),
	(maths_sin,			$+6),
	(maths_cos,			$+6),
	(maths_tan,			$+6),
	(maths_asin,		$+6),
	(maths_acos,		$+6),
	(maths_atan,		$+6),
	(maths_log,			$+6),
	(maths_log10,		$+6),
	(maths_exp,			$+6),
	(maths_round,		$+6),
	(maths_ceil,		$+6),
	(maths_floor,		$+6),
	(maths_fract,		$+6),
	(maths_sign,		$+6),
	(maths_fmod,		$+6),
	(maths_atan2,		$+6),
end

!global enumdata [0:]ichar pclnames =
!	(knop=0,	$+1),
!
!	(kadd,		$+1),
!	(ksub,		$+1),
!	(kmul,		$+1),
!	(kdiv,		$+1),
!	(kidiv,		$+1),
!	(kirem,		$+1),
!	(kbitand,	$+1),
!	(kbitor,	$+1),
!	(kbitxor,	$+1),
!	(kshl,		$+1),
!	(kshr,		$+1),
!	(kmin,		$+1),
!	(kmax,		$+1),
!	(kidivrem,	$+1),
!  
!	(kmaths2,	$+1),
!	(kpower,	$+1),
!  
!	(kaddpx,	$+1),
!	(ksubpx,	$+1),
!	(ksubp,		$+1),
!
!	(kneg,		$+1),
!	(kabs,		$+1),
!	(kbitnot,	$+1),
!	(knot,		$+1),
!	(ktoboolt,	$+1),
!	(ktoboolf,	$+1),
!  
!	(ksqr,		$+1),
!  
!	(ksqrt,		$+1),
!
!	(kmaths,	$+1),
!	(ksign,		$+1),
!
!	(kfloat,    $+1),
!	(kfix,		$+1),
!	(ktruncate,	$+1),
!	(kfwiden,	$+1),
!	(kfnarrow,	$+1),
!	(kwiden,	$+1),
!  
!	(ktypepun,	$+1),
!
!	(ktobool,	$+1),
! 
!	(kincrto,	$+1),
!	(kdecrto,	$+1),
!	(kincrload,	$+1),
!	(kdecrload,	$+1),
!	(kloadincr,	$+1),
!	(kloaddecr,	$+1)
!end
!

global []int D_typestarterset= (stdtypesym,lsqsym,krefsym,krecordsym,
		kicharsym, kslicesym)

global [tr64..tc64, tr64..tc64]i16 softconvtable = (
!To: r64			r32			i64			u64			c64				 From:
	(kksoftconv,	kkfnarrow,	kkfix,		kkfix,		kkfix),			!r64
	(kkfwiden,		kksoftconv,	kkfix,		kkfix,		kkfix),			!r32
	(kkfloat,		kkfloat,	kksoftconv,	kksoftconv,	kksoftconv),	!i64
	(kkfloat,		kkfloat,	kksoftconv,	kksoftconv,	kksoftconv),	!u64
	(kkfloat,		kkfloat,	kksoftconv,	kksoftconv,	kksoftconv))	!c64

global [symbolnames.lwb..symbolnames.upb]byte endsexpr
global []byte exprendsymbols=(rbracksym,rsqsym,kthensym,kelsifsym,
			kelsesym, kuntilsym, kdosym, kendsym, commasym, barsym,
			semisym, ktosym)

global [jtagnames.bounds]byte isbooltag

global [symbolnames.bounds]byte binopset
global [symbolnames.bounds]byte keepeol

proc start=
	int genop, s,t, a, specop

	for i to exprendsymbols.len do
		endsexpr[exprendsymbols[i]]:=1
	od

	isbooltag[jcmp]:=1
	isbooltag[jcmpchain]:=1
	isbooltag[jandl]:=1
	isbooltag[jorl]:=1
	isbooltag[jnotl]:=1
	isbooltag[jistruel]:=1
	isbooltag[jisfalsel]:=1
	isbooltag[jinrange]:=1
	isbooltag[jinset]:=1

	for i in assignsym..notinsym do binopset[i]:=1 od

	for i in keepeol.bounds do
		if i in [commasym, lsqsym, lbracksym] or binopset[i] and 
				i not in [maxsym, minsym] then
			keepeol[i]:=1
		fi
	od

end

