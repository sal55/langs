function binsearch(ref[0:]int a, int length, int key)int=
	int low,high,middle
	int result

!with low, high,middle do
	low:=0; high:=length
	result:=-1
	while high>low do
!  middle:=low+(high-low)/2
			middle:=low+(high-low)>>1
			if key=a^[middle] then
				result:=middle
				exit
!			return middle
			elsif key>a^[middle] then
				low:=middle+1
			else
				high:=middle
			fi
	od

	return result
end

proc main=
	int i,j,k,n,sum,length,step,key,length2
	ref[0:]int data

	n:=1800
!	n:=180
	data:=malloc(n*int.bytes)
	if data=nil then
CPL "NIL DATA", N*INT.BYTES,DATA

 stop fi
	for i:=0 to n-1 do data^[i]:=2*i+1 od

!sum:=binsearch(data,0,data^[0])
	sum:=-1

	for length:=1 to n do
		for step:=1 to length do
			key:=0
			length2:=length*2
			while key<=length2 do
				sum+:=binsearch(data,length,key)
				key+:=step
			od
		od
	od
	println "Sum=",sum
end
