!dummy

export function list_make(iobject a, int length,lower=1)object p=
!create a list of length objects starting from a
!VAR INT SS:=SMALLMEMTOTAL
!STATIC REF VOID SPTR
!
!!PCERROR("LIST MAKE")
!ASM MOV [SPTR],DSTACK

!CPL "LM1",A, =SPTR!,STDNAMES[A.TAG],A.VALUE
	p:=obj_new(vlist)
!CPL "LM2",SMALLMEMTOTAL-SS
	p.mutable:=1
	p.lower32:=lower
	p.length:=length
	if length then
!CPL "LM3",SMALLMEMTOTAL-SS
		p.varptr:=pcm_alloc(length*object.bytes)
!CPL "LM4",SMALLMEMTOTAL-SS
		p.alloc32:=allocbytes/object.bytes
		memcpy(p.varptr, a, length*object.bytes)
	fi
!CPL "LM5",SMALLMEMTOTAL-SS
	return p
end

global proc list_print(object p, ichar fmt)=
	iobject q

!CPL "LP1"
	m$print_str("(")
	m$print_nogap()

!CPL "LP2"
	q:=p.varptr
!CPL "LP3",q,stdnames[q.tag],=fmt
!CPL "LP3",q,q.tag,=fmt

	for i to p.length do
		var_print(q^,fmt)
		m$print_nogap()
		++q
		if i<p.length then m$print_str(",") fi
	od
!
	m$print_str(")")

end

global proc list_free(object p)=
	iobject q

	q:=p.varptr
	to p.length do
		var_unshare(q^)
		++q
	od
	if p.length then
		pcm_free(p.varptr,p.alloc32*object.bytes)
	fi

	pcm_free32(p)
end

!global function list_getindex(object a, int index)object=
!!a is a list, b is an int; return list[int]
!	var word offset
!
!	offset:=index-a.lower32
!	if offset>=word(a.length) then
!		pcerror("list[int] bounds")
!	fi
!
!	return var_share((a.varptr+offset)^)
!end

global function list_dupl(object p)object q=
	iobject plist, qlist

	q:=obj_new(vlist)
	q^:=p^
	q.refcount:=1
	q.mutable:=1

	if q.length=0 then return q fi
!
	qlist:=q.varptr:=pcm_alloc(p.length*object.bytes)
	q.alloc32:=allocbytes/object.bytes
	plist:=p.varptr
!
	to q.length do
		VAR_SHARE(PLIST^)
		qlist^:=var_dupl(plist^)
		++qlist
		++plist
	od

!CPL =P
!CPL =Q

	return q
end


global proc list_putindex(object p, int index, object x)=
	iobject dest
	word offset

!CPL =P,=P.REFCOUNT,P.MUTABLE


	if not p.mutable then pcerror("List not mutable") fi

	offset:=index-p.lower32
!CPL =OFFSET

	if offset>=word(p.length) then
		if int(offset)<0 then
			pcerror("putlist[int] lwb")
		elsif offset=p.length then
PCERROR("LIST/APPEND NOT READY")
!			obj_append_list(q,x)
			return
		else
			pcerror("putlist[int] bounds")
		fi
	fi

	dest:=p.varptr+offset
!CPL=DEST
	var_unshare(dest^)
	dest^:=x				!xfer ownership	
end

global function list_new(int lower, upper, object init)object p=
	int length:=upper-lower+1
	iobject q

	p:=obj_new(vlist)
	p.mutable:=1
	p.lower32:=lower
	p.length:=length
	if length then
		q:=p.varptr:=pcm_alloc(length*object.bytes)
		p.alloc32:=allocbytes/object.bytes
		if init.tag=tvoid then
			to length do
				q^:=&voidobj
				++q
			od
		else
			to length do
				q^:=var_share(init)
				++q
			od
		fi
	fi
	return p
end
