type layout = [0..8, 0..8]char
type group = [0..8]int

func tilevalue(layout board, int row, col)int =
	return -1 when board[row, col]='.'
	board[row,col]-'1'
end

func inttochar(int value)int=
	'1'+value
end

func getsquare(int row, col)int=
	(row/3)*3 + (col/3)
end

func prepare(layout board, group rows, cols, squares)int=
	int square, intvalue, candidatebits

	for row in 0..8 do
		for col in 0..8 do
			square:=getsquare(row, col)
			intvalue:=tilevalue(board, row, col)
			candidatebits:=(rows[row] ior cols[col] ior squares[square])
!CPL =ROW, =COL, =INTVALUE,=CANDIDATEBITS
			if intvalue<>-1 and ((candidatebits>>intvalue) iand 1) = 1 then
				return false
			fi
			if intvalue<>-1 then
				rows[row] ior:= 1<<intvalue
				cols[col] ior:= 1<<intvalue
				squares[square] ior:= 1<<intvalue
			fi
		od
	od
	true
end

func solverecur(layout board, group rows, cols, squares, int row, int col)int=
	int i,j
	int rowbits, colbits, candidatebits
	int nextrow, nextcol, intvalue, square
	int squarebits

	return true when row=9
	nextrow := (col = 8 | row + 1 | row);
	nextcol := (col = 8 | 0 | col + 1);

	square := getsquare(row, col);

	intvalue := tilevalue(board, row, col)

	if intValue <> -1 then
		return solveRecur(board, rows, cols, squares, nextrow, nextcol)
	fi

	rowbits := rows[row]
	colbits := cols[col]

	squarebits := squares[square]

	candidatebits := rowbits ior colbits ior squarebits

	for i in 0..8 do
!		if candidatebits >> i iand 1 = 0 then
		if candidatebits >> i iand 1 = 0 then
			rows[row] ior:= (1 << i)
			cols[col] ior:= (1 << i)
			squares[square] ior:= (1 << i)
			board[row,col] := intToChar(i)
			if solveRecur(board, rows, cols, squares, nextrow, nextcol) then
				return true
			fi

			rows[row] iand:= inot(1 << i)
			cols[col] iand := inot(1 << i)
			squares[square] iand:= inot(1 << i)
		fi
	od

	board[row,col] := '.'
	return false
end

func solve(layout board)int =
	group rows, cols, squares
	clear rows
	clear cols
	clear squares

	if not prepare(board, rows, cols, squares) then
CPL "NOT PREP"
		return false
	fi
	return solveRecur(board, rows, cols, squares, 0, 0)
end

proc printpuzzle(layout matrix)=
	println "----------------------"
	for i:=0 to 8 do
		for j:=0 to 8 do
			fprint " #",matrix[i,j]
			if j in [2,5] then
				print " |"
			fi
		od
		println
		if i in [2,5] then
			println "----------------------"
		fi
	od
	println "----------------------"
	println
end

proc main=
layout matrix, matrixcopy
layout input
!	ichar grid:=
!	"2483.176."+
!	"7...2.38."+
!	"......5.4"+
!	"..27.3..6"+
!	"....1...."+
!	"4..6.21.."+
!	"3.7......"+
!	".96.3...2"+
!	".245.6893"

	ichar strinput:=
	"..6.8.579"+
	"...6...4."+
	"4......8."+

	".3.19.6.."+
	"........3"+
	".2...3..8"+

	"..8..9..1"+
	"..2.6...."+
	"9..2.1..5"

	memcpy(&input, strinput, 81)

	matrix:=input
!	memcpy(&matrix, &input, 81)
	printpuzzle(matrix)

	to 300'000 do
		matrix:=input
!		memcpy(&matrix, &input, 81)
		solve(matrix)
	od
!
!    if solvePuzzle() then
        printPuzzle(matrix)
!    else
!        println "\nNo solution or error!"
!    fi
!
end
