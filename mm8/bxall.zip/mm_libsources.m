global const fsyslibs = 1

global tabledata []ichar syslibnames, []ichar syslibtext =
	("msyswin.m",		strinclude "msyswin.m"),
	("msyswinc.m",		strinclude "msyswinc.m"),
	("msyswini.m",		strinclude "msyswini.m"),
	("msyslinc.m",		strinclude "msyslinc.m"),
	("msys.m",			strinclude "msys.m"),
	("msysc.m",			strinclude "msysc.m"),
	("msysmin.m",		strinclude "msysmin.m"),
	("mlib.m",			strinclude "mlib.m"),
	("mclib.m",			strinclude "mclib.m"),
	("mwindows.m",		strinclude "mwindows.m"),
	("mlinux.m",		strinclude "mlinux.m"),
	("mwindll.m",		strinclude "mwindll.m"),
	("mwindllc.m",		strinclude "mwindllc.m"),
end

global proc loadbuiltins=
!load built-in libs to sources[] list
	ifile pf
	ichar filename

	for i to syslibnames.len do
		filename:=syslibnames[i]
		pf:=newsourcefile()

		sources[nsourcefiles].name:=pcm_copyheapstring(extractbasefile(filename))
		sources[nsourcefiles].filename:=filename
		sources[nsourcefiles].text:=syslibtext[i]

		SOURCES[NSOURCEFILES].TEXT:=pcm_copyheapstring(syslibtext[i])


		sources[nsourcefiles].size:=strlen(syslibtext[i])
!		sources[nsourcefiles].path:="<Builtins>"
		sources[nsourcefiles].path:=""
		sources[nsourcefiles].filespec:=filename
		sources[nsourcefiles].issyslib:=1
		sources[nsourcefiles].issupport:=0
!CPL "LOADED BUILTIN", FILENAME
	od
end
