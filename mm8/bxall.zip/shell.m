!Shell sort

const int size=50

[size]int data

proc shell_sort(ref[]int x)=
	int first,last,gap,i,j,k,tempi,tempj


	last := size
	gap := last/4 + 1

	do
		first := gap + 1
		for i := first to last do
			tempi := x^[i]
			j := i - gap 
			do
				tempj := x^[j]
				if tempi >= tempj then
					j := j+gap
					exit
				fi
				k:=j+gap

				x^[k] := tempj
				if j <= gap then
					exit
				fi
				j := j-gap
			od
			x^[j] := tempi
		od

		if gap = 1 then
			return
		else
			gap := gap/4 + 1 
		fi
	od
END

proc main=
	int i,n,t
	static [50]int data0 =( 9, 34, 14, 18, 33, 46, 11, 13, 7, 26, 22, 10, 36, 40, 2, 28, 32, 1,
		23, 31, 43, 5, 24, 42, 45, 50, 16, 3, 47, 39, 21, 49, 41, 6, 19, 30,
		20, 35, 44, 38, 25, 15, 27, 17, 8, 4, 29, 37, 48, 12)

	int xx
	println "Unsorted data:",size
	for xx:=1 to size do
		print data0[xx],$
	od
	println

	for n:=1 to 1'500'000 do
!	for n:=1 to 100'000 do
		for i:=1 to size do data[i]:=data0[i] od
		shell_sort(&data)
	od
!
	println "Sorted data:",size
	for xx:=1 to size do
		print data[xx],$
	od
	println

end

