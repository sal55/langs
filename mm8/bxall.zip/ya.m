proc xmain=
!	PRINTLN "MAIN YA"
end

proc start=
	PRINTLN "START YA"
end
