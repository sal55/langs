import clib
import msys
import mlib
import oslib
import qs_decls
import qs_tables
import qs_lib
import qs_strings
import qs_lists
import qs_arrays
!IMPORT QS_NAMES

global object voidobj

type binfunc=ref function(object x,y)object

global macro var_share(p) = (++p^.refcount; p)

global macro var_unshare(p) =
	if --p^.refcount=0 then var_free(p) fi

proc start=
	object p

	for i in smallinttable.bounds do
		p:=shortobj_new(vint)
		p.value:=i
		smallinttable[i]:=p
	od

	voidobj:=shortobj_new(tvoid)
	voidobj.refcount:=0x8000'0000		!void calls to free

end

global function var_new(int tag)object p=
!create new object descriptor, which all fields set to zero
!except refcount=1
!.objtype=0 => normal_obj

!CPL "OBJ.NEW",TTNAME[TAG]
	p:=pcm_alloc32()
	p.refcount:=1
	p.tagx:=tag
	p.value:=0
	p.c:=0
	p.d:=0
	return p
end

global function shortobj_new(int tag)object p=
!create new object descriptor, which all fields set to zero
!except refcount=1
!.objtype=0 => normal_obj

!CPL "OBJ.NEW",TTNAME[TAG]
	p:=pcm_alloc16()
	p.refcount:=1
	p.tagx:=tag
	p.value:=0

	return p
end

global proc var_free(object p)=
!remove p's resources when no more references to it
!CPL "///FREE OBJ REF COUNT=0"
!CPL "///FREE OBJ",STDTYPENAMES[P.TAG], =P.REFCOUNT

!	PCERROR("FREE")

	switch p.tag
	when vint,vreal, vrange then
!CPL "FREE",STDNAMES[P.TAG],P.VALUE
		cast(p,ref word)^:=word(int(freelist[1]))
		freelist[1]:=cast(p)
!		pcm_free16(p)

!	when tlist,trecord then
!		list_free(p)
!
!	when tarray then
!		array_free(p)
!
	when vstring then
		if p.length64 then
			pcm_free(p.strptr, p.alloc64)
		fi
		pcm_free32(p)
!!
!	when tref then
!		obj_unshare(p.uref.iobjptr^)
!
!	when trefpack then
!		if p.urefpack.objptr2 then
!			obj_unshare(p.urefpack.objptr2)
!		fi
!
	when tvoid then				!voids aren't freed
!
	else
		CPL "Can't Free",stdnames[p.tag]

	end switch
end

global function int_make(int a)object p=
!share this for common values

	if a<=smallinttable.upb and a>=smallinttable.lwb then
		return var_share(smallinttable[a])
	fi

	if p:=object(freelist[1]) then		!Items of this block size available
		freelist[1]:=ref word(int((freelist[1])^))
	else
		p:=pcm_alloc16()
	fi
	p.refcount:=1
	p.tagx:=vint
!	p.a:=vint<<32+1
	p.value:=a

	return p
end

global function string_make(ichar s)object=
!create a ivariant string from given string
!string will be copied to heap
	var ref char t
	int length:=strlen(s)

	if length=0 then
		return str_makex(t,0,0)
	else
		t:=pcm_alloc(length)
		memcpy(t,s,length)
		return str_makex(t,length,allocbytes)
	fi
end

global function str_makex(ichar s, int length,allocated)object=
!create a variant string from given string
!string is already on the heap
	var ref char t
	var object p

!	if length=-1 then
!		length:=strlen(s)
!	fi

	p:=obj_new(tstring)

	if length=0 then
		p.strptr:=nil
	else
		p.strptr:=s
		p.length64:=length
		p.alloc64:=allocated
	fi
	p.lower:=1
	p.mutable:=1
	p.refcount:=1

	return p
end

global function getintindex(int a)int=
	object p:=int_make(a)

	if nintconsts>=maxintconst then
		abortprogram("Too many int consts")
	fi
	intconsttable[++nintconsts]:=p
	return nintconsts
end

global function real_make(real x)object p=
!share this for common values
	p:=shortobj_new(vreal)
	p.xvalue:=x

	return p
end

!global function type_make(int t)object p=
!
!	p:=obj_new(ttype)
!	p.value:=t
!
!	return p
!end

!global function range_make(int a,b)object p=
!	p:=obj_new(trange)
!	p.lower64:=a
!	p.upper64:=b
!
!	return p
!end

global function void_new:object p=
	return voidobj
end

!global function var_getindex(object x,y)object z=
!
!	case pr(x.tag,y.tag)
!	when pr(tlist, tint) then
!		z:=list_getindex_int(x,y.unumber.value)
!
!	when pr(tlist,trange) then
!!		PCERROR("GET SLICE")
!		z:=list_getslice(x,y)
!	when pr(tstring,tint) then
!		z:=str_getindex_int(x,y.unumber.value)
!
!	when pr(tarray,tint) then
!		z:=array_getindex_int(x,y.unumber.value)
!
!	else
!		pcmxtypes("1:getindex",x,y)
!	esac
!
!	return z
!end

!global function var_getdotindex(object x,y)object z=
!
!	case pr(x.tag,y.tag)
!	when pr(tstring,tint) then
!		z:=str_getdotindex_int(x,y.unumber.value)
!
!	else
!		pcmxtypes("getdotindex",x,y)
!	esac
!
!	return z
!end
!
!global function var_getindexref(object x,y)object z=
!
!	case pr(x.tag,y.tag)
!	when pr(tlist, tint) then
!		z:=list_getindexref_int(x,y.unumber.value)
!
!	when pr(tarray, tint) then
!		z:=array_getindexref_int(x,y.unumber.value)
!
!!	when pr(tlist,trange) then
!	else
!		pcmxtypes("getindexref",x,y)
!	esac
!
!	return z
!end
!
!global proc var_putindex(object x,y,z)=
!!x[y]:=z
!	case pr(x.tag,y.tag)
!	when pr(tlist, tint) then
!		list_putindex_int(x,y.unumber.value,z)
!
!	when pr(tarray, tint) then
!		array_putindex_int(x,y.unumber.value,z)
!
!!	when pr(tlist,trange) then
!	else
!		pcmxtypes("putindex",x,y)
!	esac
!end

!global function var_dupl(object p)object q=
!
!	switch p.tag
!	when tint,treal,tvoid then
!		++p.refcount
!		return p
!
!	when tlist,trecord then
!		q:=list_dupl(p)
!	else
!		GERROR_S("CAN'T DUPL: ",STDTYPENAMES[P.TAG])
!	end switch
!
!	return q
!end

!global function ref_make(iobject p)object q=
!!turn object onto a reference to an object, which is itself an object
!	q:=obj_new(tref)
!	q.uref.iobjptr:=p
!
!	obj_share(p^)
!	return q
!end
!
!global function refpack_make(ref void a, int tp,mutable,object p)object q=
!!caller should share the object of which a is a part
!	q:=obj_new(trefpack)
!	q.urefpack.ptr:=a
!	q.urefpack.target:=tp
!	q.urefpack.mutable:=mutable
!	q.urefpack.objptr2:=p			!when pointing inside object
!	return q
!end

!global function pch_new(object a,b,c)object p=
!!create a new object using 'new'
!!CPL =TTNAME[A.TAG]
!	var int lower,upper, length
!
!!PCERROR("PCH NEW")
!	case a.tag
!	when trecorddef then
!		return record_new(a,b)
!	when ttype then
!!CPL =TTNAME[A.UNUMBER.VALUE]
!!PCERROR("NEW/TYPE")
!		case a.unumber.value
!		when tarray then
!			if b.tag<>tpacktype then pcerror("pack type expected") fi
!			(lower,upper,length):=getdims(c)
!			return array_new(b.unumber.value,length,lower)
!		when tlist then
!			(lower,upper,length):=getdims(b)
!			return list_new(length,lower,(c.tag=tvoid|nil|c))
!		esac
!		println ttname[a.unumber.value]
!		pcerror("new/type")
!
!	else
!		pcustype("PCH NEW",a)
!	esac
!
!	return nil
!end

!global function array_new(object pelem,pdim)object q=
!	if pelem.tag<>tpacktype then
!		pcerror("new/array not packtype")
!	fi
!
!	pcerror("ARRAY/NEW NOT DONE YET")
!
!	return q
!end
!
!global function var_equal(object a,b)int=
!!compare objects that must have compatible types
!!return 1/0 for equal/not equal
!
!	if a.tag<>b.tag then
!		return domixed_arith_int(a,b,cast(obj_equal))
!	fi
!
!	switch a.tag
!	when vint then return a.value=b.value
!	when vreal then return (a.xvalue=b.xvalue|1|0)
!	when vstring then
!		if a.length64<>b.ustring.length64 then return 0 fi
!		if a.length64 then
!			return eqbytes(a.strptr,b.strptr,a.length64)
!		fi
!		return 1				!both empty
!	else
!		pcerror_s("obj/equal not ready:",ttname[a.tag])
!	end switch
!	return 0
!end
!
!global function var_compare(object a,b)int=
!!compare objects that must have compatible types
!!return -1/0/1 for less than/equal/greater than
!	var int alen,blen
!
!	if a.tag<>b.tag then
!		return domixed_arith_int(a,b,cast(obj_equal))
!	fi
!
!	switch a.tag
!	when tint then
!		if a.value<b.value then return -1
!		elsif a.value>b.value then return 1
!		fi
!	when treal then
!		if a.xvalue<b.xvalue then return -1
!		elsif a.xvalue>b.xvalue then return 1
!		fi
!	when tstring then
!		alen:=a.ustring.length
!		blen:=b.ustring.length
!
!		if alen=0 then
!			if blen=0 then
!				return 0		!empty:empty
!			else
!				return -1		!empty:str
!			fi
!		elsif blen=0 then	!str:empty
!			return 1
!		else
!			if alen=blen then
!				return cmpstringn(a.ustring.strptr,b.ustring.strptr,alen)
!			else
!				return cmpstring(convCstring(a.ustring.strptr,alen),convCstring(b.ustring.strptr,blen))
!			fi
!		fi
!	else
!		pcerror_s("obj/compare not ready:",ttname[a.tag])
!	end switch
!assume equal
!	return 0
!end
!
!global function var_true(object a)int=
!!return 1/0 for true/not true
!
!	switch a.tag
!	when tint,treal then return (a.value|1|0)
!	when tstring,tlist then
!		return a.ustring.length<>0
!	when trefpack then
!		return (a.urefpack.ptr|1|0)
!	when tnil then
!		return 0
!	else
!		pcerror_s("obj/true not ready:",ttname[a.tag])
!	end switch
!	return 0
!end
!
global function var_add(object x,y)object z=
!caller must ensure that x and y have compatible types
!sharing is not handled here

	if x.tag<>y.tag then
PCERROR("MIXED ADD")
!		return domixed_arith(x,y,cast(obj_add))
	fi



	switch x.tag
	when vint then
		z:=int_make(x.value+y.value)
!	when treal then
!		return real_make(x.xvalue+y.xvalue)

!	when vstring then
!		z:=str_add(x,y)

	else
PCERROR("ADD/T")
!		pcustype("ADD",x)
	end switch

	var_unshare(x)
	var_unshare(y)

	return z
end

!global proc var_iappend(object x,y)=
!
!	switch x.tag
!	when tlist then
!		list_iappend(x,y)
!
!	when tarray then
!		array_iappend(x,y)
!
!	when tstring then
!!		str_iappend(x,y)
!
!	else
!		pcustype("APPEND",x)
!	end switch
!!	return nil
!end
!
!global function var_power(object x,y)object z=
!!caller must ensure that x and y have compatible types
!!sharing is not handled here
!
!	case pr(x.tag,y.tag)
!	when pr(tint,tint) then
!		return int_make(x.value**y.value)
!!	when pr(treal,tint) then
!!	when pr(treal,treal) then
!
!	else
!		pcmxtypes("POW",x,y)
!	end case
!	return nil
!end
!
!global function var_sub(object x,y)object z=
!
!	if x.tag<>y.tag then
!		return domixed_arith(x,y,cast(obj_sub))
!	fi
!
!	switch x.tag
!	when tint then
!		return int_make(x.value-y.value)
!	when treal then
!		return real_make(x.xvalue-y.xvalue)
!
!	else
!		pcustype("SUB",x)
!	end switch
!	return nil
!end
!
!global function var_mul(object x,y)object z=
!
!	if x.tag<>y.tag then
!		return domixed_arith(x,y,cast(obj_mul))
!	fi
!
!	switch x.tag
!	when tint then
!		return int_make(x.value*y.value)
!	when treal then
!		return real_make(x.xvalue*y.xvalue)
!
!	else
!		pcustype("MUL",x)
!	end switch
!	return nil
!end
!
!global function var_div(object x,y)object z=
!
!	if x.tag<>y.tag then
!		return domixed_arith(x,y,cast(obj_div))
!	fi
!
!	switch x.tag
!	when tint then
!		return real_make(real(x.value)/y.value)
!
!	when treal then
!		return real_make(x.xvalue/y.xvalue)
!
!	else
!		pcustype("DIV",x)
!	end switch
!	return nil
!end
!
!global function var_idiv(object x,y)object z=
!
!	if x.tag<>y.tag then
!		return domixed_arith(x,y,cast(obj_idiv))
!	fi
!
!	switch x.tag
!	when tint then
!		return int_make(x.value/y.value)
!	else
!		pcustype("IDIV",x)
!	end switch
!	return nil
!end
!
!global function var_irem(object x,y)object z=
!
!	if x.tag<>y.tag then
!		return domixed_arith(x,y,cast(obj_irem))
!	fi
!
!	switch x.tag
!	when tint then
!		return int_make(x.value rem y.value)
!	else
!		pcustype("IREM",x)
!	end switch
!	return nil
!end
!
!global function var_iand(object x,y)object z=
!
!	if x.tag<>y.tag then
!		return domixed_arith(x,y,cast(obj_iand))
!	fi
!
!	switch x.tag
!	when tint then
!		return int_make(x.value iand y.value)
!	else
!		pcustype("IAND",x)
!	end switch
!	return nil
!end
!
!global function var_ior(object x,y)object z=
!
!	if x.tag<>y.tag then
!		return domixed_arith(x,y,cast(obj_ior))
!	fi
!
!	switch x.tag
!	when tint then
!		return int_make(x.value ior y.value)
!	else
!		pcustype("IOR",x)
!	end switch
!	return nil
!end
!
!global function var_ixor(object x,y)object z=
!
!	if x.tag<>y.tag then
!		return domixed_arith(x,y,cast(obj_ixor))
!	fi
!
!	switch x.tag
!	when tint then
!		return int_make(x.value ixor y.value)
!	else
!		pcustype("IXOR",x)
!	end switch
!	return nil
!end
!
!global function var_shl(object x,y)object z=
!	case pr(x.tag,y.tag)
!	when pr(tint, tint) then
!		return int_make(x.value << y.value)
!	else
!		pcustype("SHL",x)
!	esac
!	return nil
!end
!
!global function var_shr(object x,y)object z=
!	case pr(x.tag,y.tag)
!	when pr(tint, tint) then
!		return int_make(x.value >> y.value)
!	else
!		pcustype("SHR",x)
!	esac
!	return nil
!end
!
!global function var_sqr(object x)object z=
!	switch x.tag
!	when tint then
!		return int_make(sqr x.value)
!	when treal then
!		return real_make(sqr x.xvalue)
!	else
!		pcustype("SQR",x)
!	end switch
!	return nil
!end
!
!global function var_sqrt(object x)object z=
!	switch x.tag
!	when tint then
!		return real_make(sqrt x.value)
!	when treal then
!		return real_make(sqrt x.xvalue)
!	else
!		pcustype("SQRT",x)
!	end switch
!	return nil
!end
!
!global function var_neg(object x)object z=
!	switch x.tag
!	when tint then
!		return int_make(-x.value)
!	when treal then
!		return real_make(-x.xvalue)
!	else
!		pcustype("NEG",x)
!	end switch
!	return nil
!end
!
!function domixed_arith_int(object x,y,binfunc fnptr)int=
!!called with arith object known to give an int result, eg. equal/compare
!	var object z
!	var int res
!
!	z:=domixed_arith(x,y,fnptr)
!	res:=z.value
!	obj_unshare(z)
!	return res
!end
!
!function domixed_arith(object x,y,binfunc fnptr)object z=
!	var int newx,newy
!	
!	newx:=newy:=0
!
!	case pr(x.tag, y.tag)
!	when pr(tint, treal) then
!		x:=real_make(x.value)
!		newx:=1
!	when pr(treal, tint) then
!		y:=real_make(y.value)
!		newy:=1
!	when pr(tstring,tint) then
!		if fnptr=binfunc(obj_mul) then
!PCERROR("STRING*MUL NOT READY")
!		else
!			pcerror_s("string/int:",findprocname(cast(fnptr)))
!		fi
!	when pr(tlist,tint) then
!		if fnptr=binfunc(obj_mul) then
!			return list_mul(x,y.value)
!		else
!			pcerror_s("list/int:",findprocname(cast(fnptr)))
!		fi
!	esac
!
!
!	if newx=newy=0 then
!		if (x.tag=tnil or y.tag=tnil) and fnptr=binfunc(obj_equal) then
!!		if (x.tag=tnil or y.tag=tnil) then
!!CPL "EQUAL/NIL/NOT NIL"
!			return int_make(0)
!		fi
!		pcmxtypes(findprocname(cast(fnptr)),x,y)
!	fi
!
!	z:=fnptr^(x,y)
!
!	if newx then var_unshare(x) fi
!	if newy then var_unshare(y) fi
!
!	return z
!end
!
!global function var_lwb(object x)object z=
!	case x.tag
!	when tstring then
!		return int_make(1)
!	when tlist then
!		return int_make(x.ulist.length)
!	when tarray then
!		return int_make(x.uarray.length)
!	when trange then
!		return int_make(x.urange.lower)
!	else
!		pcustype("LWB",x)
!	esac
!	return nil
!end
!
!global function var_upb(object x)object z=
!	case x.tag
!	when tlist then
!		return int_make(x.ulist.length+x.ulist.lower-1)
!	when tstring then
!		return int_make(x.ulist.length)
!	when tarray then
!		return int_make(x.uarray.length+x.uarray.lower-1)
!	when trange then
!		return int_make(x.urange.upper)
!	else
!		pcustype("UPB",x)
!	esac
!	return nil
!end
!
!global function var_len(object x)object z=
!	case x.tag
!	when tlist then
!		return int_make(x.ulist.length)
!	when tstring then
!		return int_make(x.ustring.length)
!	when tarray then
!		return int_make(x.uarray.length)
!	when trange then
!		return int_make(x.urange.upper-x.urange.lower+1)
!	else
!		pcustype("LEN",x)
!	esac
!	return nil
!end
!
!global function var_bounds(object x)object z=
!	case x.tag
!	when tlist then
!		return range_make(x.ulist.lower,x.ulist.length+x.ulist.lower-1)
!	when tarray then
!		return range_make(x.uarray.lower,x.uarray.length+x.uarray.lower-1)
!	when tstring then
!		return range_make(1,x.ustring.length)
!	when trange then
!		return var_share(x)
!	else
!		pcustype("BOUNDS",x)
!	esac
!	return nil
!end
!
!
!function getdims(object p)int,int,int=
!!return (lower,upper,length) from a dimension value that can be:
!!	an int giving length
!!	a range
!!	void so that the dimension is empty
!	var int lower,upper,length
!
!!CPL =TTNAME[P.TAG]
!
!	case p.tag
!	when tint then
!		return (1,p.value, p.value)
!	when tvoid then
!		return (1,0,0)
!	when trange then
!!CPL "GETDIMS RANGE",P.URANGE.LOWER, P.URANGE.UPPER
!		lower:=p.urange.lower
!		upper:=p.urange.upper
!		length:=upper-lower+1
!		if length<0 then length:=0; upper:=lower-1 fi
!		return (lower,upper, length)
!	else
!		pcerror("GETDIMS?")
!	esac
!	return (0,0,0)
!end
!
!global function var_getptr(object p)object=
!	case p.tag
!	when tref then
!		return var_share(p.uref.iobjptr^)
!
!	when trefpack then
!		return refpack_getptr(p)
!
!	else
!		pcustype("Getptr",p)
!	esac
!	return nil
!
!end
!
!global proc var_putptr(object p, x)=
!	case p.tag
!	when tref then
!		obj_unshare(p.uref.iobjptr^)
!		p^.uref.iobjptr^:=obj_share(x)
!
!	when trefpack then
!		refpack_putptr(p,x)
!
!	else
!		pcustype("Putptr",p)
!	esac
!end
!
!global function FRED(ichar name, int rettype, nparams, ref[]byte params)object p=
!
!	p:=obj_new(tdllproc)
!
!	p.udllproc.name:=pcm_copyheapstring(name)
!	p.udllproc.resolved:=0
!
!	p.udllproc.nparams:=nparams
!	p.udllproc.rettype:=rettype
!
!	for i to nparams do
!		p.udllproc.paramtypes[i]:=params[i]
!	od
!
!	return p
!end
