
global func scaleindex(mclopnd ax, int scale)int=
!when scale is 1/2/3/4, return scale unchanged
!anything else, scale value in ax, return 1
	int n
	if scale in [1,2,4,8] then return scale end

	mulimm(ax,scale)
	return 1
end

global proc mulimm(mclopnd ax, int n)=
!multiply operand in ax (a simple reg) by constant n
!will try efficient method if possible, otherwise use normal multiply 
	int shifts,m

	case n
	when 0 then
		clearreg(ax)
		return
	when 1 then
		return
	when -1 then
		genmc(m_neg, ax)
		return
	end case

	shifts:=0
	m:=n

	while m.even do
		m>>:=1
		++shifts
	od

	if shifts then
		genmc(m_shl, ax, mgenint(shifts))
	end

	case m
	when 1 then
		return
	when 3, 5, 9 then
		genmc(m_lea, ax, genindex(areg: ax.reg, ireg:ax.reg, scale:m-1))
	else						!mul needed anyway; forget the shift
		if shifts then
			mccodex.opcode:=m_imul2
			mccodex.b:=genint(n)
		else
			genmc(m_imul2, ax, genint(n))
		end
	end case

end

global proc copyblockarg(mclopnd px, int size, ARGNO)=
!px refers to a block in a parameter register
!if px is nil, then called for block in zz that will be pushed

!copy the block to a block temp, and change px's register to
!refer to that new block

	symbol dblock
	mclopnd ax, bx, axi, bxi

	IF PX=NIL THEN
		println "High block arg not copied in", currfunc.name, ,"()"
		return
	FI

!MERROR("COPY BLOCK ARG")

	dblock:=newblocktemp(size)
	dblock.used:=1


	if px then
		bx:=gwrm(tref)				!copy of px
		genmc(m_mov, bx, px)
	else
		bx:=loadopnd(zz, tblock)
	end
	ax:=gwrm(tref)					!refer to temp block

	genmc(m_lea, ax, genmem(dblock))

	copyblock(genireg(ax.reg), genireg(bx.reg), size)

	if px then
		genmc(m_lea, px, genmem(dblock))		!param points to temp
!	else
!		gen
	end

!note: this is needed since there may be other blocks passed before the end
!of a CALL op, as those ax/bx regs would be tied up
!caller should ensure no workregs are in use

	freeworkregs()
end

global func isimmint(int n)pcl p=
	if pclstack[n].code then
		p:=pclopnds[n]
		if p.optype=int_opnd then
			return p
		end
	end
	nil
end

global func ismemaddr(int n)int=
	if pclstack[n].code and pclopnds[n].opndtype=memaddr_opnd then return 1 end
	return 0
end

global proc do_pushlowargs(int nargs, nvariadics=0, isptr=0)=
!nargs=0 to 4 /operands/, not using more than 4 slots
!load args to D10-13/X0-3
!does not do anything with the stack at all
! Params are categorised as follows:
! Variadic:
!   float:  load to both D and X registers
!   other:  load to D register only
! Normal/non-variadic:
!   float:  load to X register
!   other:  load to D register
	mclopnd ax
	int j,k, nextireg, nextxreg, mode, imode, blockret
	symbol dblock

	if nargs=0 then return end

	blockret:=callblockret[ncalldepth]

	nextireg:=r10
	nextxreg:=xr0

	k:=0
	for i:=noperands downto noperands-nargs+1 do
		++k						!counts params from 1

		if k=1 and blockret then
!CPL "CALL NEWBT", CALLBLOCKSIZE[NCALLDEPTH]
			dblock:=newblocktemp(callblocksize[ncalldepth])
			dblock.used:=1
			genmc(m_lea, mgenreg(r10), mgenmem(dblock))

		else

			j:=i-isptr+BLOCKRET

			mode:=pclstack[j].mode

			case mode
			when tblock then
				ax:=loadparam(j, mode, nextireg)
!				copyblockarg(ax, callargsize[ncalldepth,k], k)

			when tr64, tr32 then
				loadparam(j, mode, nextxreg)
				if nvariadics and k>=nvariadics then			!variadic floats go to both regs

!I need to move xmm reg to int reg
					imode:=(mode=tr32|tu32|tu64)
					genmc(m_mov, mgenreg(nextireg, imode), mgenreg(nextxreg, mode))
				end
			else
doint:
				loadparam(j, mode, nextireg)
			end case
		end

		++nextireg
		++nextxreg
	od
end

global proc do_getretvalue(pcl p)=
	int reg,xreg,i,n, m
	[10]int modes

!MERROR("DOGETRETVAL")
!MCOMM("DOGETRETVAL")
	if (p+1).opcode=ktype then
		n:=0
		while (++p).opcode=ktype do
			modes[++n]:=p.mode
		od
		currpcl:=p-1

		for i:=n downto 1 do 
			m:=modes[i]
			pushpcl_reg(m, (stdfloat[m]|multxregs[i]|multregs[i]))
		od

	else
		pushpcl_reg(p.mode, (stdfloat[p.mode]|xr0|r0))

	end
end

global func newblocktemp(int size)symbol=
	[16]char str
	symbol d

	if nblocktemps>=maxblocktemps then
		merror("Too many block temps")
	end
	++nblocktemps

	fprint @str,"$B#",nblocktemps

	d:=makesymbol(str, frameid)
	d.mode:=tblock
	d.size:=size
	d.used:=1
!	d.nextlocal:=currfunc.nextlocal

	d.nextdef:=currfunc.deflist
	currfunc.deflist:=d

 	d.owner:=currfunc
!	currfunc.nextlocal:=d

!CPL "NBT", D.SIZE
	blockdefs[nblocktemps]:=d
	d
end

global proc do_for(pcl p, int incop, addop, cond)=
	pcl q, r
	mclopnd ax, bx, cx, dx, mx
	int reg

	q:=p.next
	r:=currpcl:=q.next

	mx:=mgenmem(q.def, pmode)

	if q.def.reg then
		if p.stepx=1 then
			genmc(incop, mx)
		else
			genmc(addop, mx, genint(p.stepx))
		end
		ax:=mx
	else
!		ax:=genreg(getworkireg())
		ax:=gwrm(ti64)
		genmc(m_mov, ax, mx)
		if p.stepx=1 then
			genmc(incop, ax)
		else
			genmc(addop, ax, genint(p.stepx))
		end
		genmc(m_mov, mx, ax)
	end

	if r.opndtype=int_opnd then
		bx:=genint(r.value)
	else
		bx:=genmem(r.def)
	end

	genmc(m_cmp, ax, bx)

	genmc_cond(m_jmpcc, cond, genlabel(p.labelno))
end

global proc do_jumptruefalse(pcl p, int cond)=
	mclopnd ax, bx

	ax:=loadopnd(zz)

	if ispint(pmode) then
		genmc(m_test, ax, ax)

	else
		bx:=gwrm()
		genmc(m_xorps, bx, bx)
!MCOMM("D")
		genmc(m_comiss, ax, bx)
	end

	genmc_cond(m_jmpcc, cond, genlabel(p.labelno))

	poppcl()
end

global proc do_incr(pcl p, int incrop, addop)=
	mclopnd mx

	mx:=getopnd_ind(zz, mem:1)
!	mx:=getopnd_ind(zz, mem:0)
!CPL "INCR", MSTROPND(MX)

	if p.stepx=1 then
		genmc(incrop, mx)
	else
		genmc(addop, mx, genint(p.stepx, p.size))
	end
	poppcl()
end

global proc do_incrload(pcl p, int incrop, addop)=
	mclopnd ax, mx
	int reg
	pcsrec ps

	mx:=getopnd_ind(zz, mem:1)
!	mx:=getopnd_ind(zz, mem:0)

	reg:=gwri(getmemreg(mx))					!for dest

	ax:=mgenreg(reg, pmode)

	if p.stepx=1 then
		genmc(incrop, mx)
	else
		genmc(addop, mx, mgenint(p.stepx))
	end

	genmc(m_mov, ax, mx)
!
!now replace ax opnd with new value
	clear ps

	ps.reg:=reg
	ps.mode:=pmode
	ps.count:=1
	pclstack[zz]:=ps

	pclopnds[zz]:=nil

	PCLSET.[REG]:=1

end

global proc do_loadincr(pcl p, int incrop, addop)=
	mclopnd ax, mx

	mx:=getopnd_ind(zz, mem:1)
!	mx:=getopnd_ind(zz, mem:0)

	pushpcl_reg(pmode)			!to hold loaded value

	ax:=getopnd(zz)

	genmc(m_mov, ax, mx)

	if p.stepx=1 then
		genmc(incrop, mx)
	else
		genmc(addop, mx, mgenint(p.stepx))
	end

	swapopnds(yy, zz)
	poppcl()
end

global proc do_bitwise(pcl p, int opc)=
	mclopnd ax, bx

	ax:=loadopnd(yy)
	bx:=getopnd(zz)

	genmc(opc, ax, bx)

	poppcl()
end

global proc do_shift(pcl p, int opc)=
	mclopnd ax, cx
	pcl y
	pcsrec ps:=pclstack[zz]

	ax:=loadopnd(yy)
	y:=pclopnds[zz]

	if ps.code and y.opndtype=int_opnd then
		genmc(opc, ax, mgenint(y.value))
	else
		genmc(m_push, mgenreg(r10)) when r10used
		cx:=loadparam(zz, tu8, r10)
		genmc(opc, ax, cx)
		genmc(m_pop, mgenreg(r10)) when r10used
	end
	poppcl()
end

global proc do_max_int(int cond)=
	mclopnd ax, bx

	ax:=loadopnd(yy)
	bx:=loadopnd(zz)

	genmc(m_cmp, ax, bx)
	genmc_cond(m_cmovcc, cond, ax, bx)

	poppcl()
end

global proc do_max_float(int opc)=
	mclopnd ax, bx
	ax:=loadopnd(yy)
	bx:=getopnd(zz)
	genmc(opc, ax, bx)
	poppcl()
end

global proc do_binto(pcl p, int opc, fopc)=
	mclopnd ax, bx, rx

	if ispfloat(pmode) then
		do_binto_float(p, fopc)
		return
	end

!MCOMM("ONE")
!	ax:=getopnd_ind(zz, p.mode)
	ax:=getopnd_ind(zz, p.mode, mem:1)
!	ax:=getopnd_ind(zz, p.mode, mem:0)

!CPL "BINTO", MSTROPND(AX)

!MCOMM("TWO")
!MCOMM(MSTROPND(AX))
	bx:=loadopnd(yy, p.mode)

	genmc(opc, ax, bx)
	poppcl()
	poppcl()
end

global proc do_binto_float(pcl p, int opc)=
	mclopnd px, bx, cx

	pushpcl_reg(pmode)		!z^:=y => y^:=x; z is temo

	px:=getopnd_ind(yy, mem:1)
	bx:=getopnd(xx)
	cx:=getopnd(zz)

	genmc(m_mov, cx, px)
	genmc(opc, cx, bx)
	genmc(m_mov, px, cx)

	poppcl()
	poppcl()
	poppcl()
end

global proc do_shiftnto(pcl p, int opc)=
!shift opc=shl/shr/sar, when both operands are on the stack
!first operand is address of dest
	mclopnd px, cx
	pcsrec ps

	px:=getopnd_ind(zz, mem:1)
!	px:=getopnd_ind(zz, mem:0)
	ps:=pclstack[yy]

	if ps.code and pclopnds[yy].opndtype=int_opnd then
		genmc(opc, px, mgenint(pclopnds[yy].value, pmode))

	else
		genmc(m_push, mgenreg(r10)) when r10used

		cx:=loadparam(yy, tu8, r10)
		genmc(opc, px, cx)

		genmc(m_pop, mgenreg(r10)) when r10used

	end

	poppcl()
	poppcl()
end

global proc do_maxto_int(int cond, mode)=
	mclopnd ax, bx, lx
	int lab

!	if size<8 then merror("min/maxto size?") end

	ax:=getopnd_ind(zz, mem:1)
!	ax:=getopnd_ind(zz, mem:0)
	bx:=loadopnd(yy)

	genmc(m_cmp, ax, bx)
	lab:=++mlabelno

	genmc_cond(m_jmpcc, cond, lx:=genlabel(lab))
	genmc(m_mov, ax, bx)
	genmc(m_label, lx)
	poppcl()
	poppcl()
end

global proc do_maxto_real(int cond, mode)=
	mclopnd px, ax, bx, lx
	int lab

	px:=getopnd_ind(zz, mode)
	bx:=loadopnd(yy, mode)

	pushpcl_reg(mode)

!CPL STROPNDSTACK()
!CPL =STRMODE(PMODE)
!!	ax:=getopnd(yy, pmode)
	ax:=getopnd(ZZ, pmode)
!CPL =MSTROPND(AX)

	genmc(m_mov, ax, px)

!MCOMM("E")
	genmc(m_comiss, ax, bx)
	lab:=++mlabelno

	genmc_cond(m_jmpcc, cond, lx:=genlabel(lab))
	genmc(m_mov, px, bx)
	genmc(m_label, lx)
	poppcl()
	poppcl()
	poppcl()
end

global proc do_divrem(pcl p, int issigned, isdiv)=
!isdiv = 0/1/2 = rem/div/divrem
! Z' := Y % Z
	mclopnd ax, bx, px
	pcl q
	int opc, n, shifts
	byte fdivto:=0
	int locyy:=yy, loczz:=zz


	if p.opcode in [kidivto, kiremto] then
		swap(locyy, loczz)

		ax:=loadopnd(locyy, tu64)
		fdivto:=1
		genmc(m_push, changeopndsize(ax, 8))
		px:=makeopndind(ax, pmode)
		ax:=mgenreg(ax.reg, pmode)

		genmc(m_mov, ax, px)
	else
		ax:=loadopnd(locyy, pmode)
	end

	q:=isimmint(loczz)

	if q and isdiv=1 then
		n:=q.value
		case n
		when 0 then
			merror("Divide by zero")
		when 1 then
			poppcl()
			return
		else
			shifts:=ispoweroftwo(n)
			if shifts AND NOT FDIVTO then
				genmc((issigned|m_sar|m_shr), ax, genint(shifts, pmode))
				poppcl()
				return
			end
		end case
	fi 

	bx:=loadopnd(loczz)

	saverdx()
	fixdivopnds(locyy, loczz)
	bx:=loadopnd(loczz)			!in case regs have changed

	if issigned then
		opc:=
			case stdsize[pmode]
			when 8 then	m_cqo
			when 4 then	m_cdq
			when 2 then	m_cwd
			else merror("div/u8"); 0
			end case
		genmc(opc)

		opc:=m_idiv
	else
!		genmc(m_xor, mgenreg(r11), mgenreg(r11))
		clearreg(mgenreg(r11))
		opc:=m_div
	end

	genmc(opc, bx)

	case isdiv
	when 0 then				!rem
		genmc(m_xchg, mgenreg(r0, pmode), mgenreg(r11, pmode))

	when 2 then				!divrem
		genmc(m_xchg, bx, mgenreg(r11, pmode))			!rem replace y-operand
		swapopndregs(r1)						!make sure it is in r1
		swapopnds(locyy, loczz)

	end case

	restorerdx()

	if fdivto then
		bx:=gwrm(ti64)
		genmc(m_pop, bx)
		genmc(m_mov, makeopndind(bx, pmode), getopnd(locyy))
		poppcl()
	end

	if isdiv<>2 then
		poppcl()
	end

end

proc fixdivopnds(int locyy, loczz)=
!two div operands exist as the top two operands, which will be
!in registers
!the div op requires that x is in d0, and y in any other register
!d11 also needs to be free, which will be the case is reg allocs only
!go up to d9, and d10/d11/12/13 are in use for win64 parameter passing
	int regx, regy, zop
	mclopnd bx, ax

	regx:=pclstack[locyy].reg
	regy:=pclstack[loczz].reg

	if regx=r0 then			!regy will be OK
		return
	end

	bx:=getopnd(locyy, tu64)
	ax:=getopnd(loczz, tu64)

	if regy=r0 then			!need to swap then
		genmc(m_xchg, bx, ax)
		swapopnds(locyy, loczz)		!switch operands
		return
	end

!neither x nor y in r0
	if regset.[r0]=0 then	!d0 not in use
		genmc(m_xchg, mgenreg(r0), bx)
		regset.[regx]:=0				!switch registers for yy

		pclstack[locyy].reg:=r0
		regset.[r0]:=1

		return
	end

!need to move current occupier of r0
	for zop:=noperands downto 1 do
		if pclstack[zop].reg=r0 then exit end
	else
		return
	od

!zop is the operand number that happens to be using r0
	genmc(m_xchg, mgenreg(r0), getopnd(locyy, tu64))	
	swap(pclstack[locyy].reg, pclstack[zop].reg)		!switch registers
end

proc saverdx=
	genmc(m_push, mgenreg(r11)) when r11used
end

proc restorerdx=
	genmc(m_pop, mgenreg(r11)) when r11used
end

global func do_addrmode*(pcl p)mclopnd px =
!Top two stack elements are an array (yy) and index (zz)
!Return a operand which provdes the address mode to access the element,
!for either reading or writing
!The address mode will use 0, 1 or 2 registers. The registers may be 1 or 2
!associated with the pcl operands, or may be regvars.
!If for reading, caller will need to make their own arrangements for a dest reg.
!When Xb has to be loaded into a register anyway, then the caller can make use
!of that

	mclopnd ax,bx
	int scale, extra,offset, reg,regix
	symbol d
	pcl q
	pcsrec ys:=pclstack[yy], zs:=pclstack[zz]

	scale:=p.scale
	extra:=p.extra

	q:=isimmint(zz)
	if q then
		offset:=q.value*scale+extra	!for imm offset
	end

	px:=nil

!CPL "AM", $LINENO, STRREG(YS.REG)
	if regvarset.[ys.reg] then				!(if not reg, will be 0)
!CPL "AM", $LINENO
		if regvarset.[zs.reg] then
			reg:=zs.reg
			regix:=scaleregvar(reg, scale)
			px:=genindex(areg:ys.reg, ireg:regix, offset:extra, scale:scale)

		elsif q then						!regvar/imm
			px:=genindex(areg:ys.reg, offset:offset)
		else								!regvar/any
			scale:=scaleindex(bx:=loadopnd(zz, zs.mode), scale)
			px:=genindex(areg:ys.reg, ireg:bx.reg, scale:scale, offset:extra)
		end

	elsif ismemaddr(yy) then
!	if ismemaddr(yy) then
!CPL "DAM/ISMEMADDR"
		d:=pclopnds[yy].def
!CPL =D.NAME, NAMENAMES[D.NAMEID], STRMODE(YS.MODE), STRMODE(D.MODE)
		if d.nameid=staticid and highmem=2 or 
!			D.NAMEID=PARAMID AND stdpcl[ttbasetype[d.mode]]=tblock  then skip end
			D.NAMEID=PARAMID AND isblock(d.mode)  then skip end

		if regvarset.[zs.reg] then			!memaddr/regvar
!CPL "AM", $LINENO
			reg:=zs.reg
			regix:=scaleregvar(reg, scale)
			px:=genindex(ireg:regix, def:d, offset:extra, scale:scale)

		elsif q then			!memaddr/imm
			px:=genindex(def:d, offset:offset)
		else							!memaddr/any
			scale:=scaleindex(bx:=loadopnd(zz, ti64), scale)
			px:=genindex(ireg:bx.reg, def:d, offset:extra, scale:scale)
		end
	else								!
skip:
!CPL "DAM/OTHER"
		ax:=loadopnd(yy, tu64)

		if zs.reg then			!any/regvar
			regix:=scaleregvar(zs.reg, scale)
			px:=genindex(areg:ax.reg, ireg:regix, offset:extra, scale:scale)

		elsif q then						!any/imm	
			px:=genindex(areg:ax.reg, offset:offset)
		else
			scale:=scaleindex(bx:=loadopnd(zz, tu64), scale)
			px:=genindex(areg:ax.reg, ireg:bx.reg, scale:scale, offset:extra)
		end
	end

	px.size:=p.size

	return px
end

function scaleregvar(int reg, &scale)int=
!When scale is 1/2/3/4, return reg (a regvar) and scale unchanged;
!otherwise set up a new register for operand n
!Copy reg to it, and scale. Return new reg, and set scale to 1
	int regix
	mclopnd ax

	if scale in [1,2,4,8] then return reg end

	regix:=gwri()
	ax:=mgenreg(regix)

	IF SCALE=16 THEN
		genmc(m_lea, ax, genindex(ireg:reg, areg:reg, scale:1))
		scale:=8

	ELSE
		genmc(m_mov,ax, genreg(reg))
		mulimm(ax,scale)
		scale:=1
	FI

	pcsrec ps
	clear ps

	ps.reg:=regix
	ps.mode:=ti64

	return regix
end

global proc dolea(mclopnd ax, px)=
!do 'lea ax, px`, but suppress in cases like 'lea d0,[d0]'
	unless px.regix=px.valtype=px.offset=0 and px.reg=ax.reg then
		genmc(m_lea, ax, px)
	end
end

global proc clearblock(mclopnd ax, int n)=
!ax is the operand with the address of memory to be cleared
!generate code to clear n bytes

!CPL "CLEARBLOCK", MSTROPND(AX), N

	mclopnd rx, rcount
	int nwords, lab, oddbytes, offset, workreg, countreg

	oddbytes:=n rem 8		!will be zero, or 1..7

	n-:=oddbytes			!n will always be a multiple of 8; n can be zero too
	nwords:=n/8				!number of u64s (ie. octobytes)

	rx:=gwrm(tu64)
	clearreg(rx)

	offset:=0

	if 1<=nwords<=8 then		!use unrolled code (no loop)
		ax:=changeopndsize(ax, 8)

		to nwords do
			genmc(m_mov, applyoffset(ax, offset), rx)
			offset+:=8
		od

	elsif nwords<>0 then		!use a loop

!SPLIT INTO xx VERSIONS:
! NWORDS IS A MULTIPLE OF 4, so can write 4 words at a time, in 1/4 of iterations
! Or do one word at a time like now.
! nword is a multiple of 4 happens when N is a multiple of 32 bytes, which will
! always be the case for power-of-two sizes of 32 bytes or more. 32/64 may already
! be done without a loop. So non-part-unrolled version only really for odd array or
! struct sizes, such as [100]char.

		if nwords iand 3 then		!not 4n

			rcount:=genreg(countreg:=gwri())
			lab:=++mlabelno

			ax:=makesimpleaddr(ax)

			genmc(m_mov, rcount, genint(nwords))
			genmc(m_label, genlabel(lab))
			genmc(m_mov, ax, rx)

			genmc(m_add, genreg(ax.reg), genint(8))

			genmc(m_dec, rcount)
			genmc_cond(m_jmpcc, ne_cond, genlabel(lab))

			offset:=0
		else
			rcount:=genreg(countreg:=gwri())
			lab:=++mlabelno

			ax:=makesimpleaddr(ax)
			genmc(m_mov, rcount, genint(nwords/4))
			genmc(m_label, genlabel(lab))

			for i to 4 do
				genmc(m_mov, applyoffset(ax, offset), rx)
				offset+:=8
			od

			genmc(m_add, genreg(ax.reg), genint(targetsize*4))

			genmc(m_dec, rcount)
			genmc_cond(m_jmpcc, ne_cond, genlabel(lab))

			offset:=0
		end
	end

	if oddbytes then
		n:=oddbytes						!1..7

		if n>=4 then
			rx:=changeopndsize(rx, 4)
			genmc(m_mov, applyoffset(ax, offset, 4), rx)
			n-:=4
			offset+:=4
		end
		if n>=2 then
			rx:=changeopndsize(rx, 2)
			genmc(m_mov, applyoffset(ax, offset, 2), rx)
			n-:=2
			offset+:=2
		end
		if n=1 then
			rx:=changeopndsize(rx, 1)
			genmc(m_mov, applyoffset(ax, offset, 1), rx)
		end
	end
end

global proc do_negreal(mclopnd ax, int mode)=
	if ispwide(pmode) then
		if not labneg64 then labneg64:=createfwdlabel() end
		genmc(m_xorpd, ax, genlabelmem(labneg64))
	else
		if not labneg32 then labneg32:=createfwdlabel() end
		genmc(m_xorps, ax, genlabelmem(labneg32))
	end
end

global proc do_absreal(mclopnd ax, int mode)=
	if ispwide(pmode) then
		if not lababs64 then lababs64:=createfwdlabel() end
		genmc(m_andpd, ax, genlabelmem(lababs64))
	else
		if not lababs32 then lababs32:=createfwdlabel() end
		genmc(m_andps, ax, genlabelmem(lababs32))
	end
end

global proc do_loadbf_const(pcl p, int i, j) =
	mclopnd ax, mx
	word mask

	ax:=loadopnd(xx)

	if j=63 then			!signed field includes sign bit; assume i>0
		genmc(m_sar, ax, mgenint(i))
	else

		if i then
			genmc(m_shr, ax, mgenint(i))
		end

		mask:=inot(0xFFFF'FFFF'FFFF'FFFF<<(j-i+1))
		if mask<=word(i32.max) then			!use immediate
			genmc(m_and, ax, genint(mask))
		else
			mx:=loadopnd(yy, tu64)
			genmc(m_mov, mx, genint(mask))
			genmc(m_and, ax, mx)
		end
	end

	poppcl()
	poppcl()
end

global proc do_loadbf_var(pcl p) =
	merror("LOADBF_VAR")
end

global proc do_storebit(pcl p) =
!yy.[zz]:=xx; y.[z]:=x or b.[c]:=a
	mclopnd px, ax, cx, ix
	pcl q, r
	int i, offset
	byte mask1s, mask0s

	q:=isimmint(zz)
	r:=isimmint(xx)

	if q then						!a.[k] := 0/1/x
		px:=getopnd_ind(yy, tu8)	!update only a specific byte
		i:=q.value	
		offset:=i/8					! byte offset 0..7
		i iand:=7					! i will be bit index 0..7
		px:=applyoffset(px, offset)	! point to that byte

		mask0s:=1<<i				!eg 00001000
		mask1s:=inot(1<<i)			!eg 11110111

		if r then
			if r.value=0 then
				genmc(m_and, px, mgenint(mask1s, pmode))
			else
				genmc(m_or, px, mgenint(mask0s, pmode))
			end
		else
			ax:=loadopnd(xx, tu8)
			genmc(m_and, px, mgenint(mask1s, pmode))		!clear dest bit first
			if i then
				genmc(m_shl, ax, mgenint(i, tu8))
			end
			genmc(m_or, px, ax)							!add in 0 or 1
		end
	elsif r then								!A.[i]:=0/1/x
		px:=getopnd_ind(yy, pmode)				!update whole dest word

		if q=nil then								!A.[i]:=0/1
			ax:=gwrm(tu64)
			genmc(m_mov, ax, mgenint(1))
			
			cx:=mgenreg(r10, tu64)
			genmc(m_push, cx) when r10used
			ix:=loadparam(zz, ti64, r10)
			genmc(m_shl, ax, changeopndsize(cx, 1))
			genmc(m_pop, cx) when r10used

!Now have 00001000 for ezzmple in ax
			if r.value=0 then
				genmc(m_not, ax)				!change to 111101111
				genmc(m_and, px, ax)			!set to 0
			else								!set to 1 (assume r.value was 1)
				genmc(m_or, px, ax)
			end

		else									!A.[i]:=x
			merror("STOREBIT/VAR")
		end
	else
			merror("Storebit: both vars")
	end

	poppcl()
	poppcl()
	poppcl()
end

global proc do_storebf(pcl p) =
	mclopnd ax, rx, mx, mx4, dx
	int i, j
	pcl q, r
	word mask

	q:=isimmint(yy)
	r:=isimmint(zz)

	if q=r=nil then
		merror("storebf not imm")
	end

	dx:=loadopnd(ww)

	ax:=getopnd_ind(xx)

	i:=q.value
	j:=r.value

	mx:=gwrm(tu64)
	rx:=gwrm(pmode)

	genmc(m_mov, rx, ax)

	mask:=inot((inot(0xFFFF'FFFF'FFFF'FFFF<<(j-i+1)))<<i)

	genmc(m_mov, mx, genint(mask))

	if i then
		genmc(m_shl, dx, genint(i))
	end

	genmc(m_and, rx, changeopndsize(mx, p.size))
	genmc(m_or, rx, dx)

	genmc(m_mov, ax, changeopndsize(rx, p.size))

	poppcl()			!j
	poppcl()			!i
	poppcl()			!A
	poppcl()			!x?
end

global proc do_callrts(pcl p, ichar opname, int nargs, symbol d=nil)=
	int slots

	saveopnds(nargs)
	slots:=0

	if mstackdepth.odd then
		pushslots(1)
		slots:=1
	end

	do_pushlowargs(nargs)

	if mstackdepth then
		slots+:=4
		pushslots(4)					!shadowspace
	else
		localshadow:=1
	end

	if opname then
		genmc(m_call, genextname(opname))
	else
		genmc(m_call, genmemaddr(d))
	end

	to nargs do
		poppcl()
	od

	if slots then
		popslots(slots)
	end

	do_getretvalue(p)
end

global func findhostfn(int opc)symbol=
!called from pcl/mcl backend. opc refers to a PCL op

	case opc
	when kpower then			!assume for i64
		getsysfnhandler(sf_power_i64)

	else
		nil
	end case
end

GLOBAL PROC CHECKPCL(ICHAR MESS)=
	pcsrec ps


	FOR I TO NOPERANDS DO
		PS:=PCLSTACK[I]
		IF PS.REG=PS.TEMP=PS.CODE=0 THEN
			CPL "BAD PCL",MESS,":", I
			CPL
			STOP

		FI
	OD
END

