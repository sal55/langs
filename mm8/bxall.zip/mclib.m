export type filehandle=ref void

importdll $cstd=
	func malloc		(u64)ref void
	func realloc	(ref void, word)ref void
	proc free		(ref void)
	proc memset		(ref void, i32, word)
	proc memcpy		(ref void, ref void, word)
	proc memmove		(ref void, ref void, word)
	func clock		:i32
	func ftell		(filehandle)i32
	func fseek		(filehandle, i32, i32)i32
	func fread		(ref void, word, word, filehandle)word
	func fwrite		(ref void, word, word, filehandle)word
	func getc		(filehandle)i32
	func ungetc		(i32, filehandle)i32
	func fopen		(ichar a, b="rb")filehandle
	func fclose		(filehandle)i32
	func fgets		(ichar, int, filehandle)ichar
	func remove		(ichar)i32
	func rename		(ichar, ichar)i32
	func getchar	:i32
	proc putchar	(i32)
	proc setbuf		(filehandle, ref byte)

	func strlen		(ichar)int
	func strcpy		(ichar, ichar)ichar
	func strcmp		(ichar, ichar)i32
	func strncmp	(ichar, ichar, word)i32
	func strncpy	(ichar, ichar, word)word
	func memcmp		(ref void, ref void, word)i32
	func strcat		(ichar, ichar)ichar
	func tolower	(i32)i32
	func toupper	(i32)i32
	func isalpha	(i32)i32
	func isupper	(i32)i32
	func islower	(i32)i32
	func isalnum	(i32)i32
	func isspace	(i32)i32
	func strstr		(ichar, ichar)ichar
	func atol		(ichar)int
	func atoi		(ichar)i32
	func strtod		(ichar,ref ref char)r64
	func _strdup	(ichar)ichar

	func puts		(ichar)i32
	func printf		(ichar, ...)i32

	func sprintf	(ichar, ichar, ...)i32

	func sscanf		(ichar, ichar, ...)i32
	func scanf		(ichar, ...)i32

	func rand		:i32
	proc srand		(u32)
	func system		(ichar)i32

	func fgetc		(filehandle)i32
	func fputc		(i32,  filehandle)i32
	func fprintf	(filehandle, ichar, ...)i32
	func fputs		(ichar,  filehandle)i32
	func feof		(filehandle)i32
	func getch		:i32
	func _getch		:i32
	func kbhit		:i32
	func _mkdir		(ichar)i32
	func mkdir		(ichar)i32
	func strchr		(ichar,i32)ichar

	func _setmode	(i32,i32)i32

	proc _exit		(i32)
	proc "exit"		(i32)
!	proc `exit		(i32)
	func pow		(real,real)real

	func `sin 		(real)real
	func `cos		(real)real
	func `tan		(real)real
	func `asin		(real)real
	func `acos		(real)real
	func `atan 		(real)real
	func `log		(real)real
	func `log10		(real)real
	func `exp		(real)real
	func `floor		(real)real
	func `ceil		(real)real

	proc  qsort   	(ref void, u64, u64, ref proc)

end

export macro strdup=_strdup

importdll $cstdextra=
	func __getmainargs	(ref i32, ref void, ref void, int, ref void)i32
end

export const c_eof		=-1
export const seek_set	= 0
export const seek_curr	= 1
export const seek_end	= 2
