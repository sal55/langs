proc main=
	static ichar s = "\u20ac\u20ac\u20ac"

!	s:="A"+
!	"\v0020AC"+
!	"B"
!	ic

	int c

	c:='A\u20AC\u20ACB'
!	c:='ABC'

!	PRINTLN int(C):"h"
!	PRINTLN C
	PRINTLN C:"M"

	PRINTLN 6:"v",, S:".*"

!	PRINTF("%.*s\n", 1, &c)
!	PRINTF("%.*s\n", 2c)
!	PRINTF("%.3s\n", s)

end
