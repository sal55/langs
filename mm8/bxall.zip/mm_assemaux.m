global proc domcl_assem(unit pcode)=
	return when not pcode or pcode.tag<>jassem

	genmc(pcode.asmopcode, genasmopnd(pcode.a),genasmopnd(pcode.b))
	mccodex.cond:=pcode.cond

	case pcode.asmopcode
	when m_pcmpistri,m_pcmpistrm, m_shld, m_shrd then
		if pcode.c=nil or pcode.c.tag<>jconst then gerror("pcmpistr/no imm") fi
		mccodex.c:=pcode.c.value

	esac

end

func genasmopnd(unit p)mclopnd ax=
!	[1..8]byte regmodes=(tpu8, tpu16, 0, tu32, 0,0,0, tpu64)
	psymbol d
	int offset,labno
	unit a				!expr: nil/name/const/(add name, const)
	unit x,y
!	symbol e

	if p=nil then return nil fi

	case p.tag
	when jassemreg then
!		ax:=mgenreg(p.reg, p.regsize)
		ax:=mgenreg(p.reg, regmodes[p.regsize])

	when jconst then
		ax:=mgenint(p.value)

	when jassemmem then
		a:=p.a
		d:=nil
		offset:=labno:=0

		if a then
			case a.tag
			when jconst then
				offset:=a.value
			when jname then
				d:=getpsymbol(a.def)
				if d.id=label_id then
					labno:=fixasmlabel(d)
					d:=nil
				fi
			when jbin then
				x:=a.a
				y:=a.b
				if x.tag=jname and y.tag=jconst then
					d:=getpsymbol(x.def)
					if d.id=label_id then
						labno:=fixasmlabel(d)
						d:=nil
					fi
				else
					goto error
				fi
				offset:=(a.pclop in [kadd,kaddpx]|y.value|-y.value)
			when junary then
				if a.pclop<>kneg then merror("assume/unary") fi
				unless a.a.tag=jconst then gerror("-name") end
				offset:=-a.a.value
			when jsyscall then
MERROR("ASSEM/SYSFN?")
!				labno:=getsysfnlabel(a.opcode)

			else
error:
				cpl jtagnames[a.tag]
				gerror("Can't do memexpr")
			esac
		fi
		ax:=mgenindex(areg:p.reg, ireg:p.regix, scale:p.scale, size:ttsize[p.prefixmode],
			offset:offset, labno:labno, def:d)

	when jname then
		d:=getpsymbol(p.def)
		if d.id=label_id then
			labno:=fixasmlabel(d)
			ax:=mgenlabel(labno)
		else
			ax:=mgenmemaddr(d)
		fi

	when jassemxreg then
		ax:=mgenxreg(p.reg)
	when jbin then				!assume add/sub
		x:=p.a
		y:=p.b
		if x.tag=jname and y.tag=jconst then
			d:=getpsymbol(x.def)
			offset:=(p.pclop in [kadd,kaddpx]|y.value|-y.value)
			if d.id=label_id then
				labno:=fixasmlabel(d)
				ax:=mgenlabel(labno)
			else
				ax:=mgenmemaddr(d)
			fi
			ax.offset:=offset
		else
			gerror("ax:imm/add")
		fi
	else
		cpl jtagnames[p.tag]
		gerror("genasmopnd?")
	esac

	return ax

end

func fixasmlabel(psymbol d)int=
!d.labelno contains the label number that is passed to PCL
!PCL maintains a labelmap[] array to convert such labels to renumbered labels
!Do that translation here, and return that new label
!Note: mapped label is stored as negative value to indicate it's been done
!Will return +ve mapped label

	if d.labelno=0 then
		gerror("FIXASMLABEL: zero")
	fi
	return d.labelno
end

global func checkasmlabel(unit p)int=
!CPL "CHECK ASM LABEL", JTAGNAMES[P.TAG]
	unit q
	symbol d

	q:=p.a

	if q and q.tag=jname then
		d:=q.def
		if d.nameid=labelid then return d.index fi
	fi

	0
end

