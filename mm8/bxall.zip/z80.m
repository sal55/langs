[0:65536]byte ram

const nop_opc = 0
const halt_opc = 0x76

proc run=
	u16 pc:=0

	doswitch ram[pc]
	when nop_opc then
		++pc
	when halt_opc then
		exit
	else
		println "Unknown Opcode:",int(ram[pc])
		++pc
	end
end

proc main=
	int n,t
	real runtime, z80runtime

	memset(&ram,0,ram.bytes)
	ram[65535]:=halt_opc

	n:=1000

	t:=clock()
	to n do
		run()
	od
	t:=clock()-t

	runtime:=t/1000.0
	z80runtime:=n/16.0

	cpl "Runtime=",runtime
	cpl "Z80 Runtime=",z80runtime
	cpl "Emulation is",z80runtime/runtime,"times faster"

end
