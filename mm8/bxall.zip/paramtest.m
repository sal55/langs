IMPORTDLL dummy=
	clang proc billc(byte, int, date, var)
end

record date=(int d,m,y)

ref proc(byte, int, date, var)billptr

!proc fred(byte a,byte &b,date c)=
!proc fred(int a, &b)=

proc main=
	int a,b
	byte aa, bb
	date c
	var d

!	billval(aa, b, c, d)
!	billref(&aa, &b, &c, &d)
!	billbyref(aa, b, c, d)
!	billc(aa, b, c, d)
	billptr(aa, b, c, d)

!	fred(a,b)
!	fred(aa,bb)
end

proc billval(byte a, int b, date c, var d)=
!	eval a
!	eval b
!	eval c
!	eval d
end

proc billref(ref byte a, ref int b, ref date c, ref var d)=
!	eval a
!	eval b
!	eval c
!	eval d
end

proc billbyref(byte &a, int &b, date &c, var &d)=
!	eval a
!	eval b
!	eval c
!	eval d
end

!
!
!
!proc fred(byte a, &b)=
!	int x
!
!	x:=a
!	x:=b
!	b:=a
!end


