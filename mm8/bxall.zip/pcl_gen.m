
global const pclpresent=1

macro divider = pc_comment("-"*40)

global pcl pcldoswx

global proc genpcl=
!generate pcl code for each function
	ref procrec pp
	symbol d
	int tt:=clock()

	pp:=proclist
	while pp do
		d:=pp.def
		genprocpcl(d)
!++NPROCS
!PCLLENGTH+:=D.PCLINFO.LENGTH

		pp:=pp.nextproc
	od

!CPL =NPROCS
!CPL =PCLLENGTH
!CPL real (PCLLENGTH)/nprocs
!CPL

	pcltime:=clock()-tt
end

proc genprocpcl (symbol p) =
	imodule ms
	byte ismain:=0

	ms:=modules[p.moduleno]
	pcldoswx:=nil

!-----------------
	currfunc:=p
	pcl_start()
	mmpos:=p.pos


	if p=ms.stmain and moduletosub[p.moduleno]=mainsubprogno then
		ismain:=1
		entryproc:=p
		p.isentry:=1
		genmain(p)

	elsif p=ms.ststart then
		genstart(p)
	fi
!------------------


	retindex:=createfwdlabel()

	divider()

	if p.hasdoswx then
		pc_gen(kinitdswx)			!this op needed by C?
		pcldoswx:=pccurr			!code to be injected later after this instr
	fi

!	pc_comment("<EVALBLOCk>")

!CPL "PROC",P.NAME, P.OWNER.NAME, P.CODE
	evalunit(p.code)
!CPL "PROC",$LINENO

	if ismain then
		genpushint(0)
		pc_gen(kstop)
		pc_setmode(ti64)
	fi

	divider()
	definefwdlabel(retindex)
	genreturn()

	p.pccode:=pcl_end()
	p.pclength:=pclength

!CPL "DONE genpcl", P.NAME, P.CODE, =p

end

proc genmain(symbol p)=
	symbol d
	for i to nsubprogs when i<>mainsubprogno do
		d:=modules[subprogs[i].mainmodule].ststart
		docallproc(d)
	od
	d:=modules[subprogs[mainsubprogno].mainmodule].ststart
	docallproc(d)

	entryproc:=p
end

proc genstart(symbol p)=
	symbol d
	int lead:=0, m,s

	m:=p.moduleno
	s:=p.subprogno

	if s=mainsubprogno and p.moduleno=subprogs[s].mainmodule then
		LEAD:=1
	elsif p.moduleno=subprogs[s].firstmodule then
		LEAD:=2
	fi

	if lead then
		for i to nmodules when moduletosub[i]=s and i<>m do
			d:=modules[i].ststart
			docallproc(d)
		od
	fi
end

proc docallproc(symbol d)=
!call a simple proc, eg. start(), with no args
	return unless d
	pc_gen(ksetcall)
	pc_setnargs(0)

	pc_gen(kcallp, genmemaddr_d(d))
end

global proc genreturn=
!assume returning from currproc
	case currfunc.nretvalues
	when 0 then
		pc_gen(kretproc)
	when 1 then
		pc_gen(kretfn)
		pc_setmode(currfunc.mode)

	else
		pc_genx(kretfn, currfunc.nretvalues)
	esac
end

global func genmem_u(unit p)pcl=
	return pgenmem(p.def)
end

global func genmem_d(symbol d)pcl=
	return pgenmem(d)
end

global proc genpushmem_d(symbol d)=
	pc_gen(kload, pgenmem(d))
end

global func genmemaddr_d(symbol d)pcl=
	return pgenmemaddr(d)
end

global proc genpushmemaddr_d(symbol d)=
	pc_gen(kload, pgenmemaddr(d))
end

global proc genpushint(int a)=
	pc_gen(kload, pgenint(a))
	pc_setmode(ti64)
end

global func reversecond(int cc)int=
!reverse conditional operator
	case cc
	when eq_cc then cc:=ne_cc
	when ne_cc then cc:=eq_cc
	when lt_cc then cc:=ge_cc
	when le_cc then cc:=gt_cc
	when ge_cc then cc:=lt_cc
	when gt_cc then cc:=le_cc
	esac

	return cc
end

global func reversecond_order(int cc)int=
	case cc
	when eq_cc then cc:=eq_cc
	when ne_cc then cc:=ne_cc
	when lt_cc then cc:=gt_cc
	when le_cc then cc:=ge_cc
	when ge_cc then cc:=le_cc
	when gt_cc then cc:=lt_cc
	esac

	return cc
end

global proc genpushreal(real x, int mode)=
	pc_gen(kload, pgenrealmem(x))
	pc_setmode(mode)
end

global proc genpushstring(ichar s)=
	pc_gen(kload, pgenstring(s))
	pc_setmode(tu64)
end

global func createfwdlabel:int =
	return ++mlabelno
end

global func definelabel:int =
	pc_gen(klabel, pgenlabel(++mlabelno))
	return mlabelno
end

global proc definefwdlabel(int lab) =
	pc_gen(klabel, pgenlabel(lab))
end

