const fshowpclseqno=1
!const fshowpclseqno=0

strbuffer sbuffer
ref strbuffer dest=&sbuffer
int destlinestart

const tab1="    "
const tab2="        "

ref[]byte labeltab

int pclseqno

global ichar longstring					!used in stropnd
global int longstringlen

global proc strpcl(pcl p)=
	[256]char str
	int opcode, n,x,y
	symbol d, e

	const showformatted=1

	opcode:=p.opcode

!	if fshowpclseqno then
!		psstr(string(pclseqno, "z5"))
!		psstr("  ")
!	fi

!CPL "STRPCL", PCLNAMES[P.OPCODE]

!PSSTR("<PCL>")
!PSINT(INT(P.A))
!PSSTR( " ")

!PSSTR(OPNDNAMES[P.OPNDTYPE])

!psstr(strint(getlineno(p.pos),"4"))
!psstr(" ")

	case opcode
	when klabel then
		strlabel(p.labelno,1)

		IF P.POPONE THEN
			PSSTR(" NOT USED")
		FI

		return
	when klabeldef then
		psstr("! ")
		psstr(p.def.name)
		psstr(":")
		return
	when kcomment then
		if p.svalue^ then
			psstr("!")
			psstr(p.svalue)
		ELSE
			PSSTR("! - - -")
		fi
		return

	esac

	psstr(tab1)
skiptab:


	case opcode
	when kjumpcc then
		strcpy(str, "jump")
		strcat(str, ccnames[p.condcode])
!		if p.popone then
!			strcat(str, "/1")
!		fi
	when ksetcc then
		strcpy(str, "set")
		strcat(str, ccnames[p.condcode])
	else
		strcpy(str, pclnames[opcode])
	esac

	gs_leftstr(dest,str,9)

	str[1]:=0
	if p.mode then
		strcat(str, strmode(p.mode))

		if pclhastype[opcode]=2 then
			strcat(str, "/")
			strcat(str, strmode(p.mode2))
		fi
		STRCAT(STR, " ")
	fi
	gs_leftstr(dest,str,4)

	fprint @str,"[#] ", p.spindex:"2"
	psstr(str)

	str[1]:=0
	n:=pclextra[opcode]
	if n then
		x:=p.x; y:=p.y
		if x or n=2 then			!don't show single 0 value
			strcat(str, "/")
			strcat(str, strint(p.x))
		fi

		if n=2 and y then
			strcat(str, "/")
			strcat(str, strint(y))
		fi
		STRCAT(STR, " ")
	fi	
	gs_leftstr(dest,str,5)

	if p.opndtype then
		psstr(" ")
		psstr(stropnd(p))
	fi
	pstabto(40)

	if fshowpclseqno then
		psstr("! ")
		psstr(strint(pclseqno,"z5"))
		psstr("  ")
	fi
end

global func strpclstr(pcl p, int buffsize)ichar=
	gs_free(dest)
	gs_init(dest)
	destlinestart:=0
	strpcl(p)
	gs_char(dest,0)

	if dest.length>=buffsize then return "<BIGSTR>" fi

	dest.strptr
end

global func writeallpcl:ref strbuffer=
!write all pcl code in system by scanning all procs
!pcl code is only stored per-proc
	ref procrec pp
	symbol d

	labeltab:=pcm_allocz(mlabelno)			!indexed 1..labelno

	gs_init(dest)
	destlinestart:=dest.length

	gs_strln(dest, "!PROC PCL")


	pp:=proclist
	while pp, pp:=pp.nextproc do
		currfunc:=d:=pp.def

		psprocsig(d)
		psprocbody(d)

		psstrline("End")
		psline()
	od


	pcm_free(labeltab, mlabelno)

	return dest
end

proc psstr(ichar s)=
	gs_str(dest,s)
end

proc psstrline(ichar s)=
	gs_str(dest,s)
	gs_line(dest)
end

proc psline=
	gs_line(dest)
end

proc psint(int a)=
	gs_str(dest,strint(a))
end

proc psname(symbol d)=
	gs_str(dest,getfullname(d))
end

proc psprocsig(symbol d)=
	symbol e
	byte comma:=0
	int lastmode:=tvoid, m, lastsize, size

	psstr("Proc ")
	psstr(d.name)
	psstr("(")

	e:=d.deflist

	while e, e:=e.nextdef do
		if e.nameid=paramid then
			if comma then psstr(", ") fi
			if e.mode<>lastmode then
				lastmode:=e.mode
				psstr(strmode(lastmode))
				psstr(" ")
			fi
			psstr(e.name)

			comma:=1
		fi
	od
	psstr(")")

	if d.mode then
		psstr(strmode(d.mode))
	fi
	psstrline(" =")


	e:=d.deflist
	comma:=0
	while e, e:=e.nextdef do
		if e.nameid in [frameid, staticid] then
			psstr(tab1)
			psstr(strmode(e.mode))
			psstr(" ")
			psstrline(e.name)
			comma:=1
		fi
	od
	if comma then psline() fi
end

proc psprocbody(symbol d)=
	pcl p
	int lastsp:=0

	p:=d.pclinfo.pccode

	return unless p

!do first pass populating label table

	while p, p:=p.next do
		if p.opcode<>klabel then
			if p.opndtype=label_opnd then
				labeltab[p.labelno]:=1
			fi
		fi
	od

	p:=d.pclinfo.pccode
	destlinestart:=dest.length
	pclseqno:=0

	while p, p:=p.next do
		++pclseqno
		lastsp:=p.spindex

!UNLESS P.OPCODE IN [KSETCALL, KSETARG] THEN
		strpcl(p)
		gs_line(dest)
!END
		destlinestart:=dest.length
	od

	psstr("Last SP:")
	psint(lastsp)
	psline()
end

global proc strlabel(int labelno,colon=0)=
	psstr("L")
	psint(labelno)
	if colon then
		psstr(":")
	fi
	psstr(" ")
end

global proc pstabto(int n)=
	int col:=dest.length-destlinestart
	while n>col do psstr(" "); ++col od
end

global func stropnd(pcl p)ichar=
	static[512]char str
!	static[32]char str
	int length
	symbol d
	static ichar longstring

	if p=nil then
		return ""
	fi

	str[1]:=0

	case p.opndtype
	when int_opnd then
		return strint(p.value)
	when real_opnd, realimm_opnd, realimm32_opnd, r32_opnd then
!RETURN "<REAL>"
!CPL "HERE"
		if p.xvalue=infinity then
!CPL "INF"
!			fprint @str,"0x#",word@(p.xvalue):"h"
			fprint @str,"infinity"
		else
			print @str,p.xvalue:"e16.16"
		fi

!	when r32_opnd then
!		print @str, p.xvalue

!	when realimm_opnd, realimm32_opnd THEN
!		print @str,p.xvalue
!STRCAT(STR, OPNDNAMES[P.OPNDTYPE])


	when string_opnd then
		if (length:=strlen(p.svalue))<str.len/2 then
			strcpy(str,"""")
			convertstring(p.svalue, &str[1]+1, length)
			strcat(str,"""")

		else

			if longstring then
				pcm_free(longstring,longstringlen)
			fi
			longstringlen:=length*2
			longstring:=pcm_alloc(longstringlen)
			longstring^:='"'
			length:=convertstring(p.svalue, longstring+1, length)
			(longstring+length+1)^:='"'
			(longstring+length+2)^:=0
			return longstring
		fi

	when mem_opnd then
		d:=p.def
		strcat(str, p.def.name)

	when memaddr_opnd then
		strcpy(str, "&")
		recase mem_opnd

	when label_opnd then
		fprint @str,"## ","#",p.labelno

	when no_opnd then
		return ""

!	when data_opnd then
!		fprint @str,"<Data * # (#)>", p.size,p.svalue

	else
		println "---------",OPNDNAMES[P.OPNDTYPE]
		return "<PCLOPND?>"
	esac

	return str
end

