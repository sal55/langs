global ichar str=F"ABCDEF"
global ichar str=F"ABCDE\F\"
global ichar str="ABCDEF"

func os_getmpath:ichar=
	return F"C:@@@@@\B\"
end

