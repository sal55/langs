record node=
	int a,b,c,d
end

proc testlist()=
	[6]node nos
!	int n,target
	int k,m
	[6]node newnos

	newnos[m]:=nos[k]
end

