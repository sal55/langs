[10]int xx

proc main=
	slice[]int s
	ref slice[]int p
	int a
	

!	eval s.len
	eval p.len


end
