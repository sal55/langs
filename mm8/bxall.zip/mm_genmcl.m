macro mdivider = mcomment("-"*40)
macro divider = pc_comment("-"*40)

global pcl pcldoswx

const maxnestedloops	= 50

global [maxnestedloops,4]int loopstack
global int loopindex							!current level of nested loop/switch blocks

unitrec zero_unit
global unit pzero=&zero_unit

INT PCLLENGTH
INT NPROCS

global proc genmcl=
	ref strbuffer asmstr
	ref procrec pp
	symbol d
	int tt

	return when mcldone

	tt:=clock()

!*!	inithandlers()
	mclinit()

	mcomment("Generated ASM")

	dolibfiles()

	pp:=staticlist
	while pp do
		d:=pp.def
!CPL "DOSTATIC",D, D.NAME
		dostaticvar(d)
		pp:=pp.nextproc
	od

	mcomment("")

!import list not needed for AA; only for NASM

!	for i to ndllproctable do
!		gendllproc(dllproctable[i])
!	od

	pp:=proclist
	while pp do
		d:=pp.def
		genprocmcl(d)
		pp:=pp.nextproc
	od

	genrealtable()
	genabsneg()
	genstringtable()

	genmc(m_endx)					!need as buffer in optimiser
	genmc(m_endx)

	if fpeephole then
!*!		peephole()
	fi

	mcldone:=1

	mcltime:=os_clock()-tt
!CPL $LINENO


end

global proc genpcl=
!generate pcl code for each function
	ref procrec pp
	symbol d
	int tt:=clock()

	pp:=proclist
	while pp do
		d:=pp.def
		genprocpcl(d)
!++NPROCS
!PCLLENGTH+:=D.PCLINFO.LENGTH

		pp:=pp.nextproc
	od

!CPL =NPROCS
!CPL =PCLLENGTH
!CPL real (PCLLENGTH)/nprocs
!CPL

	pcltime:=clock()-tt
end

proc start=
	zero_unit.tag:=jconst
	zero_unit.mode:=ti64
	zero_unit.value:=0
	zero_unit.resultflag:=1
end

proc dolibfiles =
	mcomment("Lib files go here")
	mcomment("")
end

proc dostaticvar(symbol d) =

	return when d.isimport or d.equivvar

	if d.scope = program_scope and d.name^='$' then
		if eqstring(d.name,"$cmdskip") then
			d.scope:=export_scope				!export from mlib subprog
		fi
	fi

	setsegment((d.code|'I'|'Z'), getalignment(d.mode))
	genmc(m_labelname, mgenmemaddr(d))

	if d.code then
		genidata(d.code)
	else
		genmc(m_resb, mgenint(ttsize[d.mode]))
	fi
end

proc genidata(unit p)=
	[2000]byte data
	int t, tbase, offset
	byte allbytes, nbytes
	unit q, a
	symbol d
	ref char s
	mclopnd dx

	t:=p.mode
!CPL "GENIDATA",JTAGNAMES[P.TAG], STRMODE(T)
!PRINTUNIT(P)

	mmpos:=p.pos
	tbase:=ttbasetype[t]
	a:=p.a
!RETURN

	case p.tag
	when jconst then
		case tbase
		when tref then				!ref or string
			if t=trefchar and p.isastring then
				gerror("idata/empty str?") unless p.svalue
				if p.strtype='B' then gerror("1:B-str?") fi
				genmc(m_dq, mgenlabel(getstringindex(p.svalue)))
			else
				gendataint(p.value)
			fi

		when tr64 then
			genmc(m_dq, mgenrealimm(p.xvalue, tr64))

		when tr32 then
			genmc(m_dd, mgenrealimm(p.xvalue, tr32))

		when tarray then			!should be data string
			if p.strtype=0 then gerror("idata/array/not blockdata") fi
			doblockdata(p.svalue, p.slength)

		else						!assume integer
			gendataint(p.value, t)

		esac

	when jmakelist then
		q:=a

		allbytes:=1
		nbytes:=0
		while q, q:=q.nextunit do
			if q.tag=jconst and q.mode=tu8 and nbytes<data.len then
				data[++nbytes]:=q.value
			else
				allbytes:=0
				exit
			end
		end

		if allbytes and nbytes then		!was all byte constants, not in data[1..nbytes]
			doblockdata(cast(&data), nbytes)
		else
			q:=a
			while q, q:=q.nextunit do
				genidata(q)
			od
		fi

	when jname then
		d:=p.def
		offset:=0
doname:
		case d.nameid
		when staticid, procid, dllprocid then
			dx:=applyoffset(mgenmemaddr(d), offset)

		when labelid then
			if d.index=0 then d.index:=++mlabelno fi
			dx:=mgenlabel(d.index)
		else

			MCOMMENT("Idata &frameXXX")
!			gerror("Idata &frameXXX")
		esac
		genmc(m_dq, dx)

	when jconvert then
		genidata(p.a)

	when jshorten then
		gendataint(a.value, t)

	when jaddrof then
		if a.tag<>jname then recase else fi
		offset:=0
		if p.b then offset:=p.b.value fi
		d:=a.def
		doname

	else
		gerror_s("IDATA: ", jtagnames[p.tag], p)

	esac
end

proc gendataint(int a, mode=ti64)=
	static []byte opctable =(m_db, m_dw, 0,0, m_dd, 0,0, m_dq)

	genmc(opctable[ttsize[mode]], mgenint(a))
end

!proc doblockdata(unit p) =
proc doblockdata(ref byte s, int n) =
!p contains jconst with array type; treat as data-string

	ref u64 d:=cast(s)
	int nwords, r

	return when n=0

	nwords:=n/8

	to nwords do
		genmc(m_dq, mgenint(d++^))
	od

	r:=n-nwords*8
	if r then
		s:=cast(d)
		to r do
			genmc(m_db, mgenint(s++^))
		od
	fi
	MCOMMENT("ENDDATA")

end

proc genprocmcl(symbol d) =

	currfunc:=d
	setsegment('C',1)

	genmc(m_procstart, mgenmemaddr(currfunc))
	genmc(m_labelname, mgenmemaddr(currfunc))

	mcomment("?>>")
	mclprocentry:=mccodex

	do_proccode_a()						!initialise offsets etc

	mcomment("?>>")
	mclprocentry:=mccodex

	mdivider()

	MCOMMENT("CONVERT PCL BODY TO MCL")
!*!	pcltomcl(d)

	if mclprocentry=mccodex then		!empty body: add dummy mcl op
		mcomment("---")					!injection of entry code goes wrong otherwise
	fi

	mdivider()

	do_proccode_b()						!do entry code (inject into start)
	do_proccode_c()						!do exit code

	genmc(m_procend)

	currfunc:=nil

end

proc genprocpcl (symbol p) =
	imodule ms
	byte ismain:=0

	ms:=modules[p.moduleno]
	pcldoswx:=nil
!	nblocktemps:=0

!-----------------
	currfunc:=p
	pcl_start()
	mmpos:=p.pos


	if p=ms.stmain and moduletosub[p.moduleno]=mainsubprogno then
		ismain:=1
		entryproc:=p
!		p.isentry:=1
		genmain(p)

	elsif p=ms.ststart then
		genstart(p)
	fi
!------------------


	retindex:=createfwdlabel()

	divider()

	if p.hasdoswx then
		pc_gen(kinitdswx)			!this op needed by C?
		pcldoswx:=pccurr			!code to be injected later after this instr
	fi

!	pc_comment("<EVALBLOCk>")

!CPL "PROC",P.NAME, P.OWNER.NAME, P.CODE
	evalunit(p.code)
!CPL "PROC",$LINENO

	if ismain then
		genpushint(0)
		pc_gen(kstop)
		pc_setmode(ti64)
	fi

	divider()
	definefwdlabel(retindex)
	genreturn()

	p.pclinfo.code:=pcl_end()
	p.pclinfo.length:=pclength
!	CPL P.NAME:"JL18", p.pclinfo.length:"5"

!	CPL P.PCLINFO.LENGTH:"5", P.NAME:"JL18"

!	scanpclstack(p, p.pclinfo.code)


end

proc genmain(symbol p)=
	symbol d
	for i to nsubprogs when i<>mainsubprogno do
		d:=modules[subprogs[i].mainmodule].ststart
		docallproc(d)
	od
	d:=modules[subprogs[mainsubprogno].mainmodule].ststart
	docallproc(d)

	entryproc:=p
end

proc genstart(symbol p)=
	symbol d
	int lead:=0, m,s

	m:=p.moduleno
	s:=p.subprogno

	if s=mainsubprogno and p.moduleno=subprogs[s].mainmodule then
		LEAD:=1
	elsif p.moduleno=subprogs[s].firstmodule then
		LEAD:=2
	fi

	if lead then
		for i to nmodules when moduletosub[i]=s and i<>m do
			d:=modules[i].ststart
			docallproc(d)
		od
	fi
end

proc docallproc(symbol d)=
!call a simple proc, eg. start(), with no args
	return unless d
	pc_gen(ksetcall)
	pc_setnargs(0)

	pc_gen(kcallp, genmemaddr_d(d))
end

global proc genreturn=
!assume returning from currproc
	case currproc.nretvalues
	when 0 then
		pc_gen(kretproc)
	when 1 then
		pc_gen(kretfn)
		pc_setmode(currproc.mode)

	else
		pc_genx(kretfn, currproc.nretvalues)
	esac
end

global func genmem_u(unit p)mclopnd=
	return mgenmem(p.def)
end

global func genmem_d(symbol d)mclopnd=
	return mgenmem(d)
end

global proc genpushmem_d(symbol d)=
	pc_gen(kload, mgenmem(d))
end

global func genmemaddr_d(symbol d)mclopnd=
	return mgenmemaddr(d)
end

global proc genpushmemaddr_d(symbol d)=
	pc_gen(kload, mgenmemaddr(d))
end

global proc genpushint(int a)=
	pc_gen(kload, mgenint(a))
	pc_setmode(ti64)
end

global func reversecond(int cc)int=
!reverse conditional operator
	case cc
	when eq_cc then cc:=ne_cc
	when ne_cc then cc:=eq_cc
	when lt_cc then cc:=ge_cc
	when le_cc then cc:=gt_cc
	when ge_cc then cc:=lt_cc
	when gt_cc then cc:=le_cc
	esac

	return cc
end

global func reversecond_order(int cc)int=
	case cc
	when eq_cc then cc:=eq_cc
	when ne_cc then cc:=ne_cc
	when lt_cc then cc:=gt_cc
	when le_cc then cc:=ge_cc
	when ge_cc then cc:=le_cc
	when gt_cc then cc:=lt_cc
	esac

	return cc
end

global proc genpushreal(real x, int mode)=
	pc_gen(kload, mgenrealmem(x, ttsize[mode]))
	pc_setmode(mode)
end

global proc genpushstring(ichar s)=
	pc_gen(kload, mgenstring(s))
	pc_setmode(tu64)
end

global proc stacklooplabels(int a,b,c)=
!don't check for loop depth as that has been done during parsing
	++loopindex
	if loopindex>maxnestedloops then
		gerror("Too many nested loops")
	fi

	loopstack[loopindex,1]:=a
	loopstack[loopindex,2]:=b
	loopstack[loopindex,3]:=c

end

global func findlooplabel(int k,n)int=
!k is 1,2,3 for label A,B,C
!n is a 1,2,3, according to loop nesting index
	int i

	i:=loopindex-(n-1)		!point to entry
	if i<1 or i>loopindex then gerror("Bad loop index") fi
	return loopstack[i,k]
end

global proc genpc_sysfn(int fnindex, unit a=nil,b=nil,c=nil)=
	genpc_sysproc(fnindex, a,b,c, 1)
end

global proc genpc_sysproc(int fnindex, unit a=nil,b=nil,c=nil, int asfunc=0)=
	int nargs:=0, opc
	symbol d
	pcl p
	opc:=0

	pc_gen(ksetcall)
	p:=pccurr

	pushsysarg(c, 3, nargs)
	pushsysarg(b, 2, nargs)
	pushsysarg(a, 1, nargs)
!
	p.nargs:=nargs

	d:=getsysfnhandler(fnindex)
	if d then
		pc_gen((asfunc|kcallf|kcallp), mgenmemaddr(d))
		pc_setnargs(nargs)
	else
!		pc_gen((asfunc|kcallf|kcallp), gennameaddr(sysfnnames[fnindex]+3))
		pc_gen((asfunc|kcallf|kcallp), mgenname(sysfnnames[fnindex]+3))
	fi
	pccurr.nargs:=nargs
end

global proc pushsysarg(unit p, int n, &nargs) =
!return 0 or 1 args pushed
	if p then
		evalunit(p)
		pc_gen(ksetarg)
		pc_setmode_u(p)
		pccurr.x:=n
		pccurr.y:=n			!ASSUMES ALL INTS; however this only important
							!for arm64, and only matters if more than 8 args
		++nargs
	fi
end

global func getsysfnhandler(int fn)symbol p=
	[300]char str
	int report

	if sysfnhandlers[fn] then
		return sysfnhandlers[fn]
	fi

	strcpy(str,"m$")
	strcat(str,sysfnnames[fn]+3)	!"sf_stop" => "m$stop"

	ref procrec pp:=proclist
	while pp, pp:=pp.nextproc do
		if eqstring(pp.def.name, str) then
			sysfnhandlers[fn]:=pp.def
			return pp.def
		fi
	od

!	report:=passlevel>asm_pass
	report:=1
	report:=0

	if report then
		println "Sysfn not found:",str
	fi
	if fn<>sf_unimpl then
		p:=getsysfnhandler(sf_unimpl)
		if p=nil and report then
			gerror("No m$unimpl")
		fi
		return p
	fi

	return nil
end

global proc setfunctab=
	if pnprocs=nil then
		pnprocs:=makesymbol("$nprocs", staticid)
!CPL "SET PNPROCS", PNPROCS
		pnprocs.mode:=tpi64
		pprocname:=makesymbol("$procname", staticid)
		pprocaddr:=makesymbol("$procaddr", staticid)
	fi
end

global func makesymbol(ichar s, int id)symbol d=
	d:=newstrec()
	d.name:=pcm_copyheapstring(s)

	d.nameid:=id

	addstatic(d)
	d
end

!proc scanpclstack(symbol d, pcl p)=
!!scan pcl sequence from a function d, and set the stack index for each
!	int sp:=0				!start with empty stack
!	int a, b				!popped and pushed stack opnds for each opcode
!	int opcode
!	int mxlevel:=0, spstart
!
!	while p, p:=p.next do
!		opcode:=p.opcode
!		a:=pclpop[opcode]
!		b:=pclpush[opcode]
!
!		if a=9 or b=9 then		!needs special analysis
!			case opcode
!			when kstartmx then
!				if mxlevel then cpl "Nested startmx",currfunc.name fi
!				++mxlevel
!				spstart:=sp
!			when kresetmx then
!				sp:=spstart
!			when kendmx then
!				--mxlevel
!			when kcallp, kcallf then
!				sp:=sp-p.nargs+b
!			when kicallp, kicallf then
!				sp:=sp-p.nargs-1+b
!!			when kjumpret then
!!				a:=b:=0
!			when kjumpcc then
!				sp:=sp-(p.popone|1|2)
!			ELSE
!				CPL "CAN'T DO",PCLNAMES[OPCODE]
!			esac
!		else
!			sp:=sp-a+b
!		fi
!		p.spindex:=sp
!	od
!
!	if sp then
!		println d.name," Stack not empty:", sp
!	fi
!
!end
