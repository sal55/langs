[0..7]int row
int s

proc main=

CPL "ROW"

	to 7000 do
!	to 1 do
!CPL "HELLO"
		mainx(1)
	od
end

function safe(int x,y)int=
	int i,a

!CPL "SAFE:",X," ",Y

	for i:=1 to y do
		a:=row[y-i]
		if a=x or a=x-i or a=x+i then
			return 0
		fi


! if row[y-i]=x or row[y-i]=x-i or row[y-i]=x+i then return false fi
	od
	return 1
end

proc putboard=
	int x,y

	++s
	println "\wSolution",s

	for y:=0 to 7 do
		for x:=0 to 7 do
			print ((x=row[y]|"| Q "|"|   "))
		od
		println "|\n---------------------------------"
	od
end

proc mainx(int y)=
	int x

	for x:=0 to 7 do
		row[y-1]:=x
		if safe(x,y-1) then
			if y<8 then
				mainx(y+1)
			else
!				putboard()
			fi
		fi
	od
end
