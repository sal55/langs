global int nsaveregs, nsavefregs		!number of integer/float non-vols to be saved
global int nspilled						!spilled int/float registers

global int framesize					!counts bytes in stack frame
!global int framebytes, frameoffset, paramoffset
global int paramstackoffset
global int paramspilloffset

symbol dblockarg

int nsavedregs, nsavedxregs
global int retindex

global proc do_proccode_a=
!	nextworkreg:=r0						!first 3 are volatile
!	nextworkxreg:=xr4					!first 2 are volatile
!
!	highworkreg:=nextworkreg			!assume workreg will be used
!	highworkxreg:=nextworkxreg
!
	retindex:=createfwdlabel()
end

global proc do_proccode_b=
! Stack layout (grows downwards)
!	| ...
!	| Pushed arg 6
!	| Pushed arg 5
!	| Shadow space 32-byte		For spilled args (always present even with 0-3 args)
!	| ----------
!	| Pushed return address		Via 'call'
!	| ----------				Above done in caller; below in callee
!	| Pushed nonvol workregs	If extend to R3 and above
!	| Pushed nonvol workxregs	If extend to XR6 and above
!	| ----------				Above done in caller; below in callee
!	| Pushed FP					Save FP
!	| ----------
!	! Local vars				All locals (when used)
!	| ----------
!	| Temps						All temps
!	| ----------
!	| 32-byte shadow space		For any calls made in this func
!	| [Stack adj]				Extra slot may be added to keep stack pointer 16-byte aligned

	int retmode, hasequiv, offset, size, reg
	int nsavedbytes, paramoffset
!*!	mclopnd ax
	symbol d
	[100]char str, newname
	int r, n

!CPL $LINENO

	setmclentry(mclprocentry)

	framesize:=0
	dblockarg:=nil

!NEXTWORKREG:=R4
!NEXTWORKXREG:=XR7

	nsavedregs:=max(highworkreg-r2, 0)
	nsavedxregs:=max(highworkxreg-xr5, 0)
	nsavedbytes:=(nsavedregs+nsavedxregs)*8

!CPL $LINENO
!CPL CURRFUNC.NAME,"HIGHWORKREG=", STRREG(HIGHWORKREG)
!CPL CURRFUNC.NAME,"HIGHWORKXREG=", STRREG(HIGHWORKXREG)


!allocate offsets to args, and set defines

!CPL "PROC B", =CURRFUNC.NAME, =CURRFUNC.NPARAMS, STRPMODE(CURRFUNC.MODE, CURRFUNC.SIZE)

	if ttbasetype[currfunc.mode]=tblock then	!need to inject extra parameter
		GERROR("PROCB/BLOCKRET")
!		dblockarg:=tc_makesymbol("$block", param_id)
!		dblockarg.nextparam:=currfunc.nextparam
!		dblockarg.mode:=tblock
!		dblockarg.size:=currfunc.size
!
!		currfunc.nextparam:=dblockarg
!		++currfunc.nparams
	fi
!CPL "PROC B2", =CURRFUNC.NAME, =CURRFUNC.NPARAMS, STRPMODE(CURRFUNC.MODE, CURRFUNC.SIZE)

!IF NSAVEDBYTES THEN
!	CPL "Saving:", nsavedregs, nsavedxregs,"in", currfunc.name
!FI

	paramoffset:=16+nsavedbytes		!between top of stackframe and 1st param is fp/retaddr/saved

	d:=currfunc.deflist
	while d, d:=d.nextdef do
		case d.nameid
		when paramid then
			d.offset:=paramoffset
			paramoffset+:=8
	!		if d.used then
				genmc_def(m_define, d)
!			elsif pcheckunusedlocals then
!				println "Unused param:", d.name, "in", currfunc.name
!			fi

		when frameid then
!			if not d.used then
!				if pcheckunusedlocals then
!					println "Unused local:", d.name, "in", currfunc.name
!				fi
!				nextloop
!			fi

			size:=stdsize[ttbasetype[d.mode]]
			if d.mode=tblock then
				size:=ttsize[d.mode]
			fi

			if d.equivvar then
				MERROR("PCODEB/@")
			else
				framesize+:=roundsizetg(size)
				d.offset:=-framesize
				genmc_def(m_define, d)
			fi
		esac
	od

	framesize+:=32									!shadow space
!CPL "FS AFTER SHADOW SPACE", FRAMESIZE

	if (framesize+nsavedbytes) iand 8 then			!keep stack frame 16-byte aligned
		framesize+:=8
	end

	savevolregs(nsavedregs, nsavedxregs)

!generate stack entry code proper:

	genmc(m_push, dframeopnd)
	genmc(m_mov, dframeopnd, dstackopnd)
	pushstack(framesize)

!spill any args to shadow space
	spillparams()

!	MCOMM("="*40)
	resetmclentry()
end

global proc do_proccode_c=
	int offset
	mclopnd ax, bx

!	MCOMM("="*40)

	genmc(m_label, mgenlabel(retindex))

!	if dblockarg then
!!		MCOMMENT("BLOCK RETURN COPY NEEDED")
!!D0 has address of block to be copied
!!It needs to be returned on D0 after copying
!MCOMMENT("BLOCKRET1")
!
!		ax:=mgenireg(r0)
!		bx:=mgenreg(r1)
!		genmc(m_mov, bx, mgenmem(dblockarg))
!		nextworkreg:=r2
!		copyblock(mgenireg(r1), ax, dblockarg.size)		!does not affect r0
!		genmc(m_xchg,  mgenreg(r0), bx)
!
!MCOMMENT("BLOCKRET2")
!
!	fi

	popstack(framesize)
	genmc(m_pop, dframeopnd)
	restorevolregs(nsavedregs, nsavedxregs)

	genmc(m_ret)
end

proc spillparams=
	symbol d
	mclopnd ax
	int offset:=16, regoffset:=0, xregoffset, firstoffset

	regoffset:=0

	d:=currfunc.deflist

!	if currfunc.variadic then				!C proc def using ...
!		firstoffset:=d.offset				!param offsets may be pushed up
!
!		for i:=currfunc.nparams to 3 do				!0-based; if nparams=2, loops over 2..3 as 0..1 are normal
!			ax:=mgenindex(areg:rframe, size:8, offset:i*8+firstoffset)
!			genmc(m_mov, ax, mgenreg(i+r10))
!		od
!	fi
!
	while d, d:=d.nextdef do
		if d.nameid=paramid then
			if regoffset>3 then exit fi

			if d.used or regoffset=0 then
				ax:=mgenindex(areg:rframe, size:8, offset:d.offset)
				case d.mode
				when tr64 then
					genmc(m_movq, ax, mgenxreg(regoffset+xr0))
				when tr32 then
					genmc(m_movd, changeopndsize(ax,4), mgenxreg(regoffset+xr0))
				else
					genmc(m_mov, ax, mgenreg(regoffset+r10))
				esac
			fi

			offset+:=8
			++regoffset
		fi
	od

end

proc savevolregs(int nregs, nxregs)=
	int reg
	mclopnd ax

	reg:=r3
	to nregs do
		genmc(m_push, mgenreg(reg++))
	od

	reg:=xr6
	ax:=mgenreg(r0)
	to nxregs do
		genmc(m_movq, ax, mgenreg(reg++))
		genmc(m_push, ax)
	od
end

proc restorevolregs(int nregs, nxregs)=
	int reg
	mclopnd ax

	reg:=xr6+nxregs
	ax:=mgenreg(r13)

	to nxregs do
		genmc(m_pop, ax)
		genmc(m_movq, mgenreg(--reg), ax)
	od
	reg:=r3+nregs
	to nregs do
		genmc(m_pop, mgenreg(--reg))
	od

end

proc gendq(int a)=
	genmc_int(m_dq, a)
end

global proc genabsneg=
	if lababs32+lababs64+labneg32+labneg64 then
		setsegment('I', 16)
	fi

	if lababs32 then
		mcomment("lababs32")
		genmc_label(m_label, lababs32)
		gendq(0x7FFF'FFFF'7FFF'FFFF)
		gendq(0x7FFF'FFFF'7FFF'FFFF)
	fi
	if lababs64 then
		mcomment("lababs64")
		genmc_label(m_label, lababs64)
		gendq(0x7FFF'FFFF'FFFF'FFFF)
		gendq(0x7FFF'FFFF'FFFF'FFFF)
	fi

	if labneg32 then
		mcomment("labneg32")
		genmc_label(m_label, labneg32)
		gendq(0x8000'0000'8000'0000)
		gendq(0x8000'0000'8000'0000)
	fi
	if labneg64 then
		mcomment("labneg64")
		genmc_label(m_label, labneg64)
		gendq(0x8000'0000'0000'0000)
		gendq(0x8000'0000'0000'0000)
	fi

	if labzero then
		mcomment("labzero")
		genmc_label(m_label, labzero)
		gendq(0)
	fi

	if labmask63 then
		mcomment("mask63/offset64")
		genmc_label(m_label, labmask63)
		gendq(0x7FFF'FFFF'FFFF'FFFF)
		genmc_label(m_label, laboffset64)
		gendq(0x43E0'0000'0000'0000)
	fi
end

proc setmclentry(mcl p)=
!temporarily set mcl insertion before p

	mce_oldmccodex:=mccodex
	mccodex:=p
	mce_lastmcl:=p.lastmcl
	mce_nextmcl:=p.nextmcl
end

func resetmclentry:mcl pnew =
!restore mcl insertion point to normal
!restireturn mcl instruction that followed	
	mccodex.lastmcl:=mce_lastmcl
	mccodex.nextmcl:=mce_nextmcl
	pnew:=mccodex
	mccodex:=mce_oldmccodex
	pnew
end

proc setmclentryf(mcl p)=
!temporarily set mcl insertion before p

	mcf_oldmccodex:=mccodex
	mccodex:=p
	mcf_lastmcl:=p.lastmcl
	mcf_nextmcl:=p.nextmcl
end

func resetmclentryf:mcl pnew =
!restore mcl insertion point to normal
!restireturn mcl instruction that followed	
	mccodex.lastmcl:=mcf_lastmcl
	mccodex.nextmcl:=mcf_nextmcl
	pnew:=mccodex
	mccodex:=mcf_oldmccodex
	pnew
end

global func createfwdlabel:int =
	return ++mlabelno
end

global func definelabel:int =
	pc_gen(klabel, mgenlabel(++mlabelno))
	return mlabelno
end

global proc definefwdlabel(int lab) =
	pc_gen(klabel, mgenlabel(lab))
end

global func mdefinelabel:int =
	genmc(m_label, mgenlabel(++mlabelno))
	return mlabelno
end

global proc mdefinefwdlabel(int lab) =
	genmc(m_label, mgenlabel(lab))
end

global func getpclmode(int t)int u=
	u:=stdpcl[ttbasetype[t]]

	if u=tblock then
		case ttsize[t]
		when 8 then u:=tu64
		when 4 then u:=tu32
		when 2 then u:=tu16
		when 1 then u:=tu8
		esac
	fi
	return u
end

global func addstr(ichar s, t)ichar=
	static [256]char str
	strcpy(str, s)
	strcat(str, t)
	str
end

