proc blurhelper(int m, n, shift, ref byte p)=
	int sum
	ref byte q

	to m do
		sum:=0
		q:=p
		to n do
			sum+:=q++^
		od
		p++^:=sum>>shift
	od
end

