!type system

!.opndtype in pxlrec

global enumdata [0:]ichar opndnames =
	(no_opnd=0,			$),
	(mem_opnd,			$),
	(memaddr_opnd,		$),
	(label_opnd,		$),
	(int_opnd,			$),
	(real_opnd,			$),
	(real32_opnd,		$),
	(string_opnd,		$),
	(strimm_opnd,		$),
	(assem_opnd,		$),
	(realimm_opnd,		$),
	(data_opnd,			$),
end

global type pxl = ref pxlrec

export record pxlrec =
	byte opndtype
	byte opcode
	byte pcat

	int32 psize

	union
		struct
			union
				int64 value
				real64 xvalue
				real32 xvalue32
				ichar svalue			!also used for data
				int labelno
!*!				symbol def
				ref void asmcode
			end
			union								!two 32-bit params used according to opcode
				struct (i32 x, y)				! common access to these 1/2 extra attribs
				struct (i32 scale, extra)		! pointer ops: scale factor for offset; extra scaled byte offset
				struct (i32 nargs, nvariadics)	! (x,y) call/etc
				struct (i32 minlab, maxlab)		! (x,y) switch

				struct					!for fix/float, source type
					byte oldcat			!for trunc, it is truncation type
					byte oldsize
					union
						byte oldsigned
						byte oldwide
					end
				end
!
				int32 stepx				! (x) always +ve fixed step size for forup/fordown; also INCR
				int32 align
				int32 nret				! (x) setretmult: no. of return values
				int32 popone			! (x) jumpcc: leave X on stack
				int32 strindex			! (x) any string operand: index into string table
				int32 r64index			! (x) any real operand: index into real table
				int32 r32index			! (x) any real32 operand: index into real32 table
				int32 slicelwb			! (x) for .upb

			end
		end
	end

	union
		byte pwide							! r64 rather than r32 for pcat=real
		byte psigned						! whether pcat=intcat is signed
	end
end


!Stack operands depend on a in (a b):
! a is number of relevant stack operand before the op
! b is number of relevant stack operands after the op

!Input operands (a) are name as follows. Here the stack grows left-to-right, and the
!rightmost X/Y/Z/W is the top of stack:

! a = 0       No stack operands
! a = 1       X
! a = 2       X Y
! a = 3       X Y Z
! a = 4       X Y Z W
!
! When X' is set, it usually means all a are popped, and b=1
! When X'/Y' are set, it usually means all a are popped, and b=2

!Inline operand (not on the stack but as part of the instruction):
!   A			(various)
!   L			(various)

!Extra info:
!   op			opindex
!   fn			fnindex
!   c			cond code
!   t[:size]    type (:size for block types)
!   u           secondary type for some ops (convert etc)
!   n			nargs for calls
!   n			increment
!   s x			scale and byte-offset for ptr/offset ops
!   x y			min/max lab index for switch
!   p			jumpcc flag

!Auxiliary operands:
!	B			Secondary operand in a following kopnd instruction
!	C			Tertiary operand in a following kopnd instruction

export enumdata [0:]ichar pxlnames,
			[0:]byte pxlhastype,
			[0:]byte pxlextra =
!                           t x     ! (a b) (Inline)
	(k_nop=0,			$,	0,0),	! (0 0)
	(k_stop,			$,	0,0),	! (1 0)	          Stop X
	(k_comment,			$,	0,0),	! (0 0)	(A)       Comment A (a string)
	(k_endprogram,		$,	0,0),	! (0 0)

	(k_istatic,			$,  1,0),	! (0 0) (A t)     Define idata label (must be followed by correct db etc ops)
	(k_zstatic,			$,	1,0),	! (0 0) (A t)     Define zdata label and reserve sufficient space

	(k_procdef,			$,	1,0),	! (0 0) (A,t)     Define proc A, of given return type
	(k_endproc,			$,	0,0),	! (0 0)
	(k_threadedproc,	$,	1,0),	! (0 0) (A,t)     Define proc A, of given return type

	(k_label,			$,	0,0),	! (0 0) (L)       Define numbered label L

	(k_load,			$,	1,0),	! (0 1) (A t u)	  X' := A (various forms)
	(k_iloadc,			$,	1,0),	! (1 1) (t u x)   X' := (X + x)^; x is a byte offset
	(k_iloadx,			$,	1,2),	! (2 1) (t u x)   X' := (X + Y*s + x)^
	(k_rloadci,			$,	1,0),	! (1 1) (t u x)   X' := X.[x]; X is a value   Load from in-reg array/record
	(k_rloadxi,			$,	1,2),	! (2 1) (t u x)   X' := X.[Y + x]; X is a value

	(k_store,			$,	1,0),	! (1 0) (A t)     A := X
	(k_istorec,			$,	1,0),	! (2 0) (A t x)   (Y + x)^ := X
	(k_istorex,			$,	1,2),	! (3 0) (t s x)   (Y + Z*s + x)^ := X
	(k_rstoreci,		$,	1,0),	! (2 1) (A t x)   X' := Y.[x] := X Store to in-reg array/record
	(k_rstorexi,		$,	1,2),	! (3 1) (t s x)   X' := Y.[Z+x] := X

	(k_dupl,			$,	1,0),	! (1 1+)          Step count for operand X
	(k_swapopnds,		$,	1,0),	! (2 2)           (X', Y') := (Y, X)
	(k_unload,			$,	1,0),	! (1 0)           Pop stack

	(k_opnd,			$,	0,0),	! (0 0) (A t)     Define auxiliary operand A
	(k_type,			$,	1,0),	! (0 0) (t)       Define auxiliary type t

	(k_loadbit,			$,	1,0),	! (2 1)           X' := X.[Y]
	(k_loadbf,			$,	1,0),	! (3 1)           X' := X.[Y..Z]

	(k_storebit,		$,	1,0),	! (3 0)           Y^.[Z] := X
	(k_storebf,			$,	1,0),	! (4 0)           Y^.[Zb..W] := X

	(k_eval,			$,	1,0),	! (1 0)           Evaluate X [load to an actual register], then pop

	(k_callp,			$,	0,2),	! (n 0) (A n)     Call &A with nargs, then pop args
	(k_icallp,			$,	0,2),	! (a 0) (n)       Call X with nargs, then pop args (a=n+1)
	(k_retproc,			$,	0,0),	! (0 0)           Return from proc

	(k_callf,			$,	1,2),	! (n 1) (A t u n) Call &A, then pop args, leave retval
	(k_icallf,			$,	1,2),	! (a 1) (t u n)   Call X, then pops args, leave retval (a=n+1)
	(k_retfn,			$,	1,0),	! (0 0) (t)       Return from function with X=retval

	(k_jump,			$,	0,0),	! (0 0) (L)       goto L
	(k_ijump,			$,	0,0),	! (1 0)           goto X

	(k_jumpcc,			$,	1,1),	! (2 b) (L t c p) goto L when X c Y; p=1: X':=X (b=0/1)

	(k_jumptrue,		$,	1,0),	! (1 0) (L t)     goto L when X is true
	(k_jumpfalse,		$,	1,0),	! (1 0) (L t)     goto L when X is false

	(k_setcc,			$,	1,0),	! (2 1) (t c)     X' := X c  Y

	(k_casejumpeq,		$,	1,1),	! (2 1) (L t)     goto L when X=Y; pop Y, leave X

	(k_to,				$,	0,0),	! (0 0) (L t B)   --B (aux); goto L when B<>0 

	(k_forup,			$,	1,1),	! (0 0) (L t n B C) B+:=n; goto L when B<=C
	(k_fordown,			$,	1,1),	! (0 0) (L t n B C) B-:=n; goto L when B>=C

	(k_swap,			$,	1,0),	! (2 0) (t)       swap(X^,Y^) ref T/V

	(k_storeslice,		$,	1,0),	! (2 0) (t)       A:=slice(X, Y)
	(k_storesliced,		$,	1,0),	! (2 1) (t)       A:=slice(X, Y); leave A on stack

	(k_switch,			$,	0,2),	! (1 0) (L x y B) L=jumptab; B=elselab; x/y=min/max values
	(k_switchu,			$,	0,2),	! (1 0) (L x y B) L=jumptab; B=elselab; x/y=min/max values
	(k_switchlabel,		$,	0,0),	! (0 0) (L)       jumptable entry
	(k_endswitch,		$,	0,0),	! (0 0)           Mark end of switch jumptable

	(k_clear,			$,	1,0),	! (1 0) (t)       Clear X^

	(k_db,				$,	0,0),	! (0 0) (A)       Define a u8 data value
	(k_dw,				$,	0,0),	! (0 0) (X)       u16 value: ...
	(k_dd,				$,	0,0),	! (0 0) (X)       u32 value: u32/i32/r32, depends on operand
	(k_dq,				$,	0,0),	! (0 0) (X)       u64 value: u64/i64/r64/string/addr/label, depends on operan
	(k_data,			$,	0,0),	! (0 0) (X t)     Strdata value

	(k_assem,			$,	0,0),	! (0 0)           To be worked out....

	(k_add,				$,	1,0),	! (2 1) (t)       X' := X + Y
	(k_sub,				$,	1,0),	! (2 1) (t)
	(k_mul,				$,	1,0),	! (2 1) (t)
	(k_div,				$,	1,0),	! (2 1) (t)
	(k_idiv,			$,	1,0),	! (2 1) (t)
	(k_irem,			$,	1,0),	! (2 1) (t)
	(k_idivrem,			$,	1,0),	! (2 2) (t)
	(k_iand,			$,	1,0),	! (2 1) (t)
	(k_ior,				$,	1,0),	! (2 1) (t)
	(k_ixor,			$,	1,0),	! (2 1) (t)
	(k_shl,				$,	1,0),	! (2 1) (t)
	(k_shr,				$,	1,0),	! (2 1) (t)
	(k_in,				$,	1,0),	! (2 1) (t)
	(k_notin,			$,	1,0),	! (2 1) (t)
	(k_min,				$,	1,0),	! (2 1) (t)
	(k_max,				$,	1,0),	! (2 1) (t)
	(k_same,			$,	1,0),	! (2 1) (t)
	(k_andl,			$,	1,0),	! (2 1) (t)
	(k_orl,				$,	1,0),	! (2 1) (t)
	(k_addrefx,			$,	1,2),	! (2 1) (t s x)   X' := X + Y*scale + offset
	(k_subrefx,			$,	1,2),	! (2 1) (t s x)   X' := X - Y*scale + offset
	(k_subref,			$,	1,1),	! (2 1) (t s)     X' := (X - Y)/scale

	(k_neg,				$,	1,0),	! (1 1) (t)       X' := -X
	(k_abs,				$,	1,0),	! (1 1) (t)
	(k_inot,			$,	1,0),	! (1 1) (t)
	(k_notl,			$,	1,0),	! (1 1) (t)
	(k_istruel,			$,	1,0),	! (1 1) (t)
	(k_sqr,				$,	1,0),	! (1 1) (t)

	(k_sqrt,			$,	1,0),	! (1 1) (t)       X' := sqrt(X)
	(k_sin,				$,	1,0),	! (1 1) (t)
	(k_cos,				$,	1,0),	! (1 1) (t)
	(k_tan,				$,	1,0),	! (1 1) (t)
	(k_asin,			$,	1,0),	! (1 1) (t)
	(k_acos,			$,	1,0),	! (1 1) (t)
	(k_atan,			$,	1,0),	! (1 1) (t)
	(k_log,				$,	1,0),	! (1 1) (t)
	(k_log10,			$,	1,0),	! (1 1) (t)
	(k_exp,				$,	1,0),	! (1 1) (t)
	(k_round,			$,	1,0),	! (1 1) (t)
	(k_floor,			$,	1,0),	! (1 1) (t)
	(k_ceil,			$,	1,0),	! (1 1) (t)
	(k_sign,			$,	1,0),	! (1 1) (t)
	(k_atan2,			$,	1,0),	! (1 1) (t)
	(k_power,			$,	1,0),	! (1 1) (t)
	(k_fmod,			$,	1,0),	! (1 1) (t)

	(k_incr,			$,	1,1),	! (1 0) (t n)     X^+:=step
	(k_decr,			$,	1,1),	! (1 0) (t n)     X^-:=step
	(k_incrload,		$,	1,1),	! (1 1) (t n)     X' := (X+:=step)^
	(k_decrload,		$,	1,1),	! (1 1) (t n)     X' := (X-:=step)^
	(k_loadincr,		$,	1,1),	! (1 1) (t n)     X' := X++^ (difficult to express step)
	(k_loaddecr,		$,	1,1),	! (1 1) (t n)     X' := X--^

	(k_addto,			$,	1,0),	! (2 0) (t)       X^ +:= Y
	(k_subto,			$,	1,0),	! (2 0) (t)
	(k_multo,			$,	1,0),	! (2 0) (t)
	(k_divto,			$,	1,0),	! (2 0) (t)
	(k_idivto,			$,	1,0),	! (2 0) (t)
	(k_iremto,			$,	1,0),	! (2 0) (t)
	(k_iandto,			$,	1,0),	! (2 0) (t)
	(k_iorto,			$,	1,0),	! (2 0) (t)
	(k_ixorto,			$,	1,0),	! (2 0) (t)
	(k_shlto,			$,	1,0),	! (2 0) (t)
	(k_shrto,			$,	1,0),	! (2 0) (t)
	(k_minto,			$,	1,0),	! (2 0) (t)
	(k_maxto,			$,	1,0),	! (2 0) (t)
	(k_andlto,			$,	1,0),	! (2 0) (t)
	(k_orlto,			$,	1,0),	! (2 0) (t)
	(k_addrefxto,		$,	1,2),	! (2 0) (t s x)   X^ +:= Y
	(k_subrefxto,		$,	1,2),	! (2 0) (t s x)   X^ -:= Y

	(k_negto,			$,	1,0),	! (1 0) (t)       -:=X^
	(k_absto,			$,	1,0),	! (1 0) (t)
	(k_inotto,			$,	1,0),	! (1 0) (t)
	(k_notlto,			$,	1,0),	! (1 0) (t)
	(k_istruelto,		$,	1,0),	! (1 0) (t)

!for conversions, t is always the current operand type
!u is the new type. However, for conversions involving widening, the result
!must end up at at least 64 bit. So i64->u8 masks to 8 bits, the sign-extends to u64

	(k_typepun,			$,	2,1),	! (1 1) (t,u)

	(k_float,			$,	2,0),	! (1 1) (t u)     X' := cast(X,t) Int u to real t
	(k_fix,				$,	2,0),	! (1 1) (t u)     X' := cast(X,t) Real u to int t
	(k_truncate,		$,	2,0),	! (1 1) (t u)     X' := cast(X,u) Mask to width of u, but type is widened to t
	(k_widen,			$,	2,0),	! (1 1) (t u)     X' := cast(X,t) Mask to width of u, but type is widened to t
	(k_fwiden,			$,	2,0),	! (1 1) (t u)     X' := cast(X,t) r32 to r64
	(k_fnarrow,			$,	2,0),	! (1 1) (t u)     X' := cast(X,t) r64 to r32

!These ones e currently still needed by or all PCL targets

	(k_startmx,			$,	0,0),
	(k_resetmx,			$,	0,0),
	(k_endmx,			$,	0,0),

!these are ecial ones used reflection

	(k_getnprocs,		$,	0,0),	! (0 1)           X' := Get number of functions in function table
	(k_getprocname,		$,	0,0),	! (1 1)           X' := Getprocname(X) Name of nth function (1-based)
	(k_getprocaddr,		$,	0,0),	! (1 1)           X' := Getprocaddr(X) Addr of nth function (1-based)

	(k_last,			$,	0,0),	! (0 0)
end

!* LOCALS: all that have been USED
!* PARAMS: all including not used ones (but need the USED flag)
!* HIGHPARAM max param (of 0..4) that has been used, to determine
!  if any spare PREG exists
!* NCALLS all calls including those hidden inside POWER etc
!* HIGHARG max argument (of 0..4) of any calls.
!* ASSEMUSED
!* LEAFPROC
!* Need ADDROF flags for each LOCAL and PARAM
!* MAXREGVARS how many locals would qualify as regvars
!* MAXXREGVARS how many locals would qualify as xregvars
!* R3USED (see below)

!global symbol currproc
global ref pxlrec pxlprocdef	!ref to kprocdef opcode of currproc

global int frameoffset
global int paramoffset
global int framebytes

global const maxparams=32
global const maxlocals=256

!these are reset at each procdef
!global [maxparams]symbol paramdefs
!global [maxlocals]symbol localdefs
global int nlocals				!no. of locals that are used, both int/float
global int nparams				!no. of params whether used or not, int and float

global int usedparams			!how many of pregs needed for used incoming params
global int usedxparams			!how many of pxregs needed for used incoming params

global int highreg				!highest D-reg used
global int highxreg				!highest X-reg used
global int bspill, bxspill		!no. to spill
global int bxspilloffset		!base frame offset of bxreg spill area

global byte r10used				!these may be set in pass2 when occupied by params
global byte r11used
global byte r13used

global int maxregvars			!how many locals would qualify for regvars
global int maxxregvars			!how many locals would qualify for xregvars

global int nproccalls			!number of calls including implicit ones (eg. ** and sin)
global int highargs				!max number of args (0-4) of any call
global macro leafproc =	nproccalls=0			!1 if leaf function
global byte localshadow			!1 if local, proc-wide shadow space used for a call

global byte assemused			!1 if assem used

global int passno

