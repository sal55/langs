global fun foo:ichar = "I'm Foo"

