global const maxoperands=16
!global [maxoperands]pclopndrec pstack
global [maxoperands]pcl	   pclopnds
global [maxoperands]pcsrec pclstack

!The following are reset per proc and augmented as it is processed
global [maxoperands]byte pcltempflags		!1 means a temp uses local storage
global [maxoperands]mclopnd pcltempopnds	!store mcl opnd for such a temp

global int noperands						!number of pcl operands, including wide

global macro zz = noperands
global macro yy = noperands-1
global macro xx = noperands-2
global macro ww = noperands-3

global int mstackdepth						!hw stack size (pcl operands, + extra for wide, + padding)

global const u64 invertbytes = 0x0101'0101'0101'0101

global const maxcalldepth=32
global [maxcalldepth]byte callalign		!pending 1-slot alignment for syscalls
global [maxcalldepth]byte callblockret	!1 if fnc returns a block
global [maxcalldepth]u32 callblocksize	!size of any returned block
global [maxcalldepth,4]u32 callargsize	!size of any block pushed in low args
global int ncalldepth

!global symbol currfunc
global symbol blockretname
!global int mstackdepth						!hw stack size (pcl operands, + extra for wide, + padding)
global byte localshadow			!1 if local, proc-wide shadow space used for a call

global byte r10used				!these may be set in pass2 when occupied by params
global byte r11used

global const maxblocktemps=50
global [maxblocktemps]symbol blockdefs
global int nblocktemps

global []int multregs=(r0,r1,r2,r10,r11,r12)
global []int multxregs=(r0,r1,r2,r3,r4,r5)

const maxworkreg = 8
const maxworkxreg = 8

!global u64 baseworkset				!default initial working set program-wide
!global u64 workset					!'1' bits mean available as workreg in this proc
global [maxworkreg]byte workregs		!contains set of work regs eg (r0 r1 r2 ...)
global [maxworkxreg]byte workxregs	!contains set of work xregs eg (xr4 ...)
global u64 regset					!'1' bits mean workreg currently in use
global u64 oldregset				!'1' bits mean workreg currently in use
global u64 usedset					!accumulates '1' bits from regset to show used regs in proc
global u64 regvarset				!'1' means holds a regvar
global u64 pclset					!'1' means reg hold pcl operand

global int nregvars, nxregvars		!how many are available from r9-r3, or xr15-xr8 etc

global const nbaseworkregs = 3		!program-wide minimums
global const nbaseworkxregs = 4

global int nworkregs				!no. of int workregs (base + extra)
global int nworkxregs				!no. of real workregs (base + possible extra)

global [stdnames.bounds]byte ploadopx
global [stdnames.bounds]byte ploadop

proc start=
	for i in ploadop.bounds do ploadop[i]:=m_nop od

	ploadop[tu8]:=ploadop[tu16]:=ploadop[tu32]:=m_movzx
	ploadop[ti8]:=ploadop[ti16]:=ploadop[ti32]:=m_movsx
	ploadop[tr32]:=m_movd
	ploadop[tr64]:=m_movq
	ploadop[tu64]:=ploadop[ti64]:=m_mov
end

global pcl currpcl

global int pmode

global macro ispint(m) = stdint[m]
global macro ispfloat(m) = stdfloat[m]
global macro ispwide(m) = stdwide[m]

