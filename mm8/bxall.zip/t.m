proc main=
	int a,b,c,d,i
	real x,y,z

	a:=b+c*d

end
