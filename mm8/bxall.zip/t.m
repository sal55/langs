record date8=
	i32 d,m
end

record date16=
	i64 d,m
end

proc main=

	date8 dd
	date16 ee

	fred(dd,ee)

end


proc fred(date8 x, date16 y)=
	int a

	a:=x.m
	a:=y.m
end
