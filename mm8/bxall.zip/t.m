record date=
	int d,m,y
end

func F(date dd)date =
	static date ee=(88,99,100)

	println dd.d, dd.m, dd.y
	ee
end

!proc G(date dd) =
!	println dd.d, dd.m, dd.y
!end
!
!func H:date =
!	static date ee=(88,99,100)
!	ee
!end


proc main=
	static date dd=(10,20,30)
	date ee
!
	ee:=F(dd)

!	ee:=H()
!	ee:=H()

!	G(dd)

	println EE.d, ee.m, ee.y

end
