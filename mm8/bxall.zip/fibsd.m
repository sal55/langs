function fibs(int n)int=
	if n<3 then
		1
	else 
		fibs(n-1)+fibs(n-2)
	fi
end

fun fibd(n)=
	if n<3 then
		1
	else 
		fibd(n-1)+fibd(n-2)
	fi
end

proc main=
	const n=40
	int t:=clock()

	fprintln "fibs(#) = #", n, fibs(n)
	println "Time:", clock()-t
	t:=clock()

	fprintln "fibd(#) = #", n, fibd(n)
	println "Time:", clock()-t

end


