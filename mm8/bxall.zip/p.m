!const n = 1'500'000
!const n = 150'000
!const n = 150

proc t(real x)=
	[8]real pol
	real su
!	real mu,pu,su
!	int i,j

!	mu := 10.0
!	pu := 0.0

!	su := 0.0
!	for j:=1 to pol.len do
!		su := x * su + pol[1]
		su := x+pol[1]
!	end
END

proc main=
	t(0.2)
end
