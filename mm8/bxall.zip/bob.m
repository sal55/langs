export proc bob=
	println "BOB",bob
end
