proc xmain=
	INT A,B,C

	A:=B+C
	PRINTLN "MAIN XA"
end

proc start=
	PRINTLN "START XA"
end
