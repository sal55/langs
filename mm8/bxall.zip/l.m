proc main=
	int a,b,c,d
	real x,y,z

fred:
	a:=b

end
