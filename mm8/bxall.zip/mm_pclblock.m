!blockpcl

const dodotchains=1
!const dodotchains=0

INT NNN

const maxnestedloops	= 50

const maxparams=100

const maxswitchrange=500
const maxcases=maxswitchrange

const maxcasedepth=20
[maxcasedepth]unit casestmt
[maxcasedepth]int caseelse
int casedepth

ref[]int sw_labeltable			!set from do-switch
ref[]int sw_valuetable
int sw_lower
int sw_ncases					!1..n for serial switch; 0 for simple
byte sw_defaultseen				!starts at 0, set to 1 when default: seen
int sw_defaultlabel
int sw_breaklabel

int maxreg=0

global symbol pnprocs, pprocname, pprocaddr


global macro getmemmode_m(p) = (p.memmode|p.memmode|p.mode)
macro evallv(p) = evalref(p)
macro evalunitx(p, isref) = (isref|evalref(p)|evalunit(p))
macro evalblock(p) = evalunit(p)

!global proc genpcl=
!!generate pcl code for each function
!	ref procrec pp
!	symbol d
!	int tt:=clock()
!
!	pp:=proclist
!	while pp do
!		d:=pp.def
!		genprocpcl(d)
!!++NPROCS
!!PCLLENGTH+:=D.PCLINFO.LENGTH
!
!		pp:=pp.nextproc
!	od
!
!!CPL =NPROCS
!!CPL =PCLLENGTH
!!CPL real (PCLLENGTH)/nprocs
!!CPL
!
!	pcltime:=clock()-tt
!end
!



global proc evalunit(unit p)=
!p is a single executable unitrec; not a list or const
!should be called via execblock() to executate a code item in a unitrec
	unit a, b, c

	if p=nil then return fi

!CPL "EVALUNIT", JTAGNAMES[P.TAG]


	mmpos:=p.pos

	a:=p.a
	b:=p.b
	c:=p.c

	switch p.tag
	when jconst         then do_const(p)
	when jnull          then
	when jname          then do_name(p)
	when jblock then
		do_block(p)
	when jcall          then
		do_callproc(p, a, b)
	when jreturn        then do_return(p, a)
	when jreturnmult    then do_returnmult(p, a)
	when jassign        then do_assign(p, a, b)
	when jassignms      then do_assignms(a, b)
	when jassignmm      then do_assignmm(a, b)
	when jassignmdrem   then do_assignmdrem(a, b)
	when jto            then do_to(p, a, b)
	when jif            then do_if(p, a, b, c, 0)
	when jforup         then do_for(p, a, b, c, 0)
	when jfordown       then do_for(p, a, b, c, 1)
	when jforall        then do_forall(p, a, b, c, 0)
	when jforallrev     then do_forall(p, a, b, c, 1)
	when jwhile         then do_while(p, a, b, c)
	when jrepeat        then do_repeat(p, a, b)
	when jgoto          then do_goto(a)
	when jlabeldef      then do_labeldef(p)
	when jredo          then do_exit(p, 1)
	when jnext          then do_exit(p, 2)
	when jexit          then do_exit(p, 3)
	when jdo            then do_do(p, a, b)
	when jcase          then do_case(p, a, b, c, 0, 0)
	when jdocase        then do_case(p, a, b, c, 1, 0)
	when jswitch, jdoswitch, jdoswitchu, jdoswitchx then
		do_switch(p, a, b, c)
	when jrecase        then do_recase(p, a)
	when jswap          then do_swap(p, a, b)
	when jselect        then do_select(p, a, b, c, 0)
	when jprint, jprintln then
		do_print(p, a, b)
	when jfprint, jfprintln then
		do_print(p, a, b)
	when jread	        then do_read(p, a)
	when jreadln        then do_readln(a)
	when jstop          then do_stop(p, a)
	when jeval          then
		evalunit(a)
		pc_gen(keval)
		pc_setmode_u(a)

	when jandl          then do_andl(p, a, b)
	when jorl           then do_orl(p, a, b)
	when jcmp           then do_setcc(p, a, b)
	when jcmpchain      then do_setccchain(p, a)

	when jbin           then do_bin(p, a, b)
	when jindex         then do_index(p, a, b)

	when jdotindex      then do_dotindex(p, a, b)
	when jdotslice      then do_dotslice(p, a, b)
	when jdot           then do_dot(p)
	when jptr           then do_ptr(p, a)
	when jaddrof        then evalref(a, b)

	when jconvert       then do_convert(p, a)
	when jtypepun       then do_typepun(p, a)
	when jshorten       then do_shorten(p, a)
	when jtypeconst     then do_typeconst(p)

	when junary         then do_unary(p, a)

	when jnotl          then do_notl(p, a)
	when jistruel       then do_istruel(p, a)
	when jisfalsel      then do_isfalsel(p, a)

	when jincr          then
		if p.pclop in [kincrto, kdecrto] then
			do_incr(p, a)
		else
			do_incrload(p, a)
		fi
!
	when jbinto         then do_binto(p, a, b)
!
	when junaryto       then do_unaryto(p, a)
!
	when jsyscall then
		do_syscall(p, a)

	when jclear         then do_empty(p, a)

	when jslice then
		do_slice(p, a, b)

	else
		GERROR_S("UNSUPPORTED TAG ", JTAGNAMES[P.TAG])
		return
	end switch

!CPL "  EVALUNIT2", JTAGNAMES[P.TAG]
!CPL "EVALU", JTAGNAMES[P.TAG], STRMODE(P.MODE), =P.RESULTFLAG

	if p.mode<>tvoid and not p.resultflag then
!CPL "RESULT CREATED BUT NOT USED"
		case p.tag
		when jassign, jcall, jsyscall then
!CPL "  EVALA"

		else
!CPL "  EVALB"
IF NOT JSOLO[P.TAG] THEN
PRINTUNIT(P)
GERROR(ADDSTR("NOT ALLOWED BY ITSELF:", JTAGNAMES[P.TAG]))
FI

			pc_gen(kunload)
			pc_setmode_u(p)
		esac
	fi
!CPL "  EVALUNIT3", JTAGNAMES[P.TAG]

end

proc evalref(unit p, q=nil)=
	unit a, b, c
	a:=p.a
	b:=p.b
	c:=p.c
	mmpos:=p.pos

	case p.tag
	when jname then
		genpushmemaddr_d(p.def)
		pc_setmode(tu64)
		if q then					!addrof may have optional byte offset
			genpushint(q.value)
			pc_genix(kaddpx)
			pc_setmode(tu8)
		fi

	when jindex then
		do_indexref(a, b)

	when jdot then
		do_dotref(p)

	when jptr then
		evalunit(p.a)

	else
		case p.tag
		when jif then
			do_if(p, a, b, c, 1)
!		when jselect then
!			do_select(p, a, b, c, 1)
!		when jswitch then
!			do_switch(p, a, b, c, 1)
!		when jcase then
!			do_case(p, a, b, c, 0, 1)
!		elsif ttisblock[p.mode] then
!			evalunit(p)

		else
			PRINTUNIT(P)
			gerror("evalref")
		esac
	esac
end

proc evalarray(unit p)=
	case ttbasetype[p.mode]
	when tslice then
		evalref(p)
		pc_gen(kiload)
		pc_setmode(tu64)
	elsif p.mode=trefchar then
		evalunit(p)
	else
		evalref(p)
	esac

end

proc do_block(unit p)=
	unit a:=p.a

	while a do
		evalunit(a)
		a:=a.nextunit
	od
end

proc genjumpcond(int opc, unit p, int lab)=
!p is some conditional expression of arbitrary complexity
!opc is kjumpf or kjumpt
!evaluate and generate jumps as needed
	unit q, r, s
	int lab2, i

	q:=p.a
	r:=p.b

	case p.tag
	when jandl then
		case opc
		when kjumpf then
			genjumpcond(kjumpf, q, lab)
			genjumpcond(kjumpf, r, lab)
		when kjumpt then
			lab2:=createfwdlabel()
			genjumpcond(kjumpf, q, lab2)
			genjumpcond(kjumpt, r, lab)
			definefwdlabel(lab2)
		esac

	when jorl then
		case opc
		when kjumpf then
			lab2:=createfwdlabel()
			genjumpcond(kjumpt, q, lab2)
			genjumpcond(kjumpf, r, lab)
			definefwdlabel(lab2)
		when kjumpt then
			genjumpcond(kjumpt, q, lab)
			genjumpcond(kjumpt, r, lab)
		esac

	when jnotl, jisfalsel then
		case opc
		when kjumpf then
			genjumpcond(kjumpt, q, lab)
		when kjumpt then
			genjumpcond(kjumpf, q, lab)
		esac

	when jistruel then
		genjumpcond(opc, q, lab)

	when jblock then
		while q and q.nextunit do
			evalunit(q)
			q:=q.nextunit
		od
		genjumpcond(opc, q, lab)

	when jcmp then

		gcomparejump(opc, p.condcode, q, r, lab)

	when jinrange then
		evalunit(q)

		if opc=kjumpt then
			lab2:=createfwdlabel()
			evalunit(r.a)
			pc_gencond(kjumpcc, lt_cc, pgenlabel(lab2))
			pc_setmode_u(q)
			pccurr.popone:=1
			evalunit(r.b)
			pc_gencond(kjumpcc, le_cc, pgenlabel(lab))
			pc_setmode_u(q)
			definefwdlabel(lab2)
		else
			evalunit(r.a)
			pc_gencond(kjumpcc, lt_cc, pgenlabel(lab))
			pc_setmode_u(q)
			pccurr.popone:=1
			evalunit(r.b)
			pc_gencond(kjumpcc, gt_cc, pgenlabel(lab))
			pc_setmode_u(q)
		fi

	when jinset then
		s:=r.a
		if s=nil then
			gerror("empty set")
		fi

		if opc=kjumpf then
			lab2:=createfwdlabel()
			evalunit(q)

			while s do
				evalunit(s)
				s:=s.nextunit
				if s then
					pc_gencond(kjumpcc, eq_cc, pgenlabel(lab2))
					pccurr.popone:=1
				else
					pc_gencond(kjumpcc, ne_cc, pgenlabel(lab))
				fi
				pc_setmode_u(q)
			od
			definefwdlabel(lab2)
		else
			evalunit(q)

			while s, s:=s.nextunit do
				evalunit(s)
				pc_gencond(kjumpcc, eq_cc, pgenlabel(lab))
				pc_setmode_u(q)
				if s.nextunit then pccurr.popone:=1 fi
			od
		fi

	when jcmpchain then
		r:=q.nextunit
		i:=1
		evalunit(q)
		if opc=kjumpf then
			while r do
				evalunit(r)
				if r.nextunit then
					pc_genxy(kswapstk, 1, 2)

					pc_gencond(kjumpcc, reversecond_order(reversecond(p.cmpgenop[i])), pgenlabel(lab))

					pccurr.popone:=1
				else
					pc_gencond(kjumpcc, reversecond(p.cmpgenop[i]), pgenlabel(lab))
				fi

				pc_setmode_u(q)
				++i
				q:=r
				r:=r.nextunit
			od
		
		else
			lab2:=createfwdlabel()
			while r do
				evalunit(r)
				if r.nextunit then
					pc_genxy(kswapstk, 1, 2)
					pc_gencond(kjumpcc, reversecond_order(reversecond(p.cmpgenop[i])), pgenlabel(lab2))
					pccurr.popone:=1
				else
					pc_gencond(kjumpcc, p.cmpgenop[i], pgenlabel(lab))
				fi
				pc_setmode_u(q)
				++i
				q:=r
				r:=r.nextunit
			od
			definefwdlabel(lab2)
		fi
	else			!other, single expression
		evalunit(p)
		pc_gen(opc, pgenlabel(lab))
		if ttisblock[p.mode] then gerror("jumpt/f") fi
		pc_setmode(p.mode)
	end
end

proc gcomparejump(int jumpopc, int cond, unit lhs, rhs, int lab)=
!jumpopc is the base cmdcode needed: kjumpt or kjumpt
!p is the eq/compare unit
!convert into jumpcc cmdcode
	if jumpopc=kjumpf then			!need to reverse condition
		cond:=reversecond(cond)		!eqop => neop, etc
	fi

	evalunit(lhs)
	evalunit(rhs)

	pc_gencond(kjumpcc, cond, pgenlabel(lab))
	pc_setmode_u(lhs)
end

proc genjumpl(int lab)=
!generate unconditional jump to label
	pc_gen(kjump, pgenlabel(lab))
end

proc unimpl(ichar mess)=
	gerror_s("Unimplemented: #", mess)
end

proc do_const(unit p) =
	int mode:=p.mode

	if ttisinteger[mode] or mode=tbool then
		genpushint(p.value)
	elsif ttisreal[mode] then
		genpushreal(p.xvalue, getpclmode(mode))

	elsif ttisref[mode] then
		if p.isastring then
!CPL "doconst/CONST3", P.SVALUE, p.strtype
if p.strtype='B' then gerror("1:B-str?") fi

			genpushstring(p.svalue)
		else
			genpushint(p.value)
		fi
	else
		gerror("do_const")
	fi
	pc_setmode(mode)
end

proc do_name(unit p)=
	symbol d

	d:=p.def
	case d.nameid
	when procid, dllprocid then
		genpushmemaddr_d(d)
		pc_setmode(tu64)
	when labelid then
		if d.index=0 then
			d.index:=++mlabelno
		fi
		if p.resultflag then		!get label address
			pc_gen(kload, pgenlabel(d.index))
			pc_setmode(tu64)
		else
			pc_gen(kjump, pgenlabel(d.index))
			p.mode:=tvoid
			p.resultflag:=0
		fi

	when fieldid then
		genpushint(d.offset)
		pc_setmode(ti64)

	else
		genpushmem_d(d)
		pc_setmode(d.mode)

	esac
end

proc do_stop(unit p, a) =
	if a then
		evalunit(a)
	else
		pc_gen(kload, pgenint(0))
		pc_setmode(ti64)
	fi
	pc_gen(kstop)
end

proc do_andl(unit p, a, b) =
	int labfalse, labend

	pc_gen(kstartmx)

	labfalse:=createfwdlabel()
	labend:=createfwdlabel()

	genjumpcond(kjumpf, a, labfalse)
	genjumpcond(kjumpf, b, labfalse)

	genpushint(1)
	pc_gen(kresetmx)
	pc_setmode(ti64)

	genjumpl(labend)

	definefwdlabel(labfalse)
	genpushint(0)
	pc_gen(kendmx)
	pc_setmode(ti64)

	definefwdlabel(labend)
end

proc do_orl(unit p, a, b) =
	int labtrue, labfalse, labend

	pc_gen(kstartmx)
	labtrue:=createfwdlabel()
	labfalse:=createfwdlabel()
	labend:=createfwdlabel()

	genjumpcond(kjumpt, a, labtrue)
	genjumpcond(kjumpf, b, labfalse)

	definefwdlabel(labtrue)
	genpushint(1)
	pc_gen(kresetmx)
	pc_setmode(ti64)
	genjumpl(labend)

	definefwdlabel(labfalse)
	genpushint(0)
	pc_gen(kendmx)
	pc_setmode(ti64)

	definefwdlabel(labend)
end

proc do_notl(unit p, a) =
	evalunit(a)
	pc_gen(p.pclop)
	pc_setmode(ti64)
end

proc do_istruel(unit p, a) =
	evalunit(a)
!	if a.mode=tbool then
!		return
!	fi
	pc_gen(ktoboolt)
	pc_setmode_u(p)
	pc_setmode2(a.mode)
end

proc do_isfalsel(unit p, a) =
	evalunit(a)
!	if a.mode=tbool then
!		return
!	fi
	pc_gen(ktoboolf)
	pc_setmode_u(p)
	pc_setmode2(a.mode)
end

proc do_typepun(unit p, a) =
	evalunit(a)

	if a.tag=jname then
		a.def.addrof:=1
	fi

	if a.mode=p.mode then return fi
	pc_gen(ktypepun)
	pc_setmode(p.oldmode)
	pc_setmode2(a.mode)
end

proc do_shorten(unit p, a) =
	evalunit(a)
end

proc do_assign(unit p, a, b) =
!fstore=1 when result is needed

!cpl "ASSIGN", B.RESULTFLAG
!PRINTUNIT(P)

	if a.tag=jname and not a.def.used then
		RETURN
	FI

	case b.tag
	when jmakelist then					!a:=(x, y, z)
		if not p.resultflag then
			do_assignblock(p, a, b)		!(avoids pushing/popping block data)
			return
		fi

!	when jslice then					!a:=b[i..j] etc
!		if a.tag=jname then
!			doslice(b, b.a, b.b, a.def, p.resultflag)
!			return
!		fi
	esac

	case a.tag
	when jindex then
		do_storeindex(p, a.a, a.b, b)
		return
	when jslice then
GERROR("ASS/SLICE")

	when jdot then
		do_storedot(a, a.b, b)
		return
	esac

	evalunit(b)
	if p.resultflag then
		pc_gen(kdouble)
	fi

	case a.tag
	when jname then
		if a.def.nameid in [procid, dllprocid, labelid] then GERROR("Assign to proc?") fi

		pc_gen(kstore, genmem_u(a))

	when jptr then
		evalref(a)
		pc_gen(kistore)
		pc_setmode_u(a)

	when jdotindex then
		evalref(a.a)
		evalunit(a.b)
		pc_gen(kstorebit)
		pc_setmode_u(a.a)
		return
	when jdotslice then
		evalref(a.a)
		evalunit(a.b.a)
		evalunit(a.b.b)
		pc_gen(kstorebf)
		pc_setmode_u(a.a)
		return

	when jif then
		do_if(a, a.a, a.b, a.c, 1)
		pc_gen(kistore)
		pc_setmode_u(a)


	else
		cpl jtagnames[a.tag]
		gerror("Can't assign")
	esac

	pc_setmode_u(a)
end

proc do_bin(unit p, a, b) =
	evalunit(a)
	evalunit(b)

	if p.pclop in [kaddpx, ksubpx] then
		pc_genix(p.pclop, ttsize[tttarget[a.mode]])
	else
		pc_gen(p.pclop)
		if p.pclop=ksubp then
			pc_setscaleoff(ttsize[tttarget[a.mode]])
		fi
	fi

	pc_setmode_u(p)
end

proc do_setcc(unit p, a, b) =
	evalunit(a)
	evalunit(b)
	pc_gencond(ksetcc, p.condcode)
	pc_setmode_u(a)
end

proc do_setccchain(unit p, q) =
	int lab1, lab2, i, cond
	unit r

	lab1:=createfwdlabel()
	lab2:=createfwdlabel()

	r:=q.nextunit
	i:=1

	pc_gen(kstartmx)

	evalunit(q)
	while r do
		evalunit(r)
		cond:=reversecond(p.cmpgenop[i])
		if r.nextunit then
			pc_genxy(kswapstk, 1, 2)
			cond:=reversecond_order(cond)
		fi

		pc_gencond(kjumpcc, cond, pgenlabel(lab1))
		if r.nextunit then pccurr.popone:=1 fi

		pc_setmode_u(q)
		++i
		q:=r
		r:=r.nextunit
	od

	genpushint(1)
	pc_gen(kresetmx)
	pc_setmode(ti64)
	pc_gen(kjump, pgenlabel(lab2))

	definefwdlabel(lab1)
	genpushint(0)
	pc_gen(kendmx)
	pc_setmode(ti64)
	definefwdlabel(lab2)
end

proc do_binto(unit p, a, b)=
	evalunit(b)
	evallv(a)
	do_setinplace()

	pc_gen(getto_op(p.pclop))
	pc_setmode_u(a)

	if ttisref[a.mode] and ttisinteger[b.mode] then
		pc_setscaleoff(ttsize[tttarget[a.mode]])
	fi
end

proc do_unary(unit p, a) =
	int adj
!
	if ttbasetype[a.mode]=tslice then
		evalref(a)
		case p.propcode
		when kklen, kkupb then
			genpushint(8)
			pc_genix(kiloadx, 1, 0)
			pc_setmode(ti64)
			if p.propcode=kkupb then
				adj:=ttlower[a.mode]-1
				if adj then
					genpushint(adj)
					pc_gen(kadd)
					pc_setmode(ti64)
				fi
			fi

		when kksliceptr then
			pc_gen(kiload)
			pc_setmode(tu64)

		esac

		return
	fi

	evalunit(a)
	pc_gen(p.pclop)
	pc_setmode_u(a)
end

proc do_unaryto(unit p, a)=
	evallv(a)
	do_setinplace()

	pc_gen(getto_op(p.pclop))
	pc_setmode_u(a)
end

func getto_op(int opc)int=
	static [,2]byte table = (
	(kadd,       kaddto),
	(ksub,       ksubto),
	(kmul,       kmulto),
	(kdiv,       kdivto),
	(kidiv,      kidivto),
	(kirem,      kiremto),
	(kbitand,    kbitandto),
	(kbitor,     kbitorto),
	(kbitxor,    kbitxorto),
	(kshl,       kshlto),
	(kshr,       kshrto),
	(kmin,       kminto),
	(kmax,       kmaxto),
	(kaddpx,     kaddpxto),
	(ksubpx,     ksubpxto),

	(kneg,       knegto),
	(kabs,       kabsto),
	(kbitnot,    kbitnotto),
	(knot,       knotto))
!	(ktobool,    ktoboolto))

	for i to table.len do
		if opc=table[i,1] then
			return table[i,2]
		fi
	od

	gerror("No -to op")
	0
end


proc do_ptr(unit p, a)=
	evalunit(a)
	pc_gen(kiload)
	pc_setmode_u(p)
end

proc do_labeldef(unit p)=
	symbol d
	[256]char str

	d:=p.def
	if d.index=0 then
		d.index:=++mlabelno
	fi

	pc_gen(klabeldef, genmemaddr_d(d))

	pc_gen(klabel, pgenlabel(d.index))
end

proc do_goto(unit a)=
	symbol d

	if a.tag=jname and a.def.nameid=labelid then
		d:=a.def
		if d.index=0 then
			d.index:=++mlabelno
		fi
		pc_gen(kjump, pgenlabel(d.index))
	else
		evalunit(a)
		pc_gen(kijump)
	fi
end

proc do_do(unit p, a, b) =
	int lab_abc, lab_d

	lab_abc:=definelabel()
	lab_d:=createfwdlabel()

	stacklooplabels(lab_abc, lab_abc, lab_d)

	evalblock(a)

	genjumpl(lab_abc)
	definefwdlabel(lab_d)
	--loopindex
end

proc do_to(unit p, a, b) =
	unit cvar
	int lab_b, lab_c, lab_d, count

	cvar:=p.c

	a.mode:=ti64

	evalunit(a)
	pc_gen(kstore, genmem_u(cvar))
	pc_setmode(ti64)

	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()
	stacklooplabels(lab_b, lab_c, lab_d)

!check for count being nonzero
	if a.tag<>jconst then			!assume const limit is non-zero
		evalunit(cvar)
		evalunit(pzero)

		pc_gencond(kjumpcc, le_cc, pgenlabel(lab_d))
		pc_setmode(ti64)

	else
		count:=a.value
		if count<=0 then
			genjumpl(lab_d)
		fi
	fi

	definefwdlabel(lab_b)
	evalblock(b)			!main body

	definefwdlabel(lab_c)

	pc_gen(kto, pgenlabel(lab_b))
	pc_setmode(ti64)
	pc_gen(kopnd, genmem_u(cvar))
	pc_setmode(ti64)

	definefwdlabel(lab_d)
	--loopindex
end

proc do_while(unit p, pcond, pbody, pincr) =
	int lab_b, lab_c, lab_d, lab_incr

	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()

	if pincr then
		lab_incr:=createfwdlabel()
	else
		lab_incr:=lab_c
	fi

	stacklooplabels(lab_b, lab_c, lab_d)

	genjumpl(lab_incr)		!direct to condition code which is at the end

	definefwdlabel(lab_b)

	evalblock(pbody)

	definefwdlabel(lab_c)

	if pincr then
		evalblock(pincr)
		definefwdlabel(lab_incr)
	fi

	docond(kjumpt, pcond, lab_b)
	definefwdlabel(lab_d)
	--loopindex
end

proc do_repeat(unit p, a, b) =
	int lab_ab, lab_c, lab_d

	lab_ab:=definelabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()

	stacklooplabels(lab_ab, lab_c, lab_d)

	evalblock(a)

	definefwdlabel(lab_c)

	unless b.tag=jconst and b.value=0 then
		docond(kjumpf, b, lab_ab)
	end

	definefwdlabel(lab_d)
	--loopindex
end

proc do_exit(unit p, int k) =
	int n, index

	index:=p.loopindex
	if index=0 then index:=loopindex fi

	n:=findlooplabel(k, index)
	if n=0 then
		gerror("Bad exit/loop index", p)
	else
		genjumpl(n)
	fi
end

proc do_if(unit p, pcond, plist, pelse, int isref) =
	int labend, i, lab2, ismult

	labend:=createfwdlabel()
	ismult:=p.mode<>tvoid

	i:=0
	if ismult then pc_gen(kstartmx) fi

	while pcond, (pcond:=pcond.nextunit; plist:=plist.nextunit) do
		++i
		lab2:=createfwdlabel()

		docond(kjumpf, pcond, lab2)

		evalunitx(plist, isref)
		if ismult then pc_gen(kresetmx); pc_setmode_u(p) fi

		if pcond.nextunit or pelse then
			genjumpl(labend)
		fi
		definefwdlabel(lab2)
	od

	if pelse then
		evalunitx(pelse, isref)
		if ismult then pc_gen(kendmx); pc_setmode_u(p) fi
	fi
	definefwdlabel(labend)
end

proc do_return(unit p, a) =
	if a then
		evalunit(a)

		pc_gen(kjumpret, pgenlabel(retindex))
		pc_setmode_u(a)
	else
		genjumpl(retindex)
	fi
end

proc do_returnmult(unit p, a) =
	[maxparams]unit params
	unit q
	int nparams

	q:=a
	nparams:=0
	while q do
		if nparams>=maxparams then gerror("Mult?") fi
		params[++nparams]:=q
		q:=q.nextunit
	od

	for i:=nparams downto 1 do
		evalunit(params[i])
	od

!need individual setret codes (not sure about the order)
	pc_gen(kjumpretm, pgenlabel(retindex))
	pc_setnargs(nparams)
	p.resultflag:=1
end

proc do_callproc(unit p, a, b) =
	[maxparams]unit paramlist
	[maxparams]i8 argattr
	int nparams, isptr, nvariadics, nret, isfn
	int iparams, fparams
	int nfixedparams
	symbol d, e
	ref[]i32 pmult
	unit q

	isptr:=0
!	isfn:=p.tag=jcallfn


	case a.tag
	when jname then
		d:=a.def

	when jptr then
		d:=ttnamedef[a.mode]
		isptr:=1
	else
		gerror("call/not ptr")
	esac

	isfn:=d.mode<>tvoid

	nparams:=0
	nvariadics:=0

	q:=b
	nfixedparams:=0
	e:=d.deflist
	while e, e:=e.nextdef do
		if e.nameid=paramid then ++nfixedparams fi
	od

	q:=b
	while q, q:=q.nextunit do
		if nparams>=maxparams then gerror("maxparams") fi
		paramlist[++nparams]:=q

		if d.varparams and nparams>=nfixedparams and nparams<=4 and nvariadics=0 then
			nvariadics:=nparams
		fi
	od

	pc_gen(ksetcall)
	pc_setmode_u(p)
	pccurr.nargs:=nparams

	iparams:=fparams:=0

	for i to nparams do
		q:=paramlist[i]
		argattr[i]:=0
		if q.mode in [tr32, tr64] then
			if ++fparams>8 then argattr[i]:=2 fi
		else
			if ++iparams>8 then argattr[i]:=2 fi
		fi
	od

	if fparams>8 and iparams>8 then
		gerror("Mixed stack args")
	fi
	iparams:=max(fparams, iparams)-8		!no. of stack args

	for i:=nparams downto 1 do
		if iparams.odd and argattr[i] then
			argattr[i]:=1					!change first/rightmost '2' to '1'
			iparams:=0
		fi
		q:=paramlist[i]
		evalunit(q)

		if nvariadics and i>=nvariadics and pccurr.mode=tr32 then
			pc_gen(kfwiden)
			pccurr.size:=8
			pccurr.mode:=tr64
			pccurr.mode2:=tr32

			pc_gen(ksetarg)
			pc_setmode(tr64)
		else
			pc_gen(ksetarg)
			pc_setmode_u(q)
		fi

		pccurr.x:=i
		pccurr.y:=argattr[i]
	od

	if not isptr then
		pc_gen((isfn|kcallf|kcallp), genmemaddr_d(d))
	else
		evalunit(a.a)
		pc_gen((isfn|kicallf|kicallp))
	fi

	pccurr.nargs:=nparams
    pccurr.nvariadics:=nvariadics

	if isfn then
		pc_setmode_u(p)
	fi

	if d.nretvalues>1 and isfn then
		nret:=d.nretvalues
		pmult:=ttmult[d.mode]

		for i to nret do
			pc_gen(ktype)
			pc_setmode(pmult[i])
		od
	fi

	if isfn and not p.resultflag then
		pc_gen(kunload)
		pc_setmode_u(p)
	fi

end

proc do_print(unit p, a, b) =
	unit q, r, fmt
	int m, fn, needprintend

	if a then
		needprintend:=1
		if ttbasetype[a.mode]<>tref then gerror("@dev no ref") fi
		case ttbasetype[tttarget[a.mode]]
		when tvoid then
			genpc_sysproc(sf_print_startfile, a)
		when tc8 then
			genpc_sysproc(sf_print_startstr, a)
		when tref then
			genpc_sysproc(sf_print_startptr, a)
		else
			gerror("@dev?")
		esac
	else
		needprintend:=1
		genpc_sysproc(sf_print_startcon)
	fi

	q:=b

	case p.tag
	when jfprint, jfprintln then
		if ttbasetype[q.mode]<>tref or ttbasetype[tttarget[q.mode]]<>tc8 then
			gerror("string expected")
		fi
		genpc_sysproc(sf_print_setfmt, q)
		q:=p.c
	esac

	while q do
		case q.tag
		when jfmtitem then
			fmt:=q.b
			r:=q.a
			m:=r.mode
		when jnogap then
			genpc_sysproc(sf_print_nogap)
			q:=q.nextunit
			nextloop
		when jspace then
			genpc_sysproc(sf_print_space)
			q:=q.nextunit
			nextloop
		else
			fmt:=nil
			r:=q
			m:=q.mode
		esac

		case ttbasetype[m]
		when ti64 then
			fn:=sf_print_i64
			if not fmt then fn:=sf_print_i64_nf fi
		when tu64 then
			fn:=sf_print_u64
		when tr32 then
			fn:=sf_print_r32
		when tr64 then
			fn:=sf_print_r64
		when tref then
			if tttarget[m]=tc8 or tttarget[m]=tarray and tttarget[tttarget[m]]=tc8 then
				fn:=sf_print_str
				if not fmt then fn:=sf_print_str_nf fi
			else
				fn:=sf_print_ptr
				if not fmt then fn:=sf_print_ptr_nf fi
			fi
		when tbool then
			fn:=sf_print_bool
		when tarray then
			GERROR("PRINTARRAY")
			q:=q.nextunit
		when trecord then
			GERROR("PRINTRECORD")
		when tslice then
			if tttarget[m]=tc8 then
				fn:=sf_print_strsl
			else
				gerror("PRINTSLICE")
			fi

		when tc64 then
			fn:=sf_print_c8

		else
			PRINTLN STRMODE(M), STRMODE(TTBASETYPE[M])
			gerror_s("PRINT/T=#", strmode(m))
		esac

		case fn
		when sf_print_i64_nf, sf_print_str_nf, sf_print_ptr_nf then
			genpc_sysproc(fn, r)
		else
			genpc_sysproc(fn, r, (fmt|fmt|pzero))
		esac

		q:=q.nextunit
	od

	case p.tag
	when jprintln, jfprintln then
		genpc_sysproc(sf_print_newline)
	esac
	if needprintend then
		genpc_sysproc(sf_print_end)
	fi
end

proc do_incr(unit p, a) =
	evallv(a)
	do_setinplace()
	pc_gen(p.pclop)
	pc_setmode_u(a)
	setincrstep(a.mode)
end

proc setincrstep(int m)=
	pccurr.stepx:=m

	if ttisref[m] then
		pccurr.stepx:=ttsize[tttarget[m]]
	fi
end

proc do_incrload(unit p, a) =
	evallv(a)
	do_setinplace()
	pc_gen(p.pclop)
	pc_setmode_u(a)
	setincrstep(a.mode)
end

proc do_for(unit p, pindex, pfrom, pbody, int down) =
!Structure:
!	Forup/to
!		pindex -> [ptoinit]
!		pfrom -> pto -> [pstep]
!		pbody -> [pelse]
!When pto is complex, then pto refers to an AV variable, and ptoinit contains code
!to evaluate the complex pto, and assign it to that AV

	unit pto, pstep, pelse, px, ptoinit
	int lab_b, lab_c, lab_d, lab_e
	int a, b, stepx

	pto:=pfrom.nextunit
	pstep:=pto.nextunit
	pelse:=pbody.nextunit
	ptoinit:=pindex.nextunit

	if pto.tag=jptr then
		px:=pto.a
		symbol d
		if px.tag=jname and (d:=px.def).nameid=paramid and
			 d.byref then
			gerror("Possibly using &param as for-loop limit")
		fi
	fi

	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()

	if pelse then
		lab_e:=createfwdlabel()
	else
		lab_e:=lab_d
	fi

	stacklooplabels(lab_b, lab_c, lab_d)

!now start generating code
	evalunit(pfrom)
	pc_gen(kstore, genmem_u(pindex))
	pc_setmode_u(pindex)

	if ptoinit then			!using temp for limit
		ptoinit.resultflag:=0
		evalunit(ptoinit)
	fi

	if pfrom.tag=jconst and pto.tag=jconst then
		a:=pfrom.value
		b:=pto.value
		if (down and a>=b) or (not down and a<=b) then	!in range
		else							!loop not executed
			pc_gen(kjump, pgenlabel(lab_e))
		fi
	else
		if pfrom.tag=jconst then				!reverse condition; compare mem:imm
			evalunit(pto)
			evalunit(pfrom)
			pc_gencond(kjumpcc, (down|gt_cc|lt_cc), pgenlabel(lab_e))
		else
			evalunit(pindex)
			evalunit(pto)
			pc_gencond(kjumpcc, (down|lt_cc|gt_cc), pgenlabel(lab_e))
		fi
		pc_setmode_u(pindex)
	fi

	definefwdlabel(lab_b)

	evalblock(pbody)				!do loop body

	definefwdlabel(lab_c)

	if pstep then
		if pstep.tag<>jconst then
			gerror("for/step non-const not ready")
		fi
		stepx:=pstep.value
		if stepx<=0 then
			gerror("Bad for-step")
		fi
		pc_genx((down|kfordown|kforup), stepx, pgenlabel(lab_b))
		pc_setmode_u(pindex)
	else
		pc_genx((down|kfordown|kforup), 1, pgenlabel(lab_b))
		pc_setmode_u(pindex)
	fi

	pc_gen(kopnd, genmem_u(pindex))
	pc_setmode(ti64)

	case pto.tag
	when jconst then
		pc_gen(kopnd, pgenint(pto.value))
		pc_setmode(ti64)
	when jname then
		pc_gen(kopnd, genmem_u(pto))
		pc_setmode(ti64)
	esac

	if pelse then
		definefwdlabel(lab_e)
		evalblock(pelse)
	fi

	definefwdlabel(lab_d)
	--loopindex
end

proc do_forall(unit p, pindex, plist, pbody, int down) =
!Structure:
!	forall
!		pindex -> plocal -> pfrom -> pto
!		plist -> passign
!		pbody -> [pelse]

	unit plocal, pfrom, pto, pelse, passign
	int lab_b, lab_c, lab_d, lab_e
	int a, b
	symbol dto

	plocal:=pindex.nextunit
	pfrom:=plocal.nextunit
	pto:=pfrom.nextunit
	passign:=plist.nextunit
	pelse:=pbody.nextunit

	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()

	if pelse then
		lab_e:=createfwdlabel()
	else
		lab_e:=lab_d
	fi

	stacklooplabels(lab_b, lab_c, lab_d)

!now start generating code

	evalunit(pfrom)
	pc_gen(kstore, genmem_u(pindex))
	pc_setmode_u(pindex)

	if pto.tag not in [jconst, jname] then
		evalunit(pto)
		dto:=getavname(currproc)
		pc_gen(kstore, genmem_d(dto))
		pc_setmode(ti64)
		pto:=createname(dto)
		pto.mode:=dto.mode
		pto.resultflag:=1
	fi

	if pfrom.tag=jconst and pto.tag=jconst then
		a:=pfrom.value
		b:=pto.value
		if (down and a>=b) or (not down and a<=b) then	!in range
		else							!loop not executed
			pc_gen(kjump, pgenlabel(lab_e))
		fi
	else
		if pfrom.tag=jconst then				!reverse condition; compare mem:imm
			evalunit(pto)
			evalunit(pfrom)
			pc_gencond(kjumpcc, (down|gt_cc|lt_cc), pgenlabel(lab_e))
		else
			evalunit(pfrom)
			evalunit(pto)
			pc_gencond(kjumpcc, (down|lt_cc|gt_cc), pgenlabel(lab_e))
		fi
		pc_setmode_u(pindex)
	fi

	definefwdlabel(lab_b)

!need to generate assignment to local
	passign.resultflag:=0
	evalunit(passign)

	evalblock(pbody)				!do loop body

	definefwdlabel(lab_c)

	pc_genx((down|kfordown|kforup), 1, pgenlabel(lab_b))
	pc_setmode_u(pindex)

	pc_gen(kopnd, genmem_u(pindex))
	pc_setmode(ti64)
	case pto.tag
	when jconst then
		pc_gen(kopnd, pgenint(pto.value))
	when jname then
		pc_gen(kopnd, genmem_u(pto))
	else
		PC_GEN(KOPND, GENMEM_D(DTO))
!		gerror("forall/to: not const or name")
	esac
	pc_setmode(ti64)

	if pelse then
		definefwdlabel(lab_e)
		evalblock(pelse)
	fi

	definefwdlabel(lab_d)
	--loopindex
end

proc do_convert(unit p, a) =

	case p.convcode
	when kksoftconv then
		evalunit(a)
		return
	when kkerror then
		gerror("CONV/ERROR")

	else
		evalunit(a)
		pc_gen(convtopcl[p.convcode])
	esac
	pc_setmode_u(p)

	pc_setmode2(p.oldmode)
end

proc do_swap(unit p, a, b) =
	evallv(a)
	do_setinplace()
	evallv(b)
	do_setinplace()
	pc_gen(kiswap)
	pc_setmode_u(a)
end

global func checkdotchain(unit p, &pname)int=
!return accumulated offset of this and nested dot-expressions, 
!or -1 when offsets cannot be combined
	int offset

	case p.tag
	when jdot then
		offset:=checkdotchain(p.a, pname)
		return p.offset+offset

	else							!anything else, is the start expression
		pname:=p
		return 0
	esac
	return 0
end

proc do_dotref(unit pdot) =
	int imode:=createrefmode(nil, pdot.mode, 0)
	int offset
	unit a, pname


	a:=pdot.a

	if dodotchains then
		pname:=nil
		offset:=checkdotchain(a, pname)
		offset+:=pdot.offset
		a:=pname
	else
		offset:=pdot.offset
	fi

	evalref(a)

	if offset then
		genpushint(offset)
		pc_genix(kaddpx)
	fi
	pc_setmode(imode)
end

proc do_dot(unit pdot) =
	int offset
	unit a, pname

	a:=pdot.a

	if dodotchains then
		pname:=nil
		offset:=checkdotchain(a, pname)
		offset+:=pdot.offset
		a:=pname
	else
		offset:=pdot.offset
	fi

	evalref(a)
	pc_gen(kload, pgenint(offset))
	pc_setmode(ti64)

	pc_genix(kiloadx, 1)
	pc_setmode_u(pdot)
end

proc do_storedot(unit pdot, pfield, rhs) =
	int offset
	unit a, pname

	evalunit(rhs)
	if pdot.resultflag then
		pc_gen(kdouble)
	fi

	a:=pdot.a

	if dodotchains then
		pname:=nil
		offset:=checkdotchain(a, pname)
		offset+:=pdot.offset
		a:=pname
	else
		offset:=pdot.offset
	fi

	evalref(a)
	pc_gen(kload, pgenint(offset))
	pc_setmode(ti64)

	pc_genix(kistorex, 1)

	pc_setmode_u(pdot)
end

proc do_index(unit p, parray, pindex) =
	int addoffset, scale, offset


!GENCOMMENT("INDEX/ILOADNEXT/block")
!	if ttisblock[p.mode] then
!CPL "INDEX/BLOCK"
!		do_indexref(parray, pindex)
!
!		return
!	fi

	addoffset:=getindexoffset(parray, pindex)

	evalarray(parray)
	scale:=ttsize[tttarget[parray.mode]]
	offset:=-ttlower[parray.mode]*scale + addoffset*scale

	evalunit(pindex)
!GENCOMMENT("INDEX/ILOADNEXT")

	pc_genix(kiloadx, scale, offset)
	pc_setmode_u(p)
!GENCOMMENT("...INDEX/ILOADNEXT")
end

proc do_storeindex(unit p, parray, pindex, rhs) =
	int addoffset, scale
	addoffset:=getindexoffset(parray, pindex)

	evalunit(rhs)
	if p.resultflag then
		pc_gen(kdouble)
	fi

	evalarray(parray)
	evalunit(pindex)

	scale:=ttsize[tttarget[parray.mode]]
	pc_genix(kistorex, scale, -ttlower[parray.mode]*scale+addoffset*scale)
	pc_setmode_u(p.a)
end

proc do_indexref(unit parray, pindex) =
	int addoffset, scale
	addoffset:=getindexoffset(parray, pindex)

	evalarray(parray)
	evalunit(pindex)

	scale:=ttsize[tttarget[parray.mode]]
	pc_genix(kaddpx, scale, -ttlower[parray.mode]*scale+addoffset*scale)
	pc_setmode(tttarget[parray.mode])
end

func getindexoffset(unit parray, &pindex)int offset=
!convert index like [i+3] to [i], returning the +3 etc as a separate offset
	int addoffset:=0

	if pindex.tag=jbin and pindex.pclop in [kadd, ksub] then
		if pindex.b.tag=jconst then		!incorporate const offset into lwb adjustment
			addoffset:=(pindex.pclop=kadd|pindex.b.value|-pindex.b.value)
			pindex:=pindex.a
		fi
	fi
	return addoffset
end

proc do_switch(unit p, pindex, pwhenthen, pelse, int isref=0) =
!'looptype' is set up here:
! 0 = switch	normal switch (range-checked)
! 1 = doswitch	looping switch (range-checked)
! 2 = doswitchu	looping switch via computed goto/indexed (both non-range-checked)
! 3 = doswitchx	looping switch via computed goto/labels

	const maxlabels = 1000
	int minlab, maxlab, n, iscomplex, i
	int lab_a, lab_d, labjump, elselab, labstmt, ax, bx, ismult, mode
	byte looptype, opc
	[0..maxlabels]pcl labels
	unit w, wt, pjump, pnext
	pcl psetup, pc, px, pw
	symbol djump

	case p.tag
	when jswitch then
		looptype:=0; opc:=kswitch
	when jdoswitch then
dodosw:
		looptype:=1; opc:=kswitch
	when jdoswitchu then
		if ctarget then dodosw fi			
		looptype:=2; opc:=kswitchu
	else
		looptype:=3
	esac

	ismult:=p.mode<>tvoid and looptype=0

	minlab:=1000000
	maxlab:=-1000000		!highest index seen

	n:=0				!no. different values
	iscomplex:=0			!whether complex switch

	wt:=pwhenthen
	while wt do
		w:=wt.a
		while w do		!for each when expression
			case w.tag
			when jmakerange then
				ax:=w.a.value
				bx:=w.b.value
	dorange:
				for i:=ax to bx do
					minlab := min(i, minlab)
					maxlab := max(i, maxlab)
				od
			when jconst then		!assume int
				ax:=bx:=w.value
				goto dorange
			else
				gerror_s("Switch when2: not const: #", strexpr(w).strptr)
			esac
			w:=w.nextunit
		od
		wt:=wt.nextunit
	od

	n:=maxlab-minlab+1
	if n>maxlabels then
		gerror("Switch too big")
	fi

	if looptype then
		lab_a:=definelabel()
		lab_d:=createfwdlabel()
		stacklooplabels(lab_a, lab_a, lab_d)
	else
		lab_d:=createfwdlabel()
	fi

	labjump:=createfwdlabel()
	elselab:=createfwdlabel()

	if ismult then pc_gen(kstartmx) fi

	if looptype=3 then		!need to initialise pointer to JT
		pjump:=pindex.nextunit
		if pjump.tag<>jname then gerror("doswx not name") fi
		djump:=pjump.def
		if ttbasetype[djump.mode]<>tref then gerror("doswx not ref") fi

!these two instrs to be moved to kinitdswx later
!	PC_COMMENT("JT LOAD")
		pw:=pccurr							!last op before the two new ops
		pc_gen(kload, pgenlabel(labjump))
		pc_setmode(tu64)
		px:=pccurr							!px=pw.next = 1st of two ops

		pc_gen(kstore, genmem_u(pjump))
		pc_setmode(tu64)

		if pcldoswx=nil then
			gerror("doswx in main?")
		fi

!Before:  A B PCLDOSWX C D ...  W X Y				!X Y are load/store above
!After:   A B PCLDOSWX X Y D ...  W

		pc:=pcldoswx.next					!point to C
		pcldoswx.next:=px
		px.next.next:=pc
		pw.next:=nil
		pccurr:=pw

	fi

	evalunit(pindex)

	if looptype<>3 then
		pc_genxy(opc, minlab, maxlab, pgenlabel(labjump))
		pc_setmode(ti64)
		if looptype<2 then
			pc_gen(kopnd, pgenlabel(elselab))
			pc_setmode(ti64)						!dummy type (kopnd is general purpose)
		fi
	else
!PC_COMMENT("J1")
		pc_gen(kijump)
		pc_setmode(tu64)
	fi

	definefwdlabel(labjump)

	for i:=minlab to maxlab do			!fill with else labels first
		pc_gen(kswlabel, pgenlabel(elselab))
		labels[i]:=pccurr
	od
!*!	pc_gen(kendsw)


!scan when statements again, o/p statements

	wt:=pwhenthen
	while wt do
		labstmt:=definelabel()
		w:=wt.a
		while w do
			case w.tag
			when jmakerange then
				ax:=w.a.value
				bx:=w.b.value
			when jconst then
					ax:=bx:=int(w.value)
			esac
			for i:=ax to bx do
				labels[i].labelno:=labstmt
			od
			w:=w.nextunit
		od

		evalunitx(wt.b, isref)
		if ismult then pc_gen(kresetmx); pc_setmode_u(p) fi

		case looptype
		when 0 then
			genjumpl(lab_d)
		when 1 then
			genjumpl(lab_a)
		when 2 then
			evalunit(pindex)
			pc_genxy(opc, minlab, maxlab, pgenlabel(labjump))
			pc_setmode(ti64)
		else
			evalunit(pindex)
!PC_COMMENT("J2")
			pc_gen(kijump)
			pc_setmode(tu64)
		esac

		wt:=wt.nextunit
	od

	definefwdlabel(elselab)
	if pelse then
		evalunitx(pelse, isref)
		if ismult then pc_gen(kendmx); pc_setmode_u(p) fi
	fi

	if looptype then
		case looptype
		when 1 then
			genjumpl(lab_a)
		when 2 then
			evalunit(pindex)
			pc_genxy(opc, minlab, maxlab, pgenlabel(labjump))
			pc_setmode(ti64)
		else
			evalunit(pindex)
!PC_COMMENT("J3")
			pc_gen(kijump)
			pc_setmode(tu64)
		esac
		--loopindex
	fi

	definefwdlabel(lab_d)
end

proc do_select(unit p, a, b, c, int isref) =
	const maxlabels=256
	[maxlabels]pcl labels
	int labend, labjump, n, i, elselab, labstmt, ismult
	unit q

	ismult:=p.mode<>tvoid and p.resultflag

	q:=b
	n:=0
	while q do
		if n>=maxlabels then gerror("selectx: too many labels") fi
		++n
		q:=q.nextunit
	od

	labend:=createfwdlabel()
	labjump:=createfwdlabel()
	elselab:=createfwdlabel()

	if ismult then pc_gen(kstartmx) fi
	evalunit(a)

	pc_genxy(kswitch, 1, n, pgenlabel(labjump))
	pc_setmode(ti64)
	pc_gen(kopnd, pgenlabel(elselab))
	pc_setmode(ti64)


	definefwdlabel(labjump)

	q:=b
	i:=0
	for i:=1 to n do
		pc_gen(kswlabel, pgenlabel(elselab))
		labels[i]:=pccurr
	od
!*!	pc_gen(kendsw)

	q:=b
	i:=0
	while q do
		labstmt:=definelabel()
		++i
		labels[i].labelno:=labstmt
		evalunitx(q, isref)
		if ismult then pc_gen(kresetmx); pc_setmode_u(p) fi
		genjumpl(labend)
		q:=q.nextunit
	od

	definefwdlabel(elselab)

	evalunitx(c, isref)
	if ismult then pc_gen(kendmx); pc_setmode_u(p) fi

	definefwdlabel(labend)
end

proc do_case(unit p, pindex, pwhenthen, pelse, int loopsw, isref) =
	const maxcase=500
	[maxcase]int labtable
	[maxcase]unit unittable
	int ncases, ismult, a, b

	int lab_abc, lab_d, labelse
	unit w, wt, plower, pupper

	loopsw:=p.tag=jdocase

	if pindex=nil then
		GERROR("EMPTY CASE NOT DONE")
	fi

	ismult:=p.mode<>tvoid and not loopsw

	if loopsw then
		lab_abc:=definelabel()		!start of loop
		lab_d:=createfwdlabel()	!end of case/end of loop
		stacklooplabels(lab_abc, lab_abc, lab_d)
	else
		lab_d:=createfwdlabel()	!end of case/end of loop
	fi

	if ismult then pc_gen(kstartmx) fi

	ncases:=0

	if casedepth>=maxcasedepth then
		gerror("case nested too deeply")
	fi
	casestmt[++casedepth]:=p

	if pwhenthen=nil then
		if ismult then gerror("case") fi
		goto skip
	fi

	evalunit(pindex)

!CPL "INCR CASED", CASEDEPTH

	wt:=pwhenthen

	while wt do
		w:=wt.a
		if ncases>=maxcase then
			gerror("too many cases")
		fi
		labtable[++ncases]:=createfwdlabel()
		unittable[ncases]:=wt.b

		while w do
!			if w.nextunit or wt.nextunit then pc_gen(kdouble) fi
!			if w.tag=jmakerange then
!				plower:=w.a
!				pupper:=w.b
!				unless plower.tag=pupper.tag=jconst then
!					gerror("case/var-range")
!				end
!
!
!
!GERROR("CASE/RANGE", W)
!			else
				evalunit(w)
!			fi
			pc_gencond(kjumpcc, eq_cc, pgenlabel(w.whenlabel:=labtable[ncases]))
			if w.nextunit or wt.nextunit then
				pccurr.popone:=1
			fi
			pc_setmode_u(w)
			w:=w.nextunit
		od

		wt:=wt.nextunit
	od

skip:
	labelse:=createfwdlabel()
	caseelse[casedepth]:=labelse
	genjumpl(labelse)

	for i:=1 to ncases do
		definefwdlabel(labtable[i])
		evalunitx(unittable[i], isref)
		if ismult then pc_gen(kresetmx); pc_setmode_u(p) fi

		if loopsw then
			genjumpl(lab_abc)
		else
			genjumpl(lab_d)
		fi
	od

	definefwdlabel(labelse)

	if pelse then
		evalunitx(pelse, isref)
		if ismult then pc_gen(kendmx); pc_setmode_u(p) fi
	fi

	if loopsw then
		genjumpl(lab_abc)
		definefwdlabel(lab_d)
		--loopindex
	else
		definefwdlabel(lab_d)
	fi

!IF CASEDEPTH=0 THEN
!GERROR("CASE - DEPTH 0?")
!FI

	--casedepth
!CPL "DECR CASED", CASEDEPTH
end

proc do_dotindex(unit p, a, b) =
	evalunit(a)
	evalunit(b)

	pc_gen(kloadbit)
	pc_setmode(ti64)
end

proc do_dotslice(unit p, a, b) =
	evalunit(a)
	evalunit(b.a)
	evalunit(b.b)

	pc_gen(kloadbf)
	pc_setmode(ti64)
end

proc do_read(unit p, a) =
	int m

	m:=p.mode

	if a=nil then
		a:=pzero
	fi

	if ttisinteger[m] then
		genpc_sysfn(sf_read_i64, a)
	elsif ttisreal[m] and ttsize[m]=8 then
		genpc_sysfn(sf_read_r64, a)
	elsif m=trefchar then
		genpc_sysfn(sf_read_str, a)
	else
CPL =STRMODE(M)
		GERROR("CAN'T READ THIS ITEM")
	fi
	pc_setmode_u(p)
end

proc do_readln(unit a) =
	if a then
		if ttbasetype[a.mode]<>tref then gerror("@dev no ref") fi

		case ttbasetype[tttarget[a.mode]]
		when tvoid then
			genpc_sysproc(sf_read_fileline, a)
		when tu8, tc8 then
			genpc_sysproc(sf_read_strline, a)
		else
			gerror("rd@dev?")
		esac
	else
		genpc_sysproc(sf_read_conline)
	fi
end

proc docond(int opc, unit p, int lab)=
	genjumpcond(opc, p, lab)
end

proc do_syscall(unit p, a)=

	setfunctab()

	case p.fnindex
	when sf_getnprocs then
		pc_gen(kload, pgenmem(pnprocs))

	when sf_getprocname then
		pc_gen(kload, pgenmemaddr(pprocname))
		pc_setmode(tu64)
		evalunit(a)
		pc_genix(kiloadx, 8, -8)

	when sf_getprocaddr then
		pc_gen(kload, pgenmemaddr(pprocaddr))
		pc_setmode(tu64)
		evalunit(a)
		pc_genix(kiloadx, 8, -8)

	else
		PC_COMMENT("SYSCALL/GENERIC")
	esac
	pc_setmode(ti64)
end

proc do_slice(unit p, a, b) =
!generate separate code for (ptr, length) parts

	if b=nil then
		evalarray(a)
		if a.tag=jconst then			!assume string
			genpushint(strlen(a.svalue))
		else
			genpushint(ttlength[a.mode])
		fi

	else
!worth checking for const bounds? Both must be const to make it worthwhile
		do_indexref(a, b.a)
		if b.a.tag=b.b.tag=jconst then
			genpushint(b.b.value-b.a.value+1)
		else
			evalunit(b.b)
			evalunit(b.a)
			pc_gen(ksub)
			pc_setmode(ti64)
			genpushint(1)
			pc_gen(kadd)
		fi
		pc_setmode(ti64)

	fi

	pc_gen(kstorem); pc_setmode(tslice)
end

proc do_assignblock(unit p, a, b) =
!fstore=1 when result is needed
!method used is:
! load ref to lhs
! load ref to rhs
! do block xfer, not using the stack

	if b.tag=jmakelist then
		if ttbasetype[a.mode]=tarray then
			do_assignarray(a, b)
		else
			do_assignrecord(a, b)
		fi
	else
		GERROR("ASSIGN BLOCK")
	fi
end

proc do_assignarray(unit a, b)=
	unit passign, pindex, pconst, q
	int index

	if ttbasetype[tttarget[a.mode]]=tc8 then
		gerror("Assignment not suitable for []char type")
	fi

	pconst:=createconstunit(1, ti64)
	pindex:=createunit2(jindex, a, pconst)
	passign:=createunit2(jassign, pindex, b.a)
	passign.mode:=pindex.mode:=tttarget[a.mode]

	index:=ttlower[a.mode]
	q:=b.a

	while q do
		pconst.value:=index
		pconst.resultflag:=1
		passign.b:=q
		evalunit(passign)

		++index
		q:=q.nextunit
	od

end

proc do_assignrecord(unit a, b)=
	unit passign, pdot, pfield, q
	int m, fieldtype
	symbol d, e

	pfield:=createunit0(jname)
	pdot:=createunit2(jdot, a, pfield)
	passign:=createunit2(jassign, pdot, b.a)
	passign.mode:=pdot.mode:=tttarget[a.mode]

	m:=a.mode
	d:=ttnamedef[m]
	e:=d.deflist
	q:=b.a
	while e do
		if e.nameid=fieldid and e.mode<>tbitfield then
			fieldtype:=e.mode
			pfield.def:=e
			passign.mode:=pfield.mode:=pdot.mode:=fieldtype
			passign.b:=q
			pdot.offset:=e.offset
			evalunit(passign)
			q:=q.nextunit
		fi
		e:=e.nextdef
	od
end

proc pushrhs(unit a)=
	if a=nil then return fi
	pushrhs(a.nextunit)
	evalunit(a)
end

proc do_assignms(unit a, b)=
	int nlhs, nrhs
	symbol d

	nlhs:=a.length

	case b.tag
	when jcall then
		evalunit(b)
		if b.a.tag<>jname then
			gerror("multassign from fn: not simple fn")
		fi
		d:=b.a.def
		nrhs:=d.nretvalues

		a:=a.a					!point to elements of makelist
	elsif ttbasetype[b.mode]=tslice then
GERROR("DECONSTR SLICE NOT READY")
	else
		gerror("(a, b):=x; var only")
	esac

	poptomult(a)

	if nrhs>nlhs then
		d:=getprocretmodes(b)

		for i:=nlhs+1 to nrhs do
			pc_gen(kunload)
			pc_setmode(ttmult[d.mode, i])
		od
	fi
end

proc do_assignmm(unit a, b)=
!(a, b, c):=(x, y, z)
	pushrhs(b.a)			!push rhs elements in right-to-left order
	pc_gen(kloadall)
	poptomult(a.a)
end

proc do_assignmdrem(unit a, b)=
!(a, b):=x divrem y
	evalunit(b)
	poptomult(a.a)
end

proc poptomult(unit a)=
!a is a linked list; assign n popped values to each element in turn 
	repeat
		case a.tag
		when jname then
			pc_gen(kstore, genmem_u(a))
		when jindex, jslice, jdot then
			evalref(a)
			pc_gen(kistore)

		when jptr then
			evalunit(a.a)
			pc_gen(kistore)

		when jif, jcase, jswitch, jselect then
			evalref(a)
			pc_gen(kistore)

		when jdotindex then
			evalref(a.a)
			evalunit(a.b)
			pc_gen(kstorebit)

		else
			cpl jtagnames[a.tag]
			gerror("Bad mult assign element")
		esac

		pc_setmode_u(a)

		a:=a.nextunit
	until a=nil
end

proc do_recase(unit p, a)=
	unit q, wt, w
	int destlab, casevalue

!CPL "DO_RECASE", CASEDEPTH

	if casedepth=0 then
		gerror("recase outside case stmt")
	fi

	if a then
		casevalue:=a.value
	else				!a=null means goto else
		genjumpl(caseelse[casedepth])
	fi

	q:=casestmt[casedepth]

	destlab:=0

	wt:=q.b
	while wt do
		w:=wt.a
		while w do
			if w.tag=jconst and ttisinteger[w.mode] and w.value=casevalue then
				destlab:=w.whenlabel
				exit all
			fi
			w:=w.nextunit
		od
		wt:=wt.nextunit
	od

	if destlab=0 then
		genjumpl(caseelse[casedepth])
	else
		genjumpl(destlab)
	fi
end

proc do_empty(unit p, a)=
	evallv(a)
	pc_gen(kclear)
	pc_setmode_u(a)
end

proc do_typeconst(unit p)=
	genpushint(p.value)
end

proc do_setinplace=
	if pccurr.opcode=kload and pccurr.opndtype=memaddr_opnd then
		pccurr.inplace:=1
	fi
end
