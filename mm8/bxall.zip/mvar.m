include "mm_types.m"

global type symbol    	= ref void

global type object   	= ref varrec
global type iobject   	= ref object

!global macro pr(a,b)	= (a<<16 ior b)

global const varsize  	 	 = varrec.bytes
global const shortvarsize    = shortvarrec.bytes

!global ref[0:]ichar vttname

export record varrec =
!1st 8 bytes
	union
		struct
			word32 refcount
			union
				struct
					byte tag
					byte flags: (mutable:1)
					union
						word16 usertag
						word16 elemtag
						struct
							u8 bittag
							u8 bitoffset
						end
					end
				end
				word32 tagx
			end
		end
		word64 a
	end

!second 8 bytes (and end of short objects)
	union
		int64		value
		real64		xvalue
		word64		uvalue
		ichar		strptr
		iobject		varptr
		ref byte	ptr
		ref[]int	num
		word64 b
	end

!3rd 8 bytes
	union
		int64 length
		int64 lower
		struct
			word32 rows
			word32 columns
		end
		word64 c
	end

!4th 8 bytes (and end of long objects)
	union
		int64 alloc64
		object varptr2
		int64 upper
		struct
			int16 neg
			int16 numtype
			int32 expon
		end
		struct
			word32 alloc32
			union
				word32 lower32
				word32 dictitems
			end
		end
		word64 d
	end
end

!export record flatvarrec =
!	u64 a, b, c, d
!
!	word32	refcount	@ a
!	byte	tag			@ a+4
!	byte	flags		@ a+5
!
!	byte	usertag		@ a+6
!	byte	elemtag		@ a+6
!	word32	tagx		@ tag
!	...
!end

export record shortvarrec =			!represents first half of varrec
	[16]byte dummy
end

!export record genfieldrec=
!	symbol def
!	ref genfieldrec nextdef
!end
!
!export const maxgenfield=1000
!export [maxgenfield]ref genfieldrec genfieldtable
!export int ngenfields

export [0..255]object chrtable				!remember single-character objects

!export [-256..+256]object smallinttable		!for general int values at runtime
export [-256..+10'000]object smallinttable		!for general int values at runtime
!export [0..+256]object inttable

export const maxintconst=1000
export [maxintconst]object intconsttable	!int constants in sourc code
export int nintconsts

global varrec voidobj

global macro var_share(p) = (++p^.refcount; p)

export function void_new:object=
	&voidobj
end

export proc start=
	object p

	voidobj.tag:=tvoid
	voidobj.refcount:=0x8000'0000

	for i in smallinttable.bounds do
		p:=shortobj_new(vint)
		p.value:=i
		smallinttable[i]:=p
	od

end

!export setttname(ref[]ichar tt)=
!	vttame:=tt
!end	

global function shortobj_new(int tag)object p=
	p:=pcm_alloc16()
	p.refcount:=1
	p.tagx:=tag
	p.value:=0

	return p
end

global function obj_new(int tag)object p=
!create new object descriptor, which all fields set to zero
!except refcount=1
!.objtype=0 => normal_obj

!CPL "OBJ.NEW",TTNAME[TAG]
	p:=pcm_alloc32()
	p.refcount:=1
	p.tagx:=tag
	p.value:=0
	p.c:=0
	p.d:=0
	return p
end

export proc var_unshare(object p)=
	if --(p.refcount)=0 then
		var_free(p)
	fi
end

export proc var_free(object p) =
!RETURN
	switch p.tag
	when vint,vreal, vrefpack then
!CPL "FREEINT",P.VALUE
		cast(p,ref word)^:=word(int(freelist[1]))
		freelist[1]:=cast(p)
!		pcm_free16(p)

	when vlist then
		list_free(p)
!
!	when tarray then
!		array_free(p)
!
	when vstring then
		if p.length then
			pcm_free(p.strptr, p.alloc64)
		fi
		pcm_free32(p)
!!
	when vrefvar then
		var_unshare(p.varptr^)
		pcm_free32(p)

!	when trefpack then
!		if p.urefpack.objptr2 then
!			obj_unshare(p.urefpack.objptr2)
!		fi
!
	when vrange then
!CPL "FREE/RANGE"
		pcm_free32(p)

	when tvoid then				!voids aren't freed
!
	else
		CPL "Can't Free",stdnames[p.tag]

	end switch
end

!export func var_share(object a)object c =
!	unimpl("var_share")
!end

export func var_dupl(object a)object c =
!assumes a has been 'pushed', so needs to be unshared
!when called from internal code, need to share a before calling

	switch a.tag
	when vint then
		c:=int_make(a.value)
	when vreal then
		c:=real_make(a.xvalue)

	when vstring then
		c:=string_dupl(a)
!	when vset then
!		var_dupl_set(a)
	when vlist then
		c:=list_dupl(a)
!	when vdict then
!		var_dupl_dict(a)
!	when varray then
!		var_dupl_array(a)
!	when vbits then
!		var_dupl_bits(a)
!	when vrecord then
!		var_dupl_record(a)
!	when vstruct then
!		var_dupl_struct(a)
!	when vdecimal then
!		var_dupl_dec(a)
	else
		pcustype("dupl", a)
	endswitch

	var_unshare(a)

	return c
end

export proc var_push(object a) =
	unimpl("var_push")
end

export proc var_popmem(iobject p, object x) =
!CPL "POPMEM1",X,X.REFCOUNT
	var_unshare(p^)
	p^:=x
end

!export func var_storemem(object a, b)object c =
!	unimpl("var_storemem")
!end
!
export func var_getptr(object a)object c =
	case a.tag
	when vrefvar then
		c:=a.varptr^
		var_share(c)
		var_unshare(a)
	when vrefpack then


	else
		pcustype("getptr",a)
	esac
	c
end

export func var_putptr(object a, x)object c =
	unimpl("var_putptr")
end

!export func var_storeptr(object a, x)object c =
!	unimpl("var_storeptr")
!end

export func var_add(object x, y)object z =
!caller must ensure that x and y have compatible types

	if x.tag<>y.tag then
PCERROR("MIXED ADD")
!		return domixed_arith(x,y,cast(obj_add))
	fi

	switch x.tag
	when vint then
		z:=int_make(x.value+y.value)

	when vreal then
		return real_make(x.xvalue+y.xvalue)

	when vstring then
		z:=string_add(x,y)

	else
!PCERROR("ADD/T")
		pcustype("ADD",x)
	end switch

	var_unshare(x)
	var_unshare(y)

	return z
end

export func var_sub(object x, y)object z =

	if x.tag<>y.tag then
!CPL STDNAMES[X.TAG], STDNAMES[Y.TAG]
PCERROR("MIXED SUB")
!		return domixed_arith(x,y,cast(obj_mul))
	fi

	switch x.tag
	when vint then
		z:=int_make(x.value-y.value)

	when vreal then
		z:=real_make(x.xvalue-y.xvalue)

	else
!PCERROR("ADD/T")
		pcustype("SUB",x)
	end switch

	var_unshare(x)
	var_unshare(y)

	return z
end

export func var_mul(object x, y)object z =
	if x.tag<>y.tag then
PCERROR("MIXED MUL")
!		return domixed_arith(x,y,cast(obj_mul))
	fi

	switch x.tag
	when vint then
		z:=int_make(x.value*y.value)

	when vreal then
		z:=real_make(x.xvalue*y.xvalue)

	else
		pcustype("MUL",x)
	end switch

	var_unshare(x)
	var_unshare(y)

	return z
end

export func var_div(object x, y)object z =
	if x.tag<>y.tag then
PCERROR("MIXED DIV")
!		return domixed_arith(x,y,cast(obj_mul))
	fi

	switch x.tag
!	when vint then
!		z:=int_make(x.value*y.value)

	when vreal then
		z:=real_make(x.xvalue/y.xvalue)

	else
		pcustype("DIV",x)
	end switch

	var_unshare(x)
	var_unshare(y)

	return z
end

export func var_idiv(object x, y)object z =
	if x.tag<>y.tag then
PCERROR("MIXED IDIV")
!		return domixed_arith(x,y,cast(obj_mul))
	fi

	switch x.tag
	when vint then
		z:=int_make(x.value / y.value)

	else
		pcustype("IDIV",x)
	end switch

	var_unshare(x)
	var_unshare(y)

	return z
end

export func var_irem(object a, b)object c =
	unimpl("var_irem")
end

export func var_power(object a, b)object c =
	unimpl("var_power")
end

export func var_eq(object a, b)int res=
	if a.tag<>b.tag then
		PCERROR("EQ/MIXED")
	fi

	switch a.tag
	when vint, vword then
		res:=a.value=b.value
	when vreal then
		res:=a.xvalue=b.xvalue

	when vstring then
		res:=string_equal(a,b)

	else
		pcustype("EQ", a)
	endswitch

	var_unshare(a)
	var_unshare(b)

	return res
end

export func var_ne(object a, b)int =
	return not var_eq(a,b)
end

export func var_lt(object a, b)int res=
	if a.tag<>b.tag then
		PCERROR("LT/MIXED")
	fi

	switch a.tag
	when vint, vword then
		res:=a.value<b.value
	when vreal then
		res:=a.xvalue<b.xvalue
	when vstring then
		res:=string_compare(a,b)<0
	else
		pcustype("LT", a)
	endswitch

	var_unshare(a)
	var_unshare(b)

	return res
end

export func var_le(object a, b)int res =
	if a.tag<>b.tag then
		PCERROR("LE/MIXED")
	fi

	switch a.tag
	when vint, vword then
		res:=a.value<=b.value
	when vreal then
		res:=a.xvalue<=b.xvalue
	when vstring then
		res:=string_compare(a,b)<=0
	else
		pcustype("LE", a)
	endswitch

	var_unshare(a)
	var_unshare(b)

	return res

end

export func var_ge(object a, b)int =
	return not var_lt(a,b)
end

export func var_gt(object a, b)int =
	return not var_le(a,b)
end

export func var_isequal(object a, b)int =
	unimpli("var_isequal")
end

export func var_iand(object x, y)object z =
	if x.tag<>y.tag then
PCERROR("MIXED IAND")
!		return domixed_arith(x,y,cast(obj_add))
	fi

	switch x.tag
	when vint then
		z:=int_make(x.value iand y.value)

	else
!PCERROR("ADD/T")
		pcustype("IAND",x)
	end switch

	var_unshare(x)
	var_unshare(y)

	return z
end

export func var_ior(object a, b)object c =
	unimpl("var_ior")
end

export func var_ixor(object a, b)object c =
	unimpl("var_ixor")
end

export func var_shl(object x, int n)object z =
	switch x.tag
	when vint then
		z:=int_make(x.value << n)

	else
		pcustype("SHL",x)
	end switch

	var_unshare(x)

	return z
end

export func var_shr(object x, int n)object z =
	switch x.tag
	when vint then
		z:=int_make(x.value >> n)

	else
		pcustype("SHR",x)
	end switch

	var_unshare(x)

	return z
end

export func var_andl(object a, b)object c =
	unimpl("var_andl")
end

export func var_append(object a, b)object c =
	unimpl("var_append")
end

export func var_concat(object a, b)object c =
	unimpl("var_concat")
end

export func var_min(object a, b)object c =
	unimpl("var_min")
end

export func var_max(object a, b)object c =
	unimpl("var_max")
end

export func var_neg(object a)object c =
	unimpl("var_neg")
end

export func var_abs(object a)object c =
	unimpl("var_abs")
end

export func var_inot(object a)object c =
	unimpl("var_inot")
end

export func var_notl(object a)object c =
	unimpl("var_notl")
end

export func var_istruel(object a)int res =
	case a.tag
	when vint, vreal then
		res:=istrue a.value
	when vstring, vset then
		res:=istrue a.length
	when vstring, vset then
		res:=istrue a.length
	else
		pcustype("istruel",a)
	esac
	var_unshare(a)
	res
end

export func var_sqrt(object a)object c =
	case a.tag
	when vreal then
		c:=real_make(sqrt(a.xvalue))
	when vint then
		c:=real_make(sqrt(a.value))
	else
		pcustype("sqrt",a)
	esac
	var_unshare(a)
	c
end

export func var_sin(object a)object c =
	unimpl("var_sin")
end

export func var_cos(object a)object c =
	unimpl("var_cos")
end

export func var_tan(object a)object c =
	unimpl("var_tan")
end

export func var_asin(object a)object c =
	unimpl("var_asin")
end

export func var_acos(object a)object c =
	unimpl("var_acos")
end

export func var_atan(object a)object c =
	unimpl("var_atan")
end

export func var_atan2(object a, b)object c =
	unimpl("var_atan2")
end

export func var_exp(object a)object c =
	unimpl("var_exp")
end

export func var_ln(object a)object c =
	unimpl("var_ln")
end

export func var_log(object a)object c =
	unimpl("var_log")
end

export func var_round(object a)object c =
	unimpl("var_round")
end

export func var_floor(object a)object c =
	unimpl("var_floor")
end

export func var_ceil(object a)object c =
	unimpl("var_ceil")
end

export func var_fract(object a)object c =
	unimpl("var_fract")
end

export func var_asc(object a)int =
	unimpli("var_asc")
end

export func var_chr(object a)object c =
	unimpl("var_chr")
end

export func var_lwb(object a)int n=
	case a.tag
	when vlist then
		n:=a.lower32
	when vstring then
		n:=1
	else
		pcustype("lwb",a)
	esac
	var_unshare(a)
	n
end

export func var_upb(object a)int n=
	case a.tag
	when vlist then
		n:=a.length+a.lower32-1
	when vstring then
		n:=a.length
	else
		pcustype("upb",a)
	esac
	var_unshare(a)
	n
end

export func var_len(object a)int n=
	case a.tag
	when vlist then
		n:=a.length
	when vstring then
		n:=a.length
	else
		pcustype("len",a)
	esac
	var_unshare(a)
	n
end

export func var_bounds(object a)object c =
	int lower, upper
	case a.tag
	when vlist then
		lower:=a.lower32
		upper:=a.length+lower-1
	when vstring then
		lower:=1
		upper:=a.length
	else
		pcustype("bounds",a)
	esac
	var_unshare(a)
	return range_make(lower, upper)
end

export proc var_addto(iobject a, object b) =
	unimpl("var_addto")
end

export proc var_subto(iobject a, object b) =
	unimpl("var_subto")
end

export proc var_multo(iobject a, object b) =
	unimpl("var_multo")
end

export proc var_divto(iobject a, object b) =
	unimpl("var_divto")
end

export proc var_idivto(iobject a, object b) =
	unimpl("var_idivto")
end

export proc var_iremto(iobject a, object b) =
	unimpl("var_iremto")
end

export proc var_iandto(iobject a, object b) =
	unimpl("var_iandto")
end

export proc var_iorto(iobject a, object b) =
	unimpl("var_iorto")
end

export proc var_ixorto(iobject a, object b) =
	unimpl("var_ixorto")
end

export proc var_shlto(iobject a, object b) =
	unimpl("var_shlto")
end

export proc var_shrto(iobject a, object b) =
	unimpl("var_shrto")
end

export proc var_andlto(iobject a, object b) =
	unimpl("var_andlto")
end

export proc var_orlto(iobject a, object b) =
	unimpl("var_orlto")
end

export proc var_appendto(iobject a, object b) =
	unimpl("var_appendto")
end

export proc var_concatto(iobject a, object b) =
	unimpl("var_concatto")
end

export proc var_minto(iobject a, object b) =
	unimpl("var_minto")
end

export proc var_maxto(iobject a, object b) =
	unimpl("var_maxto")
end

export proc var_negto(iobject a) =
	unimpl("var_negto")
end

export proc var_absto(iobject a) =
	unimpl("var_absto")
end

export proc var_inotto(iobject a) =
	unimpl("var_inotto")
end

export proc var_notlto(iobject a) =
	unimpl("var_notlto")
end

export proc var_istruelto(iobject a) =
	unimpl("var_istruelto")
end

export proc var_incrto(iobject a) =
	object p:=a^, q
	case p.tag
	when vint then
		a^:=int_make(p.value+1)
		var_unshare(p)

	else
		pcustype("incrto",p)
	esac

end

export proc var_decrto(iobject a) =
	unimpl("var_decrto")
end

export func var_loadincrto(iobject a)object c =
	unimpl("var_loadincrto")
end

export func var_loaddecrto(iobject a)object c =
	unimpl("var_loaddecrto")
end

export func var_incrloadto(iobject a)object c =
	unimpl("var_incrloadto")
end

export func var_decrloadto(iobject a)object c =
	unimpl("var_decrloadto")
end

export proc var_print(object p, ichar fmt) =
	array [100]char str

	case p.tag
	when vint then
		m$print_i64_nf(p.value)

	when vreal then
		m$print_r64(p.xvalue, nil)

	when vstring then
		if p.length then
			m$print_strn(p.strptr,p.length, fmt)
		else
			m$print_str_nf("")
!M$PRINT_I64_NF(P.REFCOUNT)
		fi
	when vlist then
		list_print(p, fmt)

	when tvoid then
		m$print_str_nf("<void>")
	when vrange then
		fprint @str, "#..#",p.lower,p.upper
		m$print_str_nf(str)
!		m$print_str_nf("ABC")
!
!!		m$print_i64_nf(p.lower)
!		needgap:=0
!		m$print_str_nf("..")
!		needgap:=0
!		m$print_i64_nf(p.upper)

	when vrefvar then
		fprint @str,"Refvar<#>",p.varptr
		m$print_str_nf(str)

	when vrefpack then
		fprint @str,"Refpack(#)<#>",stdnames[p.elemtag],p.varptr
		m$print_str_nf(str)

	else
		m$print_str_nf("<varprint?>")
	esac

	var_unshare(p)
end

export func var_tostr(object a)object c =
	unimpl("var_tostr")
end

export func var_getdot(object a, b)object c =
	unimpl("var_getdot")
end

export proc var_putdot(object a, b) =
	unimpl("var_putdot")
end

export func var_getindex(object a, int index)object c =
	word offset

	case a.tag
	when vlist then
		offset:=index-a.lower32
		if offset>=word(a.length) then
			pcerror("list[int] bounds")
		fi

		var_unshare(a)
		return var_share((a.varptr+offset)^)
	else
		cast(pcustype("Getindex",a))
	esac
end

export func var_getindexref(object a, int index)object c =
!return a ref
    word offset

!CPL "GETINDEXREF"

	case a.tag
	when vlist then
		offset:=index-a.lower32
		if offset>=word(a.length) then
			pcerror("&list[int] bounds")
		fi

		var_unshare(a)
		return refvar_make((a.varptr+offset))
	else
		cast(pcustype("Getindexref",a))
	esac
end

export proc var_putindex(object a, int i, object x) =
	case a.tag
	when vlist then
		list_putindex(a,i,x)

		var_unshare(a)
	else
		pcustype("Putindex",a)
	esac
end

export func var_getdotindex(object a, b)object c =
	unimpl("var_getdotindex")
end

export proc var_putdotindex(object a, int i, object x) =
	unimpl("var_putdotindex")
end

export func var_getslice(object a, int i, j)object c =
	unimpl("var_getslice")
end

export proc var_putslice(object a, int i, j, object x) =
	unimpl("var_putslice")
end

export func var_getdotslice(object a, int i, j)object c =
	unimpl("var_getdotslice")
end

export proc var_putdotslice(object a, int i, j, object x) =
	unimpl("var_putdotslice")
end

export func var_getkeyindex(object a, b)object c =
	unimpl("var_getkeyindex")
end

export proc var_putkeyindex(object a, x) =
	unimpl("var_putkeyindex")
end

export proc var_insert(object a, b) =
	unimpl("var_insert")
end

export proc var_delete(object a) =
	unimpl("var_delete")
end

export proc var_resize(object a, b) =
	unimpl("var_resize")
end

export func int_make(int a)object p =
	if a<=smallinttable.upb and a>=smallinttable.lwb then
		return var_share(smallinttable[a])
	fi

	if p:=object(freelist[1]) then		!Items of this block size available
		freelist[1]:=ref word(int((freelist[1])^))
	else
		p:=pcm_alloc16()
	fi
	p.refcount:=1
	p.tagx:=vint
	p.value:=a

!CPL "INTMAKE",P,P.REFCOUNT

	return p
end

export func bool_make(int a)object c =
	c:=obj_new(tbool)
	c.value:=a
	return c
end

export func real_make(real x)object p =
	if p:=object(freelist[1]) then		!Items of this block size available
		freelist[1]:=ref word(int((freelist[1])^))
	else
		p:=pcm_alloc16()
	fi
	p.refcount:=1
	p.tagx:=vreal
	p.xvalue:=x

	return p
end

export func string_make(ichar s)object c =
!create a ivariant string from given string
!string will be copied to heap
	ref char t
	int length:=strlen(s)

	if length=0 then
		return str_makex(t,0,0)
	else
		t:=pcm_alloc(length)
		memcpy(t,s,length)
		return str_makex(t,length,allocbytes)
	fi
end

export func dec_make(object a)object c =
	unimpl("dec_make")
end

!export func list_make(object a)object c =
!	unimpl("list_make")
!end

export func array_make(object a)object c =
	unimpl("array_make")
end

export func range_make(int lower, upper)object c =
	c:=obj_new(vrange)
	c.lower:=lower
	c.upper:=upper
	c
end

export func refvar_make(iobject p)object c =
	c:=obj_new(vrefvar)
	c.varptr:=p
	++(p.refcount)
	c
end

export func refpack_make(ref void p, int t)object c =
	c:=obj_new(vrefpack)
	c.ptr:=p
	c.elemtag:=t
	c
end

export func slice_make(object a)object c =
	unimpl("slice_make")
end

export func var_convert(object a)object c =
	unimpl("var_convert")
end

export func var_to_int(object p)int a=

	case p.tag
	when vint then a:=p.value
	else
		pcerror("vartoint?")
	esac

	var_unshare(p)
	return a
end

export func var_to_real(object p)real x =
	case p.tag
	when vreal then x:=p.xvalue
	else
		pcerror("vartoreal?")
	esac

	var_unshare(p)
	return x
end

export func var_to_string(object a)object c =
	unimpl("var_to_string")
end

export func var_to_slice(object a)object c =
	unimpl("var_to_slice")
end

export proc var_swap(object a,b)=
!a,b must be ref x
	if a.tag<>b.tag then pcerror("Swap") fi

	case a.tag
	when vrefvar then
		swap(a.varptr^, b.varptr^)
!CPL "VAR/SWAP", A^.VALUE
	else
		pcustype("Swap",a)
	esac
	var_unshare(a)
	var_unshare(b)
end

export function daddrvv(object a)object c=
!DADDR attempts to get a refpack pointer
!a is expeced to contain refvar/refpack/refbit value
!when refpack/refbit, it is already in the right format
!when refvar, it is not clear if that can be returned, or if I can
!call daddrtv to narrow it down further 


	case a.tag
	when vrefpack, vrefbit then
		return a
	when vrefvar then
		c:=daddrtv(a.varptr)
		var_unshare(a)
	else
		pcustype("&&VAR",a)
	esac

	c
end

export function daddrtv(iobject p)object c=
!p is a ref var; create a refpack/ref bit object pointing to the
!data in p^

	object a:=p^

!	case ttbasetype[a.tag]
	case a.tag
	when vint then
		c:=refpack_make(&a.value, ti64)
!	when vreal then
	when vstring then
		if a.length then
			c:=refpack_make(a.strptr,tu8)
		else
			PCERROR("&&empty str")
		fi
	else
		pcustype("&&REF VAR",a)
	esac

!VOID_NEW()
	c
end

export func unimpl(ichar name)object=
	println "MVAR:",name,"not implemented"
	stop 1
	nil
end

export func unimpli(ichar name)int=
	int(unimpl(name))
end

global function pcerror(ichar mess)object=
	println "Var runtime error:",mess
	stop 1
	nil
end

global function pcustype(ichar mess, object a)object=
	fprintln "Var: type (#) not supported for: #",stdnames[a.tag],mess
	println
	println
	stop 1
	nil
end

export function $id(var a)int id=
	int@(a)
end

PROC PRINTVARSTR(ICHAR M,OBJECT A)=
	PRINTLN M,A.LENGTH:"V",A.STRPTR:".*"

END
