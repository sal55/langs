global type int8	= i8
global type int16	= i16
global type int32	= i32
global type int64	= i64

global type word8	= u8
global type word16	= u16
global type word32	= u32
global type word64	= u64

global type char64	= c64

global type real32	= r32
global type real64	= r64

