!String testing
!Operations
!//	Empty
!//	New (with default value)
!	--Make (From existing value?? Mainly for internal use, from cstring)
!// 	Makestr
!//	Lwb, Upb, Len, Bounds
!//	Free
!//	Dupl
!//	^string
!//	&string

!//	Istrue

!//	Add/Concat/Append
!//	Addto/Concatto/Appendto
!//	(Grow a character at a time, assigning to S[$+1])

!//	Mul

!//	Equal
!//	Compare

!//	Index
!//	Putindex
!//	Indexref

!//	Slice
!//	Putslice

!//	Dotindex
!//	Putdotindex
!//	Dotindexref

!//	Dotslice
!//	Putdotslice
!	**Dotsliceref

!//	In (string/string, string/list)

!//	Min/Max
!//	Minto/Maxto

!//	Leftstr/Rightstr

!//	Asc
!//	Chr
!//	Convuc/Convlc

!//	Tostr formatted
!//	Iterate over

!//	Expand
!//	Convert to int/array/list

!	To Unicode array
!	To Decimal
!	Reverse

!Test also for memory leaks, by monitoring net small object allocations
!after lots of strings ops

int startmem

sub main=
	startmem:=smallmemtotal
	mem("Initial mem")

!	basic()
!	testnew()
!	compare()
!	multiply()
!	ascchr()
!	convertcase()
!	leftright()
!	instring()
!
!	addstring()
!	addto()
!	indexslice()
!	indexslice()
!	indexslice()
!
!	putindex()
!	putslice()
!	indexref()
!	dotindex()
!	dotslice()
!
!	putdotindex()
!	dotindexref()
!	format()
!	iterate()
!	expand()
!	convert()
!
	mem("Final mem")
	println
!WAITKEY()

END

sub mem(mess)=
	println mess,,":",smallmemtotal-startmem
end

sub basic=

	s:=""
	fprintln "S=<#> # # # # mem:#", s, s.lwb, s.upb, s.lwb, s.bounds

	s::="ABCDEF"
	fprintln "S=<#> # # # # mem:#", s, s.lwb, s.upb, s.lwb, s.bounds
	t::=s
	fprintln "S.id=# T.id=# mem:#", $id(s), $id(t)
	s:=0

	s:="ABCDEF"

	p:=^s
	q:=&s
	cpl =p
	cpl =q
	cpl =p^
	cpl =q^

end

sub testnew=
	s:=newvar((string),4.5)
	fprintln "S=<#> # # # #", s, s.lwb, s.upb, s.lwb, s.bounds

	a:='ABCDEFG'
	s:=makestr(&a,7)

	fprintln "S=<#> # # # #", s, s.lwb, s.upb, s.lwb, s.bounds

end

sub compare=
	s::="ABCD"
!	t::="ABC"
	t::="ABCDE"
!	t::="DEF"

	if s then fi

	println =istrue s
	println =not s

	println =S
	println =T

	if s=t then
		println "SAME"
	else
		println "DIFFERENT"
	fi
	if s<t then
		println "LESS THAN"
	elsif s>t then
		println "GREATER THAN"
	else
		println "SAME"
	fi

	println =S=T
	println =S<>T
	println =S<T
	println =S<=T
	println =S>=T
	println =S>T
	println

	println =min(s,t)
	println =max(s,t)

	a:=s
	b:=s

	a min:=t
	b max:=t
	println =a
	println =b
end

sub multiply=
	s:="abc"

	t:=s*10

	println t
	println t.len

end

sub ascchr=
	s:="ABC"
!	s:=""
	println asc(s)

	t:=chr(66)

	println t, t.len

end

sub convertcase=

	s:="ABCDEefghij"

	println =s

	println convuc(s)
	println convlc(s)

	println convuc(s,7)
	println convlc(s,7)

!	println convuc(s,0)
!	println convlc(s,0)

!	println convuc(s,-100)

end

sub leftright=
	s:="abcdefghij"

	println =s

	fprintln "<#>",leftstr(s,3)
	fprintln "<#>",leftstr(s,13)
	fprintln "<#>",leftstr(s,-3)
	fprintln "<#>",leftstr(s,-13)

	fprintln "<#>",rightstr(s,3)
	fprintln "<#>",rightstr(s,13)
	fprintln "<#>",rightstr(s,-3)
	fprintln "<#>",rightstr(s,-13)


!	fprintln "<#>",leftstr(s,-3)
!	fprintln "<#>",leftstr(s,13)
!	fprintln "<#>",leftstr(s,-13)

end

sub instring=
	s:="fox"
	t:="the quick brown fox jumps"
!	t:=(1,2,"fox",4)

	println =s
	println =t
	println s in t
end

sub addstring=
	s:="XYZ"
	t::="ABC"
	u::="FFF"

	cpl =s
	cpl =t

	u:=s + t
	u:=s concat t
	u:=s append t
!	u:=s concat t concat U
!	u:=s append t Append u

	CPL =u
end

sub addto=
	s::="ABCDEFGHIJKLMNOP"
	t::="XYZ"
!	t:='Z'

	cpl =s
	cpl =t

!	to 50 million do
!	to 10 do
		s+:=t
!		s append:=t
!		s concat:=t
!	od

	cpl =s
	cpl =s.len

end

sub indexslice=
	s:="ABCDEFGHIJ"
	i:=3

	println =s
	println =i
!	println =s[i]

	t:=s[i]
	CPL =t, t.bounds

	j:=7
	t:=s[i..j]

	cpl =t,t.bounds

end

sub putindex=
	s::="ABCDEFGHIJ"
	i:=3

	println =s
	println =i

	t::="*"

!	for i:=9 to 50 do
		s[i]:=t
!	od

	println =s
	println =s.len
end

sub putslice=
	s::="ABCDEFGHIJ"
	i:=3
	j:=6

	println =s
	println =i,=j

	t::="FREDBILL"

!	s[i..j]:=t
!	println =s
!
	s.[i..j]:=t
	println =s



end

sub indexref=
	s::="ABCDEFGHIJ"
	i:=3

	println =s
	println =i

	p:=^s[i]

	cpl p
	cpl p^

end

sub dotindex=
	s:="ABCDEFGHIJ"
	i:=3

	println =s
	println =i
!	println =s[i]

	t:=s.[i]
	CPL =t
	CPL =chr(t)
end

sub dotindexref=
	s:="ABCDEFGHIJ"
	i:=3

	println =s
	println =i
!	println =s[i]

	p:=&s.[i]
	CPL =p
	CPL =p^
end

sub dotslice=
	s:="ABCDEFGHIJ"
	i:=3
	j:=7

	println =s
	println =i,=j
!	println =s[i]

	t:=s.[i..j]
	CPL =t
	CPL =t.bounds
end

!sub dotsliceref=
!	s:="ABCDEFGHIJ"
!	i:=3
!	j:=7
!
!	println =s
!	println =i,=j
!!	println =s[i]
!
!	p:=^s.[i..j]
!	CPL =p
!!	CPL =t.bounds
!end
!
sub putdotindex=
	s::="ABCDEFGHIJ"
	i:=3

	println =s
	println =i
!	println =s[i]

!	to 100 do
		s.[i++]:='x'
!	od

	CPL =s
	CPL =s.bounds
end

sub format=
	s:="ABCDEfghij"

	fprintln "<#>",s:"15"

	t:=tostr(s,"15 JL")

	fprintln "<#>",T

end

sub iterate=
	s:="ABCDEfghij"

	for i in s do
		cpl i
!		s:=""
	od

	for i in s.len do
		println s.[i]
	od

!	foreach i in s do
!		cpl i
!	od
end

sub expand=
	s:=""

	(b,a,r,t):="BART"

	println b,a,r,t

end

sub convert=
	s:="fred"

	a:=list(s)

	println a
	println a.len,a.bounds

end
