global const maxmodule=400
global const maxsubprog=30
global const maxlibfile=50
global const maxsourcefile=300

global type symbol		= ^strec
global type unit  		= ^unitrec
global type imodule   	= ^modulerec
global type ifile   	= ^filerec
global type isubprog  	= ^subprogrec

global macro pr(a,b)	= (a<<16 ior b)

global record tokenrec =
	byte symbol
	byte subcode
	u16 slength				!string length; includes any zero term
	u32 pos: (sourceoffset:24, fileno:8)

	union
		^strec symptr		!pointer to symbol table entry for name
		i64 value				!64-bit int
		real xvalue				!64-bit float
		u64 uvalue			!64-bit word
		ichar svalue			!pointer to string or charconst (not terminated)
	end
end

global record typenamerec=
	symbol owner			!owner of scope where typename was encountered
							!moduleno required by resolvetypename can be derived from owner
!A/B used as follows
!  nil B			Simple typename B
!  A   B			Dotted pair A.B
!  A   nil          I think represents a typeof(x) where x is a name
	symbol defa
	union
		symbol defb
		symbol def
	end
	^i32 pmode
end

global record posrec=
	u32 pos: (sourceoffset:24, fileno:8)
end

global record uflagsrec =
	[7]byte	codes
	byte	ulength
end

!global record strec = $caligned
global record strec =
	ichar name
	^strec owner
	^strec deflist
	^strec deflistx			!point to last in deflist

	^strec nextdef
	^strec firstdupl			!point to generic version
	^strec nextdupl

	^strec nextlinear			!next linear symbol (user identifiers only)

	psymbol pdef

!	^fwdrec fwdrefs

!	MCLOPND MX

	unit code					!vars with init data or proc bodies

	i32 mode					!modes must be i32 to allow fixup later
	byte namelen
	byte symbol
	byte subcode
	byte nameid					!procid etc

	union
		i32 lexindex			!for certain tokens
		i32 fnindex				!dll proc: index into table
		i32 labelno				!named labels: labelno
	end
	i32 offset

	u32 pos: (
		sourceoffset:24,		!char offset within source file
		fileno:8)				!sourcefile no

	u16 flags: (
		isstatic:1,
		hasdoswx:1,				!uses doswitchx in proc
		txdone:1,				!tx-processing flags
		circflag:1,

		islet:1,				!let-name initialised
		ishandler:1,			!proc is a handler (proc F*())

		atfield:1,				!field def has @ x (.equivfield will be set too, but that is shared)

		ADDROF:1,				!TEMP ADDITIONS FOR MCL/PCL BACKEND
		ISENTRY:1,

		regcand:1,				!1 when either could be a candidate for a regvar,
		xregcand:1,				! if there were available registers

		used:1,
		cvariadic:1,			!used in C front end; always 0 here
		isimport:1)				!for dllproc/dllvar

	byte moduleno				!module in which this name is defined
	byte subprogno				!enclosing sub-prog

	unit equivvar				!nil, or reference to @ var, as an expression

	u32 size					!used in backend, when set to basic 'tblock'

	union
		struct					!when a proc or dllproc
			ichar truename		!for imported name only
			^strec paramlist

			byte nretvalues		!func: number of return values (0 for proc)
			byte varparams		!0 or number fixed params for variadic imports
[6]BYTE DUMMY
		end

		struct					!when a record or record field
			^strec equivfield	!@ x used in record field defs; ^to x
			uflagsrec uflags
			byte bitfieldwidth	!width of bitfield in record
			byte caligned		!caligned used
			byte bitoffset		!0..31 for bitfields in records
			byte equivoffset
	byte maxalign				!for record types (doesn't fit above)
		end

		struct					!when a param name
			^strec nextparam
			byte byref			!0/1 = byvalue/byref
			byte optional		!0 or 1	
		end
	end

!	^pclinforec pclinfo

!	byte used					!1 if var used at least once

	byte scope					!module_scope etc

!temporary, added for mcl backend which now uses same strec
!	byte reg
!	byte reftype
!	byte segment
!	i16 stindex
!	i16 importindex
!	i16 exportindex
!	u32 size
end

!global record unitrec = $caligned
global record unitrec =
	unit nextunit

	byte tag					!jtag number
	byte resultflag				!1 when the result of this unit is needed; 0=void or discarded
	byte insptr					!tx-processing flags
	byte txcount

	u32 pos: (
		sourceoffset:24,		!char offset in source file
		fileno:8)				!sourcefileno

	i32 mode
	i32 oldmode					!convert/typepun: original mode (usually that of any subnode)

	byte moduleno
	byte subprogno
	byte flags: (
		initlet:1,				!1 for an assignment that initialises a let
		isconst:1)				!1 for jconst, and jmakerange with const range

	union
		byte pclop				!kadd etc, for jbin, incr etc
		byte propcode			!kklen etc
		byte inv				!notin
!		byte convcode			!kkfix etc
		byte bfcode				!bf_even etc
		byte cvindex			!cv_lineno etc, compile var index
		byte fnindex			!sf_print etc
	end
	union
		byte mathsop			!maths_sin etc
		byte condcode			!eq_cc etc
	end

!	byte pmode					!
	byte avcode
	[2]byte SPARE

!Rest of unit is fields A, B, C. Not all will be used
!Jsubs[tag] says how many (0-3) will be sub-nodes
!The rest may be used for other purposes depending on jtag

	union
		unit	a				!subnode
		symbol	def				!jname
		i64		value			!jconst
		r64		xvalue			!jconst
		ichar	svalue			!jconst: string const or data-string
		i64		range_lower		!jmakerange only
	end

	union
		unit	b				!subnode
		i64		range_upper		!jmakerange only
	end

	union
		unit	c				!subnode

		struct					!const string
			u32  slength		!includes any zero term
			byte isastring
			char strtype		!0/'B'/'S' = normal / bindata / strdata
		end

		u32 length			!makelist: number of elements

		struct					!cmpchain
			[8]byte cmpgenop
		end

		u32 offset				!jdot
!		byte avcode				!jname for/autovars: 'I','T','S' = index/to/step autovars

		i32 loopindex			!jexit etc
		i32 whenlabel			!label associated with expr, for recase

	end
	[3]unit abc @ a				!alias a/b/c with an array
end

global record modulerec=
	ichar	name				!module name and base filename
	ifile	file
	i16		moduleno			!useful if using pointer to a source rec
	i16		subprogno
	i16		fileno
	byte	issyslib
	byte	islead				!1 if lead module in sp

	union
		symbol	stmodule
		symbol	def
	end

	symbol	stsubprog
	symbol	stmacro

	symbol	ststart				!nil, or st entry of start()
	symbol	stmain				!nil, or st entry of main()
end

global record filerec=
	ichar	name				!module name and base filename
	ichar	filename			!base filename + extension
	ichar	path				!path where file resides
	ichar	filespec			!full file path
	ichar	text				!pointer to source text, 0-terminated
	ichar	dupl				!for ma files
	int		size				!source file size includes terminator

	byte	issyslib			!1 if a system module
	byte	issupport			!1 if a support file (strinclude); MAY BE STORED ELSEWHERE
	byte	compiled			!1 if compiled
	byte	islead				!1 if lead module in sp

	i16	subprogno
	i16	moduleno			!0, or moduleno

	i16	fileno				!refers to self
	i16	spare

end

global record subprogrec =
	ichar name
	i16 firstmodule			!will be header module or same as mainmodule if no header
	i16 mainmodule			!0, or module containing 'main'
	i16 lastmodule			!always first..lastmodule
!	i16 compiled				!1 if compiled
	byte flags:(compiled:1, issyslib:1)
	byte subprogno
end

global [0..maxmodule]imodule	modules
global [0..maxmodule]byte		moduletosub				!convert module no to subprog no
global [0..maxsubprog]isubprog	subprogs
global [0..maxsourcefile]ifile	sources
global [0..maxsubprog]byte		subproghasstart

global int nmodules
global int nsubprogs
global int nsourcefiles
global int nlibfiles

global symbol stprogram				!root into the symbol table
global symbol stmodule				!main module
global symbol stlinear, stlinearx	!linear list of selected identifiers (eg. statics, procs)
global int currmoduleno				!used when compiling modules
global byte loadedfromma			!1 if source/support files are in loaded .ma file

global tokenrec lx					!provides access to current token data
global tokenrec nextlx				!provides access to next token

global [0..maxlibfile]ichar libfiles

global int mainsubprogno		!index of main subprog (eg. may be before/after syslib)

!global const int maxtype=6'000
global const int maxtype=16'000

global int ntypes

global [0..maxtype]symbol	ttnamedef
global [0..maxtype]symbol	ttowner			!for ttlowerexpr/rtlengthexpr

global [0..maxtype]i32		ttbasetype		!basetype
global [0..maxtype]ichar	ttname

global [0..maxtype]u32		ttsize
global [0..maxtype]byte		ttsizeset
global [0..maxtype]i32		ttlower 		!.lbound (default 1)
global [0..maxtype]i32		ttlength 		!elements in array/record/tuple
global [0..maxtype]^[]i32	ttmult 			!ttlength elements in tuple

global [0..maxtype]unit		ttdimexpr		!length, lower:length, or lower..upper

global [0..maxtype]i32		tttarget 		!for array/^types
global [0..maxtype]i32		ttlineno

global [0..maxtype]byte		ttsigned		!is i8 i16 i32 i64
global [0..maxtype]byte		ttisreal		!is r32 r64
global [0..maxtype]byte		ttisinteger		!is i8..i64/u8..u64/c8..c64
global [0..maxtype]byte		ttisshort		!is i8/i16/i32/u8/u16/u32/c8/c16
global [0..maxtype]byte		ttisref			!is a pointer

!global const int maxtypename=4'000
!global const int maxtypename=8'000
!global const int maxtypename=38'000
global const int maxtypename=380'000

global [0..maxtypename]typenamerec typenames
global [0..maxtypename]posrec typenamepos
global int ntypenames

global [0..symbolnames.upb]byte typestarterset

global symbol currproc

global int headermode=0

!global symbol proclist,proclistx			!linked list of all procs
!global symbol staticlist,staticlistx		!linked list of all static
!global symbol constlist,constlistx		!linked list of all export consts

global unit nullunit

global const maxdllproc=1000

global int ndllproctable
global [maxdllproc]symbol dllproctable

global int fverbose=1		!1=normal, 0=less verbose, 2/3 = more verbose
global int fcodesize=0		!0/1/2/2 = quite/show code size/exe/all

global byte msyslevel=2		!0/1/2 = none/min/normal

global byte fshowtiming
!global byte fshowss
global byte fshowasm
global byte fshowpcl
global byte fshowast1
global byte fshowast2
global byte fshowast3
global byte fshowst
global byte fshowpst
global byte fshowstflat
global byte fshowtypes
global byte fshowmodules
global byte fshowdiags			!1 means any of the above set

global byte fcheckunusedlocals=0

global byte highmem=1			!enable rip by default
global byte clinux				!1 when clang_pass targeting linux

global byte dointlibs=fsyslibs

!passlevel used for compiler debug only
global int passlevel=0
global int libmode=0					!1 means eventual ML/LIB target
global int fshortnames					!mcl/asm display

global ichar outfile					!one of the following two
global ichar destfilename				!nil, or override outfile
global ichar destfilepath				!nil, or set path of outfile

!global const langhomedir	= "C:/mx/"
global const langhomedir	= "C:/bx/"
!global const langhomedir	= "C:/bx2/"

global const langhelpfile	= "mm_help.txt"

!global byte ctarget=0

global int pcltime
global int mcltime
global int sstime
global int exetime

global byte fregoptim = 0
global byte fpeephole = 0

global byte fcff = 0

global int mmpos

global int mlabelno

global const reducelabels=1
!global const reducelabels=0

!GLOBAL INT NALLUNITS
!GLOBAL INT NCONSTUNITS
!GLOBAL INT NNAMEUNITS
!GLOBAL INT NSOLOUNITS
!GLOBAL INT NONEUNITS
!
!GLOBAL INT NREADUNITS
!GLOBAL INT NTOWER
!GLOBAL INT NEARLYRET
!GLOBAL INT NALLBINS
!GLOBAL INT NALLADDS
!GLOBAL INT NSIMPLEBINS
!
!
!GLOBAL INT NALLPROCS
