[0:16]int s
[0:16]int t
int maxflips = 0
int max_n
int oddx = 0
int checksum = 0

function flip()int =
    int i
    ref int x
    ref int y
    int c

    x := &.t
    y := &.s
    i := max_n
    while i-- do
        (x++)^ := (y++)^
    od
    i := 1
    repeat 
        x := &.t
        y := &.t+t[0]
        while x<y do
            c := x^
            (x++)^ := y^
            (y--)^ := c
        od
        i++
    until not(t[t[0]])
    return i
end

proc rotate(int n) =
    int c
    int i

    c := s[0]
    i := 1
    while i<=n do
        s[i-1] := s[i]
        i++
    od
    s[n] := c
end

proc tk(int n) =
    int i
    int f
    [0:16]int c

    i := 0
    clear c

    while i<n do
        rotate(i)
        if c[i]>=i then
            c[i++] := 0
            nextloop
        fi
        c[i]++
        i := 1
        oddx := inot oddx
        if s[0] then
            f := (s[s[0]]|flip()|1)
            if f>maxflips then
                maxflips := f
            fi
            checksum +:= (oddx|-f|f)
        fi
    od
end

proc main=
    int i

    max_n := 11
    i := 0
    while i<max_n do
        s[i] := i
        i++
    od
    tk(max_n)
    printf("%lld\nPfannkuchen(%lld) = %lld\n",checksum,max_n,maxflips)
end
