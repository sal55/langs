global icl pcstart			!start of icl block
global icl pccurr			!point to current icl op
global icl pcend			!point to last allocated iclrec
global int pcalloc			!number of iclrecs allocated
byte pcfixed				!whether code is fixed up
int pcseqno
int pcneedfntable			!whether kgetnprocs etc are used

int initpcalloc=65536

const pcelemsize = iclrec.bytes

global ichar longstring					!used in stropnd
global int longstringlen
global ichar errormess

global int mcldone

global proc icl_start(int nunits=0)=
!returns a descriptor to the global tables
!at the moment little is done with the descriptor, except to have something
!tangible to pass back to the caller of the API. There is no mechanism
!to allow multiple, active sets of icltables

	pcalloc:=initpcalloc

	if nunits then				!use approx alloc of 10% more
		nunits:=nunits*9/8		!approx expected number of icl ops
		while pcalloc<nunits do
			pcalloc*:=2
		od
	fi

	pcstart:=pcm_allocz(pcalloc*pcelemsize)
	pcend:=pcstart+pcalloc-8

	pccurr:=pcstart-1
	pcfixed:=0
	pcseqno:=0
	pcneedfntable:=0

	mlabelno:=0
	mcldone:=0
end

global proc icl_end=
	if pccurr>=pccurr and pccurr.opcode<>kendprogram then
		genpc(kendprogram)
	fi	
end

proc extendiclblock=
	int newpcalloc, lengthused
	icl newpcstart

	newpcalloc:=pcalloc*2
	lengthused:=pccurr-pcstart+1

	newpcstart:=pcm_alloc(pcelemsize*newpcalloc)

	memcpy(newpcstart,pcstart, lengthused*pcelemsize)
	pcm_clearmem(newpcstart+lengthused,(newpcalloc-lengthused)*pcelemsize)

	pccurr:=newpcstart+(pccurr-pcstart)
	pcend:=newpcstart+newpcalloc-8

	pcm_free(pcstart,pcalloc*pcelemsize)

	pcstart:=newpcstart
	pcalloc:=newpcalloc
end

global function newicl:icl =
	if pccurr>=pcend then
		extendiclblock()
	fi

	++pccurr
	pccurr.pos:=mlineno
	return pccurr
end

global proc genpc(int opcode, icl p=nil) =
	static int seq

	if p=nil then
		p:=newicl()
	fi

	p.opcode:=opcode
	P.SEQ:=++SEQ

end

global proc genpc_x(int opcode, int x, icl p=nil) =

	if p=nil then
		p:=newicl()
	fi

	p.opcode:=opcode
	p.x:=x
end

global proc genpc_xy(int opcode, int x,y, icl p=nil) =

	if p=nil then
		p:=newicl()
	fi

	p.opcode:=opcode
	p.x:=x
	p.y:=y
end

global function genpc_int(int a)icl p=
	p:=newicl()
	p.value:=a
	p.opndtype:=int_opnd
	return p
end

global function genpc_real(real x)icl p=
	p:=newicl()
	p.xvalue:=x
	p.opndtype:=real_opnd
!GERROR("GRI")
	p.r64index:=getrealindex(x)
	return p
end

global function genpc_realimm(real x)icl p=
	p:=newicl()
	p.xvalue:=x
	p.opndtype:=realimm_opnd
	return p
end

global function genpc_real32(real x)icl p=
	p:=newicl()
	p.xvalue32:=x
	p.opndtype:=real32_opnd
!GERROR("GRI")
	p.r32index:=getreal32index(x)
	return p
end

global function genpc_string(ichar s)icl p=
	p:=newicl()
	p.svalue:=pcm_copyheapstring(s)
	p.opndtype:=string_opnd
!GERROR("GRI")
	p.strindex:=getstringindex(s)

	return p
end

global function genpc_strimm(ichar s)icl p=
	p:=newicl()
	p.svalue:=pcm_copyheapstring(s)
	p.opndtype:=strimm_opnd

	return p
end

global function genpc_label(int a)icl p=
	p:=newicl()
	p.labelno:=a
	p.opndtype:=label_opnd
	return p
end

global function genpc_mem(symbol d)icl p=
	p:=newicl()
	if d.atvar and d.equivvar then
		d:=d.equivvar.def
	fi
	p.def:=d

	p.opndtype:=mem_opnd
	return p
end

global function genpc_memaddr(symbol d)icl p=
	p:=newicl()
	if d.atvar and d.equivvar then
		d:=d.equivvar.def
	fi
	p.def:=d

	p.opndtype:=memaddr_opnd
	return p
end

global function genpc_data(ref byte s, int length)icl p=
	p:=newicl()
	p.svalue:=s			! assume already saved on heap
	p.opndtype:=data_opnd
	p.pcat:=blockcat
	p.psize:=length

	return p
end

global proc genpc_comment(ichar s)=
	genpc(kcomment,genpc_strimm(s))
end

global function genpc_name(ichar s)icl=
	return genpc_mem(icl_makesymbol(s))
end

global function genpc_nameaddr(ichar s)icl=
	return genpc_memaddr(icl_makesymbol(s))
end

global function genpc_assem(ref void code)icl p=
	p:=newicl()
	p.asmcode:=code
	p.opndtype:=assem_opnd
	return p
end

global function icl_makesymbol(ichar s)symbol d =
	d:=addnamestr(s)
	return d
end

global func strpmode(int cat, size=0, signedx)ichar=
	static [32]char str
!	int dprec@signed
	int dprec:=signedx

	strcpy(str, "")

	case cat
	when intcat then
		strcat(str, (signedx|"i"|"u"))
		strcat(str, strint(size*8))
	when realcat then
!		strcat(str, (dprec|"r64"|"r32"))
		strcat(str, (dprec|"r64"|"r32"))
	when blockcat then
		strcat(str, "block:")
		strcat(str, strint(size))
	else
		strcat(str, "---")
	esac

	&.str
end

global func strpmode_m(int m)ichar =
	int cat:=ttcat[m]

	if cat=realcat then
		strpmode(realcat, ttsize[m], m=tr64)
	else
		strpmode(cat, ttsize[m], ttsigned[m])
	fi
end

global proc icl_settype(int t,size=0)=
!	pccurr.pmode:=t
	pccurr.psize:=size
	pccurr.pcat:=ttcat[t]
	if pccurr.pcat=realcat then
		pccurr.pwide:=t=tr64
	else
		pccurr.psigned:=ttsigned[t]
	fi
end

global proc icl_setxy(int x,y)=
	pccurr.x:=x
	pccurr.y:=y
end

global proc icl_setscale(int scale)=
	pccurr.scale:=scale
end

global proc icl_setoffset(int offset)=
	pccurr.extra:=offset
end

global proc icl_addoffset(int offset)=
	pccurr.extra+:=offset
end

global proc icl_setincr(int n)=
	pccurr.stepx:=n
end

global proc icl_setnargs(int n)=
	pccurr.nargs:=n
end

global proc icl_setnvariadics(int n)=
	pccurr.nvariadics:=n
end

global proc icl_setalign(int n)=
	pccurr.align:=n
end

global proc icl_setoldtype(int t)=
!	pccurr.oldcat:=stdcat[t]
	pccurr.oldcat:=ttcat[t]
	pccurr.oldsize:=ttsize[t]
	if pccurr.oldcat=realcat then
		pccurr.oldwide:=t=tr64
	else
		pccurr.oldsigned:=ttsigned[t]
	fi
end

global function icl_writeiclfile(ichar filename)int=
	ref strbuffer d

	d:=writeallicl()

	return writefile(filename,d.strptr,d.length)
end

global proc perror(ichar mess)=
	perror_s(mess, nil)
end

global proc perror_s(ichar mess, param=nil)=
	print "ICL error:",mess
	if param then
		print ":",param
	fi

	stop 1
end

global function getbasename(ichar s)ichar t=
	t:=s+strlen(s)-1
	while t>s and (t-1)^<>'.' do
		--t
	od

	return t
end
