!hello

global proc writeexports(ichar basefile, modulename)=
end
