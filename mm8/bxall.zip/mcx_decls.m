

global type mclopnd = ref mclopndrec

global record mclopndrec =
!	ref pstrec labeldef	!nil, or handle of strec for label
	union
		symbol def
		i64 value		!immediate value
		r64 xvalue		!immediate or memory real (depends on .mode)
		ichar svalue	!immediate string
		int labelno
		int sysfn
		struct
			i32 tempno
			byte lasttemp		!set to 1 if .islast applied to the temp
		end
	end

	u32 size			! usually one of 1/2/4/8, but can also be string/data length
	i32 offset			! additional offset to memory operands
	byte scale			! should be 1/2/4/8
	byte mode			!a_reg, a_imm, a_mem etc
	byte valtype		!int_val etc

	byte reg			!0, or main register
	byte regix			!0, or index register
end

!value types associated with a_imm or a_mem modes (not all combos valid):
global enumdata [0:]ichar valtypenames =
	(no_val=0,		$),		!no operand
	(int_val,		$),		!immediate int
	(real_val,		$),		!immediate real (as data) or mem (code)
	(string_val,	$),		!immediate (data) or label (code)
	(def_val,		$),		!var/proc name as imm or mem
	(label_val,		$),		!label index; imm/mem
	(name_val,		$),		!immediate string must be output as an unquoted name
	(temp_val,		$),		!index of pclopnd temp (later becomes ptr to descriptor?)
	(data_val,		$),		!data string; always immediate
end

global type mcl = ref mclrec

global record mclrec = !$caligned
	ref mclrec lastmcl, nextmcl
	mclopnd a,b
	byte c
	byte opcode
	byte cond
	byte spare1
	u32 seqno
	union
		u32 mpos
		u32 lineno				!used by aa assembler
	end
	u32 spare2

!	union
!		[r0..r15]byte regfreed		!1 indicates work-register freed after this instr
!		pair regfreedpr
!	end
end

global enumdata []ichar mclnames, []byte mclnopnds, []byte mclcodes, []byte mclauto =

	(m_procstart,		$,		0,		0,		0),
	(m_procend,			$,		0,		0,		0),
	(m_comment,			$,		0,		0,		0),
!	(m_blank,			$,		0,		0,		0),
!	(m_deleted,			$,		0,		0,		0),
	(m_labelname,		$,		0,		0,		0),
	(m_define,			$,		0,		0,		0),
	(m_definereg,		$,		0,		0,		0),
	(m_definetemp,		$,		0,		0,		0),
	(m_trace,			$,		0,		0,		0),
	(m_endx,			$,		0,		0,		0),

	(m_label,			$,		1,		0,		0),
	(m_nop,				$,		0,		0x90,	0),
!	(m_param,			$,		1,		0,		0),
!	(m_assembly,		$,		1,		0,		0),
!	(m_proc,			$,		1,		0,		0),

	(m_mov,				$,		2,		0,		0),
	(m_push,			$,		1,		0,		0),
	(m_pop,				$,		1,		0,		0),
	(m_lea,				$,		2,		0,		0),
	(m_cmovcc,			$,		2,		0,		0),

	(m_movd,			$,		2,		0,		2),
	(m_movq,			$,		2,		0,		0),

	(m_movsx,			$,		2,		0,		0),
	(m_movzx,			$,		2,		0,		0),
	(m_movsxd,			$,		2,		0,		0),

	(m_call,			$,		1,		0xE8,	0),
	(m_ret,				$,		0,		0xC3,	0),
	(m_leave,			$,		0,		0xC9,	0),
	(m_retn,			$,		1,		0,		0),

	(m_jmp,				$,		1,		0xE9,	0),
	(m_jmpcc,			$,		1,		0,		0),
	(m_xchg,			$,		2,		0,		0),

	(m_adc,				$,		2,		2,		0),
	(m_sbb,				$,		2,		3,		0),
	(m_imul,			$,		1,		5,		0),
	(m_mul,				$,		1,		4,		0),
	(m_imul2,			$,		2,		0,		0),
	(m_imul3,			$,		3,		0,		0),

	(m_idiv,			$,		1,		7,		0),
	(m_div,				$,		1,		6,		0),

	(m_and,				$,		2,		0x04,	0),
	(m_or,				$,		2,		0x01,	0),
	(m_xor,				$,		2,		0x06,	0),
	(m_test,			$,		2,		0,		0),

	(m_cmp,				$,		2,		0x07,	0),

	(m_shl,				$,		2,		0x04,	0),
	(m_sar,				$,		2,		0x07,	0),
	(m_shr,				$,		2,		0x05,	0),
	(m_rol,				$,		2,		0x00,	0),
	(m_ror,				$,		2,		0x01,	0),
	(m_rcl,				$,		2,		0x02,	0),
	(m_rcr,				$,		2,		0x03,	0),

	(m_neg,				$,		1,		3,		0),
	(m_not,				$,		1,		2,		0),

	(m_inc,				$,		1,		0,		0),
	(m_dec,				$,		1,		1,		0),

	(m_cbw,				$,		0,		0,		0),
	(m_cwd,				$,		0,		0,		0),
	(m_cdq,				$,		0,		0,		0),
	(m_cqo,				$,		0,		0,		0),
	(m_setcc,			$,		1,		0,		0),

	(m_bsf,				$,		2,		0xBC,	0),
	(m_bsr,				$,		2,		0xBD,	0),

	(m_shld,			$,		2,		0xA4,	0),
	(m_shrd,			$,		2,		0xAC,	0),

	(m_sqrtss,			$,		2,		0x51,	2),
	(m_sqrtsd,			$,		2,		0x51,	0),

	(m_add,				$,		2,		0,		1),
	(m_addss,			$,		2,		0x58,	2),
	(m_addsd,			$,		2,		0x58,	0),

	(m_sub,				$,		2,		5,		1),
	(m_subss,			$,		2,		0x5C,	2),
	(m_subsd,			$,		2,		0x5C,	0),

	(m_mulss,			$,		2,		0x59,	2),
	(m_mulsd,			$,		2,		0x59,	0),

	(m_divss,			$,		2,		0x5E,	2),
	(m_divsd,			$,		2,		0x5E,	0),

	(m_comiss,			$,		2,		0,		2),
	(m_comisd,			$,		2,		0x2F,	0),
	(m_ucomisd,			$,		2,		0x2E,	0),

	(m_xorps,			$,		2,		0x57,	2),
	(m_xorpd,			$,		2,		0x57,	0),

	(m_andps,			$,		2,		0x54,	2),
	(m_andpd,			$,		2,		0x54,	0),

	(m_pxor,			$,		2,		0xEF,	0),
	(m_pand,			$,		2,		0xDB,	0),

	(m_cvtss2si,		$,		2,		0,		0),
	(m_cvtsd2si,		$,		2,		0,		0),

	(m_cvttss2si,		$,		2,		0,		0),
	(m_cvttsd2si,		$,		2,		0,		0),

	(m_cvtsi2ss,		$,		2,		0,		0),
	(m_cvtsi2sd,		$,		2,		0,		0),

	(m_cvtsd2ss,		$,		2,		0,		0),
	(m_cvtss2sd,		$,		2,		0,		0),

	(m_movdqa,			$,		2,		0x66,	0),
	(m_movdqu,			$,		2,		0xF3,	0),

	(m_pcmpistri,		$,		3,		0x63,	0),
	(m_pcmpistrm,		$,		3,		0x62,	0),

	(m_fld,				$,		1,		0,		0),
	(m_fst,				$,		1,		2,		0),
	(m_fstp,			$,		1,		3,		0),

	(m_fild,			$,		1,		0,		0),
	(m_fist,			$,		1,		2,		0),
	(m_fistp,			$,		1,		3,		0),

	(m_fadd,			$,		0,		0xC1,	0),
	(m_fsub,			$,		0,		0xE9,	0),
	(m_fmul,			$,		0,		0xC9,	0),
	(m_fdiv,			$,		0,		0xF9,	0),
	(m_fsqrt,			$,		0,		0xFA,	0),
	(m_fsin,			$,		0,		0xFE,	0),
	(m_fcos,			$,		0,		0xFF,	0),
	(m_fsincos,			$,		0,		0xFB,	0),
	(m_fptan,			$,		0,		0xF2,	0),
	(m_fpatan,			$,		0,		0xF3,	0),
	(m_fabs,			$,		0,		0xE1,	0),
	(m_fchs,			$,		0,		0xE0,	0),

	(m_minss,			$,		2,		0x5D,	2),
	(m_minsd,			$,		2,		0x5D,	0),
	(m_maxss,			$,		2,		0x5F,	2),
	(m_maxsd,			$,		2,		0x5F,	0),

	(m_db,				$,		1,		0,		0),
	(m_dw,				$,		1,		0,		0),
	(m_dd,				$,		1,		0,		0),
	(m_dq,				$,		1,		0,		0),
	(m_ascii,			$,		1,		0,		0),
	(m_asciiz,			$,		1,		0,		0),
!	(m_ddoffset,		$,		1,		0,		0),

!	(m_segment,			$,		1,		0,		0),
	(m_isegment,		$,		0,		0,		0),
	(m_zsegment,		$,		0,		0,		0),
	(m_csegment,		$,		0,		0,		0),

	(m_align,			$,		1,		0,		0),
	(m_resb,			$,		1,		1,		0),
	(m_resw,			$,		1,		2,		0),
	(m_resd,			$,		1,		4,		0),
	(m_resq,			$,		1,		8,		0),

	(m_xlat,			$,		0,		0xD7,	0),
	(m_loopnz,			$,		1,		0xE0,	0),
	(m_loopz,			$,		1,		0xE1,	0),
	(m_loopcx,			$,		1,		0xE2,	0),
	(m_jecxz,			$,		1,		0xE3,	0),
	(m_jrcxz,			$,		1,		0xE3,	0),

	(m_cmpsb,			$,		0,		0,		0),
	(m_cmpsw,			$,		0,		0,		0),
	(m_cmpsd,			$,		0,		0,		0),
	(m_cmpsq,			$,		0,		0,		0),

	(m_rdtsc,			$,		0,		0x31,	0),
	(m_popcnt,			$,		2,		0,		0),
	(m_bswap,			$,		1,		0,		0),

	(m_finit,			$,		0,		0,		0),

	(m_fldz,			$,		0,		0xEE,	0),
	(m_fld1,			$,		0,		0xE8,	0),
	(m_fldpi,			$,		0,		0xEB,	0),
	(m_fld2t,			$,		0,		0xE9,	0),
	(m_fld2e,			$,		0,		0xEA,	0),
	(m_fldlg2,			$,		0,		0xEC,	0),
	(m_fldln2,			$,		0,		0xED,	0),

	(m_cpuid,			$,		0,		0,		0),

	(m_halt,			$,		0,		0xF4,	0),
end

global enumdata [0:]ichar regnames, [0:]byte regcodes =
	(rnone=0,	$,	0),			!
	(r0,		$,	0),			!d0 rax
	(r1,		$,	10),		!d1 r10
	(r2,		$,	11),		!d2 r11
	(r3,		$,	7),			!d3 rdi
	(r4,		$,	3),			!d4 rbx
	(r5,		$,	6),			!d5 rsi
	(r6,		$,	12),		!d6 r12
	(r7,		$,	13),		!d7 r13
	(r8,		$,	14),		!d8 r14
	(r9,		$,	15),		!d9 r15
	(r10,		$,	1),			!d10 rcx
	(r11,		$,	2),			!d11 rdx
	(r12,		$,	8),			!d12 r8
	(r13,		$,	9),			!d13 r9
	(r14,		$,	5),			!d14 rbp
	(r15,		$,	4),			!d15 rsp

	(r16,		$,	4),			!b0h ah
	(r17,		$,	7),			!b1h bh
	(r18,		$,	5),			!b10h ch
	(r19,		$,	6),			!b11h dh

	(xr0,		$,	0),			!xmm0
	(xr1,		$,	1),
	(xr2,		$,	2),
	(xr3,		$,	3),
	(xr4,		$,	4),
	(xr5,		$,	5),
	(xr6,		$,	6),
	(xr7,		$,	7),
	(xr8,		$,	8),
	(xr9,		$,	9),
	(xr10,		$,	10),
	(xr11,		$,	11),
	(xr12,		$,	12),
	(xr13,		$,	13),
	(xr14,		$,	14),
	(xr15,		$,	15),

end

global const rframe = r14
global const rstack = r15

global enumdata [0:]ichar condnames, [0:]ichar asmcondnames,
		[0:]int asmrevcond =

	(ov_cond=0,	"ov",	"o",		nov_cond),
	(nov_cond,	"nov",	"no",		ov_cond),

	(ltu_cond,	"ltu",	"b",		geu_cond),
	(geu_cond,	"geu",	"ae",		ltu_cond),

	(eq_cond,	"eq",	"z",		ne_cond),
	(ne_cond,	"ne",	"nz",		eq_cond),

	(leu_cond,	"leu",	"be",		gtu_cond),
	(gtu_cond,	"gtu",	"a",		leu_cond),

	(s_cond,	"s",	"s",		ns_cond),
	(ns_cond,	"ns",	"ns",		s_cond),

	(p_cond,	"p",	"p",		np_cond),
	(np_cond,	"np",	"np",		p_cond),

	(lt_cond,	"lt",	"l",		ge_cond),
	(ge_cond,	"ge",	"ge",		lt_cond),

	(le_cond,	"le",	"le",		gt_cond),
	(gt_cond,	"gt",	"g",		le_cond),

	(flt_cond,	"flt",	"b",		fge_cond),		!special floating point codes
	(fge_cond,	"fge",	"ae",		flt_cond),
	(fle_cond,	"fle",	"be",		fgt_cond),
	(fgt_cond,	"fgt",	"a",		fle_cond)
end

global const z_cond = eq_cond
global const nz_cond = ne_cond

global enumdata [0:]ichar segmentnames =
	(no_seg=0,		$),
	(code_seg,		$),
	(idata_seg,		$),
	(zdata_seg,		$),
	(rodata_seg,	$),
	(impdata_seg,	$),
end

global enumdata [0:]ichar reftypenames =
	(extern_ref=0,		$),		!is external
	(fwd_ref,			$),		!not yet reached
	(back_ref,			$),		!has been reached
end

global enumdata [0:]ichar opndnames_ma =
	(a_none=0,	$),
	(a_reg,		$),		! Ri
	(a_imm,		$),		! d including def name, label etc
	(a_mem,		$),		! any memory modes: [d], [R], [R*4+R2+d+imm] etc
end

global int lababs32, lababs64
global int labneg32, labneg64
global int labmask63, laboffset64
global int labzero
global int kk0used=0

global ref mclrec mccode, mccodex		!genmc adds to this linked list

global int currsegment=0

global mclopnd dstackopnd
global mclopnd dframeopnd

global [r0..r15,1..8]mclopnd regtable

global [-128..64]mclopnd frameregtable

global record constrec =
	union
		int value
		real xvalue
		ichar svalue
	end
	ref constrec nextconst
	int labelno
end

global ref constrec cstringlist
global ref constrec vstringlist
global ref constrec creallist
global ref constrec cr32list

global int lab_funcnametable
global int lab_funcaddrtable
global int lab_funcnprocs

global record relocrec =			!informal version
	ref relocrec nextreloc
	int reloctype
	int offset
	int stindex
end

global record fwdrec =
	ref fwdrec nextfwd
	i32 offset
	i16 reltype
	i16 seg
end


!record used for expanding buffers. Expansion is not automatic: buffercheck(n)
!is needed at strategic points to ensure that are at least n bytes left
global record dbuffer =
	ref byte pstart
	union
		ref byte pcurr
		ref u16 pcurr16
		ref u32 pcurr32
		ref u64 pcurr64
	end
	ref byte pend
	int alloc
end

global int ss_zdatalen
global ref dbuffer ss_zdata			!used for error checking only (should be empty at end)
global ref dbuffer ss_idata
global ref dbuffer ss_code

global ref relocrec ss_idatarelocs
global ref relocrec ss_coderelocs

global int ss_nidatarelocs
global int ss_ncoderelocs

global const init_ss_symbols=32768				!globaled to coff
global ref []symbol ss_symboltable
global int ss_nsymbols
global int ss_symboltablesize

global ref[]symbol labeldeftable

global int aaseqno
global int aapos

global [1..8]byte regmodes=(tu8, tu16, 0, tu32, 0,0,0, tu64)

global ref mclrec mclprocentry
global ref mclrec mce_oldmccodex, mce_lastmcl, mce_nextmcl		!used by reset/setmclentry
global ref mclrec mcf_oldmccodex, mcf_lastmcl, mcf_nextmcl		!used by reset/setmclentry for frame setup

global byte fpcheckunusedlocals

global record riprec =
	ref riprec next
	u32 offset			!within code segment, offset of d32 field
	i32 immsize			!0,1,4 bytes of trailing imm field
end

global ref riprec riplist
global byte mcldone
global byte exedone

global const ctarget=0


global const mclpresent=1
