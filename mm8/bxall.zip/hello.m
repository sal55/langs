


proc main=
	println "Hello, World"
end
