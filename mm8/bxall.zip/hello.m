


proc main=
	println "Hello, World",1234
end
