int currlineno
int currfileno

strbuffer sbuffer
^strbuffer dest=&sbuffer

strbuffer v
^strbuffer ds=&v

const tab1="\t"
const tab2="\t\t"

const tabstr="|--"


!const fshowsymbols=1
const fshowsymbols=0

global proc printst(filehandle f, ^strec p, int level=0)=
	^strec q

	printstrec(f, p, level)

	q:=p.deflist

	while q<>nil do
		printst(f, q, level+1)
		q:=q.nextdef
	od
end

proc printstrec(filehandle f, ^strec p, int level)=
	strec dd
	^byte q
	int col, offset, n
	const tabstr="    "
	[256]char str

	gs_init(ds)

	print @str, p
	dsstr(str)
	dsstr(" ")

	offset:=0
	to level do
		dsstr(tabstr)
		offset+:=4
	od
	dsstr(":")

	gs_leftstr(ds, p.name, 28-offset, '-')
	gs_leftstr(ds, namenames[p.nameid], 12, '.')

	col:=gs_getcol(ds)
	dd:=p^


	dsstr("[")
	dsstr(scopenames[p.scope])
	dsstr(" ")
	if p.isimport then
		dsstr("Imp ")
	end

	if dd.isstatic then
		dsstr("Stat")
	end

	if dd.nameid=paramid and dd.byref then
		dsstr("byref")
	end

	if dd.caligned then
		dsstr(" $caligned")
	end
	if dd.maxalign then
		dsstr(" maxalign:")
		dsint(dd.maxalign)
		dsstr(" ")
	end
	if dd.optional then
		dsstr("Opt ")
	end
	if dd.varparams then
		dsstr("Var:")
		dsint(dd.varparams)
		dsstr(" ")
	end

	if dd.moduleno then
		if dd.nameid<>subprogid then
			print @str, "Modno#",,dd.moduleno
		else
			print @str, "Subno#",,dd.subprogno
		end
		dsstr(str)
	end

	if dd.used then
		dsstr("U ")
	end

!	if dd.isthreaded then
!		dsstr("Threaded ")
!	end
!

	dsstr("]")
	gs_padto(ds, col+10, '=')

	if p.owner then
		fprint @str, "(#)", p.owner.name
		gs_leftstr(ds, str, 18, '-')
	else
		gs_leftstr(ds, "()", 18, '-')
	end

	case p.mode
	when tvoid then
		dsstr("Void ")
	else
		GS_STRINT(DS, P.MODE)
		GS_STR(DS, ":")

		dsstr(strmode(p.mode))
		dsstr(" ")
	end case

	case p.nameid
	when fieldid, paramid then
		dsstr(" Offset:")
		dsint(p.offset)
		if p.mode=tbitfield then
			dsstr(" Bitoffset:")
			dsint(p.bitoffset)
			dsstr(":")
			dsint(p.bitfieldwidth)
		end

		sprintf(str, "%.*s", int(p.uflags.ulength), &p.uflags.codes)
		print @str, p.uflags.ulength:"v", ichar(&p.uflags.codes):".*"
		dsstr(" UFLAGS:")
		dsstr(str)
		dsstr("-")
		dsint(p.uflags.ulength)

		if p.code then
			dsstr("/:=")
			gs_strvar(ds, strexpr(p.code))
		end

	when procid then

		dsstr("Index:")
		dsint(p.fnindex)

		dsstr(" Nret:")
		dsint(p.nretvalues)

	when dllprocid then
		dsstr("Index/PCaddr:")
		dsint(p.fnindex)
		if p.truename then
			dsstr(" Truename:")
			dsstr(p.truename)
		end

	when staticid then
		if p.code then
			dsstr("=")
			gs_strvar(ds, strexpr(p.code))
		end

	when frameid then
		if p.code then
			dsstr(":=")
			gs_strvar(ds, strexpr(p.code))
		end

	when constid then
		dsstr("Const:")
		gs_strvar(ds, strexpr(p.code))

!	when enumid then
!		dsstr("Enum:")
!		dsint(p.index)
!	when dllmoduleid then
!		dsstr("DLL#:")
!		dsint(p.dllindex)
	end case

	if p.atfield then
		dsstr(" @")
		dsstr(p.equivfield.name)
		dsstr(" +")
		dsint(p.equivoffset)
	end
	if p.equivvar then
		gs_strvar(ds, strexpr(p.equivvar))
	end

!dsstr(" Module# ")
!dsint(p.moduleno)
!
!	dsstr(" Lineno: ???")
!dsint(p.lineno iand 16777215)

	gs_println(ds, f)

	case p.nameid
	when constid, frameid, staticid, macroid then
		if p.code then
			printunit(p.code, dev:f)
		end
	end case
end

global proc printstflat(filehandle f)=
symbol p
println @f, "GLOBAL SYMBOL TABLE:"

for i:=0 to hashtable.upb-1 do
	p:=hashtable[i]
	if p=nil then nextloop end

!	IF P.NEXTDUPL=NIL THEN NEXTLOOP FI

	case p.symbol
	when namesym then
		println @f, i:"5", p, p.name, symbolnames[p.symbol],,":",,namenames[p.nameid]
		p:=p.nextdupl
		while p do
			print @f, "     ", p, p.name, symbolnames[p.symbol],,":",,namenames[p.nameid]
			if p.owner then
				fprint @f, " (From #:#)", p.owner.name, namenames[p.owner.nameid]
			end

			println @f

			p:=p.nextdupl
		od
	end case
od
end

global proc printcode(filehandle f, ichar caption)=
	symbol p

	p:=stlinear
	while p, p:=p.nextlinear do
		if p.nameid=procid then
			print @f, p.name,,"=", (p.scope|"Sub", "Prog", "Exp"|"Mod")
			if p.owner.nameid=typeid then
				print @f, " in record", p.owner.name
			end
			println @f
			printunit(p.code, 0, 1, dev:f)
			println @f
		end
	end
end

global proc printunit(^unitrec p, int level=0, number=0, filehandle dev=nil)=
!p is a tagrec
	^unitrec q
	^strec d
	int t
	ichar idname
	i64 a
	r32 x32
	static int cmpchain=0

	if p=nil then
		return
	end

	if p.pos then
		currlineno:=getlineno(p.pos)
		currfileno:=p.fileno
	end

!	print @dev, p, ":"
	print @dev, getprefix(level, number, p)

	idname:=jtagnames[p.tag]
	print @dev, idname,,": "

	case p.tag
	when jname then
		d:=p.def

		print @dev, d.name
!		print @dev, d.name, namenames[d.nameid]

!		if d.code then
!			print @dev, " {",,jtagnames[d.code.tag],,"}"
!		end

!		print @dev, " ",,getdottedname(d)!, q
!		print @dev, (p.dottedname|" {Dotted}"|"")

		if p.avcode then
			print @dev, " AV:", p.c:"c"
		end

!		print @dev, " Moduleno:", p.moduleno
!
!!		if p.avcode then print @dev, " AV:", char(p.avcode) end
!		if p.avcode then print @dev, " AV:", char(p.avcode), $ end

	when jlabeldef then
		println @dev, p.def.name, p.def.labelno

	when jconst then
		t:=p.mode
		a:=p.value
		if t=trefchar then
			if p.slength>256 then
				print @dev, """",,"1:(longSTR)", """ *",,p.slength
			elsif p.slength then
				print @dev, """",,p.svalue,,""" *",,p.slength
			else
				print @dev, """"""
			end

		elsecase ttbasetype[t]
		when ti64, ti32, ti16, ti8 then print @dev, i64(a)
		when tu64, tu32, tu16, tu8 then print @dev, u64(a)
		when tc64, tc8 then print @dev, chr(a)

		when tr32, tr64 then
			print @dev, p.xvalue
		when tref then
			if p.value then
				print @dev, "#",,p.value, P.SLENGTH
			else
				print @dev, "NIL"
			end
		when tbool then
			print @dev, (p.value|"True"|"False")
		when tarray then
			print @dev, "<ARRAY>", =P.STRTYPE, =P.SLENGTH
		else
			println =typename(t), typename(ttbasetype[t])
			PRINT @DEV, "<PRINTUNIT BAD CONST PROBABLY VOID"
		end
		print @dev, " ",,typename(t)
		if p.isastring then
!			print @dev, " <isstr>"
			fprint @dev, " <isstr>(#)", p.strtype
		end

	when jtypeconst then
		print @dev, typename(p.value)

	when jbitfield then
		print @dev, bitfieldnames[p.bfcode]+3

	when jconvert, jtypepun, jtruncate, jfix, jfloat, jfwiden, jfwiden, jfnarrow then
		print @dev, " From mode:", strmode(p.oldmode)

	when jmakelist then
		print @dev, "Len:", p.length

	when jdot then
		print @dev, "Offset:", p.offset

	when jindex, jptr then

	when jexit, jredo, jnext then
		print @dev, "#",,p.loopindex

	when jsyscall then
		print @dev, sysfnnames[p.fnindex]+3

	when joperator then
		print @dev, pclnames[p.pclop]

!	when jmakeset then
	when jcmpchain then
		for i to p.cmpgenop.len do
			if p.cmpgenop[i]=0 then exit end
			print @dev, ccnames[p.cmpgenop[i]],," "
		od
	end case

	if p.isconst then
		print @dev, " Is const"
!	else
!		print @dev, " Not const"
	end

	case p.tag
	when jbin, jbinto, junary, junaryto, jincr then
		if p.pclop then
			fprint @dev, " <#>", pclnames[p.pclop]
			if p.pclop in [kmaths, kmaths2] then
				fprint @dev, " (#)", mathsnames[p.mathsop]
			end
		else
			fprint @dev, " no-op"
		end
	when jprop then
		fprint @dev, " Prop<#>", propnames[p.propcode]
	when jcmp then
		fprint @dev, " <#>", ccnames[p.condcode]
	end case


	println @dev

	for i to jsubs[p.tag] do
		printunitlist(dev, p.abc[i], level+1, i)
	od
end

proc printunitlist(filehandle dev, ^unitrec p, int level=0, number=0)=
	if p=nil then return end

	while p do
		printunit(p, level, number, dev)
		p:=p.nextunit
	od
end

func getprefix(int level, number, ^unitrec p)ichar=
!combine any lineno info with indent string, return string to be output at start of a line
	static [1024]char str
	[1024]char indentstr
	[16384]char modestr
	ichar isexpr

	indentstr[1]:=0
	if level>10 then level:=10 end

	to level do
		strcat(indentstr, tabstr)
	od

	isexpr:="S"
	if jisexpr[p.tag] then isexpr:="E" end

	case p.tag
	when jif, jswitch, jcase, jselect then
		if p.mode=tvoid then
			isexpr:="S"
		end
	end case

!	fprint @modestr, "# #:#", isexpr, (p.resultflag|"RES"|"---"), strmode(p.mode)
	fprint @modestr, "# #:#", isexpr, (p.resultflag|"RES"|"---"), strmode(p.mode)
	modestr[256]:=0

	strcat(modestr, "-----------------------------")
	modestr[17]:=' '
	modestr[18]:=0

	str[1]:=0
	strcpy(str, getlineinfok())
	strcat(str, modestr)
	strcat(str, indentstr)
	strcat(str, strint(number))
!	if prefix^ then
		strcat(str, " ")
!	end

	return str
end

func getlineinfok:ichar=			!GETLINEINFO
	static [40]char str

	fprint @str, "# # ", CURRFILENO:"Z2", currlineno:"z4"
	return str
end

global proc printmodelist(filehandle f)=
	int mbase
	static ichar tab="\t"

!	PRINTLN @F, =NTYPENAMES
!	FOR I TO NTYPENAMES DO
!		PRINTLN @F, I, TYPENAMES[I].DEF.NAME
!	OD
!	PRINTLN @F
!
	println @f, "MODELIST", ntypes

	for m:=0 to ntypes do
		println @f, m:"4", strmode(m)
		mbase:=ttbasetype[m]

		println @f, tab, "Basetype:", mbase, strmode(mbase)
		println @f, tab, "ttname:", ttname[m]
		println @f, tab, "ttnamedef:", ttnamedef[m], (ttnamedef[m]|ttnamedef[m].name|"-")
		println @f, tab, "Target:", strmode(tttarget[m])
		println @f, tab, "Size:", ttsize[m], "Sizeset", ttsizeset[m]
		fprintln @f, "# Bounds: #..#  Length:#", tab, ttlower[m], ttlower[m]+ttlength[m]-1, ttlength[m]
		if mbase=ttuple then
			print @f, tab, "Mult:"
			for i to ttlength[m] do print @f, strmode(ttmult[m, i]),," " od
			println @f
		end
		println @f, tab, "Signed:", ttsigned[m]
		println @f, tab, "Isreal:", ttisreal[m]
		println @f, tab, "Isinteger:", ttisinteger[m]
		println @f, tab, "Isshort:", ttisshort[m]
		println @f, tab, "Isref:", ttisref[m]
		println @f
	od
end

global proc showprojectinfo(filehandle dev)=
	imodule pm
	isubprog ps
	static ichar tab="    "
	ichar s
	byte isfirst, ismain

	println @dev, "Project Structure:"
	println @dev, "---------------------------------------"
	println @dev, "Modules", nmodules
	for i to nmodules do
		pm:=modules[i]

		if i>1 and pm.subprogno<>modules[i-1].subprogno then
			println @dev
		end
		ps:=subprogs[moduletosub[i]]

			isfirst:=ps.firstmodule=i
			ismain:=ps.mainmodule=i

			if isfirst and ismain then s:="hm"
			elsif isfirst then s:="h "
			elsif ismain then s:="m "
			else s:="  " 
			end

			print @dev, tab, i:"2", s, 
			pm.name:"16jl", "Sys:", pm.issyslib, 
			"Sub:", subprogs[pm.subprogno].name, "Fileno:", pm.fileno

		if pm.stmacro then
			print @dev, " Alias:", pm.stmacro.name
		end
		if pm.stmain then
			print @dev, $, pm.stmain.name, ":", scopenames[pm.stmain.scope], pm.stmain
		end
		if pm.ststart then
			print @dev, $, pm.ststart.name, ":", scopenames[pm.ststart.scope], pm.ststart
		end

		println @dev
	od
	println @dev

	println @dev, "Subprograms", nsubprogs, =mainsubprogno
	for i to nsubprogs do
		ps:=subprogs[i]
		println @dev, tab, i, ps.name, "Sys:", ps.issyslib!, =PS.STSUBPROG

		if ps.firstmodule then
			print @dev, tab, tab
			for j:=ps.firstmodule to ps.lastmodule do
				print @dev, $, modules[j].name, "(", MODULES[J].STSUBPROG, ")"
			od
			println @dev
		end
	od
	println @dev

	println @dev, "Sourcefiles", nsourcefiles
	ifile pf
	for i to nsourcefiles do
		pf:=sources[i]
		fprintln @dev, "  #:  Name=# File=# Path=# Spec=# Size=#", 
			i:"2", pf.name:"jl16", pf.filename:"jl18", pf.path:"20jl", pf.filespec:"30jl", pf.size:"7"
	od
	println @dev

	println @dev, "Link files", nlibfiles
	for i to nlibfiles do
		println @dev, tab, libfiles[i]:"16jl"
	od
	println @dev
end

global proc showlogfile=
	[256]char str
	filehandle logdev
	int size
	^strbuffer ss

	return unless fshowdiags

	logdev:=fopen(logfile, "w")

	if fshowmodules then showprojectinfo(logdev) end

	if fshowasm and passlevel>=mcl_pass then
		if ctarget then
			println @logdev, "PROC CLANG"
			addtolog(changeext(outfile, "c"), logdev)
		else
			println @logdev, "PROC ASSEMBLY"
			addtolog(changeext(outfile, "asm"), logdev)
		end
	end

	if fshowpcl and passlevel>=pcl_pass then
		println @logdev, "PROC PCL"
		addtolog("PCL", logdev)
	end

	if fshowast3 and passlevel>=type_pass then addtolog("AST3", logdev) end
	if fshowast2 and passlevel>=name_pass then addtolog("AST2", logdev) end
	if fshowast1 and passlevel>=parse_pass then addtolog("AST1", logdev) end

	if fshowpst and passlevel>=pcl_pass then
		println @logdev, "PROC PST"
		addtolog("PST", logdev)
	end

	if fshowst then
		showsttree("SYMBOL TABLE", logdev)
	end
	if fshowstflat then
		showstflat("FLAT SYMBOL TABLE", logdev)
	end
!
	if fshowtypes then
		printmodelist(logdev)
	end

	size:=getfilesize(logdev)
	fclose(logdev)

	if size then
CPL "PRESS KEY..."; if OS_GETCH()=27 then stop end
		print @str, "\\m\\ed.bat ", logfile

		if checkfile("mm.m") then
			os_execwait(str, 0, nil)
		else
			println "Diagnostic outputs written to", logfile
		end
	end
end

proc showstflat(ichar caption, filehandle f)=
	println @f, "PROC", caption
	printstflat(f)
	println @f
end

proc showsttree(ichar caption, filehandle f)=
	println @f, "PROC", caption
	printst(f, stprogram)
	println @f

	println @f, "Proc List:"

	symbol d:=stlinear

	while d, d:=d.nextlinear do
		fprintln @f, "#	#.# (#) Mod:", d, d.owner.name, d.name:"20jl", namenames[d.nameid], 
			d.moduleno
	od
	println @f, "End\n"

	println @f, "DLL Proc List:"
	for i to ndllproctable do
		d:=dllproctable[i]
		fprintln @f, "#	#.# (#) Mod:", d, d.owner.name, d.name:"20jl", namenames[d.nameid], 
			d.moduleno
	od
	println @f, "End\n"
end

global proc showast(ichar filename)=
	filehandle f

	f:=fopen(filename, "w")
	return unless f

	println @f, "PROC", filename
	printcode(f, "")
	println @f
	fclose(f)
end

global proc printsymbol(^tokenrec lp)=
	tokenrec l
	l:=lp^

	printf("%-18s", symbolnames[l.symbol])

	switch l.symbol
	when namesym then
		printstrn(l.symptr.name, l.symptr.namelen)

		if l.subcode then
			fprint " [#]", symbolnames[l.subcode]
		end

	when intconstsym then
		case l.subcode
		when tint then print l.value, "int"
		when tword then print l.uvalue, "word"
		else print l.value
		end case

	when realconstsym then
		print l.xvalue

	when stringconstsym then
		print """"
		printstr(l.svalue)
		print """", strlen(l.svalue)

	when charconstsym then
		print "'"
		printstr(l.svalue)
		print "'"

	when assignsym, addrsym, ptrsym, rangesym, 
		andlsym, orlsym, eqsym, cmpsym, addsym, subsym, 
		mulsym, divsym, idivsym, iremsym, iandsym, iorsym, ixorsym, shlsym, shrsym, 
		minsym, maxsym, powersym then
		print symbolnames[l.symbol], =L.SUBCODE
!	elsif l.subcode then
!	ELSE
	elsif l.subcode then
		fprint "SUBCODE:", l.subcode
!	fprint "#", symbolnames[l.subcode]
	end

	println $, =lx.fileno

end

proc showtime(ichar caption, int t)=
	fprintln "# # ms # %", caption:"12jl", t:"5", (t*100.0)/compiletime:"5.1jr"
end

global proc showtimings=
	endclock:=os_clock()
	compiletime:=endclock-startclock
!
	showtime("Load:", 		loadtime)
	showtime("Parse:", 		parsetime)
	showtime("Resolve:", 	resolvetime)
	showtime("Type:", 		typetime)
	showtime("PCL:", 		pcltime)
	showtime("MCL:", 		mcltime)
	showtime("SS:", 			sstime)
	showtime("EXE:", 		exetime)
	println "-----------------------------"
	showtime("Total:", 		compiletime)
end

proc dsstr(ichar s)=
	gs_str(ds, s)
end

proc dsint(int a)=
	gs_strint(ds, a)
end

