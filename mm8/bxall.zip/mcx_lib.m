const fuseregtable=1
!const fuseregtable=0

global const targetsize=8

!global int mclseqno
global int mclseqno
global int NMCLOPND

[-1..10]mclopnd smallinttable
[20]symbol nametable
int nnametable

global macro isframex(d) = (d.nameid in [frameid, paramid])

global proc mclinit(int bypass=0)=
	mclopnd a
	int r, s

	if mclrec.bytes>64 then ABORTPROGRAM("MCLREC>64B") fi

	for r:=r0 to r15 do
		regtable[r, 1]:=genreg0(r, 1)
		regtable[r, 2]:=genreg0(r, 2)
		regtable[r, 4]:=genreg0(r, 4)
		regtable[r, 8]:=genreg0(r, 8)
	od

	for i in frameregtable.bounds do
		a:=newmclopnd()
		a.mode:=a_mem
		a.reg:=rframe
		a.size:=8
		a.offset:=i
		frameregtable[i]:=a
	end

	dframeopnd:=genreg(rframe, 8)
	dstackopnd:=genreg(rstack, 8)

	initmcdest()

	setsegment('C')

	lab_funcnametable:=0
	lab_funcaddrtable:=0

!bypass is used when directly using mcl api (eg. from an external assembler)
!then genmcl(), called from pcl functions, is a no-op
	if bypass then
		mcldone:=1
	fi
end

proc start=
	for i in smallinttable.bounds do
		smallinttable[i]:=genint0(i, 8)
	od
end

global proc initmcdest=
!reset mccode/mccodex
!called should have saved any values from last linked list 
	mccode:=mccodex:=nil
!	clear rtsproclabels
end

EXPORT proc genmc(int opcode, mclopnd a=nil, b=nil)=		!used in do_mcl/assem in host
	ref mclrec m, oldm
	int labno

	m:=pcm_allocnfz(mclrec.bytes)

	m.opcode:=opcode
	m.seqno:=++mclseqno
	m.mpos:=mmpos

	m.a:=a
	m.b:=b

	case opcode
!	when m_lea then
!		if b and b.valtype=def_val then
!!*!			b.def.addrof:=1
!		fi
	when m_label then
		labno:=a.labelno

	when m_mov then				!change to movd/q if needed
		if a.reg>=xr0 or (b and b.reg>=xr0) then
			m.opcode:=(a.size=8|m_movq|m_movd)
		fi
	elsecase mclauto[opcode]
	when 1 then					!add/addss/addsd etc
		if a.mode=a_reg and a.reg>=xr0 then
			++m.opcode			!addss etc
			if a.size=8 then
				++m.opcode
			fi
		elsif b.mode=a_reg and b.reg>=xr0 then
			++m.opcode			!addss etc
			if b.size=8 then
				++m.opcode
			fi
		fi

	when 2 then					!sqrtss/sqrtsd etc
		if a.mode=a_reg and a.reg>=xr0 and a.size=8 then
			++m.opcode			!sqrtsd etc
		elsif b and b.mode=a_reg and b.reg>=xr0 and b.size=8 then
			++m.opcode			!sqrtsd etcc
		fi

	esac

	if mccode then
		m.lastmcl:=mccodex
		mccodex.nextmcl:=m
		mccodex:=m
	else
		mccode:=mccodex:=m
	fi
end

global proc genmc_cond(int opcode, cond, mclopnd a=nil, b=nil)=
	genmc(opcode, a, b)
	mccodex.cond:=cond
end

global proc genmc_label(int opcode, labelno)=
	genmc(opcode, genlabel(labelno))
end

global proc genmc_string(int opcode, ichar s)=
!as genmc but uses a single immediate string operand
	genmc(opcode, genstring(s))
end

global proc genmc_def(int opcode,  symbol d)=
!as genmc but uses a single immediate string operand
	genmc(opcode, genmem(d))
end

global proc genmc_defaddr(int opcode,  symbol d)=
!as genmc but uses a single immediate string operand
	genmc(opcode, genmemaddr(d))
end

global proc genmc_int(int opcode,  int a)=
!as genmc but uses a single immediate string operand
	genmc(opcode, genint(a))
end

global proc genmc_name(int opcode,  ichar name)=
!as genmc but uses a single immediate string operand
	genmc(opcode, genname(name))
end

func newmclopnd:mclopnd a=
!	a:=pcm_allocz(mclopndrec.bytes)
	a:=pcm_allocnfz(mclopndrec.bytes)

++NMCLOPND
	return a
end

global func duplopnd(mclopnd a)mclopnd=
	mclopnd b
!	b:=pcm_alloc(mclopndrec.bytes)
	b:=pcm_allocnfz(mclopndrec.bytes)
	b^:=a^
	return b
end

EXPORT func genindex(int areg=0, ireg=0, scale=1, offset=0, size=0, labno=0, symbol def=nil)mclopnd=
!construct a mem address mode
	mclopnd a
	a:=newmclopnd()

	a.mode:=a_mem
	a.reg:=areg

!	if areg=rframe or ireg=rframe then usedset.[rframe]:=1 fi

	a.regix:=ireg
	a.scale:=scale
	a.size:=size

	a.offset:=offset

	if labno then
		a.value:=labno
		a.valtype:=label_val
	elsif def then
		a.def:=def
!		++def.nrefs
		a.valtype:=def_val
		if isframex(def) then
			a.reg:=rframe
!			usedset.[rframe]:=1
		fi
	fi

	return a
end

global proc mcomment(ichar s)=
!if not debugmode then return fi
!	if s=nil or s^=0 then
!		genmc(m_blank)
!	else
		genmc_string(m_comment, s)
!	fi
end

global func genstring(ichar s, int length=-1)mclopnd=
	mclopnd a
	a:=newmclopnd()
	a.mode:=a_imm

	if length<0 then
		length:=strlen(s)
	fi

	a.svalue:=pcm_alloc(length+1)
	memcpy(a.svalue, s, length)
	(a.svalue+length)^:=0

	a.valtype:=string_val
	a.size:=8
	return a
end

global func gendata(ref byte p, int length)mclopnd=
	mclopnd a
	a:=newmclopnd()
	a.mode:=a_imm
	a.svalue:=pcm_copyheapstringn(p, length)

	a.valtype:=data_val
	a.size:=length
	return a
end

global func genname(ichar s)mclopnd=
	[64]char str
	mclopnd a
	a:=newmclopnd()
	a.mode:=a_imm
	a.svalue:=pcm_copyheapstring(s)
	a.valtype:=name_val
	a.size:=8

	return a
end

global proc setsegment(int seg, align=1)=
!seg is 'D', 'Z', 'C', 'R' for data, zdata, code, rdata
	int opc, oldalign

	if seg<>currsegment then
		case seg
		when 'I' then opc:=m_isegment
		when 'Z' then opc:=m_zsegment
		when 'C' then opc:=m_csegment
		when 'R' then MERROR("CAN'T DO RODATA SEG")
		else
			MERROR("BAD SEG CODE")
		esac
		if mccodex and mccodex.opcode in [m_isegment, m_zsegment, m_csegment] then
			mccodex.opcode:=opc
		else
			genmc(opc)
		fi

		currsegment:=seg
	fi

	if align>1 then
		if mccodex.opcode=m_align then
			oldalign:=mccodex.a.value
			if oldalign>=align then return fi
		fi
		genmc(m_align, genint(align))
	fi
end

global func changeopndsize(mclopnd a, int size)mclopnd=
	mclopnd b

	if a.size<>size then
		if a.reg<xr0 and a.mode=a_reg then
			b:=regtable[a.reg, size]
		else
			b:=duplopnd(a)
			b.size:=size
		fi
		return b
	fi
	return a
end

global func applyoffset(mclopnd a, int offset, int size=0)mclopnd=
!astr is an asm operand
!add possible byte offset
	mclopnd b

	if offset=0 and size=0 then
		return a
	fi
	b:=duplopnd(a)
	b.offset+:=offset
	if size then
		b.size:=size
	fi

	return b
end

global func genlabel(int x)mclopnd a=
!x is a label index
!generate immediate operand containing label
	a:=newmclopnd()
	a.mode:=a_imm

!	if x=0 then x:=++mlabelno fi
	a.value:=x
	a.valtype:=label_val
	a.size:=8

	return a
end

global func genlabelmem(int x)mclopnd a=
!x is a label index
!generate immediate operand containing label

	a:=genlabel(x)
	a.mode:=a_mem
	return a
end

EXPORT func genmemaddr(symbol d)mclopnd=
	mclopnd a

!*!	d.addrof:=1
!	++d.nrefs

	a:=newmclopnd()
	a.mode:=a_imm

	a.def:=d
!	++d.nrefs
	a.valtype:=def_val
	a.size:=8

	return a
end

global func genint(i64 x, int size=8)mclopnd a=

	if x in -1..10 and size=8 then
		return smallinttable[x]
	fi

	a:=newmclopnd()
	a.mode:=a_imm

	case size
	when 1 then x iand:=255
	when 2 then x iand:=65535
	when 4 then x iand:=0xffff'ffff
	esac

	a.value:=x
	a.valtype:=int_val
	a.size:=size

	return a
end

global func genint0(i64 x, int size=8)mclopnd a=
	a:=newmclopnd()
	a.mode:=a_imm

	a.value:=x
	a.valtype:=int_val
	a.size:=size

	return a
end

global func genrealmem(r64 x, int size=8)mclopnd a=
	a:=newmclopnd()
	a.mode:=a_mem

	if size=8 then
		a.value:=getrealindex(x)
	else
		a.value:=getr32index(x)

	fi
	a.valtype:=label_val
	a.size:=size
	return a
end

global func genrealimm(r64 x, int size=8)mclopnd a=
	a:=newmclopnd()
	a.mode:=a_imm
	a.xvalue:=x
	a.valtype:=real_val
	a.size:=size
	return a
end

global func genmem(symbol d, int size=0)mclopnd a=
	int reg

	if size=0 then
		size:=min(ttsize[d.mode], 8)
	fi

!	IF D.MX and ttsize[d.mode]=d.mx.size then
!!CPL "REUSE D.MX"
!		return d.mx
!	fi

	if d.reg then
!		if stdfloat[d.mode] then
!			return genxregvar(d)
!		else
!			return genregvar(d, mode)
!		fi
	fi

	reg:=rnone
	if isframex(d) then
!		if not foptim and (int(d.offset) in -128..64) and ttsize[d.mode]=8 then
!			return frameregtable[d.offset]
!		fi

		reg:=rframe
!		usedset.[rframe]:=1

	fi

	a:=newmclopnd()
	a.mode:=a_mem
	a.reg:=reg
	a.def:=d
!	++d.nrefs
	a.valtype:=def_val

	if size then
		a.size:=size
	else
		a.size:=min(ttsize[d.mode], 8)
	fi
	if a.size=0 then a.size:=8 fi

!	IF D.MX=NIL THEN D.MX:=A FI

	return a
end

global func genreg0(int reg, size=8)mclopnd a=
	a:=newmclopnd()
	a.mode:=a_reg
	a.reg:=reg
	a.size:=size

IF SIZE=0 THEN MERROR("1:SIZE=0") FI
	return a
end

EXPORT func genxreg(int reg, size=8)mclopnd=
	mclopnd a

!	if xreg=rnone then xreg:=++currxregno fi
	a:=newmclopnd()

	a.mode:=a_reg
	a.reg:=reg
	a.size:=size
IF SIZE=0 THEN MERROR("2:SIZE=0") FI
	return a
end

global func genreg(int reg, int size=8)mclopnd a =

!	if stdfloat[mode] and reg>=xr0 then
	if reg>=xr0 then
		genxreg(reg, size)
	else
		if size=0 then size:=8 fi
!		usedset.[reg]:=1

!IF REG IN R10..R13 THEN REGSET[REG]:=1 FI

		if fuseregtable then
			return regtable[reg, size]
		fi
		return genreg0(reg, size)
	fi
end

!global func genregi(int reg, mode=ti64)mclopnd a =
!!	if fuseregtable then
!!		return regtable[reg, stdsize[mode]]
!!	fi
!	return genreg0(reg, stdsize[mode])
!end

global func genireg(int reg, size=8, offset=0)mclopnd=
	mclopnd a

	a:=newmclopnd()
	a.mode:=a_mem
	a.reg:=reg
	a.size:=size
	a.offset:=offset

	return a
end

global func roundsizetg(int size)int=
!make sure size is round up to next multiple of targetsize (4 or 8)
	if size iand 7=0 then return size fi
	return size+(8-(size iand 7))
end

global proc merroropnd(ichar mess, int opndtype)=
	fprintln "MCL Opnd not supported: # (#) [#]", mess, opndnames_ma[opndtype]
	PRINTLN
	STOP 1
!	stopcompiler(sourcefilepaths[mmpos>>24], mmpos iand 16777215)
end

global func mcreatefwdlabel:int =
	return ++mlabelno
end

global proc mdefinefwdlabel(int lab) =
	genmc(m_label, genlabel(lab))
end

global func mdefinelabel:int =
	genmc(m_label, genlabel(++mlabelno))
	mlabelno
end

global func genextname(ichar s)mclopnd=
	[64]char str
	symbol d
	static [20]symbol table
	static int ntable

	strcpy(str, s)
!	str[strlen(s)]:=0			!lose final *

	d:=findnamesym(str)

	if not d then
		d:=pcm_allocnfz(strec.bytes)

		d.name:=pcm_copyheapstring(str)
		d.nameid:=dllprocid
		d.isimport:=1
		addnamesym(d)
	fi

	return genmemaddr(d)
end

!global func genregvar(symbol d, int mode)mclopnd a=
!	a:=genreg(d.reg, mode)
!!	isregvar[d.reg]:=1
!
!	return a
!end

!global func genxregvar(symbol d)mclopnd a=
!	a:=genxreg(d.reg)
!!	isxregvar[d.reg]:=1
!
!	return a
!end

global func getprimreg(mclopnd ax)int =
!get primary reg value; only one should be active
!return 0 if no regs
!//error if both regs are active

	if ax.reg then
!		if ax.regix then merror("getprim?") fi
		ax.reg
	else
		ax.regix	!0 if no regs used
	fi
end

global proc pushslots(int nslots)=
	pushstack(nslots*8)
	mstackdepth+:=nslots
end

global proc popslots(int nslots)=
	popstack(nslots*8)
	mstackdepth-:=nslots
end

global proc pushstack(int n)=
	if n then
		genmc(m_sub, dstackopnd, genint(n))
	fi
end

global proc popstack(int n)=
	if n then
		genmc(m_add, dstackopnd, genint(n))
	fi
end

global func getstringindex(ichar s)int=
	if s=nil then			!assume nil
		kk0used:=++mlabelno
		return kk0used
	fi

	if cstringlist and eqstring(cstringlist.svalue, s) then
		return cstringlist.labelno
	fi

	return addconst(cstringlist, cast(s))
end

global func addconst(ref constrec &clist, int value)int=
	ref constrec p

	p:=pcm_allocnfz(constrec.bytes)
	p.value:=value

	p.labelno:=++mlabelno
	p.nextconst:=clist
	clist:=p
	return mlabelno
end

global func getrealindex(real x)int=
	return addconst(creallist, cast@(x, int))
end

global func getr32index(real x)int=
	return addconst(cr32list, cast@(x, int))
end

!global func ispoweroftwo(i64 x)int=
EXPORT func ispoweroftwo(i64 x)int=
!when x is a power of two, and is at least 2, then return the power (ie. equiv number of shifts)
!otherwise return zero when x is negative, 0, 1, not a power of two, or more than 2**31
	i64 a
	int n

	a:=1
	n:=0
	to 60 do
		++n
		a:=a<<1
		if a=x then
			return n
		fi
	od
	return 0
end

global proc axerror(ichar mess)=
	CPL "AX ERROR:", mess, "AASEQ:", aaseqno
	CPL
	STOP 1

end

global func findnamesym(ichar s)symbol d=
!search for s in cache of named symbols

	for i to nnametable do
		if eqstring(s, nametable[i].name) then
			return nametable[i]
		fi
	od
	nil
end

global proc addnamesym(symbol d)=
!add new name symbol, which should be unique

	if nnametable<nametable.len then
		nametable[++nnametable]:=d
	else
		merror("Ext nametab overflow")
	fi
end

global proc callproc(ichar cpname, name, int lineno)=
RETURN
end

func genstringx(ichar s)mclopnd=
	genlabelmem(getstringindex(s))
end

global proc clearreg(mclopnd ax)=
	if ax.size=8 then
		ax:=changeopndsize(ax, 4)
	fi
	genmc(m_xor, ax, ax)
end

global proc genstringtable=
	ref constrec p

	return unless cstringlist

	mcomment("String Table")

	setsegment('I', 8)

!	if kk0used then
!		genmc(m_label, genlabel(kk0used))
!		gendb(0)
!	fi

	p:=cstringlist
	while p, p:=p.nextconst do
		genmc_label(m_label, p.labelno)
		genstring_db(p.svalue, strtype:0)
	od
end

global proc mcomm(ichar s, t="", u="")=
	[256]char str
	print @str, s, t, u
	mcomment(pcm_copyheapstring(str))
end

global proc genstring_db(ichar s, int length=-1, strtype)=
!string table generated in ax pass, so is just text
!this is target-specific, so should really be moved
!strtype should be zero for a normal string, then a zero-terminator is added.
	int i, c, seqlen
	ref char seq

	if length=-1 then
		length:=strlen(s)
	fi

	if length=0 then
		gendb(0)
		return
	fi

	seqlen:=0

	to length do
		c:=s++^
!		if c<32 or c>=127 or c='\"' then
		if c<32 or c>=127 or c in ['\"', '\\'] then
			if seqlen then
				gendbstring(seq, seqlen)
				seqlen:=0
			fi
			gendb(c)
		else
			if seqlen=0 then
				seqlen:=1
				seq:=s-1
			else
				++seqlen
			fi
		fi
	od
	if seqlen then
		gendbstring(seq,seqlen)
	fi
	if strtype=0 then
		gendb(0)
	fi
end

proc gendb(int a)=
	genmc(m_db,genint(a))
end

proc gendbstring(ichar s, int length)=
!string is printable, and doesn't include double quotes
	genmc(m_db,genstring(s,length))
end

global func gentemp(int n, size)mclopnd a=
!pcl temps are used to spill pcl operands from a register
!they will always be 64 bits

	int reg

	if pcltempflags[n] then			!already in use
		return changeopndsize(pcltempopnds[n], size)
	fi

	a:=newmclopnd()
	a.mode:=a_mem
	a.reg:=rframe
!	usedset.[rframe]:=1
	a.valtype:=temp_val
	a.size:=size
	a.tempno:=n

	pcltempopnds[n]:=a
	pcltempflags[n]:=1

	return a
end

global proc genrealtable=
	ref constrec p

	return unless creallist or cr32list

	mcomment("Real Table")
	setsegment('I',8)
	p:=creallist
	while p, p:=p.nextconst do
		genmc(m_label,genlabel(p.labelno))

!		if p.xvalue=infinity then
!			genmc(m_dq, genint(u64@(p.xvalue)))
!		else
!			genmc(m_dq, genrealimm(p.xvalue, 8))
!		fi
		if p.xvalue=infinity then
			genmc(m_dq, mgenint(u64@(p.xvalue)))
		else
			genmc(m_dq, mgenint(u64@(p.xvalue)))
		fi
	od

	mcomment("Real32 Table")
	p:=cr32list
	p:=cr32list
	while p, p:=p.nextconst do
		genmc(m_label, genlabel(p.labelno))
		if p.xvalue=infinity then
			genmc(m_dd, genint(i32@(r32(p.xvalue))))
		else
			genmc(m_dd, mgenrealimm(p.xvalue, tr32))
		fi

	od
end

global proc merror(ichar mess,ichar param="")=
	int lineno
	ichar filename, sourceline

!	if igetmsourceinfo then
!		lineno:=igetmsourceinfo(mmpos, filename, sourceline)
!		CPL =LINENO
!		CPL =FILENAME
!	else
CPL "NO LINE INFO"
		lineno:=0
		filename:="?"
!	fi

!	if currfunc then
!		println "Proc:", currfunc.name
!	fi

	fprintln "MCL Error: # (#) on Line: # in #",mess,param, lineno, filename
OS_GETCH()
	stop 1
!	pcerrorstop(filename, lineno)
end

global func getbasename(ichar s)ichar t=
	t:=s+strlen(s)-1
	while t>s and (t-1)^<>'.' do
		--t
	od

	return t
end

!global func gentemp(int n, mode)mclopnd a=
!!pcl temps are used to spill pcl operands from a register
!!they will always be 64 bits
!	mgentemp(n, stdsize[mode])
!end

global func mgenint(i64 x, int mode=ti64)mclopnd a=
	genint(x, ttsize[mode])
end

global func mgenrealmem(r64 x, int mode=tr64)mclopnd a=
	genrealmem(x, ttsize[mode])
end

global func mgenrealimm(r64 x, int mode=tr64)mclopnd a=
	genrealimm(x, ttsize[mode])
end

global func mgenmem(symbol d, int mode=tvoid)mclopnd a=
	genmem(d, ttsize[mode])
end

global func mgenreg(int reg, int mode=tu64)mclopnd a =
	genreg(reg, ttsize[mode])
end

global func mgenireg(int reg, mode=tu64, offset=0)mclopnd=
	genireg(reg, ttsize[mode])
end

global func mgentemp(int n, mode)mclopnd a=
	gentemp(n, ttsize[mode])
end

