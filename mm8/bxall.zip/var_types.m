
include "bb_types.m"

global tabledata() [0:]ichar catnames =
	(voidcat=0,		$),			! Not set
	(d64cat,		$),			! Any 64-bit value other than x64, including pointers
	(x32cat,		$),			! 32-bit float
	(x64cat,		$),			! 64-bit float when can't be treated as d64
	(shortcat,		$),			! 8/16/32-bit types, maybe zero/sign-extended to d64
	(widecat,		$),			! 128-bit types occupying 2 regs or stack slots
	(blockcat,		$),			! 64-bit pointer to block data
	(varcat,		$),			! 64-bit pointer to variant
	(bitcat,		$),
end

