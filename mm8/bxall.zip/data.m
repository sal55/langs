record date=
	int d,m,y
end

record rec =
!byte bb
	int a
	ref int p
end

int abc
int def=1234

[]int xx=(10,20,30,40)

[]date yy = ((10,20,30), (40,50,60))

[]ref int zz = (&abc, &abc, &abc)

ichar sss="one two three four five"

[]char ttt=s"one two three four five"

[]char uuu=b"one two three four five"

[]ichar table=("alpha", "bravo", "charlie")
[,7]char table2=(b"alphaxx", b"bravoxx", b"charlie")
[,9]byte table3=((10,20,30,4,5,6,7,8,9), (40,50,60,7,8,9,10,11,12))
[,8]byte table4=((10,20,30,4,6,7,8,9), (40,50,60,7,9,10,11,12))

!rec mixed = (12, 1234, &abc)
rec mixed = (1234, &abc)


proc main=
	static int aaa=100
	int bbb:=200
end

