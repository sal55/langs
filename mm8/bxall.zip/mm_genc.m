record stlinkrec =
	symbol def
	ref stlinkrec nextsymbol
end

ref stlinkrec allsymbols, allsymbolsx

int nallprocs,nexports

ichar cfilename

global proc codegen_il(ichar outfile)=

!	if fverbose>1 then
		println "Generating C code:"
!	fi

	cfilename:=outfile
	allsymbols:=allsymbolsx:=nil
	scansymbol(stprogram)

	gs_init(dest)

	ccinitline()

!	do_infoheader(cfilename);
!	unless msyslevel=0 then
		do_cheader(cfilename);
!	end

	do_alltypes();
	do_allprocdecls();

	do_allvars();
	do_allprocdefs();

	cclinecomment("********** End of C Code **********")

end

proc do_infoheader(ichar cfilename)=
	imodule pm
	int i

	ccstrline("/*")
	ccstrline("  M to C  Whole Program Translator")
	ccstr("  Input:  "); ccstr(inputfile); ccstrline(" plus imported modules")
	ccstr("  Output: "); ccstr(cfilename); ccstrline(" (this file, or renamed from that)")
	ccstrline("          File represents entire program")

	ccstrline("  Target: C 64-bit")

	if clinux then
		ccstrline("  OS:     Linux")
	else
		ccstrline("  OS:     Windows")
	fi

	ccstrline("")
	ccstrline("  Modules:")
	for i:=1 to nmodules do
		pm:=modules[i]

		ccstr("  Module ")
		ccint(i)
		ccstr(": ")
		ccstrline(pm.name)
	od
	ccstrline("")

	ccstrline("*********** Start of C Code **********/")
	ccblank()

end

proc do_cheader(ichar cfilename)=
	ccstrline(strinclude "cheader.m")

!	ccstrline("#if (UINTPTR_MAX<0xFFFFFFFFFFFFFFFF)")
!	ccstrline("	#error ""Need 64-bit target. Try -m64""")
!	ccstrline("#endif")

	ccsendline()
end

proc do_alltypes=
	ref stlinkrec p
	symbol d
	int i

	cclinecomment("Forward Struct Declarations")

	for i:=tlast to ntypes do
		if ttbasetype[i]=trecord and tttarget[i]=tvoid then
			do_typedef_fwd(ttnamedef[i])
		fi
	od
	ccblank()

	if ntypes>=tlast then
		cclinecomment("Struct Definitions")
	fi

	for i:=tlast to ntypes do
		if ttbasetype[i]=trecord and tttarget[i]=tvoid then
			do_typedef(ttnamedef[i])
		fi
	od

	ccblank()
end

proc scansymbol(symbol d)=
!collect top-level names into 'allsymbols'
!These are names at module level across the program, but also
!including functions in an importdll block.

	symbol e
	addsymbol(d)
	case d.nameid
	when procid, typeid, dllprocid then
		return
	esac

	e:=d.deflist

	while e do
		scansymbol(e)
		e:=e.nextdef
	od

end

proc addsymbol(symbol d)=
	ref stlinkrec p

	p:=pcm_alloc(stlinkrec.bytes)
	p.def:=d
	p.nextsymbol:=nil
	if allsymbols=nil then
		allsymbols:=p
	else
		allsymbolsx.nextsymbol:=p
	fi
	allsymbolsx:=p
end

proc do_typedef_fwd(symbol d)=
	if ttbasetype[d.mode]<>trecord then
		return
	fi
	genrecordfwd(d.mode)
end

proc do_typedef(symbol d)=
	if ttbasetype[d.mode]<>trecord then
		return
	fi
	genrecorddef(d.mode)
end

proc do_allprocdecls=
	ref stlinkrec p
	symbol d
!CPL "ALLPROCDDECLS"
	cclinecomment("PROCDECLS")
	p:=allsymbols
	while p do
!CPL =P
		d:=p.def
!CPL D.NAME
		case d.nameid
		when procid then
			do_procdecl(d)
		when dllprocid then
			do_procdecl(d)
		esac
		p:=p.nextsymbol
	od
	ccblank()
end

proc do_allvars=
	ref stlinkrec p
	symbol d
	cclinecomment("VARS")
	p:=allsymbols
	while p do
		d:=p.def
		case d.nameid
		when staticid then
			do_vardef(d)
		when dllvarid then
			do_dllvar(d)
		esac
		p:=p.nextsymbol
	od
	ccblank()
end

proc do_procdecl(symbol d)=
	if modules[d.moduleno].stmain=d then
		ccstrline("int main(int, char**);")
		return
	fi

	if d.code=nil then
		ccstr("extern ")
	elsif d.scope=module_scope then
		ccstr("static ")
	fi
	ccstr(strprocsig(d))
	ccstrline(";")
end

proc do_vardef(symbol d)=


	if d.nameid=staticid then
		ccstr("static ")
	fi

	ccstr(strmodec(d.mode,getfullnamec(d)))

	if d.code then
		ccstr(" = ")
		do_initdata(d.code)
	elsif d.name^='_' then
		if eqstring(d.name,"_fnnprocs") then
			writefn_nprocs()
		elsif eqstring(d.name,"_fnaddresses") then
			writefn_addresses()
		elsif eqstring(d.name,"_fnnames") then
			writefn_names()
		fi

	elsif d.atvar then
		gerror("MODULE@")
	fi

	ccstrline(";")
end

proc do_dllvar(symbol d)=
	ccstr("extern ")
	ccstr(strmodec(d.mode,d.name))
	ccstrline(";")
end

proc genprocdef(symbol p)=
	[256]char str
	symbol d
	int ismain,isstart

!	if eqstring(p.name,"start") then
!		ccstrline("// START")
!	fi

	if p.mode<>tvoid then
		if not checkblockreturn((p.code.tag=jreturn|p.code.a|p.code)) then
			gerror_s("C:Function needs explicit return: ",p.name)
		fi
	fi

	currproc:=p
	ismain:=isstart:=0

	case p
	when modules[p.moduleno].stmain then ismain:=1
	when modules[p.moduleno].ststart then isstart:=1
	esac

	if p.scope=module_scope then
		ccstr("static ")
	fi

!	if p.iscallback then
!		ccstr("CALLBACK ")
!	fi

	if ismain then
		do_maininit()
	else
		ccstr(strprocsig(p))
		ccstrline(" {")
		if isstart then
			do_startinit(p)
		fi
	fi

	d:=p.deflist

	while d do

		switch d.nameid
		when staticid,frameid then
			if d.used or d.code then
				genlocalvar(d) 
			fi
		when constid then
!		genconstdef(d)
		when paramid then
		when labelid then
		when typeid then
		when procid then
		when macroid then
		else
			fprint @&.str,"Can't output: # in # : #",d.name,p.name,namenames[d.nameid]
			gerror(&.str)
		end switch
		d:=d.nextdef
	od

!	if p.pdoswx then
!		doswitchx_table(p.pdoswx)
!	fi

	blocklevel:=0


!CPL "PROCDEF",JTAGNAMES[P.CODE.TAG]

	do_block(p.code, braces:0)

	if ismain then
		do_mainterm()
	fi
	cctab()
	ccstr("}")

	ccblank()
	ccblank()

end

proc do_maininit=
	symbol d

	ccstrline("int main(int _nargs, char** _args) {")
	case msyslevel
	when 1 then
		ccstrline("    msysminc$m$init(_nargs, (void*)_args);")
	when 2 then
		ccstrline("    msysc$m$init(_nargs, (void*)_args);")
	esac
	ccsendline()
	ccstrline("// call main-start() routines...")

	for i to nsubprogs when i<>mainsubprogno do
		d:=modules[subprogs[i].mainmodule].ststart
		docallproc(d)
	od
	d:=modules[subprogs[mainsubprogno].mainmodule].ststart
	docallproc(d)

	ccsendline()
end

proc do_startinit(symbol p)=
	symbol d
	int m, s, lead:=0

	m:=p.moduleno
	s:=p.subprogno

	if s=mainsubprogno and p.moduleno=subprogs[s].mainmodule then
		LEAD:=1
	elsif p.moduleno=subprogs[s].firstmodule then
		LEAD:=2
	fi

	if lead then
		for i to nmodules when moduletosub[i]=s and i<>m do
			d:=modules[i].ststart
			docallproc(d)
		od
	fi

	ccsendline()
end

proc do_mainterm=
	ccstrline("    return 0;")
end

proc writefn_nprocs=
	ccstr("=")
	ccint(nallprocs)
end

proc writefn_names=
	int i
	symbol d

	ccstrline("= {")
	nallprocs:=0

	for i:=1 to nmodules do
		d:=modules[i].stmodule.deflist

		while d do
			if d.nameid=procid then
				++nallprocs
				ccstr("(byte*)""",1)
				ccstr(d.name)
				ccstrline(""",")
			fi
			d:=d.nextdef
		od
	od
	ccstr("(byte*)""""}")
end

proc writefn_addresses=
	int i
	symbol d

	ccstrline("= {")


!	nallprocs:=0
!
!	for i:=1 to nmodules do
!		d:=modules[i].stmodule.deflist
!
!		while d do
!			if d.nameid=procid then
!				++nallprocs
!				ccstr("&",1)
!				if eqstring(d.name,"main") and d.moduleno=mainmoduleno then
!					ccstr("main")
!				else
!					ccstr(getprocname(d))
!				fi
!				ccstrline(",")
!			fi
!			d:=d.nextdef
!		od
!	od
	ccstr("0}")
end

proc genlocalvar(symbol d)=
	ichar prefix

	cctab(1)
	if d.nameid=staticid then
		ccstr("static ")
		ccstr(strmodec(d.mode,d.name))
		if d.code then
			ccstr(" = ")
			do_initdata(d.code)
		fi
	else
		ccstr(strmodec(d.mode,d.name))
	fi

	if d.code then

	elsif d.atvar then
		gerror_s("LOCAL@",d.name)
	fi

	ccstrline(";")
end

proc docallproc(symbol d)=
!call a simple proc, eg. start(), with no args
	return when d=nil

	ccstr(getfullnamec(d),1)
	ccstrline("();")
end

proc doswitchx_table(unit p)=
	ccstrline("//DOSWITCHX TABLE DEF;")

!*!	do_switchx(p, p.a, p.b, p.c, 1)
end

global func findhostfn(int opc)psymbol=
	nil
end

global proc pcl_reducetest=
end

global function checkblockreturn(unit p)int=
!p is any statement
!check p, or the last statement of a block, or the last statement of any
!nested block, a return, or is a unit yielding some value (as explicit return
!statement not needed)
! return 1/0 for return/not return
	unit e,wt
	int m,res

	if p=nil then return 0 fi

	m:=p.mode

	case p.tag
	when jreturn then			!that's an easy one...
		return 1
	when jstop then
		return 1
	when jif then
!CPL "CBR/IF", P.COMPACTIF
		IF NOT P.COMPACTIF THEN
			e:=p.b
			while e, e:=e.nextunit do
				if not checkblockreturn(e) then return 0 fi
			od

			return checkblockreturn(p.c)		!all branches must have a return
		FI

	when jblock then
		e:=p.a
		if e then
			while e and e.nextunit do
				e:=e.nextunit
			od
			return checkblockreturn(e)
		fi

	when jcase, jswitch, jdocase, jdoswitch, jdoswitchu then
!		p.ifretflag:=1
		wt:=p.b
		while wt do
			if not checkblockreturn(wt.b) then
				return 0
			fi

			wt:=wt.nextunit
		od

		return checkblockreturn(p.c)		!else

	when jassem then						!assume yes
		return 1
	esac

	if jisexpr[p.tag] and m<>tvoid then
		return 1							!any non-void expr allowed as return value
	else
		return 0
	fi
end

proc do_allprocdefs=
	ref stlinkrec p
	symbol d
	cclinecomment("PROCDEFS")
	p:=allsymbols
	while p do
!CPL =P
		d:=p.def
!CPL D.NAME
		if d.nameid=procid and d.code then
			genprocdef(d)
		fi
		p:=p.nextsymbol
	od
	ccblank()
end

