!type T = i64
type T = byte

function nsieve(int m0)int=
	int i,j,count,m
	ref[]T flags

	flags:=malloc((m0+1)*T.bytes)
	for i:=1 to m0 do
		flags^[i]:=1
	od

	count:=0

	m:=m0
	for i:=3 to m do
		if flags^[i] then
			++count
			j:=i+i
			while j<=m do
				if flags^[j] then
					flags^[j]:=0
				fi
				j:=j+i
			od
		fi
	od

	free(flags)

!	println "Primes up to ",m0,": ",count
	return count
end

proc main=
	int res

	to 1000'000 do
		res:=nsieve(1000)
	od

	cpl res

!	nsieve(3 million)
end
