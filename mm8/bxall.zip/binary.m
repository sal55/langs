!module mclib




int nallocs

record treenode=
	ref treenode lhs, rhs
	int dummy
end

function newtreenode(ref treenode lhs,rhs)ref treenode=
	ref treenode t

	t:=malloc(treenode.bytes)
!	t:=pcm_alloc(treenode.bytes)
!CPL =T
	++nallocs

	t.lhs:=lhs
	t.rhs:=rhs
	return t
end

function itemcheck(ref treenode tree)int=
	if tree.lhs then
		1+itemcheck(tree.lhs)-itemcheck(tree.rhs)
	else
		1
	fi
END

function bottomuptree(int depth)ref treenode=
	if depth>0 then
		return newtreenode(
				bottomuptree(depth-1),
				bottomuptree(Depth-1))
	else
		return newtreenode(nil,nil)
	fi
end

proc deletetree(ref treenode tree)=
	if tree.lhs then
		deletetree(tree.lhs)
		deletetree(tree.rhs)
	fi
	free(tree)
!	pcm_free(tree, treenode.bytes)
end

proc main=
	ref treenode stretchtree, longlivedtree, temptree
	int n,depth,mindepth,maxdepth,stretchdepth,check,iterations,i

	n:=18
	mindepth:=4
	if (mindepth+2)>n then
		maxdepth:=mindepth+1
	else
		maxdepth:=n
	fi
	stretchdepth:=maxdepth+1

	stretchtree:=bottomuptree(stretchdepth)
	println "Stretch tree of depth",stretchdepth,"\tcheck:",itemcheck(stretchtree)

	deletetree(stretchtree)
	longlivedtree:=bottomuptree(maxdepth)

	depth:=mindepth
	while depth<=maxdepth do
		iterations:=int(1)<<(maxdepth-depth+mindepth)
		check:=0
!CPL "DEPTH:",DEPTH," ITER:",ITERATIONS,"//",MAXDEPTH,DEPTH,MINDEPTH,MAXDEPTH-DEPTH+MINDEPTH
		for i:=1 to iterations do
			temptree:=bottomuptree(depth)
			check+:=itemcheck(temptree)
!  check:=check+itemcheck(temptree)
			deletetree(temptree)

		od
		println iterations,"\tTrees of depth",depth,"\tcheck:",check
		depth+:=2
! depth:=depth+2
	od
	println "long lived tree of depth",maxdepth,"\tcheck:",itemcheck(longlivedtree)
	println =nallocs,nallocs*treenode.bytes
end
