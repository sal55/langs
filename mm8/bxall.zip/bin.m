! C to M Converter

!importdll msvcrt =
!end


global int64 nallocs
record treenode =
    ref treenode leftx
    ref treenode rightx
    int64 item
end


!global function newtreenode(ref treenode leftx, rightx, int64 item)ref treenode =
!    ref treenode t
!
!    t := malloc(24)
!    ++nallocs
!    t^.leftx := leftx
!    t^.rightx := rightx
!    t^.item := item
!    return t
!end
!
global function itemcheck(ref treenode tree)int64 =
    if tree^.leftx=nil then
        return tree^.item
    else
        return tree^.item+itemcheck(tree^.leftx)-itemcheck(tree^.rightx)
    fi
end

!global function bottomuptree(int64 item, depth)ref treenode =
!    if depth>0 then
!        return newtreenode(bottomuptree(2*item-1,depth-1),bottomuptree(2*item,depth-1),item)
!    else
!        return newtreenode(nil,nil,item)
!    fi
!end
!
!global proc deletetree(ref treenode tree) =
!    if tree^.leftx then
!        deletetree(tree^.leftx)
!        deletetree(tree^.rightx)
!    fi
!    free(tree)
!end

global function cmain()int64 =
    ref treenode stretchtree
    ref treenode longlivedtree
    ref treenode temptree
    int64 n
    int64 depth
    int64 mindepth
    int64 maxdepth
    int64 stretchdepth
    int64 check
    int64 iterations
    int64 i

!    n := 14
!    mindepth := 4
!    if mindepth+2>n then
!        maxdepth := mindepth+1
!    else
!        maxdepth := n
!    fi
!    stretchdepth := maxdepth+1
!    stretchtree := bottomuptree(0,stretchdepth)
!    printf("Stretch tree of depth %d\tcheck: %d\n",stretchdepth,itemcheck(stretchtree))
!    deletetree(stretchtree)
!    longlivedtree := bottomuptree(0,maxdepth)
!    depth := mindepth
!    while depth<=maxdepth do
!!        iterations := 1<<maxdepth-depth+mindepth
!!        check := 0
!!        i := 1
!!        while i<=iterations do
!!            temptree := bottomuptree(i,depth)
!!            check := check+itemcheck(temptree)
!!            deletetree(temptree)
!!            temptree := bottomuptree(-i,depth)
!!            check := check+itemcheck(temptree)
!!            deletetree(temptree)
!!            ++i
!!        od
!!        printf("%d\tTrees of depth %d check: %d\n",iterations*2,depth,check)
!!        depth := depth+2
!    od
    printf("%s %d %s %d\n","long lived tree of depth",maxdepth,"\tcheck:",itemcheck(longlivedtree))
!    printf("%s %d %d\n","NALLOCS=",nallocs,nallocs*20)
    return 0
end

!proc main=
!!	stop cmain()
!!	cmain()
!end

