proc mainX=
!	PRINTLN "MAIN YB"
end

proc start=
	PRINTLN "START YB"
end
