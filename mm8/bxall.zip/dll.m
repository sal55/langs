export func testfn(int a, b, real c, d, int e, real f)int=

	println a,b,c,d,e,f

	return 666

end
