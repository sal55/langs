func fib(real n)real x =
	if n<2.0 then
		x:=n
	else
		x:=return fib(n-2)+fib(n-1)
	fi
 	x
end

proc main=
	for i to 40 do
		println fib(i)
	od
end
