global enumdata  [0:]ichar pstdnames,
        [0:]byte pstdsize,
		[0:]byte pstdsigned,
		[0:]byte pstdint,
		[0:]byte pstdfloat,
		[0:]byte pstdwide,
		[0:]byte pstdmin =				!minimum width for int types

!Ordering must match tx-codes in front-end
!    type         name       bits     sign int flt  wide  min
    (tvoid=0,     "void",       0,    0,	0,	0,	0,	0),

    (tr64,        "r64",        8,    0,	0,	1,	1,	0),
    (tr32,        "r32",        4,    0,	0,	1,	0,	0),
    (ti64,        "i64",        8,    1,	1,	0,	0,	ti64),
    (tu64,        "u64",        8,    0,	1,	0,	0,	tu64),
    (tc64,        "c64",        8,    0,	1,	0,	0,	tu64),

    (ti8,         "i8",          1,   1,	1,	0,	0,	ti64),
    (ti16,        "i16",         2,   1,	1,	0,	0,	ti64),
    (ti32,        "i32",         4,   1,	1,	0,	0,	ti64),
    (tu8,         "u8",          1,   0,	1,	0,	0,	tu64),
    (tu16,        "u16",         2,   0,	1,	0,	0,	tu64),
    (tu32,        "u32",         4,   0,	1,	0,	0,	tu64),

    (tblock,      "block",       8,   0,	0,	0,	0,	0),
    (tvector,     "vector",      8,   0,	0,	0,	0,	0),
end

global type psymbol = ^pstrec

global record pstrec = $caligned
!global record pstrec = $caligned
!global record pstrec =
	ichar name
	psymbol next
	psymbol nextparam
	psymbol nextlocal


	union
		pcl pcdata				!for idata: point kdata sequence
		pcl pccode				!for procs: entry point to function body code
		^proc dlladdr		!for imported functions
		^void staddr			!var statics: address
		psymbol cprocowner		!C target:var statics: owner proc
	end
	^fwdrec fwdrefs			!fwd ref chain

	byte nameid

	i32 offset

	byte isimport
	byte exported				!only for proc_id/static_id
	byte mode
	byte isentry
	u32 size

	byte addrof
	byte reg
	byte atvar
	byte used
	byte cvariadic				!C variadic function

	byte reftype
	byte segment
!	byte hasdot

	i16 stindex
	i16 importindex
	i16 exportindex
	i32 labelno

!	byte flags:(asmused:1, chasstatics:1, dllexport:1)

!	byte dllindex				!for dllproc: which dll in dlltable

	byte nretvalues				!function: number of return values (0 for proc)
	byte varparams				!0 or N; variadic params
	byte nparams

	byte ismain					!1 if a proc to be part of func tables
!	byte SPARE

!----------------------------------

!	byte nparams
	byte variadic				!local function that uses ... variadic params (for C)
	i16 nlocals
	i16 impindex
	i16 expindex
	u32 seqno

end

global type pcl = ^pclrec

global record pclrec =
	pcl next

	byte opcode
	byte mode, mode2
	byte condcode						!for jumpcc/setcc

!	mclopnd a
	union
		i64		value
		r64		xvalue
		ichar	svalue			!also used for data
		int		labelno
		psymbol	def
	end

	u32 size

	union						!two 32-bit params used according to opcode
		struct
			i16 x				!common access to these 1/2 extra attribs
			i16 y
		end

		struct					! (x,y) pointer ops
			i16 scale			! scale factor for offset
			i16 extra			! extra constant byte offset, already scaled
		end

		struct					! (x,y) call/etc
			i16 nargs			! number of args
			union
				i16 nvariadics	!call: 0, or arg # that is first variadic
				i16 nrealargs	!setcall: 1 if whole call sequence is simple
			end
		end

		struct					! (x,y) switch
			i16 minlab
			i16 maxlab
		end

		struct					! defproc/retproc/retfn
			i16 paramslots		! stack usage as 8-byte slots
			i16 localslots
		end

		i32 stepx				! (x) always +ve fixed step size for forup/fordown; also INCR
		i32 align
		i32 popone				! (x) jumpcc: leave X on stack
		i32 slicelwb			! (x) for .upb
		i32 inplace				! (x) for load, means &A operand is for inplace update
		i32 mathsop				! (x) for maths: maths_sin etc
		u32 slength				! string length: includes any terminator

	end

!	u16		lineno				!within function? Can use rel offset if func has full offset
	union
		byte	opndtype			!operand type (value, def etc)
		byte	optype				!alias used as pcl opnd
	end
	U16 SPARE
!	byte	reg						!when used as pcl opnd
!	byte	count
end

global type pclopnd = ^pcsrec

global record pcsrec =
	union
		struct
			byte mode				!mode (copy of pcl loadop to start)
			byte reg				!0: register holding operand
			byte temp				!0, or 1: pcl loadop in temp mem location
			byte code				!0, or 1: pclopnds[] element refers to PCL load instr
			byte count				!dupl count (zero to start)
!			byte regvar				!0, or 1 when reg is a regvar (copy of regvarset.[reg])

!			u32 psize				!copy of pcl load op size to start
		end
		u64 all						!use to restore whole record at once
	end
end

global record fwdrec =
	^fwdrec nextfwd
	i32 offset
	i16 reltype
	i16 seg
end

global enumdata [0:]ichar opndnames =
	(no_opnd=0,			$),
	(reg_opnd,			$),				!in reg (regvarset shows if regvar)

	(mem_opnd,			$),
	(memaddr_opnd,		$),
	(int_opnd,			$),
	(real_opnd,			$),				!will be [label]
	(string_opnd,		$),				!will be [label]
	(label_opnd,		$),				!will be the address of the label, so lea r,[label]

!	(temp_opnd,			$),

	(data_opnd,			$),
end

global enumdata [0:]ichar pclnames,
!enumdata [0:]ichar pclnames,
				[0:]byte pclhastype,			!where t or t/u are used (0/1/2)
				[0:]byte pclextra,				!uses .x or .x/.y
				[0:]byte pclargs =				!no. of call-args, incl ops that may use calls (9 = special)

!                       t  x          (attrs     )
	(knop=0,       $+1, 0, 0,  0),  ! (          ) 

	(kload,        $+1, 1, 1,  0),  ! (M L t i   ) Z' := M &M L &L 123 4.5 "abc"; i=1 for in-place ref
	(kiload,       $+1, 1, 0,  0),  ! (t         ) Z' := Z^
	(kiloadx,      $+1, 1, 2,  0),  ! (t d       ) Z' := (Y + Z*s + d)^

	(kstore,       $+1, 1, 0,  0),  ! (M t       ) M := Z
	(kistore,      $+1, 1, 0,  0),  ! (t         ) Z^ := Y
	(kistorex,     $+1, 1, 2,  0),  ! (t s d     ) (Y + Z*s + d)^ := X
	(kstorem,      $+1, 1, 0,  0),  ! (t         ) Z' :=(Y, Z) for mem:16

	(kdupl,        $+1, 0, 0,  0),  ! (          ) Z' := Y' := Z
	(kdouble,      $+1, 0, 0,  0),  ! (          ) Count extra instance of Z
	(kswapstk,     $+1, 0, 2,  0),  ! (a b       ) Swap(stack(a, 0,  0), stack(b)); 1/2/3/4 = Z/Y/X/W
	(kunload,      $+1, 1, 0,  0),  ! (t         ) Pop stack

	(kopnd,        $+1, 1, 0,  0),  ! (M L C t   ) Define auxiliary operand M or L
	(ktype,        $+1, 1, 0,  0),  ! (t         ) Define auxiliary type t

	(kloadbit,     $+1, 1, 0,  2),  ! (t         ) Z' := Y.[Z]
	(kloadbf,      $+1, 1, 0,  2),  ! (t         ) Z' := X.[Y..Z]
	(kstorebit,    $+1, 1, 0,  2),  ! (t         ) Y^.[Z] := X
	(kstorebf,     $+1, 1, 0,  2),  ! (t         ) X^.[Y..Z] := W

	(kcallp,       $+1, 0, 2,  9),  ! (M n v     ) Call &M with nargs, then pop args; v = varargs
	(kicallp,      $+1, 0, 2,  9),  ! (n v       ) Call Z with nargs, then pop args (a=n+1)
	(kretproc,     $+1, 0, 0,  0),  ! (          ) Return from proc
	(kcallf,       $+1, 1, 2,  9),  ! (M t n v   ) Call &M, then pop args, leave retval; v = varrgs
	(kicallf,      $+1, 1, 2,  9),  ! (t n v     ) Call Z, then pops args, leave retval (a=n+1)
	(kretfn,       $+1, 1, 0,  0),  ! (t         ) Return from func with Z=retval

	(kjump,        $+1, 0, 0,  0),  ! (L         ) goto L
	(kijump,       $+1, 1, 0,  0),  ! (          ) goto Z
	(kjumpcc,      $+1, 1, 1,  0),  ! (L t c p   ) goto L when Y c Z; p=1: Z':=Y (b=0/1)
	(kjumpt,       $+1, 1, 0,  0),  ! (L t       ) goto L when Z is true
	(kjumpf,       $+1, 1, 0,  0),  ! (L t       ) goto L when Z is false
	(kjumpret,     $+1, 1, 0,  0),  ! (L t       ) goto 0, common return point; deal with any ret value on stack
	(kjumpretm,    $+1, 1, 0,  0),  ! (L t n     ) goto 0, common return point; deal with any ret value on stack

	(ksetcc,       $+1, 1, 0,  0),  ! (t c       ) Z' := Y cc Z

	(kstop,        $+1, 0, 0,  0),  ! (          ) Stop Z

	(kto,          $+1, 1, 0,  0),  ! (L t       ) --B (aux); goto L when B<>0 
	(kforup,       $+1, 1, 1,  0),  ! (L t n     ) B+:=n; goto L when B<=C
	(kfordown,     $+1, 1, 1,  0),  ! (L t n     ) B-:=n; goto L when B>=C

	(kiswap,       $+1, 1, 0,  0),  ! (t         ) swap(Y^,Z^)

	(kswitch,      $+1, 1, 2,  0),  ! (L t x y   ) L=jumptab; B=elselab; x/y=min/max values
	(kswitchu,     $+1, 0, 2,  0),  ! (L x y     ) L=jumptab; B=elselab; x/y=min/max values
	(kswlabel,     $+1, 0, 0,  0),  ! (L         ) jumptable entry

	(kclear,       $+1, 1, 0,  0),  ! (t         ) Clear Z^

	(kadd,         $+1, 1, 0,  0),  ! (t         ) Z' := Y + Z
	(ksub,         $+1, 1, 0,  0),  ! (t         ) Z' := Y - Z
	(kmul,         $+1, 1, 0,  0),  ! (t         ) Z' := Y * Z
	(kdiv,         $+1, 1, 0,  0),  ! (t         ) Z' := Y / Z
	(kidiv,        $+1, 1, 0,  0),  ! (t         ) Z' := Y % Z
	(kirem,        $+1, 1, 0,  0),  ! (t         ) Z' := Y rem Z
	(kidivrem,     $+1, 1, 0,  0),  ! (t         ) Z' := divrem(Y, Z)
	(kbitand,      $+1, 1, 0,  0),  ! (t         ) Z' := Y iand Z
	(kbitor,       $+1, 1, 0,  0),  ! (t         ) Z' := Y ior Z
	(kbitxor,      $+1, 1, 0,  0),  ! (t         ) Z' := Y ixor Z
	(kshl,         $+1, 1, 0,  0),  ! (t         ) Z' := Y << Z
	(kshr,         $+1, 1, 0,  0),  ! (t         ) Z' := Y >> Z
	(kmin,         $+1, 1, 0,  0),  ! (t         ) Z' := min(Y, Z)
	(kmax,         $+1, 1, 0,  0),  ! (t         ) Z' := max(Y, Z)
	(kaddpx,       $+1, 1, 2,  0),  ! (t s d     ) Z' := Y + Z*s + d
	(ksubpx,       $+1, 1, 2,  0),  ! (t s d     ) Z' := Y - Z*s + s
	(ksubp,        $+1, 1, 1,  0),  ! (t s       ) Z' := (Y - Z)/s

	(kneg,         $+1, 1, 0,  0),  ! (t         ) Z' := -Z
	(kabs,         $+1, 1, 0,  0),  ! (t         ) Z' := abs Z
	(kbitnot,      $+1, 1, 0,  0),  ! (t         ) Z' := inot Z
	(knot,         $+1, 1, 0,  0),  ! (t         ) Z' := not Z
	(ktoboolt,     $+1, 2, 0,  0),  ! (t u       ) Z' := istrue Z; u is of type u; result is type t
	(ktoboolf,     $+1, 2, 0,  0),  ! (t u       ) Z' := not istrue Z
	(ksqr,         $+1, 1, 0,  0),  ! (t         ) Z' := sqr Z

	(ksqrt,        $+1, 1, 0,  0),  ! (t         ) Z' := sqrt Z
	(kmaths,       $+1, 1, 1,  1),  ! (t op      ) Z' := maths(Z)
	(kmaths2,      $+1, 1, 1,  2),  ! (t op      ) Z' := maths2(Y, Z)
	(ksign,        $+1, 1, 0,  1),  ! (t         ) Z' := sign Z

	(kpower,       $+1, 1, 0,  2),  ! (t         ) Z' := Y ** Z

	(kincrto,      $+1, 1, 1,  0),  ! (t n       ) Z^ +:= n
	(kdecrto,      $+1, 1, 1,  0),  ! (t n       ) Z^ -:= n
	(kincrload,    $+1, 1, 1,  0),  ! (t n       ) Z' := (Z +:= n)^
	(kdecrload,    $+1, 1, 1,  0),  ! (t n       ) Z' := (Z -:= n)^
	(kloadincr,    $+1, 1, 1,  0),  ! (t n       ) Z' := Z++^ (difficult to express step)
	(kloaddecr,    $+1, 1, 1,  0),  ! (t n       ) Z' := Z--^

	(kaddto,       $+1, 1, 0,  0),  ! (t         ) Z^ +:= Y
	(ksubto,       $+1, 1, 0,  0),  ! (t         ) Z^ -:= Y
	(kmulto,       $+1, 1, 0,  0),  ! (t         ) Z^ *:= Y
	(kdivto,       $+1, 1, 0,  0),  ! (t         ) Z^ /:= Y
	(kidivto,      $+1, 1, 0,  0),  ! (t         ) Z^ %:= Y
	(kiremto,      $+1, 1, 0,  0),  ! (t         ) Z^ rem:= Y
	(kbitandto,    $+1, 1, 0,  0),  ! (t         ) Z^ iand:= Y
	(kbitorto,     $+1, 1, 0,  0),  ! (t         ) Z^ ior:= Y
	(kbitxorto,    $+1, 1, 0,  0),  ! (t         ) Z^ ixor:= Y
	(kshlto,       $+1, 1, 0,  0),  ! (t         ) Z^ <<:= Y
	(kshrto,       $+1, 1, 0,  0),  ! (t         ) Z^ >>:= Y
	(kminto,       $+1, 1, 0,  0),  ! (t         ) Z^ min:= Y
	(kmaxto,       $+1, 1, 0,  0),  ! (t         ) Z^ max:= Y
	(kaddpxto,     $+1, 1, 1,  0),  ! (t s       ) Z^ +:= Y*s
	(ksubpxto,     $+1, 1, 1,  0),  ! (t s       ) Z^ -:= Y*s

	(knegto,       $+1, 1, 0,  0),  ! (t         ) -:= Z^
	(kabsto,       $+1, 1, 0,  0),  ! (t         ) abs:= Z^
	(kbitnotto,    $+1, 1, 0,  0),  ! (t         ) inot-:= Z^
	(knotto,       $+1, 1, 0,  0),  ! (t         ) not:= Z^
	(ktoboolto,    $+1, 1, 0,  0),  ! (t         ) istrue:= Z^

	(ktypepun,     $+1, 2, 0,  0),  ! (t u       ) Z' := t(u@(Z^))
	(kfloat,       $+1, 2, 0,  0),  ! (t u       ) Z' := cast(Z,t) Int   to real t
	(kfix,         $+1, 2, 0,  0),  ! (t u       ) Z' := cast(Z,t) Real   to int t
	(ktruncate,    $+1, 2, 0,  0),  ! (t u       ) Z' := cast(Z,u) Mask to width of u, but type is widened to t
	(kwiden,       $+1, 2, 0,  0),  ! (t u       ) Z' := cast(Z,t) Mask to width of u, but type is widened to t
	(kfwiden,      $+1, 2, 0,  0),  ! (t u       ) Z' := cast(Z,t) r32 to r64
	(kfnarrow,     $+1, 2, 0,  0),  ! (t u       ) Z' := cast(Z,t) r64 to r32

	(kstartmx,     $+1, 0, 0,  0),  ! (          ) -
	(kresetmx,     $+1, 1, 0,  0),  ! (t         ) -
	(kendmx,       $+1, 1, 0,  0),  ! (t         ) -

	(kinitdswx,    $+1, 0, 0,  0),  ! (          ) Following two ops initialise doswitchx jumptable

	(klabel,       $+1, 0, 0,  0),  ! (          ) ?
	(klabeldef,    $+1, 0, 0,  0),  ! (          ) ?

	(kdata, 	   $+1, 1, 2,  0),  ! (          ) ?

	(ksetcall,     $+1, 0, 1,  0),  ! (n s       ) n=args, s=1 for simple call
	(ksetarg,      $+1, 0, 2,  0),  ! (n1 n2     ) n1=arg no (LTR) n2=int or real arg no (maybe neg for real)

	(kloadall,     $+1, 0, 0,  0),  ! (          ) ?

	(ksetjmp,      $+1, 0, 0,  0),  ! (          ) ?
	(klongjmp,     $+1, 0, 0,  0),  ! (          ) ?

	(keval,        $+1, 0, 0,  0),  ! (          ) Evaluate Z [load to an actual register], then pop
	(kcomment,     $+1, 0, 0,  0),  ! (C         ) Comment C (a string)
end

global const kerror = knop

global enumdata [0:]ichar ccnames, [0:]ichar ccshortnames =
	(no_cc=0,	"xx",	"?"),
	(eq_cc,		"eq",	" = "),
	(ne_cc,		"ne",	" <> "),
	(lt_cc,		"lt",	" < "),
	(le_cc,		"le",	" <= "),
	(ge_cc,		"ge",	" >= "),
	(gt_cc,		"gt",	" > "),
end

global enumdata [0:]ichar mathsnames =
	(none_m = 0,		$),
	(maths_sin,			$+6),
	(maths_cos,			$+6),
	(maths_tan,			$+6),
	(maths_asin,		$+6),
	(maths_acos,		$+6),
	(maths_atan,		$+6),
	(maths_log,			$+6),
	(maths_log10,		$+6),
	(maths_exp,			$+6),
	(maths_round,		$+6),
	(maths_ceil,		$+6),
	(maths_floor,		$+6),
	(maths_fract,		$+6),
	(maths_sign,		$+6),
	(maths_fmod,		$+6),
	(maths_atan2,		$+6),
end



global psymbol entryproc		!entry point function

global psymbol currfunc
!global int retindex
!
!global const maxnestedloops	= 50
!
!global [maxnestedloops,4]int loopstack
!global int loopindex							!current level of nested loop/switch blocks
!
!unitrec zero_unit
!global unit pzero=&zero_unit

!proc start=
!	zero_unit.tag:=jconst
!	zero_unit.mode:=ti64
!	zero_unit.value:=0
!	zero_unit.resultflag:=1
!end

!global byte ssdone
!
!global int assemtype
!

global psymbol psymboltable, psymboltablex

global const pmaxparams = 30
