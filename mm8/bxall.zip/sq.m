[]byte data=bINCLUDE("sql.exe")

proc main=

	writefile("fred.exe",&.data,data.len)

!	println sinclude("fred")

end
