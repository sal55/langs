importdll msvcrt=
	proc puts(ichar)
	proc printf(ichar,...)
end

proc main=
	const n=1000
	int count

	count:=0

	for a:=1 to n do
		for b:=a to n do
			for c:=b to n+n do
				if sqr(a)+sqr(b) = sqr(c) then
					++count
				fi
			od
		od
	od

!    println "Count=",count
    printf("Count=%lld\n",count)
end
