const nn=2500
!const nn=25

function eval_a(int i,j)real=
	return 1.0/((i+j)*(i+j+1)/2+i+1)
end

proc eval_a_times_u(int n, []real &u,&au)=
	for i to n do
		au[i]:=0.0
		for j to n do
			au[i]:=au[i]+eval_a(i-1,j-1)*u[j]
		od
	od
end

proc eval_at_times_u(int n, []real &u,&au)=
	for i to n do
		au[i]:=0.0
		for j to n do
			au[i]:=au[i]+eval_a(j-1,i-1)*u[j]
		od
	od
end

proc eval_ata_times_u(int n, []real &u,&atau)=
	[0..nn]real v

	clear v

	eval_a_times_u(n,u,v)
	eval_at_times_u(n,v,atau)
end

proc main=
	[0..nn]real u,v
	real vbv,vv

	for i to nn do
		u[i]:=1.0
		v[i]:=1.0
	od

	for i to 10 do
		eval_ata_times_u(nn,u,v)
		eval_ata_times_u(nn,v,u)
	od

	vbv:=0.0
	vv:=0.0
	for i to nn do
		vbv:=vbv+u[i]*v[i]
		vv:=vv+v[i]*v[i]
	od

	println "Resultx =",sqrt(vbv/vv)

end
