const fasmformat=2			!gas
!const fasmformat=1			!nasm
!const fasmformat=0			!aa

!export ichar asmext="s"
!export ichar asmext="asm"

strbuffer sbuffer
global ^strbuffer pdest=&sbuffer

[8, r0..r15]ichar nregnames = (
	("al", "r10b", "r11b", "dil", "bl", "sil", "r12b", "r13b", "r14b", "r15b", "cl", "dl", "r8b", "r9b", "bpl", "spl"), 	! 1
	("ax", "r10w", "r11w", "di", "bx", "si", "r12w", "r13w", "r14w", "r15w", "cx", "dx", "r8w", "r9w", "bp", "sp"), 	! 2
	(nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil), 	! 3
	("eax", "r10d", "r11d", "edi", "ebx", "esi", "r12d", "r13d", "r14d", "r15d", "ecx", "edx", "r8d", "r9d", "ebp", "esp"), 	! 4
	(nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil), 	! 5
	(nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil), 	! 6
	(nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil), 	! 7
	("rax", "r10", "r11", "rdi", "rbx", "rsi", "r12", "r13", "r14", "r15", "rcx", "rdx", "r8", "r9", "rbp", "rsp"), 	! 8
)

byte currseg

global func writeasm:^strbuffer=
!write all mcl code in system by scanning all procs
!mcl code is only stored per-proc
	symbol d,e
	^procrec pp
	^mclrec m
	[32]char str2,str3

!CPL "WRITE GAS",=PHIGHMEM


	gs_init(pdest)
!	asmstr("# GAS VERSION\n")

	asmstr("    .code64\n")
	asmstr("    .intel_syntax prefix\n")
	asmstr("\n")

!do globals and externs
	pp:=proclist
	while pp, pp:=pp.nextproc do
		d:=pp.def
		if d.scope=export_scope then
			asmstr("    .global ")
			asmstr(getbasename(d.name))
			asmstr("\n")
		end
	od
	asmstr("\n")

	m:=mccode
	while m do
		writemcl(m)
		m:=m.nextmcl
	od

CPL "DONE CODE"
	byte first:=1
	pp:=proclist
	while pp, pp:=pp.nextproc do
		d:=pp.def
		if d.scope=export_scope then
			if first then
				first:=0
				asmstr("    .section .drectve\n")
			end
			asmstr("    .ascii "" -export:\\""")
			asmstr(d.name)
			asmstr("\\""""\n")
		end
	od
	asmstr("\n")

	return pdest
end

global proc strmcl(^mclrec mcl)=
	static [512]char str
	[128]char opcname
	mclopnd a,b
	int opcode,cond,sizepref
	ichar s,comment
	symbol d

	opcode:=mcl.opcode


	cond:=mcl.cond
	a:=mcl.a
	b:=mcl.b
	comment:=nil

!CPL =MCLNAMES[OPCODE]

	case opcode
	when m_procstart then
		asmstr("# Proc ")
		asmstr(a.def.name)
		currfunc:=a.def

		return

	when m_procend then
		asmstr("# End ")
		currfunc:=nil

		return

	when m_comment then
		asmchar('# ')
		asmstr(a.svalue)
		return

	when m_labelname then				!label name will be complete and will have colon(s)
		d:=a.def
		case a.valtype
		when def_val then
			asmstr(getdispname(d))
		when string_val then
			asmstr(a.svalue)
			return
		else
			merror("strmcl/lab")
		end case

		asmstr(":")

!CPL "LABEL", D.NAME, SCOPENAMES[D.SCOPE]
		if d.scope>=export_scope then
!			if eqstring(getbasename(d.name), d.name) then
!CPL "HERE2", D.NAME, GETBASENAME(D.NAME)
!!				asmstr(":")
!			else
				asmstr("\n")
!CPL "HERE"
				asmstr(getbasename(d.name))
!				asmstr("::")
				asmstr(":")
!			end
		end

		return

	when m_label then
!		fprint @str,"L#:",a.value
!		asmstr(str)
!		return
		if a.valtype=label_val then
			fprint @str,"L#:",a.value
		else
			recase m_labelname
		end
		asmstr(str)
		return

	when m_define then
		asmstr("    .set ")
		d:=a.def
		asmstr(getdispname(d))
		asmstr(", ")
		asmint(d.offset)
		return

	when m_definetemp then
		asmstr("    .set ")
		asmstr(a.svalue)
		asmstr(", ")
		asmopnd(b)
		return

!	when m_definereg then
!		d:=a.def
!		asmstr("   %define ")
!		asmstr(getdispname(d))
!		asmstr(" ")
!
!		case b.mode
!		when a_reg then
!			asmstr(strreg(b.reg, b.size))
!
!		else
!!			asmstr(getxregname(b.reg, b.size))
!			asmstr(strxreg(b.reg, b.size))
!		end case
!		return

		return

	when m_csegment then asmstr("    .text"); currseg:=code_seg; return
	when m_isegment then asmstr("    .data"); currseg:=idata_seg; return
	when m_zsegment then asmstr("    .bss"); currseg:=zdata_seg; return

	end case

	case opcode
	when m_jmpcc then
		print @opcname,"j",,asmcondnames[cond]

	when m_setcc then
		print @opcname,"set",,asmcondnames[cond]

	when m_cmovcc then
		print @opcname,"cmov",,asmcondnames[cond]

	when m_imul2 then
		strcpy(opcname,"imul")

	when m_movzx then
		if a.size=8 and b.size=4 then
			mcl.a:=a:=changeopndsize(a, 4)
			opcode:=m_mov
		end
		recase else

	when m_movsx then
		if a.size=8 and b.size=4 then
			strcpy(opcname, "movsxd")
		else
			recase else
		end

	when m_movd then
		if isxreg(a) and isxreg(b) then		!
			opcode:=m_movq
		end

		recase else

    when m_mov then
        if a.mode=a_reg and b.mode=a_imm and b.valtype=int_val and b.value not in i32.bounds then
            mcl.opcode:=m_movq
        end
		recase else

	when m_align then
		strcpy(opcname, ".align")
!		if currseg=zdata_seg then
!			strcpy(opcname, "alignb")
!		else
!			recase else
!		end
	when m_resb then
		strcpy(opcname, ".space")

	when m_db then
		strcpy(opcname, ".byte")
	when m_dw then
		strcpy(opcname, ".word")
	when m_dd then
		strcpy(opcname, ".long")
	when m_dq then
		strcpy(opcname, ".quad")
	when m_ascii then
		strcpy(opcname, ".ascii")


	when m_endx then
		return

	ELSIF OPCODE>M_HALT THEN
		STRCPY(OPCNAME,STRINT(OPCODE))

	else
		strcpy(opcname,mclnames[opcode]+2)
	end case

	ipadstr(opcname,10," ")

	if not fasmformat then
		if a and b then
			fprint @str,"  #/#",a.size,b.size
		elsif a then
			fprint @str,"  #",a.size
		else
			strcpy(str,"  ")
		end
	else
		strcpy(str,"  ")
	end

	ipadstr(str,4)

	strcat(str,opcname)

	asmstr(str)

	if a and b then		!2 operands
		sizepref:=needsizeprefix(opcode,a,b)
!
		asmopnd(a,sizepref)
		asmstr(",	")
		asmopnd(b,sizepref)

		if mcl.c then
			asmstr(",")
			asmstr(strint(mcl.c))
		end

!		ASMSTR("; ")
!		ASMSTR(strint(a.size))
!		ASMSTR(" ")
!		ASMSTR(strint(b.size))
!		ASMSTR(" #")
!		ASMSTR(STRINT(MCL.SEQNO))
!!
	elsif a and a.mode then								!1 operand
		if opcode=m_call then
			asmopnd(a,0,opcode)
		else
			asmopnd(a,1,opcode)
		end
	end

!ASMSTR("	#"); ASMSTR(STRINT(MCL.SEQNO))

end

global func strmclstr(^mclrec m)ichar=
	gs_init(pdest)
	strmcl(m)
	return pdest.strptr
end

global func mstropnd(mclopnd a,int sizeprefix=0,opcode=0)ichar=
	static [512]char str
	[128]char str2
	ichar plus,t
	int offset,tc

	str[1]:=0

	case a.mode
	when a_reg then
		return strreg(a.reg, a.size)

	when a_imm then
		if opcode=m_dq and a.valtype=int_val then
			if a.value in 0..9 then
				strcat(str,strint(a.value))
			else
				strcat(str,"0x")
				strcat(str,strword(a.value,"H"))
			end
		else
			strcpy(str,strvalue(a))
		end

	when a_mem then
!		case a.valtype
!		when intimm_val then
!			strcpy(str,strint(a.value))
!		when realimm_val then
!			strcpy(str,strreal(a.xvalue))
!		when realmem_val then
!			fprint @str,"M#",a.xvalue
!		end case

		strcat(str,getsizeprefix(a.size,sizeprefix))
		strcat(str,"[")

		plus:=""
		if a.reg then
			strcat(str,strreg(a.reg,8))
			plus:=" + "
		end
		if a.regix then
			strcat(str,plus)
			strcat(str,strreg(a.regix,8))
			plus:=" + "

			if a.scale>1 then
				strcat(str,"*")
				strcat(str,strint(a.scale))
			end
		end

		if a.valtype in [def_val,label_val, temp_val] then
			IF A.REG=A.REGIX=RNONE AND HIGHMEM THEN
				STRCAT(STR, "%rip+")
			end
			if plus^ then
				strcat(str,plus)
			end
			strcat(str,strvalue(a))
	    elsif offset:=a.offset then
			print @str2,offset:" + "
			strcat(str,str2)
		end
		strcat(str,"]")

	else
		println "BAD OPND",A.MODE
		return "<BAD OPND>"
	end case

	return str
end

global func strvalue(mclopnd a)ichar=
	static [512]char str
	[128]char str2
	symbol def
	i64 value,offset,length
	ichar ss

	def:=a.def
	value:=a.value

	strcpy(str,"")

	case a.valtype
	when def_val then
		strcat(str,getdispname(def))

	addoffset:
		if offset:=a.offset then
			print @str2,(offset>0|"+"|""),,offset
			strcat(str,str2)
		end

	when int_val then
		strcat(str,strint(value))
!		strcat(str,strint(value, "h"))

	when real_val then
		print @str,a.xvalue:"20.20"

!	when realmem_val then
!		strcat(str,"M")
!		strcat(str,strreal(a.xvalue))
!
	when string_val then
		strcat(str,"""")
		strcat(str,a.svalue)
		strcat(str,"""")

	when name_val then
		strcat(str,a.svalue)

	when label_val then
		strcat(str,"L")
		strcat(str,strint(a.labelno))
		goto addoffset

	when temp_val then
		return gettempname(currfunc,a.tempno)

	else
		merror("Stropnd?")
	end case

	return str

end

proc writemcl(^mclrec mcl)=

	case mcl.opcode
!	when m_define, m_definereg then
	when m_definereg then
	else
		strmcl(mcl)
		gs_line(pdest)
	end case
end

proc start=
	assemtype:='GAS'
end

global proc asmopnd(mclopnd a,int sizeprefix=0,opcode=0)=
	asmstr(mstropnd(a,sizeprefix,opcode))
end

global func getxregname(int reg,size=8)ichar=
	static [32]char str

	if reg=rnone then return "-" end

!	if fasmformat then
		print @str,"%XMM",,reg-xr0
!	else
!		print @str,(size=8|"DX"|"SX"),,reg-xr0
!	end
	return str
end

proc asmstr(ichar s)=
	gs_str(pdest,s)
end

proc asmchar(int c)=
	gs_char(pdest,c)
end

proc asmint(int a)=
	asmstr(strint(a))
end

global func getdispname(symbol d)ichar=
	static [256]char str

!	if d.reg then
!		fprint @str,"#.#","R", d.name
!		return str
!	end
!
!	if fpshortnames then
!		return d.name
!	end

	return getfullname(d)
!	strcpy(str, getfullname(d))
!	if d.id=static_id then
!!IF D.IMPORTED THEN CPL "STATIC", D.NAME, D.IMPORTED FI
!		strcat(str,".")
!	end
!	return str
!	return "FULL"

end 

global func gettempname(symbol d, int n)ichar=
	static [128]char str

!CPL "TEMP:", D.NAME,D.OFFSET

	if fshortnames then
		print @str,"T",,n
	else
		fprint @str,"#.$T#",getdispname(d),n
	end
	str
end

global func strreg(int reg, size=8)ichar=
	static [16]char str

	if reg>=xr0 then
		return strxreg(reg, size)
	end

	strcpy(str, "%")
	strcat(str, nregnames[size, reg])

	str
end

func strxreg(int reg, size=8)ichar=
	symbol d

!	d:=checkregvar(reg,1)

!	if size=8 and d then
!		return getdispname(d)
!	else
		return getxregname(reg,size)
!	end
end

global func needsizeprefix(int opcode,mclopnd a,b)int=
	case opcode
	when m_movsx, m_movzx, m_cvtsi2ss, m_cvtsi2sd then
		return 1

	when m_cvtss2si,m_cvtsd2si, m_cvttss2si,m_cvttsd2si then
		return 1
	when m_shl, m_shr, m_sar then
		if a.mode=a_mem then return 1 end
		return 0
	end case

	if a.mode=a_reg or b.mode=a_reg then
		return 0
	end
	return 1
end

global func getsizeprefix(int size,enable=0)ichar=
	if not enable then return "" end
	case size
	when 1 then return "byte ptr"
	when 2 then return "word ptr"
	when 4 then return "dword ptr"
	when 8 then return "qword ptr"
	end case
	return ""
end

func checkregvar(int reg, ispfloat)symbol d=
	RETURN NIL
end

