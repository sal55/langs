!hello

global const maxmodule=400
global const maxsubprog=30
global const maxlibfile=50
global const maxsourcefile=300

global type symbol		= ^strec
!global type unit  		= ^unitrec
global type imodule   	= ^modulerec
global type ifile   	= ^filerec
global type isubprog  	= ^subprogrec

!The following nameids will have child st entries
! program			Mostly modules
! module			Top level types, vars, proc etc
! proc
! dllproc			Params only
! type				Records/structs
! macro				Params only

global record strec =
	ichar name

	byte namelen
	byte token					!when used for reserved words
	u16 subcode					!used with token only
	byte moduleno
	byte subprogno
	byte nameid
	byte scope

	symbol owner				!all
	symbol firstdupl			!all: for resolving
	symbol nextdupl				!link all st entries with the same name
	symbol deflist				!first child entry
	symbol deflistx				!last child entry in sideways linked list
	symbol nextdef				!next inside any owner st
	symbol nextlinear			!link all proc/dllproc/statics (incl. inside procs)

	symbol nextparam			!proc/dllproc only
!	symbol nextlocal			!proc only (not statics)

	union
		ichar truename			!dllproc/dllvar only
		pcl labelref			!procs/labels
		variant varptr			!statics
	end

	union
		unit code
		symbol topfieldlist		!structs; point to block of ttlength[mode] top fields
	end

	union
		u64 pos: (mm:16, lineno:24, column:10, fileno:10)
		posrec posx
	end

	i32 mode
	union
		i32 offset
		i32 fieldoffset
	end

	union
		i32 lexindex			!for certain tokens
		i32 fnindex				!dll proc: index into table
		i32 labelno				!named labels: labelno
		i32 index				!field index?
	end

	u16 flags: (
		optional:	1,
		caligned:	1,
		byref:		1,
		isstatic:	1,
		isimport:	1,
		used:		1,
		atfield:	1,
		ishandler:	1,
		hasdoswx:	1,
		dummy:		1)

	byte maxalign
	byte varparams
	byte bitoffset
	byte bitfieldwidth
	byte nretvalues

	uflagsrec uflags
	symbol equivfield
	unit equivvar
	byte equivoffset
!	byte scope
end

global type unit =ref unitrec

!global record unitrec = $caligned
global record unitrec =
	unit nextunit

	byte tag					!jtag number
	byte moduleno
	byte subprogno
	byte flags: (
		initlet:1,				!1 for an assignment that initialises a let
		resultflag:1,
		insptr:1,
		txcount:1,
		isconst:1)				!1 for jconst, and jmakerange with const range
	union
		byte inv				!notin
		byte bfcode				!bf_even etc
		byte cvindex			!cv_lineno etc, compile var index
		byte fnindex			!sf_print etc
		byte optoken			!u_operator: token type tk_binop etc
	end
	byte avcode
	union
		byte binop				!u_bin
		byte unaryop			!u_unary
		byte propop				!u_prop
		byte isdecr				!u_incr
		byte mathsop			!u_maths/2
		byte addrof				!u_addrof: 0/1 means &/^
		byte hostfn				!u_callhost
	end
	[1]byte spare

	union
		u64 pos: (mm:16, lineno:24, column:10, fileno:10)
		posrec posx
	end

	i32 mode
	union
		i32 mode2				!convert/typepun: The T in T(x) or cast(x, T)
		u32 offset				!jdot
	end

!Rest of unit is fields A, B, C. Not all will be used
!Jsubs[tag] says how many (0-3) will be sub-nodes
!The rest may be used for other purposes depending on jtag

!UNIT A
!UNIT B

	union
		unit	a				!subnode
		symbol	def				!jname
		i64		value			!jconst
		r64		xvalue			!jconst
		ichar	svalue			!jconst: string const or data-string
		i64		range_lower		!jmakerange only
	end

	union
		unit	b				!subnode
		struct					!const string
			u32  slength		!includes any zero term
			byte isastring
			char strtype		!0/'B'/'S' = normal / bindata / strdata
		end

		u32 length				!makelist: number of elements

		[8]byte cmpgenop


		i32 loopindex			!jexit etc
		i32 whenlabel			!label associated with expr, for recase
	end
end

global record modulerec=
	ichar	name				!module name and base filename
	ifile	file
	i16		moduleno			!useful if using pointer to a source rec
	i16		subprogno
	i16		fileno
	byte	flags: (
			issyslib:1,
			islead:1)			!1 if lead module in sp

	union
		symbol	stmodule
		symbol	def
	end

	symbol	stsubprog
	symbol	stmacro

	symbol	ststart				!nil, or st entry of start()
	symbol	stmain				!nil, or st entry of main()

	pcl		pcstart				!nil, or start of pcl code for whole module
	pcl		pcend				!nil, or last allocated pcl rec
end

global record filerec=
	ichar	name				!module name and base filename
	ichar	filename			!base filename + extension
	ichar	path				!path where file resides
	ichar	filespec			!full file path
	ichar	text				!pointer to source text, 0-terminated
	ichar	dupl				!for ma files
	u32		size				!source file size includes terminator

	byte	issyslib			!1 if a system module
	byte	issupport			!1 if a support file (strinclude); MAY BE STORED ELSEWHERE
	byte	compiled			!1 if compiled
	byte	islead				!1 if lead module in sp

	i16	subprogno
	i16	moduleno				!0, or moduleno

	i16	fileno					!refers to self
	byte	xxxmfile				!1 when file extension is .m
	byte	spare

end

global record typenamerec=
	symbol owner			!owner of scope where typename was encountered
							!moduleno required by resolvetypename can be derived from owner
	symbol def
	union
		u64 pos: (mm:16, lineno:24, column:10, fileno:10)
		posrec posx
	end
	^i32 pmode
end

global record posrec=
	u64 pos: (dummy:16, lineno:24, column:10, fileno:10)		!dummy used in pclrec
end

global record uflagsrec =
	[7]byte	codes
	byte	ulength
end

global record subprogrec =
	ichar name
	i16 firstmodule			!will be header module or same as mainmodule if no header
	i16 mainmodule			!0, or module containing 'main'
	i16 lastmodule			!always first..lastmodule
!	i16 compiled				!1 if compiled
	byte flags:(compiled:1, issyslib:1)
	byte subprogno
end

global [0..maxmodule]imodule	modules
global [0..maxmodule]byte		moduletosub				!convert module no to subprog no
global [0..maxsubprog]isubprog	subprogs
global [0..maxsourcefile]ifile	sources
global [0..maxsubprog]byte		subproghasstart

global int nmodules
global int nsubprogs
global int nsourcefiles
global int nlibfiles

global [tokennames.bounds]byte keepeol

global symbol stprogram				!root into the symbol table
global symbol stmodule				!main module
global symbol stcurrproc
global symbol stlinear, stlinearx	!linear list of selected identifiers (eg. statics, procs)
global int currmoduleno				!used when compiling modules
!global byte loadedfromma			!1 if source/support files are in loaded .ma file
global int mainsubprogno			!index of main subprog (eg. may be before/after syslib)

global ichar sourceext				!"b" "q" or "m" of lead module; used in discovering other files
global byte projectqm=2				!0/1/2/3 = non-set/q/m/mixed; determines syslibs and default dmode
!global byte syslevel=1				!0/1/2 = none/min/normal
global byte syslevel=0				!0/1/2 = none/min/normal

global [0..maxlibfile]ichar libfiles

global const maxdllproc=1000
global int ndllproctable
global [maxdllproc]symbol dllproctable

global const int maxtype=40'000
global int ntypes

global [0..maxtype]symbol	ttnamedef
global [0..maxtype]symbol	ttowner			!for ttlowerexpr/rtlengthexpr

global [0..maxtype]i32		ttbasetype		!basetype
global [0..maxtype]ichar	ttname

global [0..maxtype]u32		ttsize
global [0..maxtype]i32		ttlower 		!.lbound (default 1)
global [0..maxtype]i32		ttlength 		!elements in array/record/tuple
global [0..maxtype]^[]i32	ttmult 			!ttlength elements in tuple

global [0..maxtype]unit		ttdimexpr		!length, lower:length, or lower..upper

global [0..maxtype]i32		tttarget 		!for array/^types
global [0..maxtype]posrec	ttpos

!global [0..maxtype]byte		ttsigned		!is i8 i16 i32 i64
!global [0..maxtype]byte		ttisreal		!is r32 r64
!global [0..maxtype]byte		ttisinteger		!is i8..i64/u8..u64/c8..c64
!global [0..maxtype]byte		ttisshort		!is i8/i16/i32/u8/u16/u32/c8/c16
!global [0..maxtype]byte		ttisref			!is a pointer
!
global const int maxtypename=8'000

global [0..maxtypename]typenamerec typenames
global int ntypenames

global [tokennames.bounds]byte typestarterset

global []int D_typestarterset= (tk_stdtype, tk_lsq, tk_ref, tk_record,
		tk_ptr, tk_stringz)

global unit nullunit

global int nextavindex=0
global posrec qpos

global macro pr(a,b)	= (a<<16 ior b)

global const varsize=16
