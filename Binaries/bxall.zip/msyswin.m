module msys
module mlib
module mclib
module mwindows
module mwindll

!proc start=
!	CPL "MSYSWIN/START"
!END
