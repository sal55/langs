const pclinitalloc=128

global pcl pcstart				!point to start of current pcl block
global pcl pccurr				!point to last create pcl rec
global pcl pcend				!point to last allocated int (with enough margin for on extra instr)
global int pcalloc				!ints allocated

global int pclcurrlineno			!current line number
const pclelemsize=pclrec.bytes
const pcsrcelemsize=i32.bytes

global const labelinitalloc=8192
global ref[]pcl labelpctable		!labelpctable[L] refers to target instr of label L
global int labelalloc
global int nextlabelno

!global [0..pclnames.upb]byte pclnopnds

proc start=
	int nn

	pcm_init()

!label/block tables are not needed after the pcl sequence has been
!generated. But they are not freed; they can be reused, with their
!current sizes, for the next module. (Might be inefficient if there is one
!very large module, then mainly small ones.)

	labelalloc:=labelinitalloc
	labelpctable:=pcm_alloc(pcl.bytes*labelalloc)
end

global proc resetpcl(int sourcesize)=
	int pclsize

	clear qpos
	nextlabelno:=0
	pclcurrlineno:=0

!pcl dest is reallocated for each module
!Any current pcl data is presumably retained so that it can be run.

	pclsize:=sourcesize			!estimated num of pcl bytecode elements

	pcalloc:=1024					!min
	while pcalloc<pclsize do
		pcalloc<<:=1
	od

	pcstart:=pcm_allocz(pcalloc*pclelemsize)
	pccurr:=pcstart-1
	pcend:=pcstart+pcalloc-8			!allow margin

	pcm_clearmem(labelpctable, pcl.bytes*labelalloc)

end

global proc pgen(int opc)=

	++pccurr

	if pccurr>=pcend then
		extendpcldata()
	fi

!only do overflow check at start of an instruction
	pccurr.opcode:=opc
!IF LABELFLAG THEN CPL "GENPC", PCLNAMES[OPC], =LABELFLAG FI
	pccurr.posx:=qpos			!sets mode to 0; must be set next
end

!global proc genopnd_int(i64 x)=
!!no pcindex overflow check needed, as the pgen() check will be sufficient as
!!it would allow for enough operands
!	pccurr.value:=x
!end
!
!global proc genopnd_name(ref strec d)=
!	pccurr.def:=d
!end

global proc pgen_int(int opc, i64 a)=
	pgen(opc)
	pccurr.value:=a
end

global proc pgen_n(int opc, n)=
	pgen(opc)
	pccurr.n:=n
end

global proc pgen_xy(int opc, x, y=0)=
	pgen(opc)
	pccurr.x:=x
	pccurr.y:=y
end

global proc pgen_name(int opc, ref strec d)=
	pgen(opc)
	pccurr.def:=d
end

global proc genopnd_strz(ichar s)=
!s must be a heap string, be a constant, or otherwise be persistent
	pccurr.svalue:=s
end

global proc genopnd_str(object s)=
!s must be a heap string, be a constant, or otherwise be persistent
	pccurr.objptr:=s
end

global proc genopnd_obj(object p)=
	pccurr.objptr:=p
end

global proc pgen_real(int opc, real x)=
	pgen(opc)
	pccurr.xvalue:=x
end

global proc pgen_lab(int opc, int lab)=
	pgen(opc)
	pccurr.labelno:=lab
end

!global proc genopnd_lab(int a)=
!	pccurr.labelno:=a
!end

global proc pcomment(ichar s)=
	pgen(kcomment)
	genopnd_strz(pcm_copyheapstring(s))
end

proc extendpcldata=
	int newpcalloc
	pcl newpcstart

	newpcalloc:=pcalloc*2

!CPL "EXTENDING PCL TABLE TO",=PCLSTART

	newpcstart:=pcm_alloc(pclelemsize*newpcalloc)

	memcpy(newpcstart,pcstart, getpcloffset(pccurr,pcstart)*pclelemsize)

	pccurr:=newpcstart+getpcloffset(pccurr,pcstart)
	pcend:=newpcstart+newpcalloc-10

	pcm_free(pcstart,pcalloc*pclelemsize)

	pcstart:=newpcstart
	pcalloc:=newpcalloc
end

global proc extendlabeltable=
	int newlabelalloc
	ref[]pcl newlabeltable

	newlabelalloc:=labelalloc*2

	newlabeltable:=pcm_alloc(pcl.bytes*newlabelalloc)

	memcpy(newlabeltable,labelpctable, labelalloc*pcl.bytes)

	pcm_free(labelpctable,labelalloc*pcl.bytes)

	labelpctable:=newlabeltable
	labelalloc:=newlabelalloc
end

global function definelabel:int=
	if nextlabelno>=labelalloc then extendlabeltable() fi
	++nextlabelno
!CPL "DEF LABEL",NEXTLABELNO
	labelpctable[nextlabelno]:=pccurr+1
	return nextlabelno
end

global function createfwdlabel:int=
	if nextlabelno>=labelalloc then extendlabeltable() fi
	++nextlabelno
!CPL "FWD LABEL",NEXTLABELNO
	labelpctable[nextlabelno]:=nil
	return nextlabelno
end

global proc definefwdlabel(int lab)=
	if labelpctable[lab] then serror("dupl label?") fi

!IF PCCURR.OPCODE=KJUMP AND PCCURR.LABELNO=LAB THEN
!CPL "JUMP NEXT???"
!FI
!
	labelpctable[lab]:=pccurr+1
end

global proc genxy(int x, y=0)=
	pccurr.x:=x
	pccurr.y:=y
end

global func getpcloffset(pcl p, q)int=
	(ref byte(p)-ref byte(q))/pclrec.bytes
end
