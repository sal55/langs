strbuffer pclv
global ref strbuffer pcldest = &pclv

int currlineno
symbol currpclproc

proc writepcl(pcl pcstart, pc, int pass)=
!write pc instruction to ttdeststr, as a single line of pcl
!index is index of ins in pccode/pcdata
	[512]char str

	int cmdcode, a
	int attrs
	ref strec d
	const tabx="!      ----------"

!CPL "WRITEPCL",PCLNAMES[PC.opcode]

	cmdcode:=pc.opcode

	case cmdcode
	WHEN KSKIP THEN
		RETURN

	when kprocdef then
!	CPL "--PROCDEF", SYMBOL(PC^).NAME
		currpclproc:=pc.def
!CPL =CURRPCLPROC
		gstr(tabx)
		gstr("Procdef:")
		gstr(currpclproc.name)
		gline()
		return
	when kprocend then
		gstr(tabx)
IF PC.HASLABEL THEN GSTR("<LABEL>") FI
		gstrln("End")
		return
	esac

	if pc.haslabel then
		gstr("                 ")
		glabeldef(pcstart, pc)
!		gstrln(str)
!		gline()
	fi

!	fprint @str, "# [#]: #: ", pc-1:"8zh", currlineno:"05jr", pc-pcstart+1:"4"
	fprint @str, "#: ", pc.lineno
	gstr(str)

	case cmdcode
	when kprocdef then
		currpclproc:=pc.def
		return
	when kcomment then
		gstr("! ")
		gstrln(pc.svalue)
		return
	esac

	str[1]:=0

	if pc.isaux then
		strcat(str, "*")
	fi

	strcat(str, pclnames[cmdcode]+1)

	a:=1
	gs_leftstr(pcldest, " ", 7, '-')
	gs_leftstr(pcldest, str, 11)
!	gstr(" ")

	if pclopnd[cmdcode] then
		strcpy(str, writepclopnd(pcstart, pc, pass))
		gstr(str)
		gstr(" ")
	fi

	attrs:=pclattrs[cmdcode]
	if attrs<>'    ' then

		gstr("<")
		to 4 do
			case attrs.[0..7]
			when ' ' then
				exit
			when 'n', 'b' then
				gstrint(pc.n)
			when 'x' then
				gstrint(pc.x)
			when 'y' then
				gstrint(pc.y)
			when 'c' then
				gstr(ccnames[pc.n])
			when 'u' then
				gstr(ttname[pc.usertag])
			when 'v' then
				gstr(ttname[pc.usertag2])
			esac
			attrs>>:=8
			if attrs iand 255<>' ' then gstr(" ") fi

		od
		gstr(">")
	fi

	gline()
end

function writepclopnd(pcl pcstart, pc, int pass)ichar=
!f=o/p channel
!fmt=single operand code
!x is value of operand
!n is operand @ (1..4)
	static [512]char str, str2
	symbol d
	ichar suffix, s
	int slen
	object p

!IF PASS=2 THEN
!	RETURN "OPND"
!FI

	d:=symbol(pc.def)

	case pclopnd[pc.opcode]
	when cint then
		print @str, pc.value

	when creal then
		print @str, pc.xvalue

	when cstring then
!CPL "CSTRING", =PASS
		if pass=1 then
!			recase cstringz			!COMPILER ERROR HERE????
			DOCSTRINGZ
		fi
!RETURN "<STROBJ>"
			p:=pc.objptr
			if (slen:=p.length)=0 then return """" fi
			s:=p.strptr
			goto dostring

	when cstringz then
DOCSTRINGZ:
!CPL "CSTRINGZ"
		s:=pc.svalue
		slen:=strlen(s)
dostring:
		if slen>=str.len then slen:=str.len fi
		memcpy(str, s, slen)			!truncate too-long strings
		str[slen+1]:=0
		convertstring(str, str2, slen)
!		fprint @&str[1], """#""", &.str2[1]
		fprint @str, """#""", &str2[1]

	when cstatic then
		if pass=1 then
			strcpy(str, d.name)
		else
			d:=stlinear
			while d, d:=d.nextlinear do
				if d.varptr=pc.varptr then
					exit
				fi
			od
			fprint @str, "[#] (#:#)", d.varptr:"h", (d|d.owner.name|"?"), (d|d.name|"?")
		fi

	when cframe then
		if pass=1 then
			strcpy(str, d.name)
		else
			d:=currpclproc.deflist

			while d do
				if d.nameid in [frameid, paramid] and d.index*16=pc.offset then
					fprint @str,"[#] (#)", pc.offset/16, d.name
					return str
				fi
				d:=d.nextdef
			od
		fi

	when csymbol then
		fprint @str, "#.$", d.name

	when cproc then
		if pass=1 then
			strcpy(str, d.name)
		else
!CPL "CPROC", D
!RETURN "PROC"
			d:=stlinear
			while d, d:=d.nextlinear do
				if d.labelref=pc.labelref then
					exit
				fi
			od
			fprint @str, "[#] (#:#)", pc.labelref, (d|d.owner.name|"?"), (d|d.name|"?")
		fi

	when cdllproc then
!		fprint @str, "[DLL:#]", getdottedname(d)
		fprint @str, "[DLL:#]", d.name

	when chost then
		print @str, pc.hostindex, hostfnnames[pc.hostindex]+2

	when cgenfield then
		if pass=1 then
			fprint @str, ".#", d.name
		else
!RETURN "GENFIELD"
			fprint @str, "## (#)", "#", pc.value, genfieldtable[pc.value].def.name
		fi
!
	when ctype then
		fprint @str, "T:# (#)", strmode(pc.typecode), pc.typecode

	when clabel then
		fprint @str, "L#", getpcloffset(pc.labelref,pcstart)+1
!		fprint @str, "L#", pc.labelno

	when coperator then
		if pc.pclop>200 then
			fprint @str, "(#)", mathsnames[pc.pclop-200]
		else
			fprint @str, "(#)", pclnames[pc.pclop]
		end

	when cbinto then
FPRINT @STR, "(BINTO)"
!		fprint @str, "(# #)", pc.bintoindex, pclnames[bintotable[pc.bintoindex].pclop]

	when cmaths then
		fprint @str, "<#>", mathsnames[pc.mathscode]+3

	else
	other:
		fprint @str, "<#>", opndnames[pclopnd[pc.opcode]]
	esac
	return str
end

global proc writemodpcl(imodule pm, int pass)=
!display code currently in pccode/pcopnd
	int cmd
	pcl pc, pclcode

	currlineno:=0
!CPL "WRITEALLPCL",=pass

	gstr("PCL FOR MODULE:")
	gstrln(pm.name)

	pc:=pclcode:=pm.pcstart

	repeat
		cmd:=pc.opcode

		writepcl(pclcode, pc, pass)
		++pc
	until cmd=kendmod

	gline()
end

global proc showpcl(isubprog sp, int pass)=
	filehandle f

	return when passlevel=run_pass

	gs_init(pcldest)
	gs_str(pcldest, "PROC ALL PCL pass:")
	gs_strint(pcldest, pass)
	gs_line(pcldest)

	if sp then
		showpcl2(sp, pass)
	else
		for i to nsubprogs do
			showpcl2(subprogs[i], pass)
		od
	fi

!CPL "SHOWPCL", PASS
	f:=fopen((pass|"PCL1", "PCL2"|"PCL3"), "wb")
	if not f then return fi
	gs_println(pcldest, f)
!CPL "WROTE PCL FILE"
!OS_GETCH()

	fclose(f)
end

global proc showpcl2(isubprog sp, int pass)=

	for i:=sp.firstmodule to sp.lastmodule do
		writemodpcl(modules[i], pass)
	od
end

global proc gstr(ichar s)=
	gs_str(pcldest,s)
end

global proc gstrln(ichar s)=
	gs_strln(pcldest,s)
end

global proc gline=
	gs_line(pcldest)
end

global proc gstrint(int a)=
	gs_strint(pcldest,a)
end

global proc glabeldef(pcl pcstart, pc)=
!GSTRLN("LABELDEF")

	gstr("L")
	gstrint(getpcloffset(pc,pcstart)+1)
	gstrln(": ")

!	int lab:=0
!	for i to nextlabelno do
!		if pc=labelpctable[i] then lab:=i fi
!	end
!
!	gstr("L")
!	gstrint(lab)
!
!	gstrln(": ")
end

