global proc loadproject(ichar file)=
!	loadsyslib()

!try .ma version of .m not present
	if not checkfile(file) then
		loaderror("Can't open", file)
	end

	sourceext:=pcm_copyheapstring(extractext(file))

	if eqstring(sourceext, "ba") then
		loaderror("BA input not ready")
	end

	loadsp(file, 1)
end

global func loadsp(ichar filename, int mainsub=0)isubprog sp=
!source = nil:  load lead module and dependencies from given sourcefile
!source <> nil: source code is given directly. filename can give a name
! to that source text, or if nil, and internal name is applied

	const maxmods=500
	const maxsubs=250
	[maxmods]ichar modnames
	[maxmods]symbol aliases
	[maxmods]ichar paths
	[maxsubs]ichar subnames
	[maxsubs]ichar subpaths
	int nmods:=0, nsubs:=0, hdrcode
	int firstmod, lastmod, issyslib:=0
	imodule pm
	symbol d, stalias
	ichar path, name, ext, file2
	byte proj:=0


CPL "LOADSP", FILENAME
!CPL "LOADSP", =EXTRACTBASEFILE(FILENAME)

!	if eqstring(extractbasefile(filename), syslibname) then
!		issyslib:=1
!	end
	pm:=loadmodule(filename, issyslib)

	if pm=nil then
		loaderror("Can't load lead module: ", filename)
	end
	path:=pm.file.path

	for i to nsubprogs do
		if eqstring(pm.name, subprogs[i].name) then
			loaderror("Subprog already loaded: ", sp.name)
		end
	end

!reader header info
	startlex(pm.file)
	lex()
	skipsemi()

	if lx.token=tk_project then
		proj:=1
		lex()
		checkequals()
		lex()
	end
!PS("H1")

!look at default syslib loading
	if mainsub and syslevel then
		println "<Load Syslib>", syslevel
		subnames[++nsubs]:="qsyswin"
		subpaths[nsubs]:=path
	end

	do
!PS("H2")
		skipsemi()
!PS("H3")
		case lx.token
		when tk_header then
!CPL "HDR",HEADERDIRNAMES[LX.SUBCODE]
			hdrcode:=lx.subcode

			lex()
			case hdrcode
			when hdr_module then
				checktoken(tk_name)
				name:=lx.symptr.name

				if not eqstring(name, pm.name) then
					if nmods>=maxmods then loaderror("Too many modules in header") end
					modnames[++nmods]:=name
					paths[nmods]:=path
					aliases[nmods]:=nil

				end
				if nextlx.token=tk_name and eqstring(nextlx.symptr.name, "as") then
					lex()
					lex()
					if lx.token=tk_name then
						stalias:=lx.symptr
						lex()
					else
						checktoken(tk_stringconst)
						stalias:=addnamestr(lx.svalue)
					end
					aliases[nmods]:=stalias
				end

			when hdr_import then
				checktoken(tk_name)
				if nsubs>=maxsubs then loaderror("Too many imports in header") end
				subnames[++nsubs]:=lx.symptr.name
				subpaths[nsubs]:=path

			when hdr_linkdll then
				checktoken(tk_name)
				addlib(lx.symptr.name)

			when hdr_sourcepath then
				checktoken(tk_stringconst)
!				unless loadedfromma then			!ignore paths for .ma
					path:=pcm_copyheapstring(lx.svalue)
!				end
			else
				loaderror("Hdr cmd not ready")
			end case
			lex()

		when tk_semi then
		else
			exit
		end case
	end

	if proj then
		checkend(tk_end, tk_project)
	end
	skipsemi()

!process nested imports
	for i to nsubs do
CPL I,SUBNAMES[I], =PM.NAME
		if eqstring(subnames[i], pm.name) then loaderror("Importing self") end
!		loadsp(getmodulefilename(path, subnames[i]))
		loadsp(getmodulefilename(subpaths[i], subnames[i]))
	end

!create new subprog entry
	if nsubprogs>=maxsubprog then loaderror("Too many subprogs") end
	sp:=pcm_allocz(subprogrec.bytes)
	subprogs[++nsubprogs]:=sp
	sp.subprogno:=nsubprogs

	if mainsub then
!		loadsyslib()
		mainsubprogno:=nsubprogs
	end

	firstmod:=nmodules+1
	lastmod:=firstmod+nmods
	if lastmod>maxmodule then loaderror("Too many modules") end
	nmodules:=lastmod
	pm.subprogno:=nsubprogs
	pm.islead:=1
	pm.moduleno:=firstmod
	pm.stmodule:=d:=getduplst(stprogram, addnamestr(pm.name), moduleid, 1)
!	pm.stmodule:=d:=getduplnameptr(stprogram, addnamestr(pm.name), moduleid)
	d.moduleno:=firstmod
	d.subprogno:=nsubprogs

	moduletosub[firstmod]:=nsubprogs

	sp.name:=pm.name
	sp.firstmodule:=firstmod

	sp.mainmodule:=0

	sp.lastmodule:=lastmod
	sp.issyslib:=issyslib

!create new set of modules[] entries and load those other modules
!create stmodule entries for each module
	modules[firstmod]:=pm

	for i to nmods do
		pm:=loadmodule(getmodulefilename(paths[i], modnames[i], issyslib), issyslib)
		stalias:=aliases[i]
		if not pm then
			loaderror("Can't load: ", modnames[i])
		end
		modules[firstmod+i]:=pm
		pm.stmodule:=d:=getduplst(stprogram, addnamestr(pm.name), moduleid, 1)
!		pm.stmodule:=d:=getduplnameptr(stprogram, addnamestr(pm.name), moduleid)
		pm.subprogno:=nsubprogs
		
		if stalias then
			pm.stmacro:=getduplst(stprogram, stalias, macroid)
			adddef(stprogram, pm.stmacro)
			pm.stmacro.deflist:=nil
			pm.stmacro.code:=createname(d)
		end

		d.moduleno:=pm.moduleno:=firstmod+i
		d.subprogno:=nsubprogs
		moduletosub[d.moduleno]:=nsubprogs

		for j to nmodules when eqstring(modules[i].name, pm.name) do
			serror_s("Dupl mod name:", pm.name)
		end
	end

	return sp
end

global func loadsourcefile(ichar filespec, int issyslib=0)ifile pf=
	ichar s, filename
	[300]char str

	filename:=extractfile(filespec)

!CPL "LSF1", =FILENAME, =NSOURCEFILES, =ISSYSLIB

!look for file already loaded, or preloaded due to built-in syslib or .ma file:
	for i to nsourcefiles do
!CPL "LOOP", I, FILENAME, SOURCES[I].FILENAME, SOURCES[I].ISSYSLIB
		if eqstring(filename, sources[i].filename) and sources[i].issyslib=issyslib then
			return sources[i]
		end
	end

	pf:=newsourcefile()

	pf.filespec:=pcm_copyheapstring(filespec)
	pf.path:=pcm_copyheapstring(extractpath(filespec))
	pf.name:=pcm_copyheapstring(extractbasefile(filespec))
	pf.filename:=pcm_copyheapstring(filename)
!	if extractext(filename)^ in ['m', 'M'] then
!		pf.mfile:=1
!	fi

	pf.issyslib:=issyslib
	pf.fileno:=nsourcefiles

	s:=cast(readfile(filespec))			!will overallocate by a few bytes
	if not s then				!unexpected error
		return nil
	end
	pf.text:=s
	pf.size:=rfsize

!	if passlevel=ma_pass then
!		pf.dupl:=pcm_copyheapstring(s)
!	end

	(s+rfsize)^:=0				!replace etx, 0 by 0, 0 (effectively, just zero)
	return pf
end

global func newsourcefile:ifile pf=
	pf:=pcm_allocz(filerec.bytes)
	if nsourcefiles>=maxsourcefile then loaderror("Too many sources") end
	sources[++nsourcefiles]:=pf
	pf.fileno:=nsourcefiles
	pf
end

global func loadmodule(ichar filespec, int issyslib=0)imodule pm=
	ifile pf

!CPL "LOADMOD", FILESPEC, =ISSYSLIB
	pf:=loadsourcefile(filespec, issyslib)
	return nil when pf=nil

	pm:=pcm_allocz(modulerec.bytes)

	pm.name:=pf.name
	pm.file:=pf
	pm.fileno:=pf.fileno
	pm.issyslib:=issyslib

	return pm
end

global proc addlib(ichar libname)=
	for i to nlibfiles do
		if eqstring(libfiles[i], libname) then return end
	end
	if nlibfiles>=maxlibfile then
		loaderror("Too many libs")
	end
	libfiles[++nlibfiles]:=libname
end

func getmodulefilename(ichar path, name, int issyslib=0)ichar =
	static [300]char str

	fprint @str, "##.#", path, name, sourceext
	return str
end
