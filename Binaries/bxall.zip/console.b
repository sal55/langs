!!Virtual keycodes
export const vklbutton=1		!note these are physical not logical buttons
export const vkrbutton=2
export const vkmbutton=4		!middle button is correct
export const vkbackspace=8
export const vktab=9
export const vkclear=12
export const vkenter=13
export const vkshift=16
export const vkctrl=17
export const vkalt=18
export const vkbreak=19
export const vkcapslock=20
!export const vkrshift=21
export const vkrctrl=22
!export const vkralt=23
export const vkinslock=24
export const vkescape=27
export const vkspace=32
export const vkpageup=33
export const vkpagedown=34
export const vkend=35
export const vkhome=36
export const vkleft=37
export const vkup=38
export const vkright=39
export const vkdown=40
export const vkinsert=45
export const vkdelete=46
export const vkhelp=47
export const vk0='0'
export const vka='A'
export const vkwindows=91
export const vkrightbutton=93
export const vknumpad0=96		!96..105 = '0'..'9'
export const vkmul=106
export const vkadd=107
export const vksub=109
export const vkdecimal=110
export const vkdiv=111
export const vkf1=112
export const vkf2=113
export const vkf3=114
export const vkf4=115
export const vkf5=116
export const vkf6=117
export const vkf7=118
export const vkf8=119
export const vkf9=120
export const vkf10=121
export const vkf11=122
export const vkf12=123
!export const vklsq=128
!export const vkrsq=129
!export const vksemi=130
!export const vkquote=131
!export const vkstroke=132
!export const vkdot=133
!export const vkcomma=134
!export const vkbackslash=135
!export const vkquote2=136
!export const vkequals=137
!export const vkminus=138
!export const vkhash=139
export const vklshift=160
export const vkrshift=161
export const vklcontrol=162
export const vkrcontrol=163
export const vklalt=164
export const vkralt=165

!oem codes
export const vkminus=189
export const vkequals=187
export const vklsq=219
export const vkrsq=221
export const vksemi=186
export const vkquote=192
export const vkhash=222
export const vkcomma=188
export const vkperiod=190
export const vkslash=191
export const vkbackslash=220
export const vkbackquote=223

export const con_black=0
export const con_dkblue=1
export const con_dkred=2
export const con_dkmagenta=3
export const con_dkgreen=4
export const con_dkcyan=5
export const con_dkyellow=6
export const con_dkgrey=7
export const con_grey=8
export const con_blue=9
export const con_red=10
export const con_magenta=11
export const con_green=12
export const con_cyan=13
export const con_yellow=14
export const con_white=15


export record winrec =
	var posx,posy
	var cols,rows
	var fgnd,bgnd			!default text/background colour

	var columns			!used when divided into columns
	var itemcols			!width of each column
	var pagesize			!columns*rows

	var name

	var hdata			!pointer to data record, or is nil
end

export var wconscreen
export var screencols,screenrows

export var chardata			!string these two represent row of the console
export var attrdata			!string

export var defscreenfgnd=con_black
export var defscreenbgnd=con_grey
export var rlkey=0		!set by readline, when special key has been input
export var rlbuffer			!contents of readline buffer when special key pressed

var cmdindex,ncmds
var cmdhistory

export const capsmask  = 0x8		!shift states as they are in .keyshift
export const altmask   = 0x4
export const ctrlmask  = 0x2
export const shiftmask = 0x1

export const capsbit=3
export const altbit=2
export const ctrlbit=1
export const shiftbit=0

var keypending=0
var lastkey
var pendkey
export var hconsole, hconsolein
var colourpalette

!export var wscreencols,wscreenrows
!export var currbgnd=-1,currfgnd=-1
export var currbgnd=con_grey, currfgnd=con_black

!export var screencolour=con_dkred..con_grey

!export var colourmap
export VAR SUPPRESS=0

VAR ALLCHARS

proc START=
!if iswindows() then
!	CPL "WINCON INIT"
		init()
!fi
	end

!proc main=
!	init()
!	settitle("New Title")
!
!!keyscreentest()
!
!!W:=MAKEWIN((1,20),(20,20))
!!CLEARWIN(W)
!
!!SHOWTEXT("^^^^^^^^^^^^^^^^^")
!
!a:=rkey(10,20,30)
!!	setpos(12, 10)
!!	print "***********hello"
!!	waitkey()
!end

proc keyscreentest=
	(cols,rows):=(screencols, screenrows)
	CPL =COLS,=ROWS

	row:=rows%2
	col:=cols%2
	ch:="X"

	setcolour(6,1)

	do
		setpos(col,row)
		cp ch
		setpos(col,row)
		k:=getkey().keycode
		case k
		when 27 then
			exit
		when vkleft then col:=max(1,col-1)
		when vkright then col:=min(cols,col+1)
		when vkup then row:=max(1,row-1)
		when vkdown then row:=min(rows,row+1)
		esac
	od

!waitkey()

end

export func makerspoint(x,y)=
!combine x,y into 32-bit value (rspoint)
	return y<<16 ior x
end

export proc setpos(col,row)=

!!ROW+:=10
!fprint "\s[{#};{#}H",row,col

	setconsolecursorposition(hconsole,makerspoint(col-1,row-1))
end

export func getpos=
	info:=new(ws_console)
	getconsolescreenbufferinfo(hconsole,&info)
	return (info.pos.x+1,info.pos.y+1)
end

export proc init(cols=100)=
!static var setdimdone=0

!CPL "CONSOLE INIT-----------"


!	consolesw.init(cols)
	cmdhistory::=()	!"one","two","three","four")
	ncmds:=cmdhistory.upb
	cmdindex:=0

!screencols:=consolesw.wscreencols
!screenrows:=consolesw.wscreenrows
!

	hconsole:=getstdhandle(-11)
	hconsolein:=getstdhandle(-10)
	lastkey:=new(ws_keyevent)
	lastkey.repeatcount:=0
	pendkey:=new(ws_keyevent)

	setdims(cols,60)
!	setdims(50,20)

	getdims()

!CPL =SCREENCOLS

	wconscreen:=makewin((1,1),(screencols,screenrows),defscreencolour)

	colourpalette:=new(ws_palette16)

	setstdpalette()
end

export func setcursor(?visible)=
	cursor:=new(ws_cursor)
	getconsolecursorinfo(hconsole,&cursor)

	if visible.isdef then
		cursor.visible:=visible
		setconsolecursorinfo(hconsole,&cursor)
	fi
	return cursor.visible
end

export proc setcolour(fgnd, ?bgnd)=
!call with as (fgnd,bgnd) or as (fgnd..bgnd)

	if bgnd.isvoid then bgnd:=currbgnd fi

	if fgnd=currfgnd and bgnd=currbgnd then
!		return
	fi

	currfgnd:=fgnd
	currbgnd:=bgnd

	setconsoletextattribute(hconsole,(bgnd*16+fgnd))
end

export proc settitle(caption)=
	setconsoletitle(caption)
end

export func getkeychar=
!wait for any key, return single char code; as returned by C's getch()
	return waitkey()
end

export func getkey2=
!wait for any key, return keyrec
!includes shift key presses as discrete keys
!use getkey() to ignore these

	return getchx()

	k:=getchx()			!get keyrec, encoded as int

	key:=new(rkey)			!convert to proper keyrec
	key.charcode:=k iand 65535
	key.shift:=k>>24
	key.keycode:=k.[23..16]
!CPL "GK2:",KEY

	return key
end

export func getkey=
!calls igetkey but doesn't return shift keys as discrete key presses
	do
		k:=getkey2()
		case k.keycode
		when vkshift,vkctrl,vkalt,vkcapslock then
		else
			exit
		esac
	od
	return k
end

export func keyready=
	return testkey()
end

export proc showtext(s,?x,?y)=

	if x.isdef then
		setpos(x,y)
	fi

	count:=0
	if s then
		if not suppress then
			writeconsole(hconsole,s,s.len,&count,nil)
		fi
	fi
end

proc setwindowsize(cols,rows)=
	r:=new(ws_srect)
	r.leftx:=0
	r.rightx:=cols-1
	r.top:=0
	r.bottom:=rows-1
	if not setconsolewindowinfo(hconsole,1,&r) then
!	CPL "WINDOW ERROR 1"
!	abort("Window error 1")
	fi
end

export proc setdims(cols,rows)=
!set new size for console, by reinitialising

	maxcol:=cols
	maxrow:=rows

	info:=new(ws_console)
	oldscreenattributes:=info.attributes
	oldscreensize:=info.size

	oldcols:=info.window.rightx-info.window.leftx+1
	oldrows:=info.window.bottom-info.window.top+1

	IF OLDSCREENSIZE.X>COLS OR OLDSCREENSIZE.Y>ROWS THEN	!need to reduce window size first
		setwindowsize(oldscreensize.x min cols, oldscreensize.y min rows)
	fi

!Set the new size of the entire (virtual) console window
	if setconsolescreenbuffersize(hconsole,rows<<16+cols)=0 then
!	abort("Buffer size error")
	fi

!now set the size of the displayed portion of it; in this case exactly the same
!size as the buffer, with no scrollbars
	setwindowsize(cols,rows)

	wscreencols:=cols
	wscreenrows:=rows

!hide blinking cursor
	cursor:=new(ws_cursor)
	cursor.size:=10
	cursor.visible:=1
end

export proc setpalette(index,colour)=
!index is 0..15; colour is an rgb value bbggrr
!updates local palette array
!to update actual console, use writepalette
	colourpalette[index]:=colour
end

export proc writepalette=
	r:=new(ws_consoleex)
	r.recsize:=ws_consoleex.bytes
	X:=getconsolescreenbufferinfoex(hconsole,&r)

	r.palette:=colourpalette

	R.WINDOW.RIGHTX:=R.WINDOW.RIGHTX+1		!workaround off-by-one bug
	R.WINDOW.BOTTOM:=R.WINDOW.BOTTOM+1

	X:=setconsolescreenbufferinfoex(hconsole,&r)

!export proc READPALETTE=
!r:=new(rconsoleex)
!r.recsize:=rconsoleex.bytes
!x:=getconsolescreenbufferinfoex(hconsole,&r)
!
!CPL "GCSBI X=",X
!FOR I:=0 TO 15 DO
! CPL I,":",R.PALETTE[I]:"H"
!OD
!
end

proc setstdpalette=
!export const con_black=0
!export const con_dkblue=1
!export const con_dkred=2
!export const con_dkmagenta=3
!export const con_dkgreen=4
!export const con_dkcyan=5
!export const con_dkyellow=6
!export const con_grey=7
!export const con_dkgrey=8
!export const con_blue=9
!export const con_red=10
!export const con_magenta=11
!export const con_green=12
!export const con_cyan=13
!export const con_yellow=14
!export const con_white=15

!R G B
	cols:=(
	(0,		0,		0),			!black
	(0,		0,		128),		!dk blue
	(128,	0,		0),			!dk red
	(128,	0,		128),		!dk magenta
	(0,		128,	0),			!dk green
	(0,		128,	128),		!dk cyan
	(128,	128,	0),			!dk yellow
	(128,	128,	128),		!dk grey
	(192,	192,	192),		!grey
	(0,		0,		192),		!blue
	(192,	0,		0),			!red
	(192,	0,		192),		!magenta
	(0,		192,	0),			!green
	(0,		192,	192),		!cyan
	(192,	192,	0),			!yellow
	(255,	255,	255))		!white

	for i,c in cols do
		setpalette(i-1,c[3]<<16+c[2]<<8+c[1])
	od
!CPL "WRITEPAL"; WAITKEY()
	writepalette()
end

proc getdims=
	info:=new(ws_console)
	getconsolescreenbufferinfo(hconsole,&info)

	screencols:=info.window.rightx-info.window.leftx+1
	screenrows:=info.window.bottom-info.window.top+1
end

export func getchx=
	const rightaltmask	= 1				!masks used by .controlkeystate
	const leftaltmask	= 2
	const leftctrlmask	= 8
	const rightctrlmask	= 4
	const shiftmask		= 16
	const capsmask		= 128
	const scrollmask	= 64

	const leftctrlbit	= 3		!for c.l.p
	const rightctrlbit	= 2

	if keypending then
		lastkey:=pendkey
		keypending:=0
	else
		if lastkey.repeatcount=0 then
			repeat
				count:=0
				readconsoleinput(hconsolein,&lastkey,1,&count)
			until lastkey.eventtype=1 and lastkey.keydown=1
		fi
	fi

	altdown		:= (lastkey.controlkeystate iand (leftaltmask ior rightaltmask)|1|0)
	ctrldown	:= (lastkey.controlkeystate iand (leftctrlmask ior rightctrlmask)|1|0)
	shiftdown	:= (lastkey.controlkeystate iand shiftmask|1|0)
	capslock	:= (lastkey.controlkeystate iand capsmask|1|0)

	lastkey.repeatcount:=lastkey.repeatcount-1

	charcode:=lastkey.asciichar
	keycode:=lastkey.virtualkeycode iand 255

!for keycodes in range 186 to 223, which are all stand-alone punctuation keys, I might
!wish to set charcode to the appropriate printed char code (currently charcode will be
!zero, and keyboard handlers need to detect keycodes such as vkequals)
!
	if altdown and ctrldown and charcode=166 then
		altdown:=ctrldown:=0;
	else
		if altdown or ctrldown then
			charcode:=0;
			if keycode>='A' and keycode<= 'Z' then
				charcode:=keycode-'@'
			fi
		fi
	fi

	keyshift:=capslock<<3 ior altdown<<2 ior ctrldown<<1 ior shiftdown

	keyshift.[4]:=lastkey.controlkeystate.[leftctrlbit]		!for c.l.p
	keyshift.[5]:=lastkey.controlkeystate.[rightctrlbit]

!need to be more ruthless with how keycoded and charcodes are combined.
!More combinations need to have only charcode or keycode set, and the other zero

	switch charcode
	when 'A'..'Z','a'..'z','0'..'9' then
	when 8,9,13,27,' ','`' then
	when 0 then				!already key-only event
	else
		keycode:=0
	end switch

	return rkey(charcode,keycode,keyshift)

end

export proc flushkeyboard=
	flushconsoleinputbuffer(hconsolein)
end

export proc w_writeconsolerow(text, attributes, length, row)=
	buffersize:=1<<16+length
	coord:=0

	box:=ws_srect(0,row-1,length-1,row-1)

	buffer:=new(array,ws_charinfo,length)

	for i:=1 to length do
		x:=new(ws_charinfo)
		x.asciichar  := text.[i]
		x.attributes := attributes.[i]
!	x.attributes := attributes.[1]
		buffer[i]:=x
	od
!CPL "HELLO",text; WAITKEY()

	writeconsoleoutputa(hconsole, &buffer,buffersize,coord,&box)
end

export func setclipboard(s)=
!copy text to the Windows clipboard
!return status 0 if no clipboard o/p was possible
	const ghnd=2 + 0x40

	if openclipboard(nil)=0 then
		return 0
	fi

	emptyclipboard()

	if s<>"" then
		h:=globalalloc(ghnd,s.len+1)
		p:=globallock(h)

		memcpy(p,&s,s.len+1)
	globalunlock(h)
		setclipboarddata(cf_text,h)
	fi

	closeclipboard()

	return 1
end

export func getclipboard=
!copy text from Windows clipboard
!return clipboard text, or "" when error or not text data available

	if openclipboard(nil)=0 then
		return ""
	fi

	htext:=getclipboarddata(cf_text)

	if not htext then
		return ""
	fi

	size:=globalsize(htext)		!should include zero terminator

	p:=globallock(htext)
	s:=makestr(p,size-1)		!assignment should copy the string data

	globalunlock(htext)

	closeclipboard()
	return s
end

export func makewin(pos, dims, fgnd=con_black,bgnd=con_grey,name="Anon")=
!export func makewin(pos, dims, ?colour)=

	w:=new(winrec)
	w.posx:=pos[1]
	w.posy:=pos[2]
	w.cols:=dims[1]
	w.rows:=dims[2]
	w.columns:=1
	if dims.len>=3 then
		w.columns:=dims[3]
	fi

!CPL =POS,=DIMS,=W.COLUMNS

	w.itemcols:=w.cols%w.columns
	w.pagesize:=w.rows*w.columns
	w.hdata:=nil

	w.fgnd:=fgnd
	w.bgnd:=bgnd
	w.name:=name

	return w
end

export proc clearwin(w)=
!clear region used by listbox
!can clear multi-columns at once
	spaces:=" "*w.cols

	setcolour(w.fgnd,w.bgnd)
	for i:=1 to w.rows do
		showtext(spaces,w.posx,w.posy+i-1)
	od
	setpos(w.posx,w.posy)
end

export proc wsetpos(w,col,row)=
	setpos(w.posx+col-1,w.posy+row-1)
end

export proc wshowtext(w,s,?col,?row)=
	if col.isdef then
		showtext(s,w.posx+col-1,w.posy+row-1)
	else
		showtext(s)
	fi
end

export proc wshowtext_b(w,s, colrow, fgnd,bgnd)=
!version of wshowtext that dumps into char/attr buffer.
!w is used for absolute column number

	if colrow.islist then
		col:=colrow[1]
	else
		col:=colrow
	fi


	length:=s.len
	offset:=w.posx-1	!hoz offset

	chardata.[(col+offset)..(col-1+length+offset)]:=s

!	attr:=consolesw.colourmap[bgnd]<<4+consolesw.colourmap[fgnd]
	attr:=bgnd<<4+fgnd

	attrdata.[(col+offset)..(col-1+length+offset)]:=chr(attr)*length
end

export proc updateconsolerow(w, row)=
!write out latest contents to chardata/attrdata to console
!this represents an entire composite wlineno+wvgap+wedit row, for given row within wedit
!etc
	w_writeconsolerow(chardata,attrdata,screencols,w.posy+row-1)
end

export func getkeyname(key)=
	case key.keycode
	when vkleft then name:="left"
	when vkright then name:="right"
	when vkup then name:="up"
	when vkdown then name:="down"
	when vkpageup then name:="pageup"
	when vkpagedown then name:="pagedown"
	when vkhome then name:="home"
	when vkend then name:="end"
	when vkinsert then name:="insert"
	when vkdelete then name:="delete"
	when vktab then name:="tab"
	when vkescape then name:="escape"
	when vkbackspace then name:="backspace"
	when vkenter then name:="enter"
	when vkf1..vkf12 then name:="f"+tostr(key.keycode-vkf1+1)
	when vkspace then name:="space"
	else
		if key.charcode in [1..26] then	!ctrl code
			name:=chr(key.charcode+'a'-1)
		elsif key.charcode in ['!','"','�','$','%','^','&','*','(',')','-','_','+','=','[',']',
		'{','}',':',';','\'','@','~','#','<','>',',','.','/','�','�','|','\\','?'] then
			name:=chr(key.charcode)
			key.shift iand:=inot shiftmask		!ignore any shift press needed to get char

		elsif key.keycode in ['A'..'Z','0'..'9'] then
			if (key.shift iand (ctrlmask ior altmask))=0 then
				name:=chr(key.charcode)
				key.shift iand:=inot shiftmask
			else
				name:=convlc(chr(key.keycode))
			fi
		elsif key.keycode in (186..223) then
			case key.keycode
			when vkminus then name:="-"
			when vkequals then name:="="
			when vklsq then name:="["
			when vkrsq then name:="]"
			when vksemi then name:=";"
			when vkquote then name:="'"
			when vkhash then name:="#"
			when vkcomma then name:=","
			when vkperiod then name:="."
			when vkslash then name:="/"
			when vkbackslash then name:="\\"
			when vkbackquote then name:="`"
			else
				return "?"
			esac
		else
			return "?"
		fi
	esac

	prefix::="*"
	if key.shift iand shiftmask then prefix+:="s" fi
	if key.shift iand ctrlmask then prefix+:="c" fi
	if key.shift iand altmask then prefix+:="a" fi
	return prefix+name

end

export func keynametokey(name)=
!given a key name in the format "*...", reconstruct an rkey record, and return that
	charcode:=shift:=keycode:=0

	name:=rightstr(name,-1)		!get rid of "*"

	if name.len=1 then		!simple printable key, no shifts
		charcode:=asc(name)
		goto simplekey

	else				!any letters s,c,a on left indicate a modifier
		while name.len>1 do
			case leftstr(name)
			when "s" then
				shift ior:=shiftmask
				name:=rightstr(name,-1)
			when "c" then
				shift ior:=ctrlmask
				name:=rightstr(name,-1)
			when "a" then
				shift ior:=altmask
				name:=rightstr(name,-1)
			else
				exit
			esac
		od

		case name
		when "left" then keycode:=vkleft
		when "right" then keycode:=vkright
		when "up" then keycode:=vkup
		when "down" then keycode:=vkdown
		when "pageup" then keycode:=vkpageup
		when "pagedown" then keycode:=vkpagedown
		when "home" then keycode:=vkhome
		when "end" then keycode:=vkend
		when "insert" then keycode:=vkinsert
		when "delete" then keycode:=vkdelete
		when "tab" then keycode:=charcode:=vktab
		when "escape" then keycode:=vkescape
		when "backspace" then keycode:=charcode:=vkbackspace
		when "enter" then keycode:=charcode:=vkenter
		when "space" then keycode:=charcode:=vkspace
		else
			if name.len>=2 and leftstr(name)="f" then	!function key
				keycode:=vkf1+strtoval(rightstr(name,-1))-1
			elsif name.len=1 then				!ordinary key, but with shifts
	simplekey:
				c:=asc(name)
				case c
				when ['A'..'Z'] then
					keycode:=c
				when ['a'..'z'] then
					keycode:=c-' '
				when ['0'..'9'] then
					keycode:=c
				when '-','_' then keycode:=vkminus
				when '=','+' then keycode:=vkequals
				when '[','{' then keycode:=vklsq
				when ']','}' then keycode:=vkrsq
				when ';',':' then keycode:=vksemi
				when '\'','@' then keycode:=vkquote
				when ',','<' then keycode:=vkcomma
				when '.','>' then keycode:=vkperiod
				when '/','?' then keycode:=vkslash
				when '\\','|' then keycode:=vkbackslash
				when '`','�' then keycode:=vkbackquote
				when '#','~' then keycode:=vkhash
				when '!' then keycode:='1'
				when '"' then keycode:='2'
				when '�' then keycode:='3'
				when '$' then keycode:='4'
				when '%' then keycode:='5'
				when '^' then keycode:='6'
				when '&' then keycode:='7'
				when '*' then keycode:='8'
				when '(' then keycode:='9'
				when ')' then keycode:='0'
				else
					pcerror("keynametokey")
				end
			fi
		esac
	fi

	if shift iand (altmask ior ctrlmask) then
		charcode:=0
		if keycode in 'A'..'Z' then
			charcode:=keycode-'@'
		fi
	fi

	key:=new(rkey)			!convert to proper keyrec
	key.charcode:=charcode
	key.shift:=shift
	key.keycode:=keycode
	return key
end

export proc clearscreen(?bgnd,?fgnd)=

if bgnd.isvoid then bgnd:=defscreenbgnd fi
if fgnd.isvoid then fgnd:=defscreenfgnd fi
setcolour(fgnd,bgnd)

for i:=1 to screenrows do
	setpos(1,i)
	showtext(" "*screencols)
!	showtext("*"*screencols)
od
setpos(1,1)
end

export func readline(?cmdline,donewline=1)=
!this func doesn't handle tabs properly
!would need to maintain 2 buffers, one with tabs translated to spaces
!or convert tabs to another char which is translated back to tabs on exit
!return with input buffer set to the line, but also returns the complete line
!newline=1 to end with a newline, 0 to leave it

!readln
!return

	buffer:=""
	nchars:=0
!congetpos()

!NOTE: getpos is dodgy using TERMCON; MAY NEED CALLER TO SPECIFY START POINT
	(startx,starty):=(getpos())

	pos:=0		!with nchars shown, pos can be 0 to nchars

	reenter:
	if cmdline.isdef and cmdline<>"" then
		buffer:=cmdline
	reenter2:
		pos:=nchars:=buffer.len
	fi

	do
! print "_"
		rlkey:=0			!normal input starts with "*" will expect rlkey to be a keyrec
		setpos(startx,starty)
		print buffer
		setpos(startx+pos,starty)

		key:=getkey()
		keycode:=key.keycode
		keyshift:=key.shift

		case keycode
		when vkpageup,vkpagedown,vkup,vkdown,vkinsert,vkf1..vkf12 then

	dospecial:
		rlbuffer:=buffer
			oldbufferlen:=buffer.len		!to help erase old buffer
			buffer:=getkeyname(key)
			rlkey:=key				!allow caller to use key code rather than name
			exit

		when vkleft then
			if buffer="" then goto dospecial fi
			if (keyshift iand 7) then goto dospecial fi

			if pos>0 then
				--pos
			fi

		when vkhome then
			if buffer="" then goto dospecial fi
			if (keyshift iand 7) then goto dospecial fi
			pos:=0

		when vkend then
			if buffer="" then goto dospecial fi
			if (keyshift iand 7) then goto dospecial fi
			pos:=nchars

		when vkright then
			if buffer="" then goto dospecial fi
			if (keyshift iand 7) then goto dospecial fi
			if pos<nchars then
				++pos
			fi

		when vkenter then

!  println
			exit

		when vkbackspace then

			if (keyshift iand 7) then goto dospecial fi
			if nchars then
				setpos(startx,starty)
				print " "*buffer.len

				case pos
				when 0 then			!not allowed
				when nchars then		!at end
					buffer:=leftstr(buffer,-1)
					--nchars
					--pos
				else				!in middle
					buffer:=leftstr(buffer,pos-1)+rightstr(buffer,-(pos))
					--nchars
					--pos
				esac

			fi

		when vkdelete then
			if (keyshift iand 7) then goto dospecial fi
			if nchars and nchars=pos then
				goto delline
			fi
			if nchars=0 then
				goto dospecial
			fi
			if nchars then
!CPL "\NNCHARS",=NCHARS,++CCC,=POS,"\N"
				setpos(startx,starty)
				print " "*buffer.len

				case pos
				when nchars then		!not allowed
!			when 0 then			!at start
!				buffer:=leftstr(buffer,-1)
!				--nchars
				else				!in middle
					buffer:=leftstr(buffer,pos)+rightstr(buffer,-(pos+1))
					--nchars
!    --pos
				esac

			fi

		when vkescape then
			if nchars=0 then
				goto dospecial
!   oldbufferlen:=buffer.len
!   buffer:="*esc"
!   exit
			fi
	delline:
			setpos(startx,starty)
			print " "*buffer.len

			buffer:=""
			nchars:=pos:=0

		when vktab then
			goto normalkey

		else
	normalkey:
			if (key.charcode>=' ' or key.charcode=9) then
				if pos=0 then
					buffer:=chr(key.charcode)+buffer
				elsif pos=nchars then
					buffer:=buffer+chr(key.charcode)
				else
					buffer:=leftstr(buffer,pos)+chr(key.charcode)+rightstr(buffer,-(pos))
				fi
				++nchars
				++pos
			else
				GOTO DOSPECIAL
				print "<",keycode,key.charcode,">"
			fi

		esac
	od

	case buffer
	when "*cup","*cdown" then
		if ncmds then
			setpos(startx,starty)
			print " "*oldbufferlen

			if cmdindex=0 then		!get started on last
				cmdline:=cmdhistory[ncmds]
				cmdindex:=ncmds
				goto reenter
			fi

			if buffer="*cup" and cmdindex>1 then
				--cmdindex
			elsif buffer="*cdown" and cmdindex<ncmds then
				++cmdindex
			fi
			cmdline:=cmdhistory[cmdindex]
			goto reenter
		fi
		buffer:=""
		goto reenter2
	esac

	if buffer.len>1 and leftstr(buffer)<>"*" then
		if ncmds=0 or cmdhistory[ncmds]<>buffer then
			cmdhistory[++ncmds]:=buffer
		fi
		cmdindex:=0
	fi

	if donewline then println fi

	return sreadln(buffer)
end

export proc wsetcolumns(w,columns)=
	w.columns:=columns
	w.itemcols:=w.cols%w.columns
	w.pagesize:=w.rows*w.columns
end

