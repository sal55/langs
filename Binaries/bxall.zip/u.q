MMODE

macro m(a,b) = a:=b+c*d
