!not opcodes, just used internally here for conditional jump logic
!const kjumpt = 1
!const kjumpf = 0

!loop stack data reused by GENMPL
const maxloopindex=20
[maxloopindex, 4]int loopstack
[maxloopindex]int trylevelstack
global int loopindex=0
int looptrylevel			!return by findlooplabel

const maxswitchrange=512
const maxlocals=300
const maxparams=100

const maxunits=400					!for constructors
int trylevel=0
!int currfunction=0				!0/1/2 = not a function/proc/function

!vars within curr procdef
int retindex						!common return point; label no
int retvaloffset					!offset of return value for procs (as stack slots)
int nprocparams						!no. of params
!global int nproclocals				!no. of locals
global pcl pprocentry				!pointer to PROCENT op; for updating locals due to AVs
const retaddrslots = 1				!+1 or +2, added to param indices (depends on return info size)
int procskiplabel

global proc gencodesp(isubprog sp)=
	for i in sp.firstmodule..sp.lastmodule do
		gencode(sp, modules[i], i=sp.firstmodule)
	end
end

global proc gencode(isubprog sp, imodule pm, int firstmodule=0)=
	const maxanonprocs=100
	[maxanonprocs]symbol anonprocs
	int nanonprocs:=0

	symbol d, e
	int lab
	int a:=sp.firstmodule
	int b:=sp.lastmodule
	pcl pc, pctarget
	ref[]byte labelmap

	stcurrproc:=stmodule:=pm.def

!CPL "GENCODE", SP.NAME, PM.NAME

	resetpcl(sources[pm.fileno].size)

!GOTO FINISH

	pcomment("Module data init code:")
!SKIP

	clear qpos
	qpos.fileno:=pm.fileno

!CPL "///////////////", QPOS

!jump around stop/raise block needed for reentry
	if firstmodule then
		lab:=createfwdlabel()
		pgen_lab(kjump, lab)
		pgen_n(kstop, 1)
		stopseq:=pccurr

		raiseseq:=pccurr+1
		pgen_int(kpushci, 0)
		pgen(kraise)
		definefwdlabel(lab)
	fi

!CPL $LINENO
	d:=stmodule.deflist
	while d do
		if d.nameid=staticid and d.code then
			evalunit(d.code)
!CPL =D.INITCODE, D.NAME
!*!			if d.initcode=3 then
!*!				pgen(kcopy)
!*!			fi
			pgen_name(kzpopm, d)
		elsif d.nameid=dprocid then
			e:=d.deflist
			while e do
				if e.nameid=staticid and e.code then
					evalunit(e.code)
					pgen_name(kzpopm, e)
				elsif e.nameid=anonprocid then
					if nanonprocs>=maxanonprocs then gerror("Too many anons") fi
					anonprocs[++nanonprocs]:=e
				fi
				e:=e.nextdef
			od
		fi
		d:=d.nextdef
	od	
!CPL $LINENO

	if firstmodule then
		for i:=b downto a+1 do
			pgen_name(kmodcall, modules[i].def)
		od
		for i:=b downto a+1 do
			if modules[i].ststart then
				pgen_name(kcallproc, modules[i].ststart)
!				genopnd_int(0)
			fi
		od

		if pm.ststart then
			pgen_name(kcallproc, pm.ststart)
!			genopnd_int(0)
		fi

		if pm.stmain then
			pgen_name(kcallproc, pm.stmain)
!!			genopnd_int(0)
		fi

		evalunit(stmodule.code, 0)
		pgen_int(kpushci, 0)
		pgen(kstop)
	else
		evalunit(stmodule.code, 0)
		pgen(kmodret)
	fi
!CPL $LINENO

	pcomment("Procs:")
	d:=stmodule.deflist
	while d do
		switch d.nameid
		when dprocid, anonprocid then
PCOMMENT(D.NAME)
PCOMMENT("PROC/ID")
!*!			do_procdef(d)
		when staticid then
!		when typeid then
		when typeid then
			e:=d.deflist
			while e, e:=e.nextdef do
				if e.nameid=dprocid then
PCOMMENT("RECORD/PROC")
!*!					do_procdef(e)
				fi
			od

		when constid then
		when labelid then
!		when typeid then
		when dllprocid then
!		when aliasid then
		when macroid then
		when dllvarid then
		else
			gerror_s("?Module def:", namenames[d.nameid])
		end switch

		d:=d.nextdef
	od	
!CPL $LINENO

	for i to nanonprocs do
PCOMMENT("ANON PROC")
!*!		do_procdef(anonprocs[i])
	od

	pgen(kendmod)

!scan pcl operands and convert label operands to pcl ref
	labelmap:=pcm_allocz(nextlabelno)

	pc:=pcstart
	while pc<=pccurr, ++pc do
		if pclopnd[pc.opcode]=clabel then
			lab:=pc.labelno
			pctarget:=labelpctable[lab]
!CPL "LABEL FIXUP:", LAB,"=>", PCTARGET
			if pctarget=nil then
				gerror_s("Lab undef:",strint(lab))
			fi
			labelmap[lab]:=1				!indicate has been referenced
			pc.labelref:=pctarget			!update from 1-NLABEL to 1-NPCL
		fi
	od

!use labelmap to unset those labeled pcl ops that have not been used
	for i to nextlabelno do
		if labelmap[i] then
			labelpctable[i].haslabel:=1
		fi
	od

	pcm_free(labelmap, nextlabelno)

	pm.pcstart:=pcstart
!	pm.pcend:=pcend
	pm.pcend:=pccurr
!	pm.pcsize:=pccurr-pcstart+1
!	pm.pcsize:=getpcloffset(pccurr,pcstart)+1

!CPL "------DONE GENPCL", PCLSTART, PCLNEXT-PCLSTART, PCLNAMES[PCLSTART^]

end

PROC EVALUNIT(UNIT P, INT X=0)=
	PCOMMENT("EVALUNIT")
END
