copy \qx\%1.q %1.b
