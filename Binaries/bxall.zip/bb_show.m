strbuffer v
^strbuffer ds=&v

int currlineno
int currfileno

const tab1="\t"
const tab2="\t\t"

const tabstr="|--"


global proc printtoken(^tokenrec lp)=
	tokenrec l
	l:=lp^

	fprint "#:# ", l.lineno:"5", l.column:"z3",$

	print tokennames[l.token]:"18jl"
!	printf("%-18s", tokennames[l.token])

	switch l.token
	when tk_name then
		print l.symptr.name

		if l.subcode then
			fprint " [#]", l.subcode
		end

	when tk_intconst then
		case l.subcode
		when tint then print l.value, "int"
		when tword then print l.uvalue, "word"
		else print l.value
		end case

	when tk_realconst then
		print l.xvalue

	when tk_stringconst then
		print "<"
		printstr(l.svalue)
		print ">*",, l.slength

	when tk_charconst then
		print "'"
		printstr(l.svalue)
		print "'"

	when tk_binop then
		print binnames[l.subcode], binstr[l.subcode]
	when tk_unary then
		print unarynames[l.subcode], unarystr[l.subcode]
!	elsif l.subcode then
!	ELSE
!	elsif l.token then
!		print "Reserved word"

	elsif l.subcode then
		fprint "SUBCODE:", l.subcode
!	fprint "#", symbolnames[l.subcode]
	end

	println

end

global proc printhashtable=
!global [0:hstsize]symbol hashtable
	symbol d
	int n:=0

	println "Hash table:"

	for i in hashtable.bounds when hashtable[i] do
		d:=hashtable[i]
!		println i,,":", d.name
		println d.name
		++n
	end
	cpl
	cpl =n
	cpl


end

global proc showprojectinfo(filehandle dev)=
	imodule pm
	isubprog ps
	static ichar tab="    "
	ichar s
	byte isfirst, ismain

	println @dev, "Project Structure:", "Ext=",sourceext, "Syslib",syslevel
	println @dev, "---------------------------------------"
	println @dev, "Modules", nmodules
	for i to nmodules do
		pm:=modules[i]

		if i>1 and pm.subprogno<>modules[i-1].subprogno then
			println @dev
		end
		ps:=subprogs[moduletosub[i]]

			isfirst:=ps.firstmodule=i
			ismain:=ps.mainmodule=i

			if isfirst and ismain then s:="hm"
			elsif isfirst then s:="h "
			elsif ismain then s:="m "
			else s:="  " 
			end

			print @dev, tab, i:"2", s, 
			pm.name:"16jl", "Sys:",, pm.issyslib, 
			"Sub:",, subprogs[pm.subprogno].name, "Fileno:",, pm.fileno

		if pm.stmacro then
			print @dev, " Alias:", pm.stmacro.name
		end
		if pm.stmain then
			print @dev, $, pm.stmain.name, ":", scopenames[pm.stmain.scope], pm.stmain
		end
		if pm.ststart then
			print @dev, $, pm.ststart.name, ":", scopenames[pm.ststart.scope], pm.ststart
		end

		println @dev
	end
	println @dev

	println @dev, "Subprograms", nsubprogs, =mainsubprogno
	for i to nsubprogs do
		ps:=subprogs[i]
		println @dev, tab, i, ps.name, "Sys:", ps.issyslib!, =PS.STSUBPROG

		if ps.firstmodule then
			print @dev, tab, tab
			for j:=ps.firstmodule to ps.lastmodule do
!				print @dev, $, modules[j].name, "(", MODULES[J].STSUBPROG, ")"
				print @dev, $, modules[j].name
			end
			println @dev
		end
	end
	println @dev

	println @dev, "Sourcefiles", nsourcefiles
	ifile pf
	for i to nsourcefiles do
		pf:=sources[i]
		fprintln @dev, "  #:  Name=# File=# Path=# Spec=# Size=#", 
			i:"2", pf.name:"jl12", pf.filename:"jl14", pf.path:"16jl", pf.filespec:"26jl", pf.size:"7"
	end
	println @dev

	println @dev, "Link files", nlibfiles
	for i to nlibfiles do
		println @dev, tab, libfiles[i]:"16jl"
	end
	println @dev
end

global proc printst(filehandle f, symbol p, int level=0)=
	symbol q

	return when p=nil

	printstrec(f, p, level)

	q:=p.deflist

	while q<>nil do
		printst(f, q, level+1)
		q:=q.nextdef
	end
end

proc printstrec(filehandle f, symbol p, int level)=
	strec dd
	^byte q
	int col, offset, n
	const tabstr="    "
	[256]char str

!CPL "PST",P.NAME, NAMENAMES[P.NAMEID]

	gs_init(ds)

!	print @str, p
!	dsstr(str)
!	dsstr(" ")

	offset:=0
	to level do
		dsstr(tabstr)
		offset+:=4
	end
	dsstr(":")

	gs_leftstr(ds, p.name, 28-offset, '-')
	gs_leftstr(ds, namenames[p.nameid], 12, '.')

	col:=gs_getcol(ds)
	dd:=p^

	dsstr("[")
	dsstr(scopenames[p.scope])
	dsstr(" ")
	if p.isimport then
		dsstr("Imp ")
	end

	if dd.isstatic then
		dsstr("Stat")
	end

	if dd.nameid=paramid and dd.byref then
		dsstr("byref")
	end

	if dd.caligned then
		dsstr(" $caligned")
	end
	if dd.maxalign then
		dsstr(" maxalign:")
		dsint(dd.maxalign)
		dsstr(" ")
	end
	if dd.optional then
		dsstr("Opt ")
	end
	if dd.varparams then
		dsstr("Var:")
		dsint(dd.varparams)
		dsstr(" ")
	end

	if dd.moduleno then
		if dd.nameid<>subprogid then
			print @str, "Modno#",,dd.moduleno
		else
			print @str, "Subno#",,dd.subprogno
		end
		dsstr(str)
	end

	if dd.used then
		dsstr("U ")
	end

	dsstr("]")
	gs_padto(ds, col+10, '=')

	if p.owner then
		fprint @str, "(#)", p.owner.name
		gs_leftstr(ds, str, 18, '-')
	else
		gs_leftstr(ds, "()", 18, '-')
	end

	case p.mode
	when tvoid then
		dsstr("Void ")
	else
		GS_STRINT(DS, P.MODE)
		GS_STR(DS, ":")

		dsstr(strmode(p.mode))
		dsstr(" ")
	end case

	case p.nameid
	when fieldid, structfieldid, paramid then
		dsstr(" Offset:")
		dsint(p.offset)
		if p.mode=tbitfield then
			dsstr(" Bitoffset:")
			dsint(p.bitoffset)
			dsstr(":")
			dsint(p.bitfieldwidth)
		end

		sprintf(str, "%.*s", int(p.uflags.ulength), &p.uflags.codes)
		print @str, p.uflags.ulength:"v", ichar(&p.uflags.codes):".*"
		dsstr(" UFLAGS:")
		dsstr(str)
		dsstr("-")
		dsint(p.uflags.ulength)

		if p.code then
			dsstr("/:=")
!*!			gs_strvar(ds, strexpr(p.code))
		end

	when dprocid, dprocid then

		dsstr("Index:")
		dsint(p.fnindex)

		dsstr(" Nret:")
		dsint(p.nretvalues)

	when dllprocid then
		dsstr("Index/PCaddr:")
		dsint(p.fnindex)
		if p.truename then
			dsstr(" Truename:")
			dsstr(p.truename)
		end

	when staticid then
		if p.code then
			dsstr("=")
!*!			gs_strvar(ds, strexpr(p.code))
		end

	when frameid then
		if p.code then
			dsstr(":=")
!*!			gs_strvar(ds, strexpr(p.code))
		end

	when constid then
		dsstr("Const:")
!*!		gs_strvar(ds, strexpr(p.code))

!	when enumid then
!		dsstr("Enum:")
!		dsint(p.index)
!	when dllmoduleid then
!		dsstr("DLL#:")
!		dsint(p.dllindex)
	end case

	if p.atfield then
		dsstr(" @")
		dsstr(p.equivfield.name)
		dsstr(" +")
		dsint(p.equivoffset)
	end
	if p.equivvar then
!*!		gs_strvar(ds, strexpr(p.equivvar))
	end

!dsstr(" Module# ")
!dsint(p.moduleno)

!	dsstr(" Lineno: ???")
!dsint(p.lineno iand 16777215)

	gs_println(ds, f)
SKIP:

!CPL $LINENO
	case p.nameid
	when constid, frameid, staticid, macroid, paramid then
!CPL $LINENO
		if p.code then
!CPL $LINENO, UTAGNAMES[P.CODE.TAG]
!DSSTR("<CODE>")
			printunit(p.code, dev:f)
!CPL $LINENO
		end
	end case
!CPL "SHOW",$LINENO
end

proc dsstr(ichar s)=
	gs_str(ds, s)
end

proc dsint(int a)=
	gs_strint(ds, a)
end

global func strmode(int m,expand=1)ichar=
	static [2048]char str
	istrmode(m,expand,str)
	return str
end

global proc istrmode(int m,expand=1,ichar dest)=
	symbol d,q
	int needcomma,i,target,mbase,n
	strbuffer sxx
	^strbuffer xx:=&sxx
	^strbuffer sdim
	[100]char strdim
	ichar prefix
	typenamerec tn

!CPL "STRMODE", M


	if m<0 then
		strcpy(dest,"*")
		tn:=typenames[-m]
		strcat(dest,tn.def.name)
		return
	end
!CPL "---STRMODE", M, =TLAST, =STDNAMES[TTBASETYPE[M]], =STDNAMES[TTTARGET[M]]

	if m<tlast and m<>tref then
		strcpy(dest,typename(m))
		return
	end

	case mbase:=ttbasetype[m]
	when tref then
		strcpy(dest,"ref ")
		target:=tttarget[m]
		if target>=0 and ttbasetype[target]=trecord then
			strcat(dest,typename(target))
		else
			istrmode(tttarget[m],0,dest+strlen(dest))
		end

	when tarray then
		if ttdimexpr[m] then
			gs_copytostr(strexpr(ttdimexpr[m]),strdim)
			fprint @dest,"@[#<#>]",&strdim[1],m
		else
			if ttlength[m] then
				if ttlower[m]=1 then
					fprint @dest,"[#]",ttlength[m]+ttlower[m]-1
				else
					fprint @dest,"[#..#]",ttlower[m],ttlength[m]+ttlower[m]-1
				end
			else
				if ttlower[m]=1 then
					fprint @dest,"[]"
				else
					fprint @dest,"[#:]",ttlower[m]
				end
			end
		end
		istrmode(tttarget[m],0,dest+strlen(dest))

!	when tslice then
!		prefix:=stdnames[mbase]
!
!		if ttdimexpr[m] then
!!*!			gs_copytostr(strexpr(ttdimexpr[m]),strdim)
!			fprint @dest,"@#[#:]",prefix,&strdim[1]
!		else
!			if ttlower[m]=1 then
!				strcpy(dest,prefix)
!				strcat(dest,"[]")
!			else
!				fprint @dest,"#[#:]",prefix,ttlower[m]
!			end
!		end
!		istrmode(tttarget[m],0,dest+strlen(dest))

	when trecord, tstruct then
		if not expand then
			strcpy(dest,typename(m))
			return
		end
		strcpy(dest,"")
		if expand<>2 then
			strcat(dest,typename(ttbasetype[m]))
		end
		strcat(dest,"(")
		d:=ttnamedef[m]
		needcomma:=0

		q:=d.deflist

		while q, q:=q.nextdef do
			if needcomma then strcat(dest,",") end
			needcomma:=1
			istrmode(q.mode,0,dest+strlen(dest))
			strcat(dest," ")
			strcat(dest,q.name)
		end
		strcat(dest,")")

	when tvoid then			!must be a usertype that is not defined (as normal voids checked above)
		strcpy(dest,"void")

!	when tuser then
!		strcpy(dest,typename(m))

	when tproc then

		d:=ttnamedef[m]

		strcpy(dest,"proc(")
!		q:=d.paramlist
!		needcomma:=0
!		while q<>nil do
!			if needcomma then strcat(dest,",") end
!			needcomma:=1
!			istrmode(q.mode,0,dest+strlen(dest))
!			strcat(dest," ")
!			strcat(dest,q.name)
!			q:=q.nextdef
!		end
		strcat(dest,")")
		if d.mode<>tvoid then
			istrmode(d.mode,0,dest+strlen(dest))
		end

	when tbitfield then
		strcpy(dest,"bitfield")

	elsif ttbasetype[m]<tlast then
		strcpy(dest,"Alias for:")
		istrmode(tttarget[m],0,dest+strlen(dest))

!		strcat(dest, " "); strcat(dest, strint(m))
!		strcat(dest, " "); strcat(dest, strint(tttarget[m]))

	else
		println typename(m),STRMODE(TTBASETYPE[M])
		mcerror("NEWSTRMODE")
	end case
end

global proc printunit(^unitrec p, int level=0, number=0, filehandle dev=nil)=
!p is a tagrec
	[1024]char str
	^unitrec q
	^strec d
	int t
	ichar idname
	i64 a
	r32 x32
	static int cmpchain=0
	if p=nil then
		return
	end

	if p.pos then
		currlineno:=p.lineno
		currfileno:=p.fileno
	end

!	print @dev, p, ":"
	print @dev, getprefix(level, number, p)

	idname:=utagnames[p.tag]
	print @dev, idname,,": "

!SKIP

	case p.tag
	when u_name then
		d:=p.def

!		print @dev, d.name
		print @dev, d.name, namenames[d.nameid]

!		if p.avcode then
!			print @dev, " AV:", p.c:"c"
!		end

	when u_labeldef then
		println @dev, p.def.name, p.def.labelno

	when u_intconst then
		a:=p.value

		case ttbasetype[p.mode]
		when ti64 then print @dev, i64(a)
		when tu64 then print @dev, u64(a)
		else
consterr:
			print dev, "show/const?"
		end

	when u_realconst then
		if ttbasetype[p.mode] in [tr32, tr64] then
			print @dev, p.xvalue
		else
			consterr
		end

	when u_stringconst then
		if p.mode=trefchar then
!			if p.slength>str.len/4 then
			if p.slength>1 then
				strcpy(str, "(longstr)")
			elsif p.slength then
				convertstring(p.svalue, str, p.slength)
			else
				strcpy(str, "")
			end
			print @dev, """"
			print @dev, str
			print @dev, """ *",,p.slength

			if p.isastring then
				fprint @dev, " isstr:(#)", p.strtype
			end
		else
			consterr
		end

	when u_typeconst then
!		print @dev, typename(p.value)
		print @dev, strmode(p.mode)

	when u_bitfield then
		print @dev, bitfieldnames[p.bfcode]+3

	when u_convert, u_typepun, u_truncate, u_fix, u_float, u_fwiden, u_fwiden, u_fnarrow then
		print @dev, " Cast to:", strmode(p.mode2)

	when u_makelist then
		print @dev, "Len:", p.length

	when u_dot then
		print @dev, "Offset:", p.offset

	when u_index, u_ptr then

	when u_exit, u_redo, u_next then
		print @dev, "#",,p.loopindex

	when u_syscall then
		print @dev, sysfnnames[p.fnindex]+3

	when u_operator then
		case p.optoken
		when tk_binop then print @dev, binstr[p.binop]
		when tk_unary then print @dev, unarystr[p.unaryop]
		when tk_prop then print @dev, propnames[p.propop]
		else
			print @dev,"?"
		end

!		print @dev, pclnames[p.pclop]

!	when u_makeset then
	when u_cmpchain then
		for i to p.cmpgenop.len do
			if p.cmpgenop[i]=0 then exit end
			print @dev, binstr[p.cmpgenop[i]],," "
		end
	end case

!	if p.isconst then
!		print @dev, " Is const"
!	else
!		print @dev, " Not const"
!	end

	case p.tag
	when u_bin, u_binto then
		PRINT @DEV, (p.binop|binstr[p.binop]|"?")
!		PRINT @DEV, p.binop
!		if p.pclop then
!			fprint @dev, " <#>", pclnames[p.pclop]
!			if p.pclop in [kmaths, kmaths2] then
!				fprint @dev, " (#)", mathsnames[p.mathsop]
!			end
!		else
!			fprint @dev, " no-op"
!		end
	when u_unary, u_unaryto then
		PRINT @DEV, unarystr[p.unaryop]
!		if p.pclop then
!			fprint @dev, " <#>", pclnames[p.pclop]
!			if p.pclop in [kmaths, kmaths2] then
!				fprint @dev, " (#)", mathsnames[p.mathsop]
!			end
!		else
!			fprint @dev, " no-op"
!		end
	when u_prop then
		print @dev, $, propnames[p.propop]
	when u_cmp then
		print @dev, $, binstr[p.binop]
	when u_inrange then
		print @dev, $,binstr[p.binop]
	when u_incr then
		print @dev, $, p.isdecr
	when u_maths, u_maths2 then
		print @dev, $, mathsnames[p.mathsop]
	when u_makeset, u_makedict then
		print @dev, " *", p.length
	when u_addrof then
		print @dev, $, p.addrof
	when u_callhost then
		print @dev, $, hostfnnames[p.hostfn]
	end case

SKIP:
	println @dev

!CPL "PRINTUNIT/B", P,UTAGNAMES[P.TAG], P.A, P.B
	if usubs[p.tag] then
!CPL "//A", P.A
		printunitlist(dev, p.a, level+1, 1)
		if usubs[p.tag]=2 then
!CPL "//B", P.B
			printunitlist(dev, p.b, level+1, 2)
		end
	end
!CPL "PRINTUNIT/C", P,UTAGNAMES[P.TAG]
end

proc printunitlist(filehandle dev, ^unitrec p, int level=0, number=0)=
	if p=nil then return end

	while p do
		printunit(p, level, number, dev)
		p:=p.nextunit
	end
end

func getprefix(int level, number, ^unitrec p)ichar=
!combine any lineno info with indent string, return string to be output at start of a line
	static [1024]char str
	[1024]char indentstr
	[16384]char modestr
	ichar isexpr

	indentstr[1]:=0
	if level>10 then level:=10 end

	to level do
		strcat(indentstr, tabstr)
	end


	isexpr:="S"
	if uisexpr[p.tag] then isexpr:="E" end

	case p.tag
	when u_if, u_switch, u_case, u_select then
		if p.mode=tvoid then
			isexpr:="S"
		end
	end case

!	fprint @modestr, "# #:#", isexpr, (p.resultflag|"RES"|"---"), strmode(p.mode)
	fprint @modestr, "# #:#", isexpr, (p.resultflag|"RES"|"---"), strmode(p.mode)
	modestr[256]:=0

	strcat(modestr, "-----------------------------")
	modestr[17]:=' '
	modestr[18]:=0

	str[1]:=0
	strcpy(str, getlineinfok())
	strcat(str, modestr)
	strcat(str, indentstr)
	strcat(str, strint(number))
!	if prefix^ then
		strcat(str, " ")
!	end

	return str
end

func getlineinfok:ichar=			!GETLINEINFO
	static [40]char str

	fprint @str, "# # ", CURRFILENO:"Z2", currlineno:"z4"
	return str
end

global proc printmodelist(filehandle f, int from=tvoid)=
	int mbase
	symbol d, owner
	static ichar tab="\t"
	ref typenamerec p

!	PRINTLN @F, =NTYPENAMES
!	FOR I TO NTYPENAMES DO
!		PRINTLN @F, I, TYPENAMES[I].DEF.NAME
!	OD
!	PRINTLN @F
!
!SKIP

	println @f, "MODELIST", ntypes

	for m:=from to ntypes do
		println @f, m:"4", strmode(m)
		mbase:=ttbasetype[m]

		println @f, tab, "Basetype:", mbase, strmode(mbase)
		println @f, tab, "ttname:", ttname[m]
		println @f, tab, "ttnamedef:", ttnamedef[m], (ttnamedef[m]|ttnamedef[m].name|"-")
		println @f, tab, "Target:", strmode(tttarget[m])
		println @f, tab, "Size:", ttsize[m]
		fprintln @f, "# Bounds: #..#  Length:#", tab, ttlower[m], ttlower[m]+ttlength[m]-1, ttlength[m]
!		println @f, tab, "Signed:", ttsigned[m]
!		println @f, tab, "Isreal:", ttisreal[m]
!		println @f, tab, "Isinteger:", ttisinteger[m]
!		println @f, tab, "Isshort:", ttisshort[m]
!		println @f, tab, "Isref:", ttisref[m]
		println @f
	end

	println @f
SKIP:
	println @f, "USERTYPES", ntypenames

	for m to ntypenames do
		p:=&typenames[m]
		d:=p.def
		owner:=p.owner
!		cpl @f, m:"3", p, p.pmode^:"4", d, d.name:"16", owner!, owner.name!, =owner.nameid
		cpl @f, m:"3", p, p.pmode^:"4", d, d.name:"16", owner, p.lineno!, owner.name!, =owner.nameid
	end

!
!global record typenamerec=
!	symbol owner			!owner of scope where typename was encountered
!							!moduleno required by resolvetypename can be derived from owner
!	symbol def
!	union
!		u64 pos: (lineno:32, column:20, fileno:12)
!		posrec posx
!	end
!	^i32 pmode
!end




end

global proc showlogfile=
	[256]char str
	filehandle logdev
	int size
	^strbuffer ss

!CPL "SHOWLOG1"
	return unless fshowdiags

!CPL "SHOWLOG2"
	logdev:=fopen(logfile, "w")
!CPL "SHOW",$LINENO
	if fshowmodules then showprojectinfo(logdev) end

!CPL "SHOW",$LINENO
!	if fshowasm and passlevel>=mcl_pass then
!		println @logdev, "PROC ASSEMBLY"
!		addtolog(changeext(outfile, "asm"), logdev)
!	end
!
	if fshowpcl1 and passlevel>=pcl_pass then
		println @logdev, "PROC PCL"
		addtolog("PCL1", logdev)
	end

!	if fshowc and passlevel=clang_pass then
!		println "PROC CLANG"
!		addtolog(changeext(outfile, "c"), logdev)
!	fi
!

	if fshowast2 and passlevel>=name_pass then addtolog("AST2", logdev) end
	if fshowast1 and passlevel>=parse_pass then addtolog("AST1", logdev) end
!CPL "SHOW",$LINENO

!	if fshowpst and passlevel>=pcl_pass then
!		println @logdev, "PROC PST"
!		addtolog("PST", logdev)
!	end

	if fshowst then
!CPL "SHOW",$LINENO
		showst("SYMBOL TABLE", logdev)
!CPL "SHOW",$LINENO
	end
!	if fshowstflat then
!		showstflat("FLAT SYMBOL TABLE", logdev)
!	end
!
	if fshowtypes then
!		printmodelist(logdev)
		printmodelist(logdev, tlast)
	end
!CPL "SHOW",$LINENO

	size:=getfilesize(logdev)
	fclose(logdev)
!CPL "SHOW",$LINENO

	if size then
CPL "PRESS KEY..."; if OS_GETCH()=27 then stop end
!		print @str, "\\m\\ed.bat ", logfile
		print @str, "\\m\\ed.bat -w ", logfile

		if checkfile("bb.m") then
			os_execwait(str, 0, nil)
		else
			println "Diagnostic outputs written to", logfile
		end
	end
end

proc showst(ichar caption, filehandle f)=
	println @f, "PROC", caption
!CPL "SHOW",$LINENO

	printst(f, stprogram)
!CPL "SHOW",$LINENO
	println @f

	println @f, "Proc List:"

	symbol d:=stlinear

	while d, d:=d.nextlinear do
		if d.nameid in [dprocid, sprocid] then
			fprintln @f, "#	#.# (#) Mod:", d, d.owner.name, d.name:"20jl", namenames[d.nameid], 
				d.moduleno
		end
	end
	println @f, "End\n"

!	println @f, "DLL Proc List:"
!	for i to ndllproctable do
!		d:=dllproctable[i]
!		fprintln @f, "#	#.# (#) Mod:", d, d.owner.name, d.name:"20jl", namenames[d.nameid], 
!			d.moduleno
!	end
!	println @f, "End\n"
end

global proc addtolog(ichar filename, filehandle logdest)=
	filehandle f
	int c

	f:=fopen(filename,"rb")

	if f=nil then
		CPL "ATL ERROR",FILENAME; return end

	do
		c:=fgetc(f)
		exit when c=c_eof
		fputc(c,logdest)
	end
	fclose(f)
end

global proc showast(ichar filename)=
	filehandle f

	f:=fopen(filename, "w")
	return unless f

	println @f, "PROC", filename
	printcode(f, "")
	println @f
	fclose(f)
end

global proc printcode(filehandle f, ichar caption)=
	symbol p

	p:=stlinear
	while p, p:=p.nextlinear do
		if p.nameid in [dprocid, anonprocid] then
!			print @f, p.name,,"=", (p.scope|"Sub", "Prog", "Exp"|"Mod")
			fprint @f, "#.# = #", p.owner.name, p.name, (p.scope|"Sub", "Prog", "Exp"|"Mod")
!			if p.owner.nameid=typeid then
!				print @f, " in record", p.owner.name
!			end
			println @f
			printunit(p.code, 0, 1, dev:f)
			println @f
		end
	end
end

global proc printstrn(ichar s, int length)=
	if length then
		print length:"v",,s:".*"
	end
end

