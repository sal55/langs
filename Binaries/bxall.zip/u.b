enumdata =
	a,b,c,d
end
