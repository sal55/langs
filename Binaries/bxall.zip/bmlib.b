VAR DEBUG=0

importdll imglib =
    func imgload_rgb		(stringz, ref byte, ref byte, ref byte, i32)ref byte

    func imgload_bgr		(stringz, ref i32, ref i32, ref i32, i32)ref byte

!    func nanoloadjpeg		(stringz, ref i32, ref i32, ref i32)ref byte
!    func loadjpegm			(stringz, ref i64, ref i64, ref i64)ref byte

    proc          imgload_free		(ref byte)
    func imgsave_jpeg_rgb	(stringz, ref byte, i32, i32, i32)i32
    func imgsave_jpeg_bgr	(stringz, ref byte, i32, i32, i32)i32
end

importdll jpeg =
    func loadjpegm			(stringz, ref i64, ref i64, ref i64)ref byte
end

type bmpheader = struct
	ws_bitmapfileheader fh
	ws_bitmapinfoheader bh
end

var	shifts=[2:1, 4:2, 8:3, 16:4, 32:5, 64:6]

proc main=

!	CPL "TESTING BMMAIN NEW"
!	FILE:="C:/JPEG/girl.jpg"
!	FILE:="C:/JPEG/girl.png"
!	FILE:="C:/JPEG/fifteen.png"
	FILE:="C:/JPEG/CARD2.jpg"
!	FILE:="C:/JPEG/MONA.jpg"
!
	BM:=BMLOAD(FILE)
!	CPL =BM.TYPE
!	CPL =BM
!	IF NOT BM THEN STOP FI
!
!	BMSAVE("freddy.jpg", BM)
!

!	w:=640
!	h:=480
!	w:=640
!	h:=48
!
!	bm:=bmcreate(8,w,h)
!!	gxclear(bm, 0xFF7FFF)
!
!	gxtext(bm,"Hello, World")
!	for y:=0 to h-1 do
!		for x:=0 to w-1 do
!			c:=0x00'FF'00
!!			gxpixel(bm,x,y,c<<16+c<<8+c)
!			gxpixel(bm,x,y,c)
!		od
!	od
!	

!	bm2:=bmtopal(bm)
!	bm2:=bmrgb24torgb32(bm)
!	bm2:=bmtogrey(bm,8)
!	bm2:=bmtogrey(bm,24)
!	bm2:=bmdupl(bm)

!BM2.PALTYPE:=COLOUR_PAL
!BMRESETPALETTE(BM2)
!CPL =BM2.PIXELBITS
!	BMSAVE("PALA.PPM",BM2)
!	BMSAVE("FRED.bmp",BM2)
!	BMSAVE("PALB.PPM",BM2,1)


!	CPL "LOADED"
!	STOP

	w:=GXCREATEWINDOW(DIM:(1800,700),caption:"Hi There")
	gxcopy(w,bm)
!	gxcopy(w,bm,scalex:0.5)
!	gxcopy(w,bm,scalex:5.0, x:100)
!	gxcopy(w,bm,scalex:2.0, x:100)
!	gxcopy(w,bm)
!T:=clock()
!to 100 do
!	gxcopy(w,bm)
!od
const srccopy =  13369376

!CPL =SRCCOPY
	bitblt(w.gdi.hdc, 0, 0, 500,300,
				w.gdi.hdc,0,0,srccopy)


!	gxcopy(w,bm)
!	gxcopy(w,bm)
!	gxcopy(w,bm)
!	gxcopy(w,bm)
!cpl =clock()-t
!WAITKEY()
	eventloop()

end

export func bmcreate(pixelbits,width,height)=
!create new bitmap with given specs, return handle to bitmap (=rwindow ref)
!when maskptr<>nil, set up mask values

	bminfo:=new(ws_bitmapv5header)
	bminfo.size:=ws_bitmapv5header.bytes
	bminfo.width:=width
	bminfo.height:=-height
	bminfo.planes:=1
	bminfo.bitcount:=pixelbits

	pixelptr:=nil

	if pixelbits not in [8,24,32] then
		abort("bmcreate pixel size not supported:"+tostr(pixelbits))
	fi

!	hwnd:=createdibsection(screendc,&bminfo,0,&pixelptr,0,0)

!CPL =BMINFO.BYTES
!CPL =WS_BITMAPV5HEADER.BYTES
!CPL =BMINFO.SIZE
!CPL =BMINFO.WIDTH
!CPL =BMINFO.HEIGHT
!CPL =BMINFO.PLANES
!CPL =BMINFO.BITCOUNT

	hwnd:=createdibsection(nil,&bminfo,0,&pixelptr,nil,0)

	pixelptr:=makeref(pixelptr,byte)

	if hwnd=0 then
		error:=getlasterror()
		abort("bmcreate:CreateDIB failed:"+tostr(error))
	fi

!now create a bm record based around this handle

	bm:=new(rwindow,0)
	bm.windclass:=bitmap_class

	bm.dimx:=width
	bm.dimy:=abs(height)		!neg height used for top-down bitmaps

	bm.style:=defstyle

	bm.pixelbits:=pixelbits
	bm.pixelptr:=pixelptr

!set bytes per pixel
	bm.pixelbytes:=pixelbits%8

!set bytes per scanline
	n:=bm.pixelbytes*width

!n must be a multiple of 4 bytes
	if (n iand 3)<>0 then	!make bytes a multiple of 4
		n:=(n+4) iand 0xfffc
	fi
	bm.linebytes:=n
!CPL "XXX",=BM.TYPE
!CPL =BM.BASETYPE

	bm.framebytes:=bm.linebytes*bm.dimy

!set palette colours, using winrgb order
	if pixelbits=8 then
		palette:=new(array,i32,0..255)
		bm.paltype:=greyscale_pal
		colour:=0
		for i:=0 to 255 do
			palette[i]:=colour
			colour+:=0x10101
		od
	fi

	setupgdi(bm,hwnd)

	bm.gdi.hdc:=createcompatibledc(nil)
	bm.gdi.drawmode:=dm_memory
	bm.gdi.oldbmobj:=selectobject(bm.gdi.hdc,hwnd)	!should store original bitmap
	setstretchbltmode(bm.gdi.hdc,4)			!average pixels for best result

	bmputpalette(bm,palette)

	return bm
end

export func bmgetpalette(bm)=
!extract entire palette to p, in bmrgb order
	if bm.paltype then
		palette:=new(array,i32,0..256)
		getdibcolortable(bm.gdi.hdc,0,256,&palette)
		palette[256]:=bm.paltype
		reversepalette(palette)
	else
		palette:=()
	fi
	return palette
end

export proc bmputpalette(bm,p,reverse=1)=
!update entire palette from p, in bmrgb order
	if bm.paltype then
		if reverse then reversepalette(p) fi		!fix colours
		setdibcolortable(bm.gdi.hdc,0,256,&p)	!store
		if reverse then reversepalette(p) fi			!restore orignal palette
		if p.upb=256 then
			bm.paltype:=p[256]
		fi
	fi
end

export func bmcolour(bm,n,?colour)=
!get/set palette info:
!n=given:
! colour given: update colour entry
! colour omitted(-1): return colour value

	if colour.isdef then		!set colour
		colour:=revpixel(colour)
		setdibcolortable(bm.gdi.hdc,n,1,&colour)
		return colour
	else				!get colour
		colour:=0
		getdibcolortable(bm.gdi.hdc,n,1,&colour)
		return revpixel(colour)
	fi
end

export proc reversepalette(&p)=
!reverse values of 32-bit colour data at p
	for i:=0 to 255 do
		p[i]:=revpixel(p[i])
	od
end

export func revpixel(a)=
!change rgb to bgr
!windows colours use red in lsb, bitmaps use blue in lsb, in 24-bit pixels and palette colours
return (a iand 0x00ff00) ior (a>>16 iand 255) ior ((a iand 255)<<16)
end

export proc bmshow(bm)=
	gxcopy(bm)
end

export proc bmfree(bm)=
	return when bm=nil
	if not deletedc(bm.gdi.hdc) then
		pcerror("ERROR DELETING BM/HDC")
	fi

	if not deleteobject(bm.gdi.hwnd) then
		pcerror("ERROR DELETING DIB")
	fi
end

export func bmdupl(bm)=
	newbm:=bmcreate(bm.pixelbits, bm.dimx, bm.dimy)
	memcpy(newbm.pixelptr, bm.pixelptr, bm.linebytes*bm.dimy)

	bmduplpalette(newbm,bm)

	return newbm
end

export proc bmduplpalette(newbm,bm)=
	if bm.paltype then
		pal:=bmgetpalette(bm)
		bmputpalette(newbm,pal)
		newbm.paltype:=bm.paltype
	fi
end

export func bmduplz(bm)=
	newbm:=bmcreate(bm.pixelbits, bm.dimx, bm.dimy)
	return newbm
end

export func bmgetptr(bm,x,y)=
!return byte pointer to given pixel
	return bm.pixelptr+(bm.linebytes*y+x*bm.pixelbytes)
end

export func bmgetrowptr(bm,y)=
	return bm.pixelptr+y*bm.linebytes
end

!export func bmgetpixel(bm,y)=
!	return bm.pixelptr+y*bm.linebytes
!end

func getcbbitmap(hwnd)=

	p:=globallock(hwnd)
	hsize:=ws_bitmapinfoheader.bytes
	bm:=nil

	if p then
		p:=makeref(p,ws_bitmapinfoheader)
		pb:=makeref(p,byte)

		bm:=bmcreate(p^.bitcount,p^.width,p^.height)
		offset:=(bm.paltype|1024|0)		!offset due to palette table

		if offset then
			setdibcolortable(bm.gdi.hdc,0,256,pb+hsize)
		fi

		pb:=pb+hsize+offset
		for y:=0 to bm.dimy-1 do
			q:=bmgetrowptr(bm,bm.dimy-y-1)
			memcpy(q,pb,bm.linebytes)
			pb:=pb+bm.linebytes
		od

	fi

	globalunlock(hwnd)

	return bm
end

export func bmgetclipboard=
!get image from clipboard if one is there, otherwise return nil
	if openclipboard(nil)=0 then
		return nil
	fi

	hwnd:=getclipboarddata(cf_dib)

	bm:=nil
	if hwnd then
		bm:=getcbbitmap(hwnd)
	fi

	closeclipboard()

	return bm
end

export func bmputclipboard(bm)=
	if openclipboard(0)=0 then
		return nil
	fi

	emptyclipboard()

	hwnd:=putcbbitmap(bm)
	if hwnd then
		setclipboarddata(cf_dib,hwnd)
	fi

	closeclipboard()
	return 1
end

func putcbbitmap(bm)=
	var mem

	hsize:=ws_bitmapinfoheader.bytes
	psize:=(bm.paltype|1024|0)
	fsize:=bm.linebytes*bm.dimy

	hmem:=globalalloc(0,hsize+psize+fsize)
	mem:=makeref(globallock(hmem),byte)
	mem:=0!makeref(globallock(hmem),byte)

	hdr:=new(ws_bitmapinfoheader)
	hdr.size:=hsize
	hdr.width:=bm.dimx
	hdr.height:=bm.dimy
	hdr.bitcount:=bm.pixelbits
	hdr.planes:=1
	hdr.xpelspermetre:=11811
	hdr.ypelspermetre:=11811
	hdr.clrused:=0

	memcpy(mem,&hdr,hsize)

	if psize then
		pal:=bmgetpalette(bm)
		memcpy(mem+hsize,&pal,psize)
	fi

	mem:=mem+hsize+psize
	for y:=0 to bm.dimy-1 do
		p:=bmgetrowptr(bm,bm.dimy-1-y)
		memcpy(mem, p, bm.linebytes)
		mem:=mem+bm.linebytes
	od
	globalunlock(hmem)

	return hmem
end

proc copy24to8(newbm,oldbm)=
!both images are same size. Copy 1st plane of 24-bit oldbm to 8-bit newbm
	for y:=0 to oldbm.dimy-1 do
		p:=bmgetrowptr(newbm,y)
		q:=bmgetrowptr(oldbm,y)
		to oldbm.dimx do
			p++^:=q^
			q:=q+3
		od
	od
end

!proc copy8to24(newbm,oldbm)=
!!both images are same size. Copy only plane of 8-bit oldbm to all planes of 24-bit newbm
!	for y:=0 to oldbm.dimy-1 do
!		p:=bmgetrowptr(newbm,y)
!		q:=bmgetrowptr(oldbm,y)
!		to oldbm.dimx do
!			p++^:=q^
!			q:=q+3
!		od
!	od
!end

export proc bmresetpalette(bm)=
# set palette back to greyscale
	pal:=new(array,i32,0..256)
	colour:=0
	for i:=0 to 255 do
		pal[i]:=colour
		colour+:=0x010101
	od
	bmputpalette(bm,pal)
	bm.paltype:=greyscale_pal
end

func makescalemap(x)=
!x=0..1; create 256-element lookup table to multiply 0..255 by x
	map:=new(list,0..255)
	for i:=0 to 255 do
		map[i]:=clamp(int(round(i*x)),0,255)
	od
	return map
end

func bmunimpl(mess)=
!ABORT("UNIMPLEMENTED: "+MESS)
PRINTLN "UNIMPLEMENTED:",MESS
PRINTLN "ABORTING"
STOP
return 0
end

!===========================================================================
!========= HANDLERS
!===========================================================================

export func bmload(filename)=
!CPL "BMLOAD:",FILENAME
	case e:=convlc(extractext(filename))
	when "jpg","jpeg" then
		return bmloadjpg(filename)
	when "bmp" then
		return bmloadbmp(filename)
!	when "pgm" then
!		return bmloadpgm_p2p5(filename)
	when "ppm","pgm" then
		return bmloadppm_p3p6(filename)
	when "png" then
		return bmloadpng(filename)
	when "" then				!try all
		exts:=("jpg","bmp","pgm","ppm","png")
		for ext in exts do
			bm:=bmload(addext(filename,ext))
			if bm then
				return bm
			fi
		od
		return nil
	else
		println "CAN'T LOAD",E,"IMAGE"
		return nil
	esac
	return nil
end

func bmloadbmp(filename)=
	f:=openfile(filename)
	if not f then return nil fi

	fileheader:=new(bmpheader)

	readrandom(f,&fileheader,0,bmpheader.bytes)
	filedimx:=fileheader.bh.width
	filedimy:=fileheader.bh.height
	invert:=1
	if filedimy<0 then
		filedimy:=abs(filedimy)
		invert:=0
	fi

	if fileheader.fh.typex<>'BM' then
		closefile(f)
		return nil
	fi

	if fileheader.bh.compression<>0 then
		closefile(f)
		return nil
	fi

	bm:=bmcreate(fileheader.bh.bitcount,filedimx,filedimy)
	framebytes:=bm.linebytes*filedimy

	if bm.paltype then
		palette:=new(array,i32,0..255)
		readrandom(f,&palette,bmpheader.bytes,1024)
		bmputpalette(bm,palette,0)
		colour:=0
		for i:=0 to 255 do
			if palette[i]<>colour then
				bm.paltype:=colour_pal
				exit
			fi
			colour+:=0x010101
		od

	fi

	readrandom(f,bm.pixelptr,fileheader.fh.offbits,framebytes)
	closefile(f)


	if invert then
		n:=bm.linebytes
		buffer:=makeref(malloc(n),byte)

		for y:=0 to filedimy%2 do
			p:=bmgetrowptr(bm,y)
			q:=bmgetrowptr(bm,filedimy-1-y)
!
			memcpy(buffer,p,n)
			memcpy(p,q,n)
			memcpy(q,buffer,n)
		od
		free(buffer)
	fi

	return bm
end

export func bmloadjpg(filename)=
	w:=h:=n:=0

CPL "LOADJ1"
!	p:=imgload_bgr(filename,&w,&h,&n,3)

!	p:=imgload_bgr(filename,&w,&h,&n,3)
	p:=loadjpegm(filename,&w,&h,&n);
!	p:=nanoloadjpeg(filename,&w,&h,&n)


!	p:=imgload_bgr(filename,&w,&h,&n)
CPL "LOADJ2",=P, W,H,N
	IF P=NIL THEN PCERROR("CAN'T LOAD JPG") FI

	pixelbits:=n*8

	if p=nil then
		return nil
	fi

	q:=makeref(p,byte)

	bm:=bmcreate(pixelbits,w,h)

	nbytes:=w*h*n
	dest:=makeref(bm.pixelptr,byte)

	to h do
		memcpy(dest,q,w*n)
		dest:=dest+bm.linebytes
		q:=q+w*n
	od

!	imgload_free(p)

	return bm
end

func bmloadpbm_p1p4(filename)=
CPL "CAN'T LOAD PBM"
RETURN NIL
!return bmunimpl("bmloadpbm")
end

func bmloadpgm_p2p5(filename)=

CPL "LOAD PGM P25",FILENAME
	f:=openfile(filename,"rb")
	if f=0 then return nil fi

	readln @f, sig:"s"

!CPL =SIG
	case sig
	when "P5" then
		binary:=1
	when "P2" then
		binary:=0
	else
		abort("Can't read pgm")
		return nil
	esac	

	width:=readnextint(f)
	height:=readnextint(f)
	maxpix:=readnextint(f)

	bm:=bmcreate(8,width,height)

	linebytes:=width
	dest:=makeref(bm.pixelptr,byte)

CPL =WIDTH,=HEIGHT, LINEBYTES,=BM
	to height do
		if binary then
			readbytes(f,dest,width)			!will be bgr
		else
			p:=dest
			to linebytes do
				p++^:=readffint(f)
			od
		fi

		dest:=dest+bm.linebytes
	od

	closefile(f)

	return bm
end

func bmloadppm_p3p6(filename)=
!read p6 ppm which is binary 24-bit, but will also recognise other formats

!CPL "P3P6"
	f:=openfile(filename,"rb")
	if f=0 then return nil fi

	readln @f, sig:"s"

!CPL =SIG
	case sig
	when "P6" then
		binary:=1
	when "P3" then
		binary:=0
	when "P5","P2" then
		closefile(f)
		return bmloadpgm_p2p5(filename)
!	when "P4","P1" then
!		closefile(f)
!		return bmloadpbm_p1p4(filename)
	else
		abort("Can't read ppm:"+sig)
		return nil
	esac	

!CPL "READING P6/P3 PPM"

	width:=readnextint(f)
	height:=readnextint(f)
	maxpix:=readnextint(f)

	bm:=bmcreate(24,width,height)

	linebytes:=width*3
	dest:=makeref(bm.pixelptr,byte)

	to height do
		if binary then
			readbytes(f,dest,linebytes)			!will be bgr
		else
			p:=dest
			to linebytes do
				p++^:=readffint(f)
			od
		fi

		p:=dest								!convert to rgb
		to width do
			swap(p^,(p+2)^)
			p:=p+3
		od

		dest:=dest+bm.linebytes
	od

	closefile(f)

	return bm
end

func readnextint(f)=
	read x
	while not x.isint and not eof(f) do
		readln @f,x
	od
	if not x.isint then return 0 fi
	return x
end

func readffint(f)=
!read next free-format int from f
	repeat
		c:=inbyte(f)
	until c in '0'..'9'

	a:=c-'0'
	do
		c:=inbyte(f)
		if c in '0'..'9' then
			a:=a*10+c-'0'
		else
			exit
		fi
	od

	return a
end

func bmloadpng(filename)=
	w:=h:=n:=0

CPL "LOADP1"
!	p:=imgload_bgr(filename,&w,&h,&n,3)

	p:=imgload_bgr(filename,&w,&h,&n,0)

!	p:=nanoloadjpeg(filename,&w,&h,&n)



!	p:=imgload_bgr(filename,&w,&h,&n)
CPL "LOADP2",=P, W,H,N

	pixelbits:=n*8

	if p=nil then
		return nil
	fi

	q:=makeref(p,byte)

	bm:=bmcreate(pixelbits,w,h)

	nbytes:=w*h*n
	dest:=makeref(bm.pixelptr,byte)

	to h do
		memcpy(dest,q,w*n)
		dest:=dest+bm.linebytes
		q:=q+w*n
	od

	imgload_free(p)

	return bm
end

export func bmsave(filename,bm,binary=0)=
	case e:=convlc(extractext(filename))
	when "jpg","jpeg" then
		return bmsavejpg(filename,bm)
	when "bmp" then
		return bmsavebmp(filename,bm)
	when "ppm","pgm" then
		return bmsaveppm_p3p6(filename,bm,binary)
	else
		println "CAN'T SAVE",E,"IMAGE"
		return nil
	esac
	return nil
end

func bmsavebmp(filename,bm)=
	w:=bm.dimx
	h:=bm.dimy
	pixelbytes:=bm.pixelbytes
	framebytes:=bm.linebytes*h
	palettebytes:=(pixelbytes=1|1024|0)

	bmfile:=createfile(filename)
	if bmfile=nil then
		return 0
	fi

	fileheader:=new(bmpheader)

	fileheader.fh.typex:='BM'
	fileheader.fh.offbits:=bmpheader.bytes+palettebytes
	fileheader.fh.size:=fileheader.fh.offbits+framebytes
	fileheader.bh.size:=ws_bitmapinfoheader.bytes
	fileheader.bh.width:=bm.dimx
	fileheader.bh.height:=-bm.dimy
	fileheader.bh.bitcount:=bm.pixelbits
	fileheader.bh.planes:=1
	fileheader.bh.xpelspermetre:=11811		!300 dpi
	fileheader.bh.ypelspermetre:=11811
	fileheader.bh.clrused:=0

	writerandom(bmfile,&fileheader,0,bmpheader.bytes)

	if palettebytes then
		palette:=bmgetpalette(bm)
		reversepalette(palette)
		writerandom(bmfile,&palette,bmpheader.bytes,palettebytes)
	fi

	writerandom(bmfile,bm.pixelptr,fileheader.fh.offbits,framebytes)

	return closefile(bmfile)
end

func bmsavejpg(filename,bm)=
	w:=bm.dimx
	h:=bm.dimy
	pixelbytes:=bm.pixelbytes
	linebytes:=bm.linebytes

	p:=q:=malloc(pixelbytes*w*h)

	s:=makeref(bm.pixelptr,byte)

	to h do
		memcpy(q,s,w*pixelbytes)
		q:=q+bm.linebytes
		s:=s+w*pixelbytes
	od

	status:=imgsave_jpeg_bgr(filename,p,w,h,pixelbytes)

	free(p)

	return status
end

func bmsavepbm_p1p4(filename,bm,binary)=
return bmunimpl("bmsaveppm-1bit")
end

func bmsavepgm_p2p5(filename,bm,binary)=
	width:=bm.dimx
	height:=bm.dimy

	f:=createfile(filename)

	CPL "WRITEPGM",filename

	if not f then return 0 fi

	println @f,(binary|"P5"|"P2")
	println @f,width,height
	println @f,"255"

	buffer:=data

	buffer:=malloc(bm.linebytes)
	if buffer=nil then return 0 fi
	buffer:=makeref(buffer,byte)

	linebytes:=width			!also number of values per line when in text mode

	for y:=0 to height-1 do
		memcpy(buffer,bmgetrowptr(bm,y),linebytes)
		if binary then
			writebytes(f,buffer,linebytes)
		else
			p:=buffer
			to linebytes do
				print @f,p++^,," "
			od
			println @f
		fi
	od
	closefile(f)
	return 1
end

func bmsaveppm_p3p6(filename,bm,binary)=
!	return bmunimpl("bmsaveppm")

	case bm.pixelbits
	when 24 then
	when 8 then
		return bmsavepgm_p2p5(filename,bm,binary)
	else
		return 0
	esac

	width:=bm.dimx
	height:=bm.dimy

	f:=createfile(filename)

	CPL "WRITEPPM",filename

	if not f then return 0 fi

	println @f,(binary|"P6"|"P3")
	println @f,width
	println @f,height
	println @f,"255"

	buffer:=data

	buffer:=malloc(bm.linebytes)
	if buffer=nil then return 0 fi
	buffer:=makeref(buffer,byte)

	linebytes:=width*3			!also number of values per line when in text mode

	for y:=0 to height-1 do
		memcpy(buffer,bmgetrowptr(bm,y),linebytes)
		p:=buffer					!convert to bgr
		to width do
			swap(p^,(p+2)^)
			p:=p+3
		od
		if binary then
			writebytes(f,buffer,linebytes)
		else
			p:=buffer
			to linebytes do
				print @f,p++^,," "
			od
			println @f
		fi
	od
	closefile(f)
	return 1
end

export func bmrotate(bm, angle)=
	case angle
	when 0 then return bmdupl(bm)
	when -90 then return bmrotleft90(bm)
	when +90 then return bmrotright90(bm)
	when 180 then return rot180(bm)
	esac
	return bmunimpl("bmrotate by "+tostr(angle))
end

export func bmrotleft90(bm)=
	case bm.pixelbits
	when 8 then return rotleft90_8(bm)
	when 24 then return rotleft90_24(bm)
	when 32 then return bmunimpl("ROTLEFT90/32")
	esac
	return nil
end

export func bmrotright90(bm)=
	case bm.pixelbits
	when 8 then return rotright90_8(bm)
	when 24 then return rotright90_24(bm)
	when 32 then return bmunimpl("ROTRIGHT90/32")
	esac
	return nil
end

export func rot180(bm)=
	newbm1:=bmfliphoz(bm)
	newbm2:=bmflipvert(newbm1)
	bmfree(newbm1)
	return newbm2
end

func rotleft90_8(bm)=
	w:=bm.dimx
	h:=bm.dimy
	linebytes:=bm.linebytes

	newbm:=bmcreate(8,h,w)

	for y:=0 to w-1 do
		q:=bmgetptr(bm,w-y-1,0)
		p:=bmgetrowptr(newbm,y)

		to h do
			p++^:=q^
!			q:=q+w
			q:=q+linebytes
		od
	od

	bmduplpalette(newbm,bm)
	return newbm
end

func rotright90_8(bm)=
	w:=bm.dimx
	h:=bm.dimy
	linebytes:=bm.linebytes

	newbm:=bmcreate(8,h,w)

	for y:=0 to w-1 do
		q:=bmgetptr(bm,y,h-1)
		p:=bmgetrowptr(newbm,y)

		to h do
			p++^:=q^
			q:=q-linebytes
		od
	od

	bmduplpalette(newbm,bm)
	return newbm
end

!function rotleft90_24(bm)=
!	newbm:=bmcreate(24,bm.dimy,bm.dimx)
!
!	xform:=new(array,ws_point,3)
!	xform[1].y:=bm.dimx
!	xform[3].x:=bm.dimy
!	xform[3].y:=bm.dimx
!
!	plgblt(newbm.gdi.hdc,&xform, bm.gdi.hdc,0,0,bm.dimx,bm.dimy, nil,0,0)
!
!	return newbm
!end

func rotleft90_24(bm)=
	w:=bm.dimx
	h:=bm.dimy

	newbm:=bmcreate(24,h,w)

	for y:=0 to w-1 do
		q:=bmgetptr(bm,w-y-1,0)
		p:=bmgetrowptr(newbm,y)

		to h do
			p++^:=q^
			p++^:=(q+1)^
			p++^:=(q+2)^
			q:=q+bm.linebytes
		od
	od

	return newbm
end

!function rotright90_24(bm)=
!	newbm:=bmcreate(24,bm.dimy,bm.dimx)
!
!	xform:=new(array,ws_point,3)
!	xform[1].X:=bm.dimy
!	xform[2].x:=bm.dimy
!	xform[2].y:=bm.dimx
!
!	plgblt(newbm.gdi.hdc,&xform, bm.gdi.hdc,0,0,bm.dimx,bm.dimy, nil,0,0)
!
!	return newbm
!end

func rotright90_24(bm)=
	w:=bm.dimx
	h:=bm.dimy

	newbm:=bmcreate(24,h,w)

	for y:=0 to w-1 do
		q:=bmgetptr(bm,y,h-1)
		p:=bmgetrowptr(newbm,y)

		to h do
			p++^:=q^
			p++^:=(q+1)^
			p++^:=(q+2)^
			q:=q-bm.linebytes
		od
	od

	return newbm
end

func rotate8(bm,angle)=
return bmunimpl("rotate8")
end

export func bmfliphoz(bm)=
	case bm.pixelbytes
    when 1 then return fliphoz8(bm)
    when 3 then return fliphoz24(bm)
    when 4 then return fliphoz32(bm)
	esac
	return nil
end

func fliphoz8(bm)=
	newbm:=bmdupl(bm)

	w:=newbm.dimx
	h:=newbm.dimy
	buffer:=makeref(malloc(bm.linebytes),byte)

	for y:=0 to h-1 do
		p:=bmgetrowptr(newbm,y)
		q:=p+w-1
		for x:=0 to w%2 do
			t:=p^
			p^:=q^
			q^:=t
			++p; --q
		od
	od

	return newbm
end

func fliphoz24(bm)=
	newbm:=bmdupl(bm)

	w:=newbm.dimx
	h:=newbm.dimy
	buffer:=makeref(malloc(bm.linebytes),byte)

	for y:=0 to h-1 do
		p:=bmgetrowptr(newbm,y)
		memcpy(buffer,p,bm.linebytes)
		q:=buffer+(w-1)*3

		to w do
			p++^:=q++^
			p++^:=q++^
			p++^:=q^

			q:=q-5
		od
	od

	return newbm
end

func fliphoz32(bm)=
return bmunimpl("fliphoz_32")
end

export func bmflipvert(bm)=
	newbm:=bmdupl(bm)

	w:=newbm.dimx
	h:=newbm.dimy
	n:=bm.linebytes
	buffer:=makeref(malloc(n),byte)

	for y:=0 to h%2 do
		p:=bmgetrowptr(newbm,y)
		q:=bmgetrowptr(newbm,h-1-y)
!
		memcpy(buffer,p,n)
		memcpy(p,q,n)
		memcpy(q,buffer,n)
	od
	free(buffer)

	return newbm
end

export func bmrepeat(bm,cols,rows)=
	w:=bm.dimx
	h:=bm.dimy
	newbm:=bmcreate(bm.pixelbits, w*cols, h*rows)
	linebytes:=bm.linebytes

	for y:=0 to h-1 do
		s:=bmgetrowptr(bm,y)
		for r:=0 to rows-1 do
			for c:=0 to cols-1 do
				memcpy(bmgetptr(newbm,c*w,r*h+y),s,linebytes)
			od
		od
	od

	if bm.pixelbits=8 then
		bmduplpalette(newbm,bm)
	fi

	return newbm
end

export func bmscale(bm, sx,?sy)=
	if sy.isvoid then sy:=sx fi
	case bm.pixelbits
	when 8 then return scalex8(bm,sx,sy)
	when 24,32 then return scalex24(bm,sx,sy)
	esac
	return nil
end

func scalex8(bm,sx,sy)=
	w:=bm.dimx
	h:=bm.dimy

	neww:=int(round(w*sx))
	newh:=int(round(h*sy))

	newbm:=bmcreate(24, neww,newh)
	return nil when not newbm

	bm24:=bmtorgb(bm,24)

	stretchblt(newbm.gdi.hdc,0,0,neww,newh,bm24.gdi.hdc,0,0,w,h, srccopy)

	if bm.paltype=greyscale_pal then
		newbm8:=bmgetplane(newbm,"R")
	else
		newbm8:=bmtopal(newbm)
	fi
	bmfree(newbm)

	return newbm8
end

func scalex24(bm,sx,sy)=
	w:=bm.dimx
	h:=bm.dimy

	neww:=int(round(w*sx))
	newh:=int(round(h*sy))

	if neww<8 or newh<8 then return nil fi

	newbm:=bmcreate(bm.pixelbits, neww,newh)
	if newbm then
		stretchblt(newbm.gdi.hdc,0,0,neww,newh,bm.gdi.hdc,0,0,w,h, srccopy)
	fi

	return newbm
end

func bmscaleupi8(bm,sx,sy)=
return bmunimpl("bmscaleupi8")
end

func bmscaleupi24(bm,sx,sy)=
return bmunimpl("bmscaleupi24")
end

func bmscaleupi32(bm,sx,sy)=
return bmunimpl("bmscaleupi32")
end

func bmscaledowni8(bm,sx,sy)=
return bmunimpl("bmscaledowni8")
end

func bmscaledowni24(bm,sx,sy)=
return bmunimpl("bmscaledowni24")
end

func bmscaledowni32(bm,sx,sy)=
return bmunimpl("bmscaledowni32")
end

export func bmneg(bm)=
	newbm:=bmdupl(bm)

	dx:=newbm.dimx-1
	dy:=newbm.dimy-1
	n:=newbm.linebytes
	do32:=0
	if n rem 4=0 then
		do32:=1
		n:=n%4
	fi

	for y:=0 to dy do
		if do32 then
			p:=makeref(bmgetrowptr(newbm,y),i32)
			to n do
				p++^ := p^ ixor 0xFFFFFFFF
			od
		else
			p:= bmgetrowptr(newbm,y)
			to n do
				p++^ := p^ ixor 255
			od
		fi
	od
	return newbm
end

export func bmmap(bm,map, channels="RGB")=
	if channels="" then channels:="RGB" fi

	case bm.pixelbits
	when 8 then
		return mapall(bm,map)
	when 24 then
		if channels="RGB" then
			return mapall(bm,map)
		fi
		return mapchan_24(bm,map,channels,0)
	when 32 then
		if channels="RGBA" then
			return mapall(bm,map)
		fi
		return mapchan_24(bm,map,channels,1)
	esac

	return nil
end

func mapall(bm,map)=
	newbm:=bmdupl(bm)
	p:=newbm.pixelptr
	to newbm.framebytes do
		p^:=map[p^]
		++p
	od
	return newbm
end

func mapchan_24(bm,map,channels,alpha=0)=
	dored:="R" in channels
	dogreen:="G" in channels
	doblue:="B" in channels
	doalpha:="A" in channels

	newbm:=bmdupl(bm)

	for y:=0 to newbm.dimy-1 do
		p:=bmgetrowptr(newbm,y)
		to newbm.dimx do
			if doblue then p^:=map[p^] fi
			++p
			if dogreen then p^:=map[p^] fi
			++p
			if dored then p^:=map[p^] fi
			++p
			if alpha then
				if doalpha then p^:=map[p^] fi
				++p
			fi
		od
	od

	return newbm
end

!function mapchan_32(bm,map,channels)=
!return bmunimpl("mapchan_32")
!end

export func bmbright(bm,dx,channels="RGB")=
	return bmunimpl("bmbright")
end

export func bmcont(bm,x,channels="RGB")=
	return bmunimpl("bmcont")
end

export func bmgamma(bm,x,channels="RGB")=
return bmunimpl("bmgamma")
end

export func bmtogrey(bm,destbits=24)=
	if destbits=0 then destbits:=bm.pixelbits fi
	case bm.pixelbits
	when 8 then
		case destbits
		when 8 then
			return pal8togrey8(bm)
		when 24 then
			cm:=pal8togrey8(bm)
			newbm:=grey8torgb24(cm)
			bmfree(cm)
			return newbm
		esac
	when 24,32 then
		case destbits
		when 8 then
			return rgb24togrey8(bm)
		when 24 then
			cm:=rgb24togrey8(bm)
			newbm:=grey8torgb24(cm)
			bmfree(cm)
			return newbm
		esac
	esac
CPL =BM.PIXELBITS, =DESTBITS
	return bmunimpl("bmtogrey bad combos")

end

func pal8togrey8(bm)=
	w:=bm.dimx
	h:=bm.dimy

	(rmap, gmap, bmap):=getlumtables()

	newbm:=bmcreate(8,w,h)
	pal:=bmgetpalette(bm)

	for y:=0 to h-1 do
		p:=bmgetrowptr(newbm,y)
		q:=bmgetrowptr(bm,y)

		to w do
			colour:=pal[q++^]
			r:=colour.[0..7]
			g:=colour.[8..15]
			b:=colour.[16..23]
			p++^:=rmap[r]+gmap[g]+bmap[b]
		od
	od

	return newbm
end

func pal8togrey24(bm)=
return bmunimpl("pal8togrey24")
end

func rgb24togrey8(bm)=
!does 24/32 bits
	qincr:=(bm.pixelbits=32|1|0)
	w:=bm.dimx
	h:=bm.dimy

	(rmap, gmap, bmap):=getlumtables()

	newbm:=bmcreate(8,w,h)

	for y:=0 to h-1 do
		p:=bmgetrowptr(newbm,y)
		q:=bmgetrowptr(bm,y)

		to w do
			b:=q++^; g:=q++^; r:=q++^
			p++^:=rmap[r]+gmap[g]+bmap[b]
			q:=q+qincr
		od
	od

	return newbm
end

func rgb24togrey24(bm)=
return bmunimpl("rgb24togrey24")
end

export func bmtorgb(bm,destbits=24)=
	if destbits=0 then destbits:=24 fi
	case bm.pixelbits
	when destbits then
		return bmdupl(bm)

	when 8 then
		case destbits
		when 8 then
			bmunimpl("8 to 8 bits rgb")
		when 24 then
			if bm.paltype=greyscale_pal then
				return grey8torgb24(bm)
			else
				return paltorgb24(bm)
			fi
		esac
	when 24 then
		if destbits=32 then
			return bmrgb24torgb32(bm)
		fi
	when 32 then
		if destbits=24 then
			return bmrgb32torgb24(bm)
		fi
	esac
CPL =BM.PIXELBITS, =DESTBITS
	return bmunimpl("bmtorgb bad combos")
end

func paltorgb24(bm)=
	w:=bm.dimx
	h:=bm.dimy

	newbm:=bmcreate(24,w,h)
	pal:=bmgetpalette(bm)

	for y:=0 to h-1 do
		p:=bmgetrowptr(newbm,y)
		q:=bmgetrowptr(bm,y)

		to w do
			colour:=pal[q++^]
			r:=colour.[0..7]
			g:=colour.[8..15]
			b:=colour.[16..23]

			p++^:=b
			p++^:=g
			p++^:=r
		od
	od

	return newbm
end

func grey8torgb24(bm)=
	w:=bm.dimx
	h:=bm.dimy

	newbm:=bmcreate(24,w,h)

	for y:=0 to h-1 do
		p:=bmgetrowptr(newbm,y)
		q:=bmgetrowptr(bm,y)

		to w do
			lum:=q++^
			p++^:=lum
			p++^:=lum
			p++^:=lum
		od
	od

	return newbm
end

export func bmrgb24torgb32(bm)=
	w:=bm.dimx
	h:=bm.dimy
	newbm:=bmcreate(32,w,h)

	for y:=0 to h-1 do
		q:=bmgetrowptr(bm,y)
		p:=bmgetrowptr(newbm,y)
		to w do
			p++^:=q++^
			p++^:=q++^
			p++^:=q++^
			p++^:=128
		od
	od
	return newbm
end

export func bmrgb32torgb24(bm)=
	w:=bm.dimx
	h:=bm.dimy
	newbm:=bmcreate(24,w,h)

	for y:=0 to h-1 do
		q:=bmgetrowptr(bm,y)
		p:=bmgetrowptr(newbm,y)
		to w do
			p++^:=q++^
			p++^:=q++^
			p++^:=q++^
			q++
		od
	od
	return newbm
end

export func bmtopal(bm)=
	if bm.pixelbits=8 then return bmdupl(bm) fi
	qincr:=(bm.pixelbits=32)
	w:=bm.dimx
	h:=bm.dimy

	newbm:=bmcreate(8,w,h)

	pal:=new(array,i32,0..255)

!create special palette mapping for rrrgggbb
	for r:=0 to 7 do
		for g:=0 to 7 do
			for b:=0 to 3 do
				index:=r<<5+g<<2+b
!				pal[index]:=r<<5+g<<13+b<<18
				pal[index]:=r<<5+g<<13+b<<22
			od
		od
	od
	bmputpalette(newbm,pal)
	bm.paltype:=colour_pal

	for y:=0 to h-1 do
		p:=bmgetrowptr(newbm,y)
		q:=bmgetrowptr(bm,y)

!noise:=-16..16
!noise:=-8..8

		to w do
			b:=q++^; g:=q++^; r:=q++^

!			r+:=clamp(random(noise),0,255)
!			g+:=clamp(random(noise),0,255)
!			b+:=clamp(random(noise),0,255)
!
			p++^:=r>>5<<5 + g>>5<<2 + b>>6
			q:=q+qincr
		od
	od

	return newbm

end

export func bmsplittorgb(bm,greydest=1)=
# split 24-bit bitmap into three separate 8-bit planes
# return 3 new bitmaps in the order red, green, blue
# return () on error
# dogreyscale=1 for each image to have a greyscale palette. Otherwise
# the red image will be shades of red, etc

	if bm.pixelbits<24 then
		return ()
	fi
	channels:=bm.pixelbytes

	w:=bm.dimx
	h:=bm.dimy

	pal:=new(array,i32,0..255)
	images::=()

	for offset:=channels-1 downto 0 do

		newbm:=bmcreate(8,w,h)

		for y:=0 to h-1 do
			q:=bmgetrowptr(bm,y)+offset
			p:=bmgetrowptr(newbm,y)
			to w do
				p++^:=q^
				q:=q+channels
			od
		od

		if not greydest then
			colour:=0
			incr:=(3-offset|0x00'00'01,0x00'01'00,0x01'00'00|0x01'01'01)
			for i:=0 to 255 do
				pal[i]:=colour
				colour+:=incr
			od
			bmputpalette(newbm,pal)
			newbm.paltype:=tinted_pal
		fi

		images append:=newbm
	od

!image order is r,g,b, or a,r,g,b
	if images.len=4 then
		return (images[2],images[3],images[4],images[1])
	else
		return images
	fi
end

export func bmsplittoyuv(bm)=
# split 24-bit bitmap into three separate 8-bit planes
# return 3 new bitmaps in the order y, u, v
# return () on error

	needfree:=0
	case bm.pixelbits
	when 24 then
	when 32 then
		bm:=bmtorgb(bm,24)
		needfree:=1
	else
		return nil
	esac

!get y plane first with existing routine
	greybm:=bmtogrey(bm,8)

	w:=bm.dimx
	h:=bm.dimy

!equations used are:
! u:=int(round(0.492*(b-y)+128)
! v:=int(round(0.702*(r-y)+128)
!b-y and r-y will be in range +/- 255

	umap:=new(list,-255..255)
	vmap:=new(list,-255..255)
	for i:=-255 to 255 do
		umap[i]:=int(round(0.492*(i)+128))
		vmap[i]:=int(round(0.702*(i)+128))
	od

	ubm:=bmcreate(8,w,h)
	vbm:=bmcreate(8,w,h)
	for c:=1 to 2 do
		if c=1 then
			offset:=0
			map:=umap
		else
			offset:=2
			map:=vmap
		fi

		for yy:=0 to h-1 do
			py:=bmgetrowptr(greybm,yy)
			p:=bmgetrowptr(bm,yy)			!point to bgr pixels in original

			pu:=bmgetrowptr(ubm,yy)
			pv:=bmgetrowptr(vbm,yy)
			to w do
				y:=py++^
				r:=(p+2)^
				b:=p^
				pu++^:=umap[b-y]
!CPL =B,=Y,=PV,=VMAP.TYPE
				pv++^:=vmap[r-y]

				p:=p+3
			od
		od
	od

!create special greyscale for u/v images, since point of zero colour
!info has been offset to +128
	pal:=new(array,i32,0..256)
	colour:=0
	pal[128]:=0
	for i:=1 to 127 do
		colour+:=0x020202
		pal [i+128]:=colour
		pal [128-i]:=colour
	od
	pal[256]:=uv_pal
	bmputpalette(ubm,pal)
	bmputpalette(vbm,pal)

	if needfree then
		bmfree(bm)
	fi

	return (greybm,ubm,vbm)
end

export func bmgetplane(bm,plane)=
# plane is one of "R","G","B"
# extract given plane of a 24-bit bitmaps into a single 8-bit greyscale image
# Return new image

	incr:=bm.pixelbytes
	if plane.len<>1 or bm.pixelbytes<3 then
		return nil
	fi

	case asc(plane)
	when 'R' then offset:=2
	when 'G' then offset:=1
	when 'B' then offset:=0
	when 'A' then offset:=3
	else return nil
	esac

	w:=bm.dimx
	h:=bm.dimy
	newbm:=bmcreate(8,w,h)

	for y:=0 to h-1 do
		q:=bmgetrowptr(bm,y)+offset
		p:=bmgetrowptr(newbm,y)
		to w do
			p++^:=q^
			q:=q+incr
		od
	od

	return newbm
end

export func bmjoinrgb(redbm,greenbm,bluebm,alphabm=nil)=

	w:=redbm.dimx
	h:=redbm.dimy

	newbm:=bmcreate((alphabm|32|24),w,h)

	for y:=0 to h-1 do
		p:=bmgetrowptr(newbm,y)

		r:=bmgetrowptr(redbm,y)
		g:=bmgetrowptr(greenbm,y)
		b:=bmgetrowptr(bluebm,y)

		if alphabm then
			a:=bmgetrowptr(alphabm,y)
			to w do
				p++^:=b++^
				p++^:=g++^
				p++^:=r++^
				p++^:=a++^
			od
		else
			to w do
				p++^:=b++^
				p++^:=g++^
				p++^:=r++^
			od
		fi
	od

	return newbm
end

export func bmjoinyuv(ybm,ubm,vbm)=
# combine y, u, v separations into a single rgb image
# return new bitmap, or nil

	if ybm.pixelbits<>8 then
		return nil
	fi

	w:=ybm.dimx
	h:=ybm.dimy

	v1425map:=new(list,0..255)
	v726map:=new(list,0..255)
	u395map:=new(list,0..255)
	u2032map:=new(list,0..255)

	for i:=0 to 255 do
		v1425map[i]:=int(round(1.425*(i-128)))
		v726map[i]:=int(round(0.726*(i-128)))
		u395map[i]:=int(round(0.395*(i-128)))
		u2032map[i]:=int(round(2.032*(i-128)))
	od

	newbm:=bmcreate(24,w,h)

	for yy:=0 to h-1 do
		p:=bmgetrowptr(newbm,yy)
		qy:=bmgetrowptr(ybm,yy)
		qu:=bmgetrowptr(ubm,yy)
		qv:=bmgetrowptr(vbm,yy)

!		to w do
		FOR X:=0 TO W-1 DO
			y:=qy++^
			r:=y+v1425map[qv^]
			g:=y-u395map[qu^]-v726map[qv^]
			b:=y+u2032map[qu^]
			++qu
			++qv
			p++^:=clamp(b,0,255)
			p++^:=clamp(g,0,255)
			p++^:=clamp(r,0,255)
		od
	od
	return newbm
end

export func bmblur(bm,n)=
	case bm.pixelbits
	when 8 then
		return blur8(bm,n)
	when 24 then
		return blur24(bm,n)
	when 32 then
		return blur32(bm,n)
	esac
	return nil
end

func blur8(bm,n)=
	shift:=shifts{n,1}

	newbm:=bmdupl(bm)
	iblurhoz8(newbm,n)

	newbm2:=rotleft90_8(newbm)
	iblurhoz8(newbm2,n)

	newbm3:=rotright90_8(newbm2)
	bmfree(newbm)
	bmfree(newbm2)

	bmduplpalette(newbm3,bm)
	return newbm3
end

func blur24(bm,n)=
	(r,g,b):=bmsplittorgb(bm)

	r2:=bmblur(r,n)
	g2:=bmblur(g,n)
	b2:=bmblur(b,n)

	newbm:=bmjoinrgb(r2,g2,b2)
	bmfree(r2)
	bmfree(g2)
	bmfree(b2)

	return newbm
end

func blur32(bm,n)=
return bmunimpl("blur32")
end

proc iblurhoz8(bm,n)=
	shift:=shifts{n,1}

	w:=bm.dimx
	h:=bm.dimy

	for y:=0 to h-1 do
		p:=bmgetrowptr(bm,y)
!		blurhelper(w-n-1, n, shift, p)

		to w-n-1 do
			sum:=0
			q:=p
			to n do
				sum+:=q++^
			od
			p++^:=sum>>shift
		od
	od
end

proc blurhelper(m, n, shift, p)=
	var sum
	var q

	to m do
		sum:=0
		q:=p
		to n do
			sum+:=q++^
		od
		p++^:=sum>>shift
	od
end

func blurhoz24(bm,n)=
return bmunimpl("blurhoz24")
end

func blurhoz32(bm,n)=
return bmunimpl("blurhoz32")
end

export func bmsharpen(bm,n=0)=
	case bm.pixelbits
	when 8 then
		return sharpen8(bm,n)
	when 24 then
		return sharpen24(bm,n)
	when 32 then
		return sharpen32(bm,n)
	esac
	return nil
end

export func sharpen8(bm,n)=
!blur in-place horizontally by averaging each set of n pixels
!n must be multiple of 2 from 2 to 64
!return new modified image

	w:=bm.dimx
	h:=bm.dimy

	newbm:=bmdupl(bm)

	for y:=1 to h-2 do
		p:=bmgetptr(newbm,1,y)

		q:=bmgetptr(bm,1,y-1)
		r:=bmgetptr(bm,1,y)
		s:=bmgetptr(bm,1,y+1)

		to w-2 do
!			abcdefghij
			a:=(q-1)^
			b:=q^
			c:=(q+1)^
			d:=(r-1)^
			e:=r^
			f:=(r+1)^
			g:=(s-1)^
			h:=s^
			i:=(s+1)^

! a b c
! d e f
! g h i
!			sum:=e*4-b-d-f-h
!			p^:=clamp(p^+sum%4,0,255)

			sum:=e*8-a-b-c-d-f-g-h-i
			p^:=clamp(p^+sum%8,0,255)

!			sum:=e*4+c+g+i-2*(b+d+f+h)
!			p^:=clamp(p^+sum%4,0,255)

			++p
			++q
			++r
			++s
		od
	od

	return newbm

end

export func sharpen24(bm,n)=
	(r,g,b):=bmsplittorgb(bm)

	r2:=bmsharpen(r,n)
	g2:=bmsharpen(g,n)
	b2:=bmsharpen(b,n)

	newbm:=bmjoinrgb(r2,g2,b2)
	bmfree(r2)
	bmfree(g2)
	bmfree(b2)

	return newbm
end

export func sharpen32(bm,n)=
return bmunimpl("bmsharpen32")
end

func getlumtables=
	rmap:=makescalemap(0.299)
	gmap:=makescalemap(0.587)
	bmap:=makescalemap(0.111)
	return (rmap, gmap, bmap)
end
