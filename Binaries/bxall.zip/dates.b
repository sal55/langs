
export var daynames=("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")

export var Monthnames=("January","February","March","April","May","June","July",
		"August","September","October","November","December")

export var days=(31,28,31, 30,31,30, 31,31,30, 31,30,31)

export record rdate=
	var day,month,year
end

export record rdatetime = 
	var	day
	var	month
	var	year
	var	hour
	var	minute
	var	second
	var	milliseconds
	var	dayofweek
end

!proc start=
!end
!
!proc main=
!end

export func makedatetime(d,m,y, h=0, minute=0, s=0)=

	d:=rdatetime(d,m,y, h,minute,s,0,0)
	d.dayofweek:=getdow(d)
	return d
end

export proc setdow(&d)=
	d.dayofweek:=getdow(d)
end

export func strdate(d,sep="-")=
!return leftstr(daynames[d.dayofweek],3)+" "+tostr(d.day)+sep+leftstr(monthnames[d.month],3)+sep+tostr(d.year)
	return tostr(d.day)+sep+leftstr(monthnames[d.month],3)+sep+tostr(d.year)
end

export func strtime(d,sep=":")=
	return tostr(d.hour)+sep+tostr(d.minute,"z2")+sep+tostr(d.second,"z2")
end

export func strdow(d,n=0)=
	if n then
		return leftstr(daynames[d.dayofweek],n)
	else
		return daynames[d.dayofweek]
	fi
end

export func strdatetime(d,dsep="-",tsep=":")=
	return strdate(d,dsep)+" "+strtime(d,tsep)
end

export func parsedate(s,defdate)=
!parse string s into a new date record
!def = default date to work from, eg. for missing year
!return date record obtained, or 0 if error

	day:=defdate.day
	month:=defdate.month
	year:=defdate.year
	if s.[1]=" " then s:=rightstr(s,-1) fi

	sepset:=[' ', '-', '/', '.']

	seppos:=0
	for i:=1 to s.len do if s.[i] in sepset then seppos:=i; exit fi od

	if not seppos then		!day only
		day:=strtoval(s)
		goto gotday
	fi
	day:=strtoval(leftstr(s,seppos-1))

	s:=rightstr(s,-seppos)		!month and possible year
	seppos:=0
	for i:=1 to s.len do if s.[i] in sepset then seppos:=i; exit fi od

	if seppos then
		monthstr:=leftstr(s,seppos-1)
		yearstr:=rightstr(s,s.len-seppos)
	else
		monthstr:=s
		yearstr:=""
	fi

	if asc(leftstr(monthstr)) in ['0'..'9'] then	!numeric month
		month:=strtoval(monthstr)
		if month<1 or month>12 then
			return 0
		fi
	else
		month:=0
		for i:=1 to 12 do
			if convlc(leftstr(monthnames[i],3))=convlc(leftstr(monthstr,3)) then
				month:=i
				exit
			fi
		od
		if not month then
			return 0
		fi
	fi

	if yearstr<>"" then
		year:=strtoval(yearstr)
		if year<200 then
			if year in [00..89] then
				year+:=2000
			else
				year+:=1900
			fi
		fi
	fi

gotday:
!check the date, rather than correct using addday(d,0)
	dd:=days[month] 
	if leapyear(year) and month=2 then dd+:=1 fi
	if day<1 or day>dd then return 0 fi
	if year<1990 or year>2089 then return 0 fi
	return makedatetime(day,month,year)
end

export func leapyear(y)=
!return true if y (eg. 1994) is a leap year
	return (y-1900) rem 4=0
end

export func getdow(d)=
!return day of week for given date, returning 1..7 (monday..sunday)
	return ((getday(d)-1) rem 7)+1
end

export func getday(d)=
!return day number for date d, measured from 1.1.90
	day:=0
	for i:=1990 to d.year-1 do
		day+:=(leapyear(i)|366|365)
	od

	for i:=1 to d.month-1 do
		day+:=(i=2|(leapyear(d.year)|29|28)|days[i])
	od
	day+:=d.day
	return day
end

export func getdays(m,y)=
!return no. of days in month m, for year y
	if leapyear(y) and m=2 then return 29 fi
	return days[m]
end

export func getmonthname(m,?n)=
	if not m.isint then
		m:=m.month
	fi
	m:=monthnames[m]
	if n.isdef then m:=leftstr(m,n) fi
	return m
end

export func getdayname(d,?n)=
	if not d.isint then
		d:=getdow(d)
	fi
	d:=daynames[d]
	if n.isdef then d:=leftstr(d,n) fi
	return d
end

export func addday(d0,i)=
	d:=d0
	if i>0 then
		to i do
			++d.day
			if d.day>getdays(d.month,d.year) then
				d.day:=1
				++d.month
				if d.month>12 then
					d.month:=1
					++d.year
				fi
			fi
		od
	else
		to -i do
			--d.day
			if d.day<1 then
				--d.month
				if d.month<1 then
					d.month:=12
					--d.year
				fi
				d.day:=getdays(d.month,d.year)
			fi
		od
	fi

!do checking
	if d.year<1990 then d:=makedatetime(1,1,1990) fi
	if d.year>2089 then d:=makedatetime(31,12,2089) fi

	dd:=getdays(d.month,d.year)
	if leapyear(d.year) and d.month=2 then dd+:=1 fi
	if d.day<1 then d.day:=1 fi
	if d.day>dd then d.day:=dd fi
	setdow(d)
	return d
end

export func getdatetime=
	tm:=getsystime()

	return rdatetime(tm.day,tm.month,tm.year,
			tm.hour, tm.minute, tm.second, tm.milliseconds,tm.dayofweek)
end

export func getsystime=
	tm:=new(ws_systemtime)
	getsystemtime(&tm)

	if tm.dayofweek=0 then
		tm.dayofweek:=7
	fi

	return tm
end
