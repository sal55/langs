!hello

proc AAA=
	PRINT "AAA"
end
