global proc lexchecktoken(int token)=
	lex()
	checktoken(token)
end

global proc checktokenlex(int token)=
	checktoken(token)
	lex()
end

global proc checktoken(int token)=
	[100]char str

	if lx.token<>token then
		fprint @str, "# expected, not #", tokennames[token], tokennames[lx.token]
		serror(str)
	end
end

global proc skipsemi=
	while lx.token=tk_semi do lex() end
end

!global proc checktoken2(int token, subcode)=
!	if lx.token<>token or lx.subcode<>subcode then
!		fprint @str, "#:# expected, not #:#", tokennames[token], subcode,
!					 tokennames[lx.token], lx.subcode
!		serror(str)
!	end
!end

global proc checkequals=
	unless lx.token=tk_binop and lx.subcode=bin_eq then
		serror("'=' expected")
	end
end

global func checkbegin(int fbrack)int=
!look for ( or [ or begin, return close symbol expected
!positioned at this opening symbol
!fbrack=1 to allow left "("
	int closetoken

	skipsemi()

	if lx.token=tk_lbrack and fbrack then
		closetoken:=tk_rbrack
		lex()
	else
		closetoken:=tk_end
	end
	return closetoken
end

global proc checkbeginend(int closetoken, kwd, startline=0)=
!look for ) or ] or end [kwd] depending on closetoken
!positioned at this symbol; exit at following symbol
	skipsemi()
!	if closetoken=tk_rbrack or closetoken=tk_rcurly then
	if closetoken=tk_rbrack then
		checktokenlex(closetoken)
!		lex()
	else
		checkend(closetoken, kwd, startline:startline)
	end
end

global proc checkend(int endtoken, endkwd1, endkwd2=0, startline=0)=
!at terminator symbol such as ), eof or 'end'
!check it matches what is expected
!tk_end is symbol expected to match
!'end' can have optional keyword following; if present, it must match endkeyword
!Some loop ends (indicated by endkeyword=tk_for, etc) can be also be terminated with 'od'
!tk_end should be tk_lbrack or kendsym
	[100]char str

!CPL "CHECKEND",TOKENNAMES[ENDTOKEN], TOKENNAMES[ENDKWD1], TOKENNAMES[ENDKWD2]
!PS("CHECKEND1")
	skipsemi()

!exit pointing to current symbol (to 'end', keyword after 'end', or ')')
	if endtoken=lx.token=tk_rbrack then
		return
	end

	if lx.token<>tk_end then
		serror("'End' expected")
	end

	if lx.subcode then
		if lx.subcode in [endkwd1, endkwd2] then
			lex()
			return
		else
error:
			strcpy(str, "Mismatched end ")
			if startline then
				fprint @(&str[1]+strlen(str)), " (from line #)", startline
			end
			serror(str)
		end
	end

!only end was used, so skip that now
!PS("CHECKEND2")
	lex()
!PS("CHECKEND3")
!CPL "KWD1/2=", TOKENNAMES[ENDKWD1], TOKENNAMES[ENDKWD2]
!now, should be semi, or possibly kwd1/2
	if lx.token in [endkwd1, endkwd2] then
		lex()
	elsif lx.token<>tk_semi then
		error
	end
end

global proc initparser(imodule pm)=
	dmode:=1
	unless nullunit then
		nullunit:=createunit(u_null)
	end unless
end

global func istypestarter:int=
	if typestarterset[lx.token] then return 1 end
	if lx.token=tk_name then				!name ...
		case nextlx.token
		when tk_name then					!name name
			return 1
		when tk_addr then
			return 1
		end case
	end
	return 0
end

proc start=
	for i:=1 to D_typestarterset.len do typestarterset[D_typestarterset[i]]:=1 end
end

global func fixcond(unit p)unit=
	checknotempty(p)
	if not isbooltag[p.tag] then
		insertunit(p, u_istruel)
	end
	return p
end

global proc checknotempty(unit p)=
	if p=nil or p.tag=u_block and p.a=nil then
		serror("Empty sunit")
	end
end

global func readtuple(int tag, n=2)unit =
!read (a,b) or (a,b,c) sequence; should be at '('
!return unit (tag, a,b), with any c being linked to b
!actually any number of elements is allowed

!should be at '('; read (x,y) or just (x) is opt is 1
!return (px, py)
	unit p, a,b,c

	checktokenlex(tk_lbrack)
	a:=readunit()
	checktokenlex(tk_comma)
	b:=readunit()
	c:=nil

	if n=3 and lx.token=tk_comma then				!optional 3rd element
		lex()
		c:=readunit()
	end
	checktokenlex(tk_rbrack)

	b.nextunit:=c							!c may be nil

	return createunit(tag, a, b)
!
!	case lx.token
!	when tk_comma then
!		lex()
!		q:=readunit()
!		checktokenlex(tk_rbrack)
!	when tk_rbrack then
!		if not opt then checktoken(tk_comma) end
!		lex()
!		q:=nil
!	else
!		checktoken(tk_rbrack)			!error; report missing bracket
!	end
!
!	return (p, q)
end

global func readcompilervar:unit=
	[100]char str
	rsystemtime tm
	static []ichar monthnames=("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
	unit p
	imodule currmodule:=modules[currmoduleno]

	switch lx.subcode
	when cv_nil then
		p:=createunit(u_nil)
		p.mode:=tref
		lex()
		return p

	when cv_pi then
!		p:=createconstunit(i64@(3.14159'265358'979'3238'4626'433'832), treal)
		p:=createrealconstunit(pi, treal)
		lex()
		return p

	when cv_infinity then
		p:=createrealconstunit(infinity, treal)
		lex()
		return p

	when cv_lineno then
!		tc_gen(kloadimm, getlineno(lx.pos)
		p:=createintconstunit(lx.lineno, ti64)
!		p:=createunit0(cv_lineno)
		lex()
		return p

	when cv_strlineno then
		getstrint(lx.lineno, str)

	when cv_modulename then
		strcpy(str, stmodule.name)

	when cv_filename then
		strcpy(str, sources[currmodule.fileno].filespec)

	when cv_func then
		strcpy(str, currproc.name)

	when cv_date then
		os_getsystime(&tm)
		fprint @str, "#-#-#", tm.day, monthnames[tm.month], tm.year:"4"

	when cv_time then
		os_getsystime(&tm)
		fprint @str, "#:#:#", tm.hour:"z2", tm.minute:"z2", tm.second:"z2"

	when cv_version then
		strcpy(str, "Compiler:M6.4")

	when cv_true, cv_false then
		p:=createintconstunit(lx.subcode=cv_true, ti64)
		lex()
		return p
	
	else
		serror_s("compiler var not impl: #", cvnames[lx.subcode])
	end switch
	lex()

	return createstringconstunit(pcm_copyheapstring(str), -1)
end

global func makeblock(unit p)unit=
	unless p and p.tag=u_block then
		p:=createunit(u_block, p)
	end
	p
end

global proc pushproc(symbol p)=
	if nprocstack>=maxprocstack then
		serror("Too many nested proc")
	end
	procstack[++nprocstack]:=currproc
	currproc:=p
end

global proc popproc=
	if nprocstack then
		currproc:=procstack[nprocstack--]
	else
		currproc:=stmodule
	end
end
!
!global func readname:unit p=
!	p:=readterm2()
!	if p.tag<>jname then serror("Name expected") end
!	return p
!end
!
!
global proc addstructflag(symbol owner, int id)=
	static int structseqno
	[32]char str
	symbol d

	print @str, "$$",,++structseqno
	d:=getduplst(owner, addnamestr(str), id)
	adddef(owner, d)
end

global func readconstint:int=
!read expression that must yield a constant int value *now*; return value
	i64 x

!keep it simple for now
	if lx.token=tk_intconst then
		x:=lx.value
		lex()
		return x
	elsif lx.token=tk_binop and lx.subcode=bin_sub then
		lex()
		if lx.token=tk_intconst then
			x:=lx.value
			lex()
			return -x
		end
	end

!later can only arbitrary expressions, provided they can be evaluated in this pass
	serror("Not const int")
	return 0
end

