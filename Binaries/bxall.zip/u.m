!global proc systest=
export proc systest=

end
