var abc::=1235


proc main=

	a:=b+c*d


end
