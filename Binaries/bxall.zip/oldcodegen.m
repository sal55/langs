!not opcodes, just used internally here for conditional jump logic
!const kjumpt = 1
!const kjumpf = 0

!loop stack data reused by GENMPL
const maxloopindex=20
[maxloopindex, 4]int loopstack
[maxloopindex]int trylevelstack
global int loopindex=0
int looptrylevel			!return by findlooplabel

const maxswitchrange=512
const maxlocals=300
const maxparams=100

const maxunits=400					!for constructors
int trylevel=0
!int currfunction=0				!0/1/2 = not a function/proc/function

!vars within curr procdef
int retindex						!common return point; label no
int retvaloffset					!offset of return value for procs (as stack slots)
int nprocparams						!no. of params
!global int nproclocals				!no. of locals
global pcl pprocentry				!pointer to PROCENT op; for updating locals due to AVs
const retaddrslots = 1				!+1 or +2, added to param indices (depends on return info size)
int procskiplabel

global proc evalunit(unit p, int res=1)=
!p is a single executable unitrec; not a list or const
!should be called via execblock() to executate a code item in a unitrec
!note: sometimes res can be 2, (passing on a res=2 from an outer stmt)
!that should be treated here same as 1 (res=2 has special meaning from pclhasvalue[] only)
	unit a, b
	symbol d
	int procflag, index

!CPL "EVALUNIT", JTAGNAMES[P.TAG]

	qpos:=p.pos

	a:=p.a
	b:=p.b

	switch p.tag
	when u_intconst then
		pgen_int(kpushci, p.value)

	when u_realconst then
		pgen_real(kpushcr, p.xvalue)

!	when u_enumconstthen
!		pgen_int2(kpushenum, p.value, p.mode)

	when u_none then

	when u_stringconst then
		pushstring(p.svalue)

	when u_name then
		d:=p.def
!CPL "NAME",D.NAME,NAMENAMES[D.NAMEID]
		case d.nameid
		when paramid then
			pgen_name(kpushm, d)
			if d.mbyref then
				pgen(kpushptr)
			fi

		when frameid, staticid then
			pgen_name(kpushm, d)

		when labelid then
			if d.labelno=0 then
				d.labelno:=createfwdlabel()
			fi
			if not res then
				pgen_lab(kjump, d.labelno)
				return
			else
				pgen_lab(kpushlab, d.labelno)
			fi

!		when dllvarid then
!			pgen_name(kpushx, d)

		else
			pgen_name(kpushsym, d)
		esac

	when u_symbol then			!assume a is jname
		if a.tag=jname then
			pgen_name(kpushsym, a.def)
		else
			gerror(".$ name expected")
		fi

	when u_block then
		if a then
			while a and a.nextunit do
				evalunit(a, 0)
				a:=a.nextunit
			od
			if a then
				evalunit(a, res)
			fi
		else
!			gerror("empty block")
		fi

	when u_decimal then
		pushstring(p.svalue)
		pgen(kmakedec)

	when u_call then
		do_call(p, a, b, res, procflag)
	when u_return then
		do_return(p, a, res)
	when u_callhost then
		do_callhost(p, a, res)

	when u_assign then
		do_assign(a, b, res, p.flag)
	when u_to then
		do_to(p, a, b)
	when u_if then
		do_if(p, a, b, b.nextunit, res)
	when u_for		then
		do_for(p, a, b
)
	when u_forx then
		do_forx(p, a, b)

	when u_forall, jforeach then
		do_forall(p, a, b)

	when u_while then
		do_while(p, a, b)

	when u_repeat then
		do_repeat(p, a, b)

	when u_goto then
		if a.tag=jname and a.def.nameid=labelid then
			d:=a.def
			if d.labelno=0 then
				d.labelno:=createfwdlabel()
			fi
			pgen_lab(kjump, d.labelno)
		else
			evalunit(a)
			pgen(kjumpptr)
		fi

	when u_labeldef then
		d:=a.def
GENCOMMENT(D.NAME)
		if d.labelno=0 then
			d.labelno:=definelabel()
		else
			index:=d.labelno
			definefwdlabel(index)
		fi

	when u_loop then
		do_loop(p)

	when u_do then
		do_do(p, a)
	when u_case, jdocase then
		do_case(p, a, b, res)
	when u_switch, jdoswitch then
		do_switch(p, a, b, res)
	when u_swap then
		evalref(a)
		evalref(b)
		pgen(kswap)

	when u_select then
		do_select(a, b, res)
	when u_print then
		do_print(p, a, b)
	when u_fprint then
		do_fprint(p, a, b, b.nextunit)
	when u_read then
		do_read(p, a, b)

	when u_stop then
		if a then
			evalunit(a)
		else
			pgen_int(kpushci, 0)
		fi
		pgen(kstop)

	when u_try then
		do_try(p, a, b)

	when u_andl then
		do_andl(a, b)
	when u_orl then
		do_orl(a, b)
	when u_makelist then
		do_pushlist(a, p.length)
		pgen_xy(kmakelist, p.length, p.lower)

	when u_makeset then
		do_pushlist(a, p.length)
		pgen_xy(kmakeset, p.length)

	when u_makedict then
		do_makedict(a, p.length)

	when u_makerange then
		evalunit(a)
		evalunit(b)
		pgen(kmakerang)

	when u_keyvalue then
		evalunit(a)
		evalunit(b)

	when u_map then
		do_map(p, a, b)

	when u_bin then
		case p.pclop
		when kidiv then
		do_idiv(a, b)
		when kirem then
		do_irem(a, b)
		else
			evalunit(a)
			evalunit(b)
			pgen(p.pclop)
		esac

	when u_binto then
		evalunit(b)
		evalref(a)
		pgen(kbinto)
		for i to bintotable.len do
			if bintotable[i].pclop=p.pclop then
				pccurr.bintoindex:=i
				exit
			fi
		else
			gerror("No binto entry")
		od

!		pccurr.bintocode:=p.pclop

	when u_unary, jproperty then
		evalunit(a)
		pgen(p.pclop)
		if p.pclop=kbounds then pccurr.n:=1 fi

	when u_unaryto then
		evalref(a)
		pgen(kunaryto)
		pccurr.pclop:=p.pclop

	when u_appendto, jconcatto then
		evalunit(b)
		evalref(a)
		pgen((p.tag=jappendto|kappendto|kconcatto))

	when u_notl then
		evalunit(a)
		pgen(knotl)

	when u_istruel then
		evalunit(a)
		pgen(kistruel)

	when u_istype then
		evalunit(a)
		pgen(kistype)
		pccurr.usertag:=p.mode

	when u_isvoid then
		evalunit(a)
		pgen(kisvoid)
		pccurr.n:=p.flag

	when u_dot then! do_bin(a, b, kdot)
		evalunit(a)
		if b.def.genfieldindex=0 then gerror(".m?") fi

		pgen_name(kdot, b.def)

	when u_index then
		do_bin(a, b, kindex)

	when u_dotindex then
		do_bin(a, b, kdotix)

	when u_keyindex then
		evalunit(a)
		evalunit(b)
		if b.nextunit then
			evalunit(b.nextunit)
		else
			pgen(kpushvoid)
		fi
		pgen(kkeyindex)

	when u_ptr then
		evalunit(a)
		pgen(kpushptr)

	when u_addrof then
		if p.flag=1 then			! ^x
			if a.tag=jptr then			!^a^ cancel out (a might be byref param)
				evalunit(a.a)
			else
				evalref(a)
			fi
		else
			evalref(a)
			pgen(kconvrefp)
		fi

	when u_convert then
		do_convert(p)

	when u_typepun then
		evalunit(a)
		pgen_int(ktypepun, p.mode)

	when u_typeconst then
		pgen_int(kpushtype, p.mode)

	when u_operator then
		pgen_int(kpushopc, p.pclop)

	when u_incrload, jloadincr then
		do_incr(p, a, res)

	when u_nil then
		pgen(kpushnil)

	when u_raise then
		evalunit(a)
		pgen(kraise)

	when u_void then
		pgen(kpushvoid)

	when u_eval then
		evalunit(a)
		pgen_n(kunshare, 1)

	when u_gettype then
		evalunit(a)
		pgen_n(ktype, p.flag)

	when u_in then
		evalunit(a)
		evalunit(b)
		pgen(kin)
		pccurr.n:=p.flag

	when u_inx then
		evalunit(a)
		evalunit(b)
		pgen(kinx)
		pccurr.n:=p.flag

	when u_cmp then
		evalunit(a)
		evalunit(b)
		pgen_n(kcmp, p.condcode)

	when u_maths then
		evalunit(a)
		if p.mathsop=mm_sqr then
			pgen(ksqr)
		else
			pgen(kmaths)
			pccurr.mathscode:=p.mathsop
		fi

	when u_maths2 then
		evalunit(a)
		evalunit(b)
		pgen(kmaths2)
		pccurr.mathscode:=p.mathsop

	else
		gerror_s("UNSUPPORTED TAG:", JTAGNAMES[P.TAG], p)
	end switch

	case uisexpr[p.tag]
	when 0 then
		if res then
			unless p.tag in [jprint, jfprint] and p.flag iand pr_sprint then
				gerror_s("Value expected:", jtagnames[p.tag])
			end
		fi
	when 1 then
		if not res then
			if p.tag=jcall and procflag=1 then		!procs have no ret value
			elsif p.tag in [jincrload, jloadincr] then
			elsif p.tag=jcallhost and hostisfn[p.index]=0 then
			else
				pgen_n(kunshare, 1)
			fi
		fi
	esac						!else ignore when 2, as already dealt with
end

proc do_procdef(symbol p) =
	int nfreevars, nnofreevars
	int isfunc
	symbol oldcurrproc

	oldcurrproc:=stcurrproc			!might be a method

	stcurrproc:=p

	retindex:=createfwdlabel()
	isfunc:=p.misfunc

	genprocentry(p, nfreevars, nnofreevars)

	if p.code=nil then
		gerror_s("Empty proc body", p.name)
	else
		evalunit(p.code, isfunc)

		if isfunc then
!CPL "CHECK BODY", JTAGNAMES[P.CODE.TAG]
			if not checkblockreturn(p.code) then
				gerror("Func: return value missing")
			fi
		fi

	fi

	definefwdlabel(retindex)			!common return point
	genprocexit(nfreevars, nnofreevars, isfunc)
	pgen(kprocend)

	if pprocentry.n=0 then			!skip past procentry instr
		++pprocentry
!		++p.labelref
	fi
	p.labelref:=pprocentry
!CPL "PROCDEF", =PCLNAMES[PPROCENTRY.OPCODE], =P.LABELREF

	stcurrproc:=oldcurrproc
end

proc genprocentry(symbol p, int &nfreevars, &nnofreevars) =		!GENPROCENTRY
	[200]char str
	int n
	symbol d

	pgen_name(kprocdef, p)

	nprocparams:=nproclocals:=0

	d:=p.deflist
	while d do
		case d.nameid
		when frameid then
			++nproclocals
			d.index:=nproclocals
		when paramid then
			++nprocparams
		esac

		d:=d.nextdef
	od

	d:=p.deflist
	n:=nprocparams

	while d, d:=d.nextdef do
		case d.nameid
		when paramid then
			--n
			d.index:=-(n+retaddrslots)
		esac

	od

	retvaloffset:=-(nprocparams+retaddrslots)

!	p.labelno:=definelabel()
!CPL "GENPROCENTRY",P.LABELNO, p.labelref
	pgen_n(kprocent, nproclocals)

	pprocentry:=pccurr

	d:=p.deflist
	while d do
		case d.nameid
		when frameid then
			if d.code then
				evalunit(d.code)
				if d.initcode=3 then
					pgen(kcopy)
				fi
				pgen_name(kzpopm, d)
			fi
		esac

		d:=d.nextdef
	od
end

proc genprocexit(int nfree, nnofree, isfunc)=		!GENPROCEXIT
	int offset

	if isfunc then
		offset:=-(nprocparams+1)*varsize
		pgen_xy(kretfn, nproclocals, offset)
		pccurr.n:=nprocparams
	else
		pgen_n(kretproc, nprocparams)
		pccurr.x:=nproclocals
	fi


!	if isfunc then
!		offset:=-(nprocparams+1)*varsize
!		pgen_int(kpopret, offset)
!	fi
!	if nproclocals then
!		pgen_n(kunshare, nproclocals)
!	fi
!
!	pgen_n(kreturn, nprocparams)
end

proc evalref(unit p)=
	unit a, b, c
	symbol d
	int lab1, lab2
	a:=p.a
	b:=p.b

	switch p.tag
	when u_name then
		d:=p.def
		if d.nameid in [procid, dllprocid] then
			gerror("^ not allowed")
		fi	

		if d.nameid=paramid and d.mbyref then
			pgen_name(kpushm, d)
		else
			pgen_name(kpushmref, d)
		fi

	when u_dot then! do_binref(a, b, kdotref)
		evalunit(a)
		if b.def.genfieldindex=0 then gerror(".m2?") fi
		pgen_name(kdotref, b.def)

	when u_index then! do_binref(a, b, kindexref)
		evalunit(a)
		evalunit(b)
		pgen(kindexref)

	when u_dotindex then! do_binref(a, b, kdotindexref)
!		evalunit(a)
		evalref(a)
		evalunit(b)
		pgen(kdotixref)

	when u_keyindex then! do_binref(a, b, kkeyindexref)
		evalunit(a)
		evalunit(b)
		if b.nextunit then gerror("Def val not allowed") fi
		pgen(kkeyixref)

	when u_ptr then
		evalunit(a)

	when u_if then
		lab1:=createfwdlabel()				!dest label of main condition (to end of if, or start if else)
		lab2:=createfwdlabel()

		genjumpcond(kjumpf, p.a, lab1)
		evalref(p.b)
		genjumpl(lab2)
		definefwdlabel(lab1)
		evalref(p.b.nextunit)
		definefwdlabel(lab2)
	else
!		case p.tag
!		when u_if then
!			do_if(p, a, b, c, 1)
!		when u_longif then
!			do_longif(p, a, b, 1)
!		when u_select then
!			do_select(p, a, b, c, 1)
!		when u_switch then
!			do_switch(p, a, b, c, 0, 1)
!		when u_case then
!			do_case(p, a, b, c, 0, 1)
!		else
!			PRINTUNIT(P)
			gerror_s("evalref", jtagnames[p.tag])
!		esac
	end switch
end

proc genjumpcond(int opc, unit p, int lab)=
!p is some conditional expression of arbitrary complexity
!opc is kjumpf or kjumpt
!evaluate and generate jumps as needed
	unit q, r, s
	int oldpos, lab2, i

	q:=p.a
	r:=p.b

	switch p.tag
	when u_andl then
		case opc
		when kjumpf then
			genjumpcond(kjumpf, q, lab)
			genjumpcond(kjumpf, r, lab)
		when kjumpt then
			lab2:=createfwdlabel()
			genjumpcond(kjumpf, q, lab2)
			genjumpcond(kjumpt, r, lab)
			definefwdlabel(lab2)
		esac

	when u_orl then
		case opc
		when kjumpf then
			lab2:=createfwdlabel()
			genjumpcond(kjumpt, q, lab2)
			genjumpcond(kjumpf, r, lab)
			definefwdlabel(lab2)
		when kjumpt then
			genjumpcond(kjumpt, q, lab)
			genjumpcond(kjumpt, r, lab)
		esac

	when u_notl then
		case opc
		when kjumpf then
			genjumpcond(kjumpt, q, lab)
		when kjumpt then
			genjumpcond(kjumpf, q, lab)
		esac

	when u_istruel then
		genjumpcond(opc, q, lab)

	when u_block then
		while q and q.nextunit do
			evalunit(q)
			q:=q.nextunit
		od
		genjumpcond(opc, q, lab)

	when u_cmp then
		evalunit(q)
		evalunit(r)
		gcomparejump(opc, p.condcode, lab)

	when u_cmpchain then
		r:=q.nextunit
		i:=1
		if opc=kjumpf then
			while r do
				evalunit(q)
				evalunit(r)
				gcomparejump(kjumpt, revconds[p.cmpconds[i]], lab)
				++i
				q:=r
				r:=r.nextunit
			od
		
		else
			lab2:=createfwdlabel()
			while r do
				evalunit(q)
				evalunit(r)
				if r.nextunit then
					gcomparejump(kjumpt, revconds[p.cmpconds[i]], lab2)
				else
					gcomparejump(kjumpt, p.cmpconds[i], lab)
				fi
				++i
				q:=r
				r:=r.nextunit
			od
			definefwdlabel(lab2)
		fi
	else
		evalunit(p)
		pgen_lab(opc, lab)
	end switch
	qpos:=oldpos

end

proc gcomparejump(int opc, cond, lab)=
!jumpopc is the base cmdcode needed: kjumpt or kjumpt
!p is the eq/compare unit
!convert into jumpcc cmdcode

	if opc=kjumpf then				!need to reverse condition
		cond:=revconds[cond]		!eq_cc => ne_cc, etc
	fi

	pgen_lab(kjumpeq+cond, lab)
end

proc genjumpl(int lab)=
!generate unconditional jump to label
	pgen_lab(kjump, lab)
end

global proc stacklooplabels(int a, b, c)=
!list of labels associated with a loop: a/b/c are redo/next/exit
	if loopindex>=maxloopindex then
		gerror("Too many nested loops")
	fi

	++loopindex
	loopstack[loopindex, 1]:=a
	loopstack[loopindex, 2]:=b
	loopstack[loopindex, 3]:=c
end

global proc unstacklooplabels=
	--loopindex
end

global function findlooplabel(int k, n)int=
!k is 1, 2, 3, 4 for label A, B, C, D
!n is a 1, 2, 3, etc, according to loop nesting index
	int i

	if n=0 then			!outermost loop
		i:=1
	else
		i:=loopindex-(n-1)		!point to entry
	fi

	if i<1 or i>loopindex then
		gerror("Bad loop index")
	fi

	looptrylevel:=trylevelstack[i]
	return loopstack[i, k]
end

proc do_assign(unit a, b, int res, deepcopy=0)=
	unit q
	int n

	if a.tag=b.tag=jmakelist then
		if res then gerror("mult/ass::=") fi
!		if deepcopy then gerror("mult/ass::=") fi
		do_multassign(a, b, deepcopy, res)
		return
	fi

	evalunit(b)
	if deepcopy then
		pgen(kcopy)
	fi

	do_store(a, res)
end

proc do_bin(unit a, b, int opc)=
	evalunit(a)
	evalunit(b)
	pgen(opc)
end

proc do_binref(unit a, b, int opc)=
	evalref(a)
	evalunit(b)
	pgen(opc)
end

proc do_unary(unit a, int opc)=
	evalunit(a)
	pgen(opc)
end

proc do_unaryref(unit a, int opc)=
	evalref(a)
	pgen(opc)
end

proc do_pushlist(unit a, int n)=
	while a, a:=a.nextunit do
		evalunit(a)
	od
end

proc do_makedict(unit a, int n)=
	to n do
		if a.tag=jkeyvalue then
			evalunit(a.a)
			evalunit(a.b)
		else
			gerror("dict not key:val")
		fi
		a:=a.nextunit
	od
	pgen_xy(kmakedict, n)
end

proc do_call(unit p, a, b, int res, &procflag)=
	int nargs, nsimple, isfunc, kwdindex
	symbol d
	unit c
	[maxparams]unit arglist

	isfunc:=1
	nargs:=nsimple:=0
	kwdindex:=0
	c:=b

	while c do
		arglist[++nargs]:=c
		if c.tag in [jintconst, jrealconst] then ++nsimple fi
		if c.tag=jkeyword then
			if kwdindex=0 then kwdindex:=nargs fi
		elsif kwdindex then
			gerror("Non-kwd follows kwd arg")
		fi
		c:=c.nextunit
	od

	case a.tag
	when u_name then
		d:=a.def
retry:
		case d.nameid
		when procid, anonprocid then
			if d.misfunc then
				pgen(kpushvoid)
				nargs:=pushparams(d, arglist, nargs, kwdindex)
!				pgen_name(kcallfn, d)
				pgen_name(kcallproc, d)
			else					!proc call
				isfunc:=0
				nargs:=pushparams(d, arglist, nargs, kwdindex)
				pgen_name(kcallproc, d)
			fi
			pccurr.n:=nargs

		when dllprocid then
			if not d.misfunc then
				isfunc:=0
			else
				pgen(kpushvoid)
			fi
			nargs:=pushparams(d, arglist, nargs, kwdindex)
			pgen_name(kcalldll, d)
			pccurr.n:=nargs

		when aliasid then
			d:=d.alias
			goto retry
		when staticid, frameid, paramid then
			goto docallptr
!
		else
			gerror_s("CAN'T CALL:", namenames[d.nameid])
		esac
	when u_dot then
		if kwdindex then docallptr fi		!share error
		pgen(kpushvoid)
		evalref(a.a)					!push &self arg
		for i to nargs do				!any extra ones
			evalunit(arglist[i])
		od
		evalunit(a)						!push lhs again, this time for dot
		pgen_n(kcallptr, ++nargs)

	else
docallptr:
		if kwdindex then gerror("Kwd params not allowed for fnptr") fi
		pgen(kpushvoid)
		for i to nargs do
			evalunit(arglist[i])
		od
		evalunit(a)
		pgen_n(kcallptr, nargs)
	esac

	if res and not isfunc then
		gerror("Func ret value expected")
	fi

	procflag:=not isfunc
end

function pushparams(symbol d, []unit &arglist, int nargs, kwdindex)int=
!push args for a known, named function
!will deal with missing/optional args, default values, and keyword params
!should work also for dll procs
!In all cases, first nparams items in d.deflist will be parameter names, 
!For dlls with no named params, the entries will be $1 etc.

	int nparams, extra, n
	[maxparams]symbol paramlist
	[maxparams]byte byreflist
	symbol e, p

	nparams:=d.nparams
	e:=d.deflist
	n:=0
	while e do
		++n
		paramlist[n]:=e
		byreflist[n]:=e.mbyref
		e:=e.nextdef
	od

	if kwdindex then
		pushkwdparams(d, arglist, nargs, kwdindex)
		return d.nparams
	fi

	extra:=0

	if nargs=nparams then
		for i to nargs do
			evalparam(arglist[i], byreflist[i])
		od
		return nargs
	elsif nargs<nparams then	!trailing args missing
		for i to nargs do
			evalparam(arglist[i], byreflist[i])
		od

		for i:=nargs+1 to nparams do
			p:=paramlist[i]
			if not p.code and not p.moptional then
				gerror_s("Param not optional:", strint(i))
			fi
			if p.code then
				if byreflist[i] then gerror("byref with default val") fi
				evalunit(p.code)
			else
				pgen(kpushvoid)
			fi
		od
		return nparams
	else						!nargs>nparams: variadic
		for i to nparams do
			evalparam(arglist[i], byreflist[i])
		od

		if not d.mvarparams then
			gerror("Too many args")
		fi
		for i:=nparams+1 to nargs do
			evalunit(arglist[i])			!o/p variadic args
		od
		return nargs
	fi
end

proc evalparam(unit a, int byref)=
	if byref then
		evalref(a)
	else
		evalunit(a)
	fi
end


proc pushkwdparams(symbol d, []unit &arglist, int nargs, kwdindex)=
	int nparams, i, j, k
	[maxparams]symbol paramlist
	[maxparams]byte byreflist
	[maxparams]unit keyunits
	unit p, q
	symbol e

	nparams:=d.nparams

	e:=d.deflist
	for i to nparams do
		paramlist[i]:=e
		byreflist[i]:=e.mbyref
		e:=e.nextdef
	od

	if nargs>nparams then
		gerror("Too many args")
	fi

	for i:=kwdindex to nparams do
		keyunits[i]:=nil			!indicate param not set
	od

	for i to kwdindex-1 do			!do positional params
		evalparam(arglist[i], byreflist[i])
	od

	for i:=kwdindex to nargs do
		p:=arglist[i]
		q:=p.a
		if q.tag<>jname then gerror("kwd not a name") fi
		e:=q.def
		k:=0
		for j:=1 to nparams do
			if eqstring(e.name, paramlist[j].name) then
				k:=j
				exit
			fi
		od

		if k=0 then gerror_s("Can't find kwd param:", e.name) fi
		if k<kwdindex then gerror_s("Kwd arg already positional:", e.name) fi
		if keyunits[k] then gerror_s("Repeating kwd arg:", e.name) fi

		keyunits[k]:=p.b
	od

	for i:=kwdindex to nparams do
		if keyunits[i]=nil then
			q:=paramlist[i].code
			if q=nil and not paramlist[i].moptional then
				gerror_s("Param not optional:", strint(i))
			fi
			keyunits[i]:=q			!q is nil when default value not set
		fi
	od

!	for i:=nparams downto kwdindex do
	for i:=kwdindex to nparams do
		if keyunits[i] then
			evalparam(keyunits[i], byreflist[i])
		elsif byreflist[i] then
			gerror("byref param not optional")
		else
			pgen(kpushvoid)
		fi
	od
end

proc do_if(unit p, a, b, pelse, int res)=
	int lab1, lab2

	lab1:=createfwdlabel()				!dest label of main condition (to end of if, or start if else)

	if pelse or res then lab2:=createfwdlabel() fi	!label past else part

	genjumpcond(kjumpf, a, lab1)

	evalunit(b, res)

	if pelse or res then
		genjumpl(lab2)
		definefwdlabel(lab1)
		if pelse then
			evalunit(pelse, res)
		else
			pgen(kpushvoid)
		fi
		definefwdlabel(lab2)
	else
		definefwdlabel(lab1)
	fi
end

proc do_do(unit p, a)=
	int lab_abc, lab_d, lab_test
	lab_abc:=definelabel()
	lab_d:=createfwdlabel()

	stacklooplabels(lab_abc, lab_abc, lab_d)

	evalunit(a, 0)

	genjumpl(lab_abc)
	definefwdlabel(lab_d)
	unstacklooplabels()
end

proc do_loop(unit p) =
	int n, index

	index:=p.a.value
	if index=0 then index:=loopindex fi

	n:=findlooplabel(p.loopcode, index)
	if n=0 then
CPL "BAD LOOP"
!		gerror("Bad exit/loop index", p)
	else
		genjumpl(n)
	fi
end

proc do_to(unit p, pcount, pbody)=
	int lab_b, lab_c, lab_d
	symbol temp
	unit pav

	pav:=pcount.nextunit
	temp:=pav.def

	evalunit(pcount)
	pgen_name(kzpopm, temp)

	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()
	stacklooplabels(lab_b, lab_c, lab_d)

!check for count being nonzero
	if pcount.tag<>jintconst then			!assume const limit is non-zero
		pgen_name(kpushm, temp)
		pgen_int(kpushci, 0)
		pgen_lab(kjumple, lab_d)

	elsif pcount.value<=0 then		!const <=0, skip body
		pgen_lab(kjump, lab_d)
	fi

	definefwdlabel(lab_b)
	evalunit(pbody, 0)
	definefwdlabel(lab_c)

	pgen_lab(ktom+temp.isframe, lab_b)
	pgen_name(kpushm, temp)

	definefwdlabel(lab_d)
	unstacklooplabels()
end

proc do_while(unit p, pcond, pbody) =
	int lab_b, lab_c, lab_d, lab_incr
	unit pincr:=pcond.nextunit

	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()

	if pincr then
		lab_incr:=createfwdlabel()
	else
		lab_incr:=lab_c
	fi

	stacklooplabels(lab_b, lab_c, lab_d)

	genjumpl(lab_incr)		!direct to condition code which is at the end

	definefwdlabel(lab_b)

	evalunit(pbody, 0)

	definefwdlabel(lab_c)

	if pincr then
		evalunit(pincr)
		definefwdlabel(lab_incr)
	fi

	genjumpcond(kjumpt, pcond, lab_b)
	definefwdlabel(lab_d)
	--loopindex
end

proc do_repeat(unit p, a, b) =
	int lab_b, lab_c, lab_d

	lab_b:=definelabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()

	stacklooplabels(lab_b, lab_c, lab_d)

	evalunit(a, 0)

	definefwdlabel(lab_c)

	unless b.tag=jintconst and b.value=0 then
		genjumpcond(kjumpf, b, lab_b)
	end

	definefwdlabel(lab_d)
	--loopindex
end

proc do_for(unit p, pvar, pbody)=
! a = pvar, pfrom, pto, [pstep]
! b = pbody [pelse]
	unit pfrom, pto, pstep, pelse, plimit, pautovar
	symbol dvar, limitvar
	int lab_b, lab_c, lab_d, lab_e, opc, oldqpos
	int step, fromval, limit, jumpinto

!CPL "FOR"
	pfrom:=pvar.nextunit
	pto:=pfrom.nextunit
	pstep:=pto.nextunit
	pautovar:=nil
	if pstep then
		gerror("By N not implem")
	fi

	pelse:=pbody.nextunit

	dvar:=pvar.def

	if pto.tag not in [jintconst, jname] or
		 pto.tag=jname and pto.def.isframe<>dvar.isframe then
		pautovar:=createavnamex(stcurrproc)
	fi

	if p.flag then
		step:=-1
	else
		step:=1
	fi

	jumpinto:=1			!assume jumping straight into increment

!now start generating code
	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()
	lab_e:=(pelse|createfwdlabel()|lab_d)
	stacklooplabels(lab_b, lab_c, lab_d)

	if pfrom.tag=jintconst then		!can incr/decr directly
		fromval:=pfrom.value
!see if limit is known
		if pto.tag=jintconst then
			limit:=pto.value
			if (step=-1 and fromval>=limit) or (step=1 and fromval<=limit) then 	!at least 1 iteration
				jumpinto:=0
			fi
		fi
		if jumpinto then
			if step<0 then
				++fromval
			else
				--fromval
			fi
			pfrom.value:=fromval
		fi
		pgen_int(kpushci, pfrom.value)

		pgen_name(kpopm, dvar)
	else
		evalunit(pfrom)
		pgen_name(kpopm, dvar)

		pgen_name(kincrtom, dvar)
		pccurr.x:=-step

	fi

	if pautovar then
		evalunit(pto)
		limitvar:=pautovar.def
		pgen_name(kzpopm, limitvar)
		pto:=pautovar
	else
		limitvar:=pto.def
	fi

	if jumpinto then
		genjumpl(lab_c)			!jump straight into incr/jump Kfor cmdcode at C:
	fi
	definefwdlabel(lab_b)

	evalunit(pbody, 0)				!do loop body

	definefwdlabel(lab_c)

	if step>0 then

		if pto.tag=jintconst then
			opc:=kformci+dvar.isframe
		elsif dvar.isframe=limitvar.isframe then
			opc:=kformm+dvar.isframe
		else
			gerror("for:mixed m/f vars")
		fi

		oldqpos:=qpos
		qpos:=p.pos
		pgen_lab(opc, lab_b)
		qpos:=oldqpos

		pgen_name(kpushm, dvar)

		if pto.tag=jintconst then
			pgen_int(kpushci, pto.value)
		else
			pgen_name(kpushm, limitvar)
		fi
	else
		pgen_name(kincrtom, dvar)
		pccurr.x:=-1
		pgen_name(kpushm, dvar)
		if pto.tag=jintconst then
			pgen_int(kpushci, pto.value)
		else
			pgen_name(kpushm, limitvar)
		fi
		pgen_lab(kjumpge, lab_b)
	fi

	if pelse then
		definefwdlabel(lab_e)
		evalunit(pelse, 0)			!any else part
	fi

	definefwdlabel(lab_d)
	unstacklooplabels()
end

proc do_forx(unit p, pvar, pbody)=
! a = pvar, pbounds
! b = pbody [pelse]
	unit pbounds, pelse, plimit, pautovar
	symbol dvar, limitvar
	int lab_b, lab_c, lab_d, lab_e, opc

CPL "FORX"

	pbounds:=pvar.nextunit

	pautovar:=createavnamex(stcurrproc)

	pelse:=pbody.nextunit
	dvar:=pvar.def

!now start generating code
	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()
	lab_e:=(pelse|createfwdlabel()|lab_d)
	stacklooplabels(lab_b, lab_c, lab_d)

	evalunit(pbounds)				!stack has lwb, upb
	limitvar:=pautovar.def
	pgen_name(kzpopm, limitvar)

	pgen_int(kpushci, 1)
	pgen(ksub)
	pgen_name(kpopm, dvar)		!from value

	genjumpl(lab_c)			!jump straight into incr/jump Kfor cmdcode at C:
	definefwdlabel(lab_b)

	evalunit(pbody, 0)				!do loop body

	definefwdlabel(lab_c)
	if dvar.isframe=limitvar.isframe then
		pgen_lab(kformm+dvar.isframe, lab_b)
	else
		gerror("forx:mixed m/f")
	fi
	pgen_name(kpushm, dvar)
	pgen_name(kpushm, limitvar)

	if pelse then
		definefwdlabel(lab_e)
		evalunit(pelse, 0)			!any else part
	fi

	definefwdlabel(lab_d)
	unstacklooplabels()
end

proc do_print(unit p, a, b)=
	int issprint
	unit x

	issprint:=p.flag iand pr_sprint

!global const pr_newline = 1
!global const pr_format = 2
!global const pr_sprint = 4


	if issprint then
		callhostfn(h_strstartprint)
	else
		if a then
			evalunit(a)
			callhostfn(h_startprint)
		else
			callhostfn(h_startprintcon)
		fi
	fi

	x:=b

	while x do
		case x.tag
		when u_fmtitem then
			evalunit(x.b)
			evalunit(x.a)
			callhostfn(h_print)
		when u_nogap then
			callhostfn(h_printnogap)
		when u_space then
			callhostfn(h_printspace)
		else
			evalunit(x)
			callhostfn(h_print_nf)
		esac
		x:=x.nextunit
	od

	if p.flag iand pr_newline then
		callhostfn(h_println)
	fi
	if issprint then
		pgen(kpushvoid)
		callhostfn(h_strendprint)
	else
		callhostfn(h_endprint)
	fi
end

proc do_fprint(unit p, a, b, c)=
	int issfprint
	unit x

	issfprint:=p.flag iand pr_sprint

	if issfprint then
		callhostfn(h_strstartprint)
	else
		if a then
			evalunit(a)
			callhostfn(h_startprint)
		else
			callhostfn(h_startprintcon)
		fi
	fi

	evalunit(b)					!format string
	callhostfn(h_setformat)

	x:=c
	while x do
		case x.tag
		when u_fmtitem then
			evalunit(x.b)
			evalunit(x.a)
			callhostfn(h_print)
		when u_nogap then
			callhostfn(h_printnogap)
		else
			pgen(kpushvoid)
			evalunit(x)
			callhostfn(h_print)
		esac
		x:=x.nextunit
	od

	if p.flag iand pr_newline then
		callhostfn(h_println)
	fi
	if issfprint then
		pgen(kpushvoid)
		callhostfn(h_strendprint)
	else
		callhostfn(h_endprint)
	fi

end

proc do_read(unit p, a, b)=
unit x, xloop

if p.flag iand pr_newline then
	if a then
		evalunit(a)
		callhostfn(h_readln)
	else
		pgen(kpushvoid)
		callhostfn(h_readln)
	fi
fi

xloop:=b
while xloop do
	x:=xloop
	pgen(kpushvoid)
	if x.tag=jfmtitem then
		evalunit(x.b)
		callhostfn(h_sread)
		x:=x.a
	else
		pgen(kpushvoid)
		callhostfn(h_sread)
	fi
	if x.tag=jname then
		pgen_name(kpopm, x.def)
	else
		evalref(x)
		pgen(kpopptr)
	fi
	xloop:=xloop.nextunit
od
end

proc do_forall(unit p, pindex, pbody)=
!I think form pvar/prange into blocks, then those can be stored together
! a = pindex, plist, pvar
! b = pbody, [pelse]

	int lab_b, lab_c, lab_d, lab_e
	unit ploopvar, plist, pelse, plimitvar, plistvar
	symbol indexvar, limitvar, loopvar, listvar

!CPL "FORALL"
	plist:=pindex.nextunit
	ploopvar:=plist.nextunit

	if ploopvar=nil then			!no discrete index var
		ploopvar:=pindex

		pindex:=createavnamex(stcurrproc)

	fi
	loopvar:=ploopvar.def

	plimitvar:=createavnamex(stcurrproc)

	limitvar:=plimitvar.def
	indexvar:=pindex.def

	if plist.tag<>jname or plist.def.isframe<>loopvar.isframe then			!complex list

		plistvar:=createavnamex(stcurrproc)

		listvar:=plistvar.def
		evalunit(plist)
		pgen_name(kzpopm, listvar)
	else
		plistvar:=plist
		listvar:=plistvar.def
	fi

	unless indexvar.isframe=loopvar.isframe=listvar.isframe then
		gerror("forall: mixed vars")
	end

	pelse:=pbody.nextunit

!set up initial loop var
	lab_b:=createfwdlabel()
	lab_c:=createfwdlabel()
	lab_d:=createfwdlabel()
	lab_e:=(pelse|createfwdlabel()|lab_d)
	stacklooplabels(lab_b, lab_c, lab_d)

!assume plist is a var where bounds are not known
!(can be optimised for a const range or a const list)
	pgen_name(kpushm, listvar)			!load the list
	pgen_n(kbounds, 2)				!extract bounds as (lower, upper); upper is tos

	pgen_name(kzpopm, limitvar)		!limit:=upb
	pgen_int(kpushci, 1)
	pgen(ksub)
	pgen_name(kzpopm, indexvar)		!index:=lwb-1 (will incr first thing)

	genjumpl(lab_c)			!jump straight into incr/jump Kfor cmdcode at C:

	definefwdlabel(lab_b)

!start of iteration, set up next loop variable
	pgen_name(kpushm, listvar)
	evalunit(pindex)

	pgen((p.tag=jforall|kindex|kdotix))
	pgen_name(kpopm, loopvar)

	evalunit(pbody, 0)			!do loop body

	definefwdlabel(lab_c)

	if indexvar.isframe=limitvar.isframe then
		pgen_lab(kformm+indexvar.isframe, lab_b)
	else
		gerror("forall:mixed m/f")
	fi
	pgen_name(kpushm, indexvar)
	pgen_name(kpushm, limitvar)

	if pelse then
		definefwdlabel(lab_e)
		evalunit(pelse, 0)			!any else part
	fi

	definefwdlabel(lab_d)
	unstacklooplabels()
end

proc do_case(unit p, pindex, pwhenthen, int res) =
!also temporarily deal wit switch/doswitch

	int lab_a, lab_d
	int loopsw, labnextwhen, labstmtstart, fmult
	unit w, wt, pelse

	if pindex.tag=jnone then
		do_case_nc(p, pindex, pwhenthen, res)
		return
	fi

	loopsw:=p.tag=jdocase or p.tag=jdoswitch
	pelse:=pindex.nextunit

	if loopsw then
		lab_a:=definelabel()
		lab_d:=createfwdlabel()
		stacklooplabels(lab_a, lab_a, lab_d)
	else
		lab_d:=createfwdlabel()
	fi

	evalunit(pindex)			!load test expr p to t

	wt:=pwhenthen
	while wt do
		w:=wt.a
		fmult:=w.nextunit<>nil

		labnextwhen:=createfwdlabel()

		if fmult then
			labstmtstart:=createfwdlabel()
		fi

		while w do
			evalunit(w)
			w:=w.nextunit
			if w then					!not last
				pgen_lab(kwheneq, labstmtstart)
			else
				pgen_lab(kwhenne, labnextwhen)
			fi
		od
		if fmult then
			definefwdlabel(labstmtstart)
		fi
		evalunit(wt.b, res)

		if not loopsw then
			genjumpl(lab_d)
		else
			genjumpl(lab_a)
		fi
		definefwdlabel(labnextwhen)
		wt:=wt.nextunit
	od

!at else part
	pgen_n(kunshare, 1)

	if pelse then
		evalunit(pelse, res)
	elsif res then
		pgen(kpushvoid)
	fi
	if loopsw then
		genjumpl(lab_a)
		definefwdlabel(lab_d)
		unstacklooplabels()
	else
		definefwdlabel(lab_d)
	fi
end

proc do_case_nc(unit p, pindex, pwhenthen, int res) =
!when no control expression

	int lab_a, lab_d
	int labnextwhen, labstmtstart, fmult
	unit w, wt, pelse

	if p.tag<>jcase then gerror("case-nc") fi

	pelse:=pindex.nextunit

	lab_d:=createfwdlabel()

	wt:=pwhenthen
	while wt do
		w:=wt.a
		fmult:=w.nextunit<>nil

		labnextwhen:=createfwdlabel()

		if fmult then
			labstmtstart:=createfwdlabel()
		fi

		while w do
			evalunit(w)
			w:=w.nextunit
			if w then					!not last
				pgen_lab(kjumpt, labstmtstart)
			else
				pgen_lab(kjumpf, labnextwhen)
			fi
		od
		if fmult then
			definefwdlabel(labstmtstart)
		fi
		evalunit(wt.b, res)

		genjumpl(lab_d)
		definefwdlabel(labnextwhen)
		wt:=wt.nextunit
	od

!at else part
	if pelse then
		evalunit(pelse, res)
	elsif res then
		gerror("Needs Else branch")
!		pgen(kpushvoid)
	fi

	definefwdlabel(lab_d)
end

proc do_try(unit p, a, b) =
	int labend, labx
	unit ptry, x, pexcept, pexcode

	++trylevel
	labend:=createfwdlabel()
	ptry:=a
	labx:=createfwdlabel()

	pexcept:=b

	if pexcept=nil then
		gerror("try: no except")
	elsif pexcept.nextunit then
		gerror("Try:multiple except block not implemented")
	fi

	while pexcept do
		pexcode:=pexcept.a
		if pexcode=nil or pexcode.nextunit then
			gerror("Try:multiple except codes not implemented")
		fi
		pgen_lab(kpushtry, labx)
		genxy(getconstvalue(pexcode), 1)

		evalunit(ptry, 0)
		genjumpl(labend)
		definefwdlabel(labx)
		evalunit(pexcept.b, 0)
		definefwdlabel(labend)
		pexcept:=pexcept.nextunit
	od

	pgen_n(kaddsp, 1)
	--trylevel
end

function unitstoarray(unit p, ref[]unit plist, int maxunits)int=
!convert a linked list of units to a linear list
!return number of units
	int n

	n:=0
	while p do
		if n>=maxunits then
			gerror("UTA Too many units")
		fi
		plist^[++n]:=p
		p:=p.nextunit
	od
	
	return n
end

proc do_select(unit pindex, pplist, int res)=
!generate selectx expression
	int n, labend, i, lab, elselab
	unit x, pelse

	[maxswitchrange]unit plist
	[maxswitchrange+1]pcl labels

	pelse:=pindex.nextunit

	n:=unitstoarray(pplist, &plist, maxswitchrange)

	if n>maxswitchrange then
		gerror("Selectx too complex")
	fi

	labend:=createfwdlabel()

	evalunit(pindex)
!	pgen_int2(kselect, n, 1)
	pgen_xy(kswitch, 1, n)

	for i:=1 to n do
		pgen_lab(kjumplab, 0)
		labels[i]:=pccurr
	od
	pgen_lab(kjumplab, 0)
	labels[n+1]:=pccurr

!scan when statements again, o/p statements
	i:=1
	for i:=1 to n do
		x:=plist[i]
		lab:=definelabel()

		labels[i].labelno:=lab
		evalunit(x, res)

		genjumpl(labend)	!break to end of statement
	od

	elselab:=definelabel()

	labels[n+1].labelno:=elselab

	if pelse then
		evalunit(pelse, res)
	elsif res then
		pgen(kpushvoid)
	fi

	pgen(knop)

	definefwdlabel(labend)
end

proc do_andl(unit x, y)=
	int a, b

	a:=createfwdlabel()
	b:=createfwdlabel()

	genjumpcond(kjumpf, x, a)
	genjumpcond(kjumpf, y, a)

	pgen_int(kpushci, 1)
	genjumpl(b)
	definefwdlabel(a)
	pgen_int(kpushci, 0)
	pgen(knop)
	definefwdlabel(b)
end

proc do_orl(unit x, y)=
	int a, b
	a:=createfwdlabel()
	b:=createfwdlabel()

	genjumpcond(kjumpt, x, a)
	genjumpcond(kjumpt, y, a)
	pgen_int(kpushci, 0)
	genjumpl(b)
	definefwdlabel(a)
	pgen_int(kpushci, 1)
	pgen(knop)
	definefwdlabel(b)
end

proc do_incr(unit p, a, int res)=
	symbol d
	int opc

	opc:=(p.tag=jincrload|kincrload|kloadincr)

	if res then
		do_unaryref(a, opc)

	elsif a.tag=jname then
		d:=a.def
		if d.nameid=paramid and d.mbyref then
			do_unaryref(a, kincrptr)
		else
			pgen_name(kincrtom, a.def)
		fi
	else
		do_unaryref(a, kincrptr)
	fi

	pccurr.x:=(p.flag|-1|1)
end

proc do_callhost(unit p, a, int res)=
	int index:=p.index
	int isfunc:=hostisfn[index]
	int nargs, nparams, fparams
	[10]unit plist
	unit q


	if res and not isfunc then
		gerror("Host proc not a function")
	fi

	if isfunc then
		pgen(kpushvoid)
	fi

	nargs:=0
	q:=a

	while q do
		if nargs>plist.upb then
			gerror("Too many host args")
		fi
		plist[++nargs]:=q

		q:=q.nextunit
	od

!	if index=h_allparams and a=nil then
!		nparams:=1
!	else
		nparams:=nargs
!	fi

	if nparams=0 and hostlvset[index] then
		gerror("LV hostfn: needs 1+ params")
	fi
	fparams:=hostnparams[index]
	if nparams>fparams then
		gerror("Hostfn too many params")
	fi

	to fparams-nparams do
		pgen(kpushvoid)
	od

!Finally, push all the params, which need to be done in reverse order
	for i:=nparams downto 1 do
		if i=1 and hostlvset[index] then
			evalref(plist[i])
!		elsif i=1 and index=h_allparams and nargs=0 then
!			pgen_name(kpushmref, stcurrproc)
		else
			evalunit(plist[i])
		fi
	od  

	callhostfn(index, res)
end

proc callhostfn(int fnindex, calledasfn=0)=
!assume caller has verified that fn is a function when calledasfn is true
!called should have pushed retval as needed, and <aparams> params

	pgen_int(kcallhost, fnindex)
end

proc genfree(int n)=
	pgen_n(kunshare, n)
end

proc do_return(unit p, a, int res)=
!CPL "RETURN", NAMENAMES[STCURRPROC.NAMEID], STRMODE(STCURRPROC.MODE), STCURRPROC.MISFUNC

!CPL "RETURN", =RES

	if a then
		if not stcurrproc.misfunc then gerror("Proc can't return a value") fi
		evalunit(a)
	else
		if stcurrproc.misfunc then gerror("Func needs return value") fi

!	elsif currfunction=2 then
!		gerror("function needs return value")
	fi

	if not res then
		genjumpl(retindex)
	fi
end

proc do_multassign(unit a, b, int deepcopy, res)=
	unit p, q
	[100]unit plist
	int n

	p:=a.a
	q:=b.a
	n:=0

	while p do
		if q=nil then gerror("Too few RHS elems") fi
		evalunit(q)
		if n>=plist.len then gerror("Too many elems") fi
		plist[++n]:=p

		p:=p.nextunit
		q:=q.nextunit
	od

	if q then gerror("Too few LHS elems") fi

	for i:=n downto 1 do
		if deepcopy then
			pgen(kcopy)
		fi

		do_store(plist[i])
	od
end

proc do_store(unit a, int res=0)=
!store stack value to a
	symbol d
	unit p
	[100]unit plist
	int n

	if res and a.tag<>jname then
		pgen(kdupl)
	fi

	case a.tag
	when u_name then
		d:=a.def
		if d.nameid=paramid and d.mbyref then
			if res then pgen(kdupl) fi
			pgen_name(kpushm, d)
			pgen(kpopptr)
		elsif res then
			pgen(kdupl)
			pgen_name(kpopm, d)
		elsif d.nameid in [procid, dllprocid] then
			gerror("Not lvalue")

!		elsif d.nameid=dllvarid then
!			pgen_name(kpopx, d)

		else
			pgen_name(kpopm, d)
		fi

	when u_dot then
		evalunit(a.a)
		if a.b.def.genfieldindex=0 then gerror(".m3?") fi
		pgen_name(kpopdot, a.b.def)

	when u_index then
		do_bin(a.a, a.b, kpopix)

	when u_dotindex then

		evalref(a.a)
		evalunit(a.b)
		pgen(kpopdotix)
	when u_ptr then
		evalunit(a.a)
		pgen(kpopptr)

	when u_keyindex then
		do_bin(a.a, a.b, kpopkeyix)

	when u_makelist then			!assign to multiple destinations
		n:=0
		p:=a.a
		while p do
			if n>=plist.len then gerror("Too many elems") fi
			plist[++n]:=p
			p:=p.nextunit
		od
		if n=0 then gerror("Empty lhs list") fi

		pgen_n(kexpand, n)
!		for i:=n downto 1 do
		for i:=1 to n do
			do_store(plist[i])
		od

	when u_if then
		evalref(a)
		pgen(kpopptr)

	else
		gerror_s("Can't store to this unit yet:", jtagnames[a.tag], a)
	esac
end

function getconstvalue(unit p)int =
	if p and p.tag=jintconst then
		return p.value
	fi
	gerror("gcv Not const")
	return 0
end

proc do_convert(unit pconv)=
!apply type-conversion t on expression p

!also do constructors
	int n, elemmode, i, lowerx, lbound, m, mbase, nfields
	[maxunits]unit plist
	unit p

	m:=pconv.mode
	p:=pconv.a
	mbase:=ttbasetype[m]

!p.length is no. of elements, but it not used here(unitstoarray will count
!anyway). But a value of -1 (rather than 1) means a trailing comma was used.

	if p.tag<>jmakelist  OR MBASE=TREFPACK then		!assume regular type conversion
			if p.tag=jmakelist then
				deleteunit(p, p.a)
			fi
			evalunit(p)
			pgen_int(kconvert, m)
			return
!		fi
	fi

!a is a usertype
	n:=unitstoarray(p.a, &plist, maxunits)

	if n and plist[1].tag=jkeyvalue then
		case mbase
		when trecord, tstruct then
			do_makerecordkv(m, n, plist)
		else
			gerror("key:value not allowed")
		esac
		return
	fi

	for i:=1 to n do		!any elements need to be pushed
		evalunit(plist[i])
	od

	case mbase
	when trecord, tstruct then
		nfields:=ttlength[m]
		if n then
			checkelems(n, nfields, p)
		else				!allow 0 fields; use defaults of 0
			to nfields do
				pgen_int(kpushci, 0)
			od
			n:=nfields
		fi
		pgen_xy((mbase=trecord|kmakevrec|kmaketrec), n)
		pccurr.usertag:=m

	when tlist then		!probably just a list prefix used
		lowerx:=p.lower
		pgen_xy(kmakelist, n, lowerx)

	when tarray then
		pgen_xy(kmakeax, n, p.lower)
		pccurr.usertag:=tarray
		pccurr.usertag2:=p.elemtype

!	when tvector then
	when tvector then
		elemmode:=tttarget[m]
		lowerx:=ttlower[m]

		checkelems(n, ttlength[m], p)
		pgen_xy(kmakeax, n, lowerx)
		pccurr.usertag:=m
		pccurr.usertag2:=elemmode

	when tbits then
		if m=tbits then			!not user-defined
			pgen_xy(kmakebits, n, p.lower)
			pccurr.usertag:=tbits
			pccurr.usertag2:=(p.elemtype=tvoid|tu1|p.elemtype)
		else
			gerror("user-define bit array not ready")
		fi

	when tset then
		pgen_xy(kmakeset, n)

	else
		gerror_s("Convert list", strmode(mbase))
	esac
end

!proc do_case(unit p, pindex, pwhenthen, int res) =
proc checkelems(int n, length, unit p)=
	if n<length then
		gerror("Too few elements")
	elsif n>length then
		gerror("Too many elements")
	fi
end

proc do_switch(unit p, pindex, pwhenthen, int res) =
	int minlab, maxlab, x, y, i, n
	unit w, wt, pelse

	pelse:=pindex.nextunit
!first a first scan over the when expressions; work out range and whether simple or complex
	minlab:=1000000
	maxlab:=-1000000			!highest index seen

	n:=0				!no. different values
	wt:=pwhenthen

	while wt do
		w:=wt.a
		while w do
			case w.tag
			when u_makerange then
				x:=getconstvalue(w.a)
				y:=getconstvalue(w.b)
dorange:
				for i:=x to y do
					minlab :=min(minlab, i)
					maxlab :=max(maxlab, i)
				od
			when u_intconst then
				x:=y:=w.value
				goto dorange
			when u_typeconst then
				x:=y:=w.mode
				goto dorange
			else
				gerror_s("Switch when2: not const", strexpr(w).strptr)
			esac
			w:=w.nextunit
		od
		wt:=wt.nextunit
	od

	if maxlab-minlab<=maxswitchrange then
		do_simpleswitch(p, pindex, pwhenthen, pelse, minlab, maxlab, res)
		return
	fi

	gerror("COMPLEX SWITCH/NOT COMPLETE")
end

proc do_simpleswitch(unit p, pindex, pwhenthen, pelse, int a, b, res) =
!a..b is the range of values of the switch which have been checked to
!be in range in terms of span. But the actual values can be anything.
!For example, 1000000 to 10000250 is valid. So, an offset needs to be
!used to bring the range down to 0 to 250

	unit w, wt, q
	int loopsw, n, offset, x, y, x0, i, labstmt, elselab
	[1..maxswitchrange+1]pcl labels
	int lab_a, lab_b, lab_c, lab_d

	loopsw:=p.tag=jdoswitch

	n:=b-a+1
	offset:=a-1		!a..b becomes 1..n

	if loopsw then
		lab_a:=definelabel()
		lab_d:=createfwdlabel()
		stacklooplabels(lab_a, lab_a, lab_d)
	else
		lab_d:=createfwdlabel()
	fi
	elselab:=createfwdlabel()

	evalunit(pindex)

	pgen_xy(kswitch, a, b)

	for i:=1 to n do
		pgen_lab(kjumplab, 0)
		labels[i]:=pccurr
	od

	pgen_lab(kjumplab, 0)			!else label
	labels[n+1]:=pccurr

!scan when statements again, o/p statements

	wt:=pwhenthen
	while wt do
		labstmt:=definelabel()
		w:=wt.a
		while w do
			case w.tag
			when u_makerange then
				x0:=getconstvalue(w.a)
				y:=getconstvalue(w.b)

			when u_intconst then
				x0:=y:=w.value
			when u_typeconst then
				x0:=y:=w.mode
			esac

			for x:=x0 to y do
				i:=x-offset
				if labels[i].labelno then			!should have been zero
					println x, char(x)
					gerror("Dupl switch value")
				fi
				labels[i].labelno:=labstmt
			od
			w:=w.nextunit
		od

		evalunit(wt.b, res)

		if not loopsw then
			genjumpl(lab_d)
		else
			genjumpl(lab_a)
		fi
		wt:=wt.nextunit
	od

!fill in zero entries with else
	definefwdlabel(elselab)
	if pelse then		!do else part
		evalunit(pelse, res)
	fi	

	if loopsw then
		genjumpl(lab_a)
		definefwdlabel(lab_d)
		unstacklooplabels()
	else
		definefwdlabel(lab_d)
	fi

	for i:=1 to n do
		if labels[i].labelno=0 then
			labels[i].labelno:=elselab
		fi
	od
	labels[n+1].labelno:=elselab
end

proc do_makerecordkv(int m, nkeyvals, []unit &kvlist)=
	unit p
	[maxunits]unit plist
	int nfields, index
	symbol d:=ttnamedef[m], e, f, k

	e:=d.deflist
	nfields:=0

	while e, e:=e.nextdef do
		if e.nameid in [fieldid, structfieldid] and e.atfield=nil then
			++nfields
			plist[nfields]:=nil
		fi
	od

	for i to nkeyvals do
		k:=kvlist[i].a.def
		p:=kvlist[i].b

		e:=d.deflist
		f:=nil
		while e, e:=e.nextdef do
			if e.nameid in [fieldid, structfieldid] and e.firstdupl=k then
				f:=e
				exit
			fi
		od

		if not f then
			gerror_s("Can't find field:", k.name)
		fi
		index:=f.index
		if plist[index] then
			gerror_s("Dupl key:", k.name)
		fi
		plist[index]:=p
	od

	for i to nfields do
		if plist[i] then
			evalunit(plist[i])
		else
			pgen_int(kpushci, 0)
		fi
	od

	pgen_xy(kmakevrec, nfields)
	pccurr.usertag:=m
end

proc do_idiv(unit a, b)=
	int n

	evalunit(a)
	if b.tag=jintconst and (n:=ispoweroftwo(b.value)) then
		pgen_int(kpushci, n)
		pgen(kshr)
	else
		evalunit(b)
		pgen(kidiv)
	fi
end

proc do_irem(unit a, b)=
	int n
	word m

	evalunit(a)
	if b.tag=jintconst and (n:=ispoweroftwo(b.value)) then
		m:=inot(0xFFFF'FFFF'FFFF'FFFF << n)
		pgen_int(kpushci, M)
		pgen(kiand)
	else
		evalunit(b)
		pgen(kirem)
	fi
end

proc do_map(unit p, popcode, x)=
	evalunit(x)
	if x.nextunit then
		evalunit(x.nextunit)
	fi
	evalunit(popcode)
	pgen(kmap)

	int lab:=createfwdlabel()
	pgen_lab(kjump, lab)		!dummy jump to be moved to runtime-generated code
	pgen(knop)					!stop jump being optimised out
	definefwdlabel(lab)
end

proc pushstring(ichar s)=
	pgen(kpushcs)
	genopnd_strz(s)
end

function checkblockreturn(unit p)int=
!p should be a block unit
!check that the last statement is a return; return 1/0 for return/not return
!just allow or check for return/if/longif for now
	ref unitrec q, r

	if p=nil then return 0 fi
!	if p.tag<>jblock then gerror("CBR?") fi
!
!	q:=p.a
!	if q=nil then return 0 fi		!empty block

!	while r:=q.nextunit do			!get q=last stmt in block
!		q:=r
!	od

	case uisexpr[p.tag]
	when 0 then return 0
	when 1 then return 1				!assume simple value
	esac								!else 2

!assume complex unit

	case p.tag
	when u_block then
		q:=p.a
		if q=nil then return 0 fi		!empty block
		while r:=q.nextunit do			!get q=last stmt in block
			q:=r
		od
		return checkblockreturn(q)

!	when u_return then			!that's an easy one...
!		return 1

	when u_if then
		return checkblockreturn(p.b) and checkblockreturn(p.b.nextunit)		!all branches must have a return

	else								!assume yes
		return 1


	esac
	return 0
end

