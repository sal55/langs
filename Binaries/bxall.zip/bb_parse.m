byte inreadprint
byte inparamlist
byte intabledata
byte insiderecord=0
byte insidedllimport=0
byte inwhileheader=0
byte indatainit=0
global byte dmode
int nextlambdaindex

const maxdollarstack=10
[maxdollarstack]unit dollarstack		!used for a[$]
int ndollar=0

symbol dretvar			!part of read-proc: nil, or symptr of retval variable

global const maxprocstack=10
global [maxprocstack]symbol procstack
global int nprocstack=0

const maxforloops=10
[maxforloops]symbol forindexvars
int nforloops
ichar tabledataname=nil

global proc parsemodules(isubprog sp)=
	return when passlevel<parse_pass

	for i in sp.firstmodule..sp.lastmodule do
		parsemodule(modules[i])
	end

	if fshowast1 then
		showast("AST1")
	end
end

proc parsemodule(imodule pm)=
	symbol owner
	unit p
	int m

	initparser(pm)

	owner:=stmodule:=pm.stmodule

	stcurrproc:=owner
	currmoduleno:=pm.moduleno

!	CPL "PARSE", STMODULE.NAME, =QMODE

	startlex(pm.file)
	lex()

	lex()

!INT TT:=CLOCK()

	skipsemi()
	readblock(stcurrproc)
	checktoken(tk_eof)

!CPL "PARSE TIME", CLOCK()-TT

end

func readblock(symbol owner)unit =
!read sequence of definitions, mixed with units when owner is a function
!owner will be:
! module: proc/func/import/type/const/table/record/macro/var/hdr
! record: proc/func/type/const/table/record/macro/var
! func:   proc/func/type/const/record/macro/var/unit
!hdr stuff will be skipped (pre-parsed separately)
	byte isrecord := owner.nameid=typeid
	byte ismodule := owner.nameid=moduleid
	byte isfunc   := owner.nameid=dprocid or owner.nameid=dprocid
	byte scope, isstatic
	byte defid, varid
	int ngroups

	unit ulist:=nil, ulistx:=nil, p, r
	symbol stname

	if ismodule then
		defid:=staticid
	elsif isrecord then
		defid:=(dmode|fieldid|structfieldid)
	else
		defid:=frameid
	end
	ngroups:=0

	do
		skipsemi()
		scope:=module_scope
		isstatic:=0
		varid:=defid

restart:
!PS("BLOCK")
		case lx.token

		when tk_name then
!PS2("NAME")
			case nextlx.token
			when tk_colon then
				serror("Label?") when not isfunc
				p:=createunit(u_labeldef)
				stname:=getduplst(stcurrproc, lx.symptr, labelid)
				adddef(stcurrproc, stname)
				p.def:=stname
				lex()
				lx.token:=tk_semi
				addlistunit(ulist, ulistx, p)
			when tk_name then				!decl
				goto domvar

			else
				goto doexpr
			end case

		when tk_global then				!allowed for most items in module; exceptions will check it
			if scope or not ismodule then
!CPL =SCOPENAMES[SCOPE], =ISMODULE, =ISFUNC
				serror("global?")
			end
			scope:=lx.subcode

			if scope=export_scope and stmodule.subprogno<>nsubprogs then
				scope:=program_scope
			end

			lex()
!check that an allowed def keyword follows
			restart

		when tk_static then
			if scope or not isfunc then serror("static?") end
			varid:=staticid		
			isstatic:=1
			lex()
			if lx.token not in [tk_var, tk_stdtype, tk_ref, tk_name, tk_lsq] then
				serror("static2?")
			end
			restart

		when tk_var then
			contexterror() when not dmode
			p:=readvardef(owner, varid,  scope)
			storeinit

		when tk_stdtype, tk_ref, TK_STRINGZ then
domvar:
!			if nextlx.token=tk_lbrack then
			if nextlx.token in [tk_lbrack, tk_at] then
				doexpr
			end
			contexterror() when dmode

			p:=readvardef(owner, varid,  scope)
storeinit:
			while p do					!entries only exists for assignments to locals
				r:=p.nextunit			!isolate head unit
				p.nextunit:=nil
				addlistunit(ulist, ulistx, p)
				p:=r
			end
	
		when tk_lsq then
			if not dmode then
				domvar
			end
			doexpr
		when tk_ptr then
			if dmode then
				doexpr
			else
				domvar
			end
		when tk_importmodule then
			readimportmodule(owner)

		when tk_func then
			readprocdef(owner, scope)

		when tk_type then
			readtypedef(owner, scope)
		when tk_const then
			readconstdef(owner, scope)

		when tk_record then
			readrecorddef(owner, scope)

		when tk_tabledata then
			readtabledef(owner, scope)

		when tk_then, tk_elsif, tk_else, tk_when, tk_until, tk_eof,
			 tk_comma, tk_bar, tk_rbrack, tk_semi, tk_rcurly,
			 tk_elseswitch, tk_elsecase, tk_except then
			exit

		when tk_end then
			if ngroups then
				--ngroups
				lex()
				if lx.token=tk_union then lex() fi
				addstructflag(owner, endblockid)
			else
				exit
			end

		when tk_do then
			exit when inwhileheader			!terminates s in 'while s do'
			doexpr

		when tk_macro then
			readmacrodef(owner, scope)

		when tk_union then
			varid:=lx.subcode				!structid/unionid
			++ngroups
			lex()
			addstructflag(owner, varid)

		when tk_project then
			repeat
				lex()
			until lx.token in [tk_end, tk_eof]
			checkend(tk_end, tk_project)

		when tk_header then
			repeat
				lex()
			until lx.token=tk_semi

		when tk_error then				!dummy: place-holder for error reporting
error:
			serror_s("Readblock not ready: ", tokennames[lx.token])

		else
doexpr:
!CPL =NAMENAMES[VARID]
!CPL =SCOPENAMES[SCOPE]

			if scope<>module_scope or isstatic then serror("scope?") fi
			if not isfunc and not indatainit then serror("Expr outside function") end
			p:=readunit()
			addlistunit(ulist, ulistx, p)		!add one by-one
		end
	end

	if isfunc or indatainit then			!return single node only
		if ulist=nil or ulist.nextunit then
			createunit(u_block, ulist)		!() or (a,b,...) => single block
		else
			ulist							!a only (single node)
		end
	else
		return nil
	end
end

global func readunit:unit p=
	unit pt
	int pos

	pos:=lx.pos
	p:=readfactor(maxprio)

	return p
end

func readfactor(int prio)unit =
	unit p, q
	int symprio, tag, ltr, pclop, pos, binop

	p:=readterm2()

	while lx.token=tk_binop do			!binary op
		pos:=lx.pos
		binop:=lx.subcode				!bin_add etc
		symprio:=binprio[binop]
		if prio<=symprio then
			exit
		end

		tag:=bintag[binop]
		lex()										!1st symbol of term, or :=

		if lx.token=tk_binop and lx.subcode=bin_assign then
			if not binassign[binop] or binrtl[binop] then
				serror("op:= not allowed")
			end
			tag:=u_binto
			symprio:=maxprio
			lex()
		end

		if not binrtl[binop] then
			q:=readfactor(symprio)

			if tag=u_cmp then
				if p.tag=u_cmp then				!second in cmp chain
					p.b.nextunit:=q
					p.a.nextunit:=p.b
					p.b:=nil
					p.cmpgenop[1]:=p.binop
					p.cmpgenop[2]:=binop
					p.tag:=u_cmpchain

				elsif p.tag=u_cmpchain then		!3rd/4th in chain
!allow only 3 cmp ops with 4 terms
					if p.cmpgenop[3] then serror("cmp chain>4 terms") end
					p.a.nextunit.nextunit.nextunit:=q
					p.cmpgenop[3]:=binop
				else							!first in cmp chain, or only
					p:=createunit(u_cmp, p, q)
				end
			else
				p:=createunit(tag, p, q)
			end

		else
			q:=readfactor(maxprio)
			p:=createunit(tag, p, q)
		end
		p.binop:=binop

		p.pos:=pos
	end

	return p
end

func readterm2:unit=
	unit p, q
	int opc, oldinrp, pos

	pos:=lx.pos
	p:=readterm()

	docase lx.token
	when tk_lbrack then
		lex()
		oldinrp:=inreadprint
		inreadprint:=0
		q:=readslist(1, 1)
		checktokenlex(tk_rbrack)
!		lex()
		if p.tag=u_syscall then
			p.a:=q
		else
			p:=createunit(u_call, p, q)
		end
		inreadprint:=oldinrp
		p:=readcondsuffix(p)

	when tk_ptr then
		p:=createunit(u_ptr, p)
		lex()

	when tk_lsq then
		p:=readindex(p, 0)

	when tk_dot then
		p:=readdotsuffix(p)

	when tk_colon then
		if inreadprint then exit end
		lex()
		q:=readunit()

		if inparamlist then
			p:=createunit(u_keyword, p, q)
		else
			serror("A:B?")
		end

	when tk_incr then
		p:=createunit(u_incr, p)
		p.isdecr:=lx.subcode
		lex()

	when tk_lcurly then
		lex()
		q:=readunit()

		if lx.token=tk_comma then
			lex()
			q.nextunit:=readunit()
		fi

		p:=createunit(u_keyindex, p, q)
		checktokenlex(tk_rcurly)

	else
		exit
	end docase

	p.pos:=pos

	return p
end

func readterm:unit=
	unit p, q, r
	u64 a
	int opc, pos, length
	byte strtype
	ichar s
	[32]u64 cstr

	pos:=lx.pos

	switch lx.token
	when tk_name then
		if nextlx.token=tk_at then		!type-punning with user type
			p:=readcast()
		else
			p:=createname(lx.symptr)
			p.pos:=lx.pos
			lex()
		end

	when tk_intconst then
		p:=createintconstunit(lx.value, lx.subcode)
		lex()

	when tk_realconst then
		p:=createrealconstunit(lx.xvalue, lx.subcode)
		lex()

	when tk_stringconst then
		p:=createstringconstunit(lx.svalue, lx.slength)
		p.strtype:=lx.subcode			!0/1/2 = str/bindata/strdata
		lex()

	when tk_charconst then
		length:=lx.slength-1
		if length>8 then serror("Char const too long") end
		a:=0
		if length then
			memcpy(&a, lx.svalue, length)
		end
		p:=createintconstunit(a, ti64)
		lex()

	when tk_lbrack then
		p:=readlbrack()

	when tk_stdtype, tk_ref then
		p:=readcast()

	when tk_unary, tk_binop, tk_maths then
		p:=readopc()

	when tk_lsq then
		p:=readset()

	when tk_incr then
		opc:=lx.subcode
		lex()
		p:=createunit(u_incr, readterm2())
		p.isdecr:=opc

	when tk_addr, tk_ptr then			!& ^
		opc:=lx.token=tk_ptr
		lex()
		p:=createunit(u_addrof, readterm2())
		p.addrof:=opc					!distinguish between &/^ using 0/1
		if p.a.tag=u_call then			!applied to function F or F()
			if p.a.b then
				serror("Params not allowed")
			end
			p.a:=p.a.a			!lose the call
		end

	when tk_compilervar then
		p:=readcompilervar()

	when tk_dollar then
		if nextlx.token=tk_lbrack then
			p:=readdollarexpr()

		elsif intabledata then
			if lx.subcode=1 then			!need char type
				cstr[1]:=0
				strcpy(cast(&cstr), tabledataname)
				p:=createintconstunit(cstr[1], ti64)
			else
				s:=tabledataname
				if nextlx.token=tk_binop and nextlx.subcode=bin_add then
					lex()
					lex()
					checktoken(tk_intconst)
					s+:=lx.value
				end
				p:=createstringconstunit(s, -1)
			end
		else
			if ndollar<=0 then
				serror("[$] No array")
			end
			p:=createunit(u_prop, dollarstack[ndollar])
			p.propop:=prop_upb
		end
		lex()

	when tk_cast then
		p:=readcastx()

	when tk_goto then
		lex()
		return readcondsuffix(createunit(u_goto, readunit()))

	when tk_if then
		p:=readif()

	when tk_unless then
		p:=readunless()

	when tk_case, tk_docase, tk_switch, tk_doswitch then
		p:=readswitchcase()

	when tk_recase then
		p:=readrecase()

	when tk_for then
		p:=readfor()

	when tk_to then
		p:=readto()

	when tk_do then
		p:=readdo()

	when tk_while then
		p:=readwhile()

	when tk_repeat then
		p:=readrepeat()

	when tk_loop then
		p:=readloopcontrol()

	when tk_return then
		p:=readreturn()

	when tk_stop then
		p:=readstop()
!
	when tk_print then
		p:=readprint()

	when tk_read then
		p:=readread()

	when tk_swap then			!swap using func syntax
		lex()
		p:=readtuple(u_swap)
!
	when tk_eval then
		lex()
		p:=createunit(u_eval, readunit())

	when tk_syscall then
		p:=createunit(u_syscall)
		p.fnindex:=lx.subcode
		lex()

	when tk_strinclude then
		strtype:=lx.subcode
		lex()
		p:=createunit(u_strinclude, readterm2())
		p.strtype:=strtype

	when tk_clear then
		lex()
		p:=createunit(u_clear, readterm2())

	when tk_try then
		p:=readtry()

	when tk_raise then
		lex()
		p:=createunit(u_raise, readunit())

	when tk_map then
		lex()
		p:=readtuple(u_map, 3)

	when tk_lcurly then
		contexterror() when not dmode
		p:=readlambda()

	when tk_hostfn then
		opc:=lx.subcode
		lex()
		checktokenlex(tk_lbrack)
		p:=readslist(1, 1)
		checktokenlex(tk_rbrack)
		p:=createunit(u_callhost, p)
		p.hostfn:=opc
		p:=readcondsuffix(p)

!	when tk_prop then
!SERROR("PROP")
!		

	else
DOELSE:
		cpl tokennames[lx.token]
		serror_s("readterm: ", tokennames[lx.token])
	end switch

	p.pos:=pos
	return p
end

global func readtypespec(symbol owner, int typedefx=0)int=
!at initial symbol of a type, or where type is expected
!read simple type (which will have a single name) or a more elaborate type-spec
!returns a moderec handle
!typedefx is not a def, but either:
! moderec	Used when called from readtypedef. This is then filled in with the
!		details of the new mode, and the new version is returned
! nil		Called from outside readtypedef; then just returns a new moderec

!If the first symbol is not a stdtype, then it is assumed to be a usertype
!For stdtypes, I might implement :N and *N width-specifiers, as an alternative to just
!using i16 etc
	symbol d, e
	int t, kwd, sltype, w
	unit x, pupper, plx
	unit dim, length
	const maxdim=30
	[maxdim]unit dims
	int ndims, i, n, k

	case lx.token
	when tk_lsq then		!array bounds
arraybounds:
		lex()

		ndims:=0
		inreadprint:=1
		do
			length:=nil				!both bounds unspecified
			if lx.token=tk_rsq or lx.token=tk_comma then		![]
				dim:=nil
			else
				dim:=readunit()
				case lx.token
				when tk_rsq, tk_comma then			![n]
				when tk_colon then				!a:n
					lex()
					if not (lx.token=tk_comma or lx.token=tk_rsq) then	!lower:length
						length:=readunit()
						dim:=createunit(u_dim, dim, length)
					else													!lower:
						dim:=createunit(u_dim, dim)
					end
				end case
			end
			if ndims>=maxdim then serror("Too many array dims") end
			dim.pos:=lx.pos
			dims[++ndims]:=dim
			exit when lx.token<>tk_comma
			lex()
		end
		inreadprint:=0
		checktokenlex(tk_rsq)
!		lex()
		t:=readtypespec(owner)

		for i:=ndims downto 1 do
			t:=createarraymode(owner, t, dims[i], (i=1|typedefx|0))
		end
		return t

	when tk_stdtype then
		t:=lx.subcode
		lex()

	when tk_name then
		d:=lx.symptr
		lex()

		t:=newtypename(d)

	when tk_record then
		serror("Use 'record name =' syntax")

	when tk_union then
		serror("Not allowed here")

	when tk_ref, tk_ptr then		!^T
	retry:

		lex()
		if lx.token=tk_to then lex() end

		case lx.token
		when tk_func then	!func pointer being created
			lex()
			t:=tproc

		when tk_void then
			lex()
			t:=tvoid
			gottarget
		else						!assume normal type
readtarget:
			t:=readtypespec(owner)
gottarget:
			t:=createrefmode(owner, t, typedefx)
		end case

	when tk_stringz then
		lex()
		if lx.token=tk_binop and lx.subcode=bin_mul then
			lexchecktoken(tk_intconst)
			n:=lx.value
			t:=createarraymodek(owner, tu8, 1, n, 0)
			lex()
		else
			t:=trefchar
		end
		return t

	when tk_var then				!might be part ref var/[]var
		lex()
		t:=tvar

	else
		serror("Bad type starter")
	end case

	if typedefx then			!assume a simple alias
		ttbasetype[typedefx]:=ttbasetype[t]
	end

	return t
end

func readindex(unit p, int dot)unit=
!at '['; dot=0/1 for a[]/a.[]
!syntax is:
![x] or [x, ...]			!single or multiple indexing (can also use [x][x].. for multiple)
!I don't need to allow indexing and section select within the same [...]
!exit with symbol just after closing ]
	unit q, plower, pupper

	lex()

	if not dot then
		case lx.token
		when tk_rsq then
	fullslice:
			lex()
			plower:=createunit(u_prop, duplunit(p))
			plower.propop:=prop_lwb
			pupper:=createunit(u_prop, duplunit(p))
			pupper.propop:=prop_upb
			p:=createunit(u_slice, p, createunit(u_makerange, plower, pupper))
			return p
		when tk_colon then
			lexchecktoken(tk_rsq)
			goto fullslice
		elsif lx.token=tk_binop and lx.subcode=bin_range then
			recase tk_colon

		end case
	end

	do
		if ndollar>=maxdollarstack then
			serror("Too many nested a[$]")
		end
		dollarstack[++ndollar]:=p
		q:=readunit()
		--ndollar

		if q.tag=u_makerange then		!convert into a discrete slice
			p:=createunit((dot|u_dotslice|u_slice), p, q)
		else
			p:=createunit((dot|u_dotindex|u_index), p, q)
		end

		exit when lx.token<>tk_comma
		lex()
	end
	checktokenlex(tk_rsq)
	return p
end

func readdotsuffix(unit p)unit=
!at '.' symbol
!read any modifiers for term currently in p
!multiple .terms can be present
	unit q, r, p2

	while lx.token=tk_dot do
		lex()
		case lx.token
		when tk_lsq then
			p:=readindex(p, 1)
		when tk_name then
			p:=createunit(u_dot, p, createname(lx.symptr))
			lex()
		when tk_prop then
			if lx.subcode=prop_bounds then
				q:=createunit(u_prop, duplunit(p))
				r:=createunit(u_prop, duplunit(p))
				if p.tag=u_typeconst then
					q.propop:=prop_minval
					r.propop:=prop_maxval
				else
					q.propop:=prop_lwb
					r.propop:=prop_upb
				end

				p2:=createunit(u_makerange, q, r)
				deleteunit(p, p2)
			else
	doprop:
				p:=createunit(u_prop, p)
				p.propop:=lx.subcode
			end
			lex()

		when tk_bitfield then
			p:=createunit(u_bitfield, p)
			p.bfcode:=lx.subcode
			lex()
		when tk_type then			!.type, convert to .gettype
			case p.tag
			when u_typeconst then			!int.type=>int
			else
				p:=createunit(u_prop, p)
				p.propop:=prop_type

			end case
			lex()

		when tk_binop then
			case lx.subcode
			when bin_max then
				lx.subcode:=prop_maxval
				goto doprop
			when bin_min then
				lx.subcode:=prop_minval
				goto doprop
			end

		when tk_stdtype then
			if p.tag=u_typeconst and lx.subcode=trange then
				q:=createunit(u_makerange, 
					createunit(u_unary, p), 
					createunit(u_unary, p))
				q.a.propop:=prop_minval
				q.b.propop:=prop_maxval
			else
				error
			end
			lex()
			p:=q
		when tk_dollar then
			if p.tag not in [u_name, u_dot] then
				serror("...name.$ needed")
			fi
			p:=createunit(u_symbol, p)
			lex()

		else
	error:
			serror("Unknown dot suffix")
		end case
	end
	return p
end

func readslist(int iscall=0, donulls)unit=
!read comma-separated list of expressions
!positioned at first symbol of first expression
! it might be | or )
!
!donulls=1 means empty expressions are allowed (u_ust comma or terminator, which
!result in null units
!return with symbol at terminating symbol: 1st non comma and is that a unit starter
!iscall=1 when called to read a func-call parameter list; then key:value pairs
!are treated as keyword arguments
!eg: (a, b, c	)
!eg: (a		!
	unit ulist, ulistx
	int oldinparamlist

	ulist:=ulistx:=nil

	skipsemi()
	if lx.token=tk_rbrack then		!empty list
		return ulist
	end

	oldinparamlist:=inparamlist
	inparamlist:=iscall

	do
		skipsemi()
		case lx.token
		when tk_comma then
			if donulls then
				addlistunit(ulist, ulistx, createunit(u_null))
			else
				serror("null comma expr not allowed")
			end
			lex()
		when tk_rbrack then
			if donulls then
				addlistunit(ulist, ulistx, nullunit)
			end
			exit
		else
			addlistunit(ulist, ulistx, readunit())
			if lx.token in [tk_comma, tk_semi] then
				lex()
				if lx.token=tk_rbrack then
					exit
				end
			else
				skipsemi()
				if lx.token=tk_rbrack then
					exit
				end
				serror("SLIST?")
			end
		end case
	end
	inparamlist:=oldinparamlist

	return ulist
end

func readcondsuffix(unit p)unit=
!p is a unit just read
!positioned at following symbol
!check whether a conditional suffix follows, and return p wrapped in a conditional if so
! ... if cond
! ... when cond
! ... unless cond
	unit q

	case lx.token
	when tk_when then
		lex()
		return createunit(u_if, fixcond(readunit()), createunit(u_block, p))
	when tk_unless then
		lex()
		q:=createunit(u_notl, fixcond(readunit()))
		return createunit(u_if, q, createunit(u_block, p))
	else
		return p
	end case
end

func readcast:unit=
!Input is (T is stdtype or REF, X is a name that might be a usertype):
! T(	positioned at (
! T@(	at @
! X@(	at @
!Won't be X(, as that is parsed as a function call, and adjusted later

	unit p
	int opc, t

	t:=readtypespec(stcurrproc)

	case lx.token
	when tk_lbrack then			!T(
		opc:=u_convert

	when tk_at then				
		opc:=u_typepun
		lexchecktoken(tk_lbrack)

	else
		p:=createunit(u_typeconst)
		p.mode:=t
		return p
	end case

!at (
	lex()
	p:=readunit()
	checktokenlex(tk_rbrack)

	p:=createunit(opc, p)
	storemode(stcurrproc, t, p.mode2)
	return p
end

func readcastx:unit p=
!explicit cast using syntax:
! cast(expr)
! cast(expr, type)
! cast@(expr, type)
!at 'cast'
	int opc, m

	lex()
	opc:=u_convert
	if lx.token=tk_at then
		opc:=u_typepun
		lex()
	end
	checktokenlex(tk_lbrack)
	m:=tvoid
	p:=readunit()
	if lx.token<>tk_comma then
		if opc=u_typepun then serror("@ type missing") end
		opc:=u_autocast
	else
		lex()
		m:=readtypespec(stcurrproc)
	end
	checktokenlex(tk_rbrack)
!	lex()

	p:=createunit(opc, p)
	storemode(stcurrproc, m, p.mode2)

	return p
end

func readopc:unit p =
!unary/bin/maths seen just before a term
	unit q, r
	int tag, opc, mathsop, token

	token:=lx.token
	opc:=lx.subcode
	tag:=u_unary

	if token=tk_unary then				!logical have dedicated tags
		case opc
		when unary_notl then tag:=u_notl
		when unary_istruel then tag:=u_istruel
		end
	end

	lex()

	case token
	when tk_unary then
dounary:
		if lx.token=tk_binop and lx.subcode=bin_assign then
			tag:=u_unaryto
			lex()
		end

		p:=readterm2()

	when tk_binop then
		case opc
		when bin_add then
			return readterm2()

		when bin_sub then
			opc:=unary_neg
			dounary

		when bin_min, bin_max then
			tag:=u_bin
			if lx.token=tk_binop and lx.subcode=bin_assign then
				lex()
				tag:=u_binto
			end
			p:=readtuple(tag)
			p.binop:=opc
			return p

		else
			serror("Binop not allowed")
		end

	when tk_maths then
		if mathsargs[opc]=1 then
			p:=readterm2()
			tag:=u_maths
		else
			p:=readtuple(u_maths2)
			p.mathsop:=opc
			return p
		end
	else
		serror("Readopc")
	end

!unary or maths at this point
	p:=createunit(tag, p)
	p.unaryop:=opc	

	return p
end

func readset:unit p =
!positioned at "["
	int length, nkeyvalues, oldinparamlist
	unit ulist, ulistx

	lex()					!first symbol of first expression

	case lx.token
	when tk_rsq then						!empty set
		lex()
		return createunit(u_makeset, nil)
	when tk_colon then						![:] empty dict
		lexchecktoken(tk_rsq)
		lex()
		return createunit(u_makedict, nil)
	esac

	oldinparamlist:=inparamlist
	inparamlist:=1

	p:=readunit()
	length:=1
	nkeyvalues:=0
	if p.tag=u_keyword then ++nkeyvalues fi

	ulist:=ulistx:=p

	while lx.token=tk_comma do
		lex()
		if lx.token=tk_rsq then exit fi		!allow trailing comma
		addlistunit(ulist, ulistx, p:=readunit())
		if p.tag=u_keyword then ++nkeyvalues fi

		++length
		skipsemi()						!allow a, b, c;]
	od

	checktokenlex(tk_rsq)

	if nkeyvalues then
		if length>nkeyvalues then serror("dict: mixed elements") fi
		p:=createunit(u_makedict, ulist)
	else
		p:=createunit(u_makeset, ulist)
	fi

	p.length:=length
	inparamlist:=oldinparamlist
	return p
end

func readlbrack:unit=
!positioned at "("
!tk_term is rbracksym
!read one of the following:
! ()				list with no elements
! (x)				simple expression
! (x,)				list with one element
! (x, x, ...)		list
! (x|x|x])			if then else end
! (x|x, ... |x])	select then else end

!return positioned at symbol following closing ")"
!listtag is jmakelist or jmakearray if 'array' was used

	unit ulist, ulistx, p, q, r, plower
	int oldirp, length, usecomma

	lex()					!first symbol of first expression
	ulist:=ulistx:=nil
	plower:=nil
	length:=0

	if lx.token=tk_at then			!lwb override
		lex()
		oldirp:=inreadprint
		inreadprint:=1
		plower:=readunit()

		inreadprint:=oldirp
		checktokenlex(tk_colon)
!		lex()

	elsif lx.token=tk_intconst and nextlx.token=tk_colon then
		plower:=createintconstunit(lx.value, lx.subcode)
!		plower.istrueconst:=1
		lex()
		lex()

!	elsif lx.token in [tk_binop, tk_binopset[lx.token] and nextlx.token=tk_rbrack then	!operator constant
!!	elsif symboloptypes[lx.token]=bin_op and nextlx.token=tk_rbrack then	!operator constant
!		p:=createunit(u_operator)
!		p.pclop:=symbolgenops[lx.token]
!		lex()
!		lex()
!		return p
	end

!check symbol after "("
	case lx.token
	when tk_rbrack then			!empty list
		lex()
		p:=createunit(u_makelist)
		p.b:=plower
		p.length:=0
		return p
	else					!assume normal expression follows
		p:=readunit()
	end case

!check symbol after "(expr"
	case lx.token
	when tk_rbrack then			!simple (x) expression
		lex()

		return p

	when tk_comma then			!separate by comma or implicit newline
		usecomma:=1
		if nextlx.token=tk_rbrack then		!means one-element list
			lex()
			lex()
			p:=createunit(u_makelist, p)
			p.length:=1
			p.b:=plower
			return p
		end
docomma:						!entry from implicit newline
		length:=1

!must be regular list
		ulist:=ulistx:=p

		if usecomma then
			repeat
				lex()							!skip comma
				if lx.token=tk_rbrack then		!allow , ) to end list
					exit
				end
				if lx.token=tk_comma then
					serror(", , null expr not allowed")
				end
				addlistunit(ulist, ulistx, readunit())
				++length
				skipsemi()
			until lx.token<>tk_comma
		else

			repeat
				skipsemi()
				if lx.token=tk_rbrack then		!allow , ) to end list
					exit
				end
				if lx.token=tk_comma then
					serror(", , null expr not allowed")
				end
				addlistunit(ulist, ulistx, readunit())
				++length
			until lx.token<>tk_semi
		end

		checktokenlex(tk_rbrack)
!		lex()
		p:=createunit(u_makelist, ulist)
		p.length:=length
		p.b:=plower
		return p

	when tk_bar then			!ifx/selectx expression; p is selector expression
		lex()
		q:=readunit()
		case lx.token
		when tk_bar then		!(a|b|c)
			lex()
			r:=readsunit()
			checktokenlex(tk_rbrack)
			p:=createunit(u_if, fixcond(p), q)
			p.a.nextunit:=r
			return p
		when tk_rbrack then
			lex()
			p:=createunit(u_if, fixcond(p), q)
			return p
		end case

!assume selectx expression
		addlistunit(ulist, ulistx, q)	!start with one-element list
		checktoken(tk_comma)
		if nextlx.token<>tk_bar then		!(n|a, | using one-element list; not useful but allow it...
			repeat
				lex()				!skip comma
				addlistunit(ulist, ulistx, readunit())
			until lx.token<>tk_comma
			checktoken(tk_bar)
		else
			lex()					!skip |
		end
		lex()
		r:=readunit()
		checktokenlex(tk_rbrack)
!		lex()
		p:=createunit(u_select, p, ulist)
		p.a.nextunit:=r
		return p

	when tk_semi then
		if lx.subcode=1 then
			usecomma:=0
			goto docomma
		end
		ulist:=ulistx:=p
		repeat
			skipsemi()
			if lx.token=tk_rbrack then
				exit
			end
			addlistunit(ulist, ulistx, readunit())
!			skipsemi()						!allow a, b, c;) (works better with a, b, c\ followed by comment on next line followed by ")")
		until lx.token<>tk_semi
		checktokenlex(tk_rbrack)
!		lex()

		return makeblock(ulist)


	else
		serror("(x ...")
	end case
	return nil
end

func readsunit:unit p =
	++indatainit			!readsunits can sometimes occur in module-scope init data
	p:=readblock(stcurrproc)
	--indatainit
	p
end

proc contexterror=
	serror("Context error")
end

func readvardef(symbol owner, int id,  scope)unit=
!positioned at either 'var', or first symbol of type
!read vars inside module or proc
!varid must be frameid[let]/staticid[let] for procs, otherwise static for modules

	unit ulist, ulistx, p
	int nvars, m, initcode, override
	symbol stname

	ulist:=ulistx:=nil
	override:=0

	if dmode then
		checktokenlex(tk_var)
		m:=tvar

		if lx.token=tk_colon then
			lex()
			m:=readtypespec(owner)
		end
	else
		m:=readtypespec(owner)
	end

!at first varname

	nvars:=0
	while lx.token=tk_name do
		++nvars
		stname:=getduplst(owner, lx.symptr, id)
		stname.scope:=scope

		stname.isstatic:=id=staticid

		if id=dllvarid then
			stname.isimport:=1
		end

		adddef(owner, stname)

		if id=staticid then
			addlinear(stname)
		end

		lex()

		initcode:=0
		case lx.token 
		when tk_binop then
			case lx.subcode
			when bin_eq then initcode:=1
			when bin_assign then initcode:=2
			when bin_copy then initcode:=3
			end
		when tk_at then
			lex()
			stname.equivvar:=readunit()
		when tk_colon then
			if not insiderecord then
				if m=tvar then
					lex()
					m:=readtypespec(owner)
					override:=1
				else
					serror("Not record or :T:T")
				end
			else
				readbitfields(owner, stname)
			end
		end

		storemode(owner, m, stname.mode)
		if override then m:=tvar end

		if initcode then
			lex()
			if id=staticid and initcode>1 and not dmode then serror("Static needs =") end
			if id<>staticid and initcode=1 then serror("Use := not =") end

			stname.code:=readunit()
			if id=frameid then
				p:=createunit(u_assign, createname(stname), stname.code)
				addlistunit(ulist, ulistx, p)
			end
		end

		exit when lx.token<>tk_comma
		lexchecktoken(tk_name)
	end

	if nvars=0 then
		serror("No vars declared")
	end
	return ulist
end

proc readconstdef(symbol owner, int scope=0)=
!at 'const' symbol
	int nconsts, deft, m
	symbol stname

	lex()

	nconsts:=0

	if istypestarter() then
		deft:=readtypespec(owner)
	else
		deft:=tvoid
	end

	while lx.token=tk_name do
		stname:=getduplst(owner, lx.symptr, constid)

		lex()

		checkequals()
		lex()
		stname.code:=readunit()

		m:=deft

		storemode(owner, m, stname.mode)
		++nconsts

		stname.scope:=scope

		adddef(owner, stname)
!		if scope=export_scope and stname.name^<>'$' then
!			addlinear(stname)
!		end

		if lx.token<>tk_comma then
			exit
		end
		lex()
	end

	if nconsts=0 then
		serror("No consts declared")
	end

end

proc readtypedef(symbol owner, int scope=0)=
!at 'type' symbol
	symbol sttype, stname
	int t, m, olddmode

	lexchecktoken(tk_name)
	stname:=lx.symptr

	lex()
	checkequals()
	lex()

	if lx.token=tk_union then
		olddmode:=dmode
		dmode:=0
		readrecorddef(owner, scope, stname)
		dmode:=olddmode
		return
	end

	sttype:=getduplst(owner, stname, typeid)
	adddef(owner, sttype)
	m:=createusertype(sttype)		!empty new type slot

	t:=readtypespec(sttype, m)		!should return filled-in version of m

	sttype.scope:=scope
	storemode(owner, t, sttype.mode)

	unless ttbasetype[t] in [tarray, trecord, tref] then
		storemode(owner, t, tttarget[m])
	end

	if t<0 then						!user type
		ttbasetype[m]:=tpending
	end
end

proc readprocdef(symbol procowner, int scope)=
!at 'proc' etc symbol; read proc def or declaration
!syntax:
!proc name: :/=> T [def]
!proc name(params) [def]
!proc name(params) [=>]T [def]
	int startline, closetoken, shortfun
	symbol stproc, stname

	shortfun:=lx.subcode=1
	nforloops:=0

	stproc:=readprocdecl(procowner, scope, lx.subcode)
CURRPARSEPROC:=STPROC
!CPL "PROCDEF", STPROC.NAME, =SCOPENAMES[SCOPE]

	checkequals()

	lex()

	startline:=lx.pos

	if not shortfun then
		closetoken:=checkbegin(0)
	end

	pushproc(stproc)
	nextavindex:=0

	IF DRETVAR THEN
		stname:=getduplst(stproc, dretvar, frameid)
		storemode(procowner, stproc.mode, stname.mode)
		adddef(stproc, stname)
	end

	if shortfun then
		stproc.code:=readunit()
		checktokenlex(tk_semi)
	else
		stproc.code:=readsunit()
		checkbeginend(closetoken, tk_func, startline)
	end

	stproc.code:=makeblock(stproc.code)

	popproc()
end

global func readprocdecl(symbol procowner, int scope, isfunc)symbol=
!at 'proc'  or 'func' 
!read proc declaration only, so exit at "=" or ";" symbol
!syntax:
!proc name: :/=> T [def]
!proc name(params) [def]
!proc name(params) [=>]T [def]
!return st entry of proc, and positioned at '=' or semi

!	int varparams
!, nparams, nretvalues
	int subprogno, sflag
	imodule ms
	isubprog ps

	ichar metadata, truename
	symbol pequiv, stproc, owner, palias

	pequiv:=nil
	metadata:=""
	truename:=nil
	sflag:=0

	if isfunc>=100 then
		sflag:=1
		isfunc-:=100
	end

	lex()

	if lx.token=tk_stringconst then		!assume dll truename
		truename:=pcm_copyheapstring(lx.svalue)
		convlcstring(lx.svalue)
		lx.symptr:=addnamestr(lx.svalue)
	else
		checktoken(tk_name)
	end

	stproc:=getduplst(procowner, lx.symptr, (insidedllimport|dllprocid|(sflag|sprocid|dprocid)))

	if truename then
		stproc.truename:=truename
	end

	adddef(procowner, stproc)
	addlinear(stproc)

	if stproc.nameid=dllprocid then
		stproc.isimport:=1
	end

	owner:=stproc
	pushproc(stproc)

	lex()
	if lx.token=tk_binop and lx.subcode=bin_mul then
		stproc.ishandler:=1
		lex()
	end

	if lx.token=tk_name and stproc.nameid=dllprocid and eqstring(lx.symptr.name, "as") then
!alias for function
		lex()
		checktoken(tk_name)

		palias:=getduplst(procowner, lx.symptr, macroid)
		adddef(procowner,  palias)
		palias.code:=createname(stproc)
		lex()
	end

	if stproc.nameid=dllprocid then
		readmsig(procowner, stproc, isfunc)
	else
		readqsig(stproc, isfunc)
	end
	stproc.code:=nil
	stproc.scope:=scope
!	stproc.varparams:=varparams

	if procowner=stmodule then
		if stproc.namelen=5 and eqstring(stproc.name, "start") then
			modules[stmodule.moduleno].ststart:=stproc
			stproc.scope:=global_scope
			dosigcheck
		elsif stproc.namelen=4 and eqstring(stproc.name, "main") then
			ms:=modules[stmodule.moduleno]
			ps:=subprogs[stmodule.subprogno]

			if ps.mainmodule then serror("More than one main() in SP") end
			ps.mainmodule:=stmodule.moduleno
			ms.stmain:=stproc

			if ps.subprogno=mainsubprogno then
				stproc.scope:=export_scope
dosigcheck:
				if stproc.nextparam or stproc.mode<>tvoid then
					serror("Wrong 'main/start' sig")
				end

			end
		end
	end

	popproc()

	return stproc
end

proc readqsig(symbol stproc, int isfunc)=
	symbol plist, plistx, d
	int isbyref, isoptional, m

!assume one or more params
	isbyref:=isoptional:=0

	if lx.token=tk_lbrack then
		lex()
		if lx.token=tk_rbrack then
			lex()
			finish
		end
	else
		finish
	end

!at '('

	plist:=plistx:=nil

	do
		m:=tvar
		if lx.token=tk_addr then
			++isbyref
			lex()
		fi
		if lx.token=tk_question then
			++isoptional
			lex()
		fi
		checktoken(tk_name)
		d:=getduplst(stproc, lx.symptr, paramid)
		adddef(stproc, d)
		addlistparam(plist, plistx, d)

		lex()
		if lx.token=tk_colon then
			lex()
			m:=readtypespec(stproc)
		end

		if lx.token=tk_binop and lx.subcode=bin_eq then
			isoptional:=1
			lex()
			d.code:=readunit()
		fi

		if isbyref and isoptional then serror("Mixed byref/optional") fi

		d.byref:=isbyref
		d.optional:=isoptional

		storemode(stproc, m, d.mode)
!		d.mode:=tvar

		isbyref:=isoptional:=0

		if lx.token=tk_comma then
			lex()
		else
			exit
		fi
	od

	checktokenlex(tk_rbrack)
	stproc.nextparam:=plist
finish:
	if isfunc then
		if istypestarter() or lx.token=tk_var then
			m:=readtypespec(stproc)
		else
			m:=tvar
		end

		storemode(stproc.owner, m, stproc.mode)

!		stproc.mode:=tvar
		stproc.nretvalues:=1
	end
	checkequals()

end

proc readmsig(symbol procowner, stproc, int isfunc)=
	int varparams, nparams
	int subprogno
	int retmode
	imodule ms
	isubprog ps

	ichar metadata, truename
	symbol pequiv, paramlist, nameptr

	paramlist:=nil
	retmode:=tvoid
	nparams:=0

	if lx.token=tk_lbrack then		!possible params
		lex()
		if lx.token<>tk_rbrack then
			paramlist:=readparams(procowner, stproc, varparams, nparams)
			checktoken(tk_rbrack)
		end
		lex()

		if lx.token=tk_colon or lx.token=tk_sendto then
			lex()
			retmode:=readtypespec(stproc)
		elsif typestarterset[lx.token] or lx.token=tk_name then
			retmode:=readtypespec(stproc)
		end
	elsif lx.token=tk_colon or lx.token=tk_sendto then
		lex()
		retmode:=readtypespec(stproc)
	end

	dretvar:=nil
	if retmode then
		if lx.token=tk_name then
			dretvar:=lx.symptr
			lex()
		end
	end

	if isfunc and retmode=tvoid then			!func: no result given
		if dmode then
			retmode:=tvar
		else
			serror("Function needs ret type")
		end
	end

	if not isfunc and retmode then		!proc: result given
		serror("Proc can't return value")
	end

	stproc.nextparam:=paramlist
	stproc.varparams:=varparams

	if retmode then
		storemode(procowner, retmode, stproc.mode)
	else
		stproc.mode:=tvoid
	end
end

func readparams(symbol procowner, owner, int &varparams, &nparams)symbol=			!READPARAMS
!positioned at first symbol after '('; this is not ')'
!read list of params, return that list
!syntax is a list of names and/or types
!each param can optionally be followed by a default value
!finish pointing at ")"
	symbol stlist, stlistx, stname
	int byref, pmode, m, isoptional, types

	stlist:=stlistx:=nil
	pmode:=tvoid
	nparams:=0
	types:=0

	if lx.token=tk_name and nextlx.token in [tk_comma, tk_rbrack] then
		types:=1
	end

	do										!expect type of name at start of loop
		byref:=0
		isoptional:=0

		if types or istypestarter() then				!assume new mode
			pmode:=readtypespec(procowner)
gotmode:

			if nparams=0 and lx.token in [tk_comma, tk_rbrack] then
				do
					[32]char str
					++nparams
					str[1]:='$'; str[2]:=0
					strcat(str, strint(nparams))
					stname:=getduplst(owner, addnamestr(str), paramid)
					adddef(owner, stname)

					storemode(owner, pmode, stname.mode)
					stname.byref:=byref
					addlistparam(stlist, stlistx, stname)

					case lx.token
					when tk_rbrack then
						exit
					end case

					checktokenlex(tk_comma)
!					lex()
					if lx.token=tk_ellipsis then
						varparams:=nparams		!no. of fixed params
						lex()
						exit
					end

					pmode:=readtypespec(procowner)
				end
				return stlist
			end

		elsif pmode=tvoid then
			serror("Type expected")
		end

		case lx.token
		when tk_addr then
			byref:=1
			lex()
			if lx.token=tk_colon then lex() end
		when tk_ellipsis then
			varparams:=nparams
			lex()
			return stlist
		end case

		checktoken(tk_name)
		++nparams
		stname:=getduplst(owner, lx.symptr, paramid)
		adddef(owner, stname)
		lex()

		if byref then
			m:=createrefmode(procowner, pmode)
		else
			m:=pmode
		end

		storemode(owner, m, stname.mode)
		stname.byref:=byref
		stname.optional:=isoptional
		addlistparam(stlist, stlistx, stname)

		if lx.token=tk_binop and lx.subcode in [bin_eq, bin_assign] then
			lex()
			stname.code:=readunit()
			stname.optional:=1
		end

		case lx.token
		when tk_comma then
			lex()
		when tk_rbrack then
			exit
		else
			serror("nameparams1")
		end case
	end

return stlist
end

func readstop:unit=
	unit p
	int i
	lex()
	if exprstarter[lx.token] then
		p:=createunit(u_stop, readunit())
	else
		p:=createunit(u_stop)
	end
	return readcondsuffix(p)
end

func readreturn:unit=
	unit p, q

	lex()
	if exprstarter[lx.token] then
		q:=readunit()
		p:=createunit(u_return, q)
		p.length:=1
	else
		p:=createunit(u_return)
		p.length:=0
	end

	return readcondsuffix(p)
end

func readdo:unit=
	unit p
	int pos

	pos:=lx.pos
	lex()
	p:=readsunit()
	checkend(tk_end, tk_do)
	p:=createunit(u_do, p)
	p.pos:=pos
	return p
end

func readto:unit=
	int pos, id
	unit p, pcount, pbody

	pos:=lx.pos
	lex()

	pcount:=readunit()

	checktokenlex(tk_do)
	pbody:=readsunit()
	checkend(tk_end, tk_to, tk_do)
	id:=frameid
!*!	if stcurrproc.nameid<>procid then id:=staticid end

	p:=createunit(u_to, pcount, pbody)
	p.a.nextunit:=createname(getavname(stcurrproc, id))
	p.pos:=pos
	return p
end

func readwhile:unit=
	int pos
	unit pcond, pbody, pincr, p
	pos:=lx.pos
	lex()
	byte oldiwh

	oldiwh:=inwhileheader
	inwhileheader:=1

	pcond:=fixcond(readsunit())
	pincr:=nil

	if lx.token=tk_comma then
		lex()
		pincr:=readsunit()
	end
	inwhileheader:=oldiwh

	checktokenlex(tk_do)
	pbody:=readsunit()

	checkend(tk_end, tk_while, tk_do)

	p:=createunit(u_while, pcond, pbody)
	p.a.nextunit:=pincr

	p.pos:=pos

	return p
end

func readrepeat:unit=
	int pos
	unit pbody, pcond, p

	pos:=lx.pos
	lex()
	pbody:=readsunit()
	checktokenlex(tk_until)
	pcond:=fixcond(readunit())
	p:=createunit(u_repeat, pbody, pcond)
	p.pos:=pos

	return p
end

func readloopcontrol:unit=
	int opc, index
	unit p

	opc:=lx.subcode

	lex()
	if lx.token=tk_name and eqstring(lx.symptr.name, "all") then
		lex()
		index:=0
	elsif exprstarter[lx.token] then
		checktoken(tk_intconst)
		index:=lx.value
	else
		index:=1
	end
	p:=createunit(opc)
	p.loopindex:=index

	return readcondsuffix(p)
end

func readunless:unit=
	int pos
	unit pcond, pthen, pelse, p, q

	pos:=lx.pos
	lex()
	pcond:=fixcond(readsunit())
	checktokenlex(tk_then)

	pthen:=readsunit()

	if lx.token=tk_else then
		lex()
		pelse:=readsunit()
	else			!assume simple if-then
		pelse:=nil
	end
	checkend(tk_end, tk_unless)
	p:=createunit(u_if, q:=createunit(u_notl, pcond), pthen)
	p.a.nextunit:=pelse
	p.pos:=pos
	return p
end

func readfor:unit=
!on 'for'; syntax is:
! for index[, local] in/inrev expr [by expr] [when expr] do stmts [else stmts] end
! for index to expr [by expr] [when expr] do stmts [else stmts] end
!The 'to expr' here is converted to '1..expr'
!forup/down: a = (pindex pfrom pto pstep) b = (pbody pelse)
!forall/rev: a = (pindex pvar pfrom pto)  b = (passign, pbody pelse)

!AV codes:
!	I	loop index, always i64; will be 'i' (declared or not declared) or autovar
!	L	forall local variable; will be 'x' (declared or not declared); type is variable

	int pos, opc
	unit pindex, pvar				!for index; for index, local
	unit pfrom, pto, pstep, ptoinit	!for INDEX:=FROM to/downto TO [by STEP]/ INDEX in FROM..TO
	unit plist, passign				!for INDEX in/inrev LIST (also LIST.BOUNDS)
	unit pcond, pbody, pelse
	unit p, q
	unit ulist:=nil, ulistx:=nil
	byte forall:=0					!1 when forall
	byte each:=0					!1 when foreach

	pos:=lx.pos
	each:=lx.subcode
	lex()						!skip 'for' kwd

	pvar:=nil
	ptoinit:=nil
	pindex:=readname()

	if nforloops>=maxforloops then
		serror("Too many for-loops")
	end
	for i to nforloops do
		if forindexvars[i]=pindex.def then
			serror("Re-using nested loop index")
		end
	end
	forindexvars[++nforloops]:=pindex.def

	if lx.token=tk_comma then
		lex()
		pvar:=readname()
	end

	opc:=u_forup
	pstep:=nil
	pcond:=nil

	if lx.token=tk_to then
		lex()
		plist:=createunit(u_makerange, createintconstunit(1, ti64), readunit())
		PFROM:=PLIST.A
		PTO:=PLIST.B

	ELSIF LX.TOKEN=TK_BINOP AND LX.SUBCODE=BIN_ASSIGN THEN
!TEMPORARILY SUPPORT OLD SYNTAX "FOR I:=A TO B"
		lex()
		pfrom:=readunit()
		checktokenlex(tk_to)
		pto:=readunit()

	else
		if lx.token=tk_comma then
			lex()
			pvar:=readname()
		end
		unless lx.token=tk_binop and lx.subcode in [bin_in, bin_inrev] then
			serror("IN expected")
		end
		opc:=u_forup
		if lx.subcode=bin_inrev then
			opc:=u_fordown
		end
		lex()

		plist:=readunit()

		if plist.tag=u_makerange then
			serror("for i,x") when pvar
			pfrom:=plist.a
			pto:=plist.b
			if lx.token=tk_by then
				lex()
				pstep:=readunit()
			end

		else
			forall:=1
			pfrom:=getrangelwbunit(duplunit(plist))
			pto:=getrangeupbunit(duplunit(plist))
		end
	end

	if each and not forall then serror("foreach?") end

	if lx.token=tk_when then
		lex()
		pcond:=fixcond(readunit())
	end
	checktokenlex(tk_do)
	pbody:=readsunit()
	pelse:=nil

	if lx.token=tk_else then
		lex()
		pelse:=readsunit()
	end
	checkend(tk_end, tk_for, tk_do)

!deal with complex limit
!problem: autovar for STEP only created when there is an autovar for TO

	if pcond<>nil then
		pbody:=makeblock(createunit(u_if, pcond, pbody))
	end

	pbody.nextunit:=pelse
	if pstep=nil then
		pstep:=createintconstunit(1, ti64)
	end

!Here, I have pindex/pvar, plist/pfrom/pto, pstep, pbody/pelse
!Next, generate most assignments, checks, and any extra jumps
!I must end with a FORUP or FORDOWN unit
!================================================================
	pindex.avcode:='I'

!init index
	p:=createunit(u_bin, pfrom, pstep)
	p.binop:=(opc=u_fordown|bin_sub|bin_add)
	p:=createunit(u_bin, duplunit(pindex), p)
	p.binop:=bin_assign

	addlistunit(ulist, ulistx, p)

	if pto.tag not in [u_intconst, u_name] then
		q:=createname(getavname(stcurrproc))
		q.avcode:='I'
		p:=createunit(u_assign, q, pto)
		addlistunit(ulist, ulistx, p)
		pto:=q
	end

	if forall then
		if pvar=nil then
			pvar:=pindex
			pindex:=createname(getavname(stcurrproc))
			pindex.avcode:='I'
		end

!create assignment
		passign:=createunit(u_assign, pvar,
			createunit((each|u_dotindex|u_index), plist, duplunit(pindex)))
		q:=pbody.nextunit
!		pbody.nextunit:=nil
		passign.nextunit:=pbody
		pbody:=passign
!		pbody.nextunit:=q
	end

	pindex.nextunit:=pto
	pto.nextunit:=pstep

	p:=createunit(opc, pindex, pbody)
	addlistunit(ulist, ulistx, p)

	--nforloops
	if ulist.nextunit then
		return makeblock(ulist)
	else
		return ulist
	end
end

global func readname:unit p=
	p:=readterm2()
	if p.tag<>u_name then serror("Name expected") end
	return p
end

func readprint:unit=
	int oldinreadprint, opc, isfprint, fshowname, prcode, newline
	unit pformat, pdev, printlist, printlistx, p, q
	^strbuffer expr

	ichar s

	oldinreadprint:=inreadprint
	inreadprint:=1
	prcode:=lx.subcode

	newline := prcode iand pr_newline

	if prcode iand pr_sprint then
		opc:=u_sprint
	elsif prcode iand pr_format then
		opc:=u_fprint
	else
		opc:=u_print
	end

	lex()

	printlist:=printlistx:=nil
	pformat:=pdev:=nil

	if lx.token=tk_at then
		lex()
		pdev:=readunit()
		if lx.token=tk_comma then lex() else goto finish end
	end

!	if not newline and lx.token=tk_semi then serror("Print?") end

	if opc=u_fprint then
		if not exprstarter[lx.token] then serror("Fprint") end
		pformat:=readunit()
		if lx.token=tk_comma then lex() else goto finish end
	end

	if not exprstarter[lx.token] then
		goto finish
	end

	do
		case lx.token
		when tk_comma then		!assume extra comma, meaning nogap
			addlistunit(printlist, printlistx, createunit(u_nogap))
		when tk_dollar then		!assume extra comma, meaning nogap
			addlistunit(printlist, printlistx, createunit(u_space))
			lex()

		else

			fshowname:=0
			if lx.token=tk_binop and lx.subcode=bin_eq then
				fshowname:=1
				lex()
			end

			p:=readunit()
			if lx.token=tk_colon then
				lex()
				p:=createunit(u_fmtitem, p, readunit())
			end
			if fshowname then
!SERROR("STREXPR NOT READY")
!CPL("STREXPR NOT READY")
				expr:=strexpr(p)
				
				gs_str(expr, "=")
				s:=expr.strptr
				iconvucn(expr.strptr, expr.length)
!
				addlistunit(printlist, printlistx, q:=createstringconstunit(s, expr.length+1))
!				addlistunit(printlist, printlistx, q:=createstringconstunit("<strexp>", -1))
			end
			addlistunit(printlist, printlistx, p)
		end case
		if lx.token<>tk_comma then exit end
		lex()
	end

	finish:
	inreadprint:=oldinreadprint
	if not newline and printlist=nil then
		serror("No print items")
	end
	if opc=u_fprint and printlist=nil and pformat=nil then
		serror("No print items")
	end

	if opc=u_fprint then
		if pformat=nil then
			serror("No fmt str")
		end
		pformat.nextunit:=printlist
		printlist:=pformat
	end

	return createunit(opc+newline, pdev,printlist)
end

proc readrecorddef(symbol owner, int scope, symbol d=nil)=
!at 'record' symbol
!read enough of the class to be able to generate export data
!if d is not nil, called from 'type name = struct', and position at 'struct';
! d refers to name

	int kwd, m, startline, closetoken, mrec, align, basetype
	symbol nameptr, sttype

	basetype:=tvoid

	if d then
		nameptr:=d
		lex()
		dostruct
	end

	lexchecktoken(tk_name)
	nameptr:=lx.symptr

	lex()

	if lx.token=tk_lbrack then
		lex()
		basetype:=readtypespec(owner)
		checktokenlex(tk_rbrack)
	fi

	checkequals()
	lex()

dostruct:
	align:=0
	if lx.token=tk_caligned then	!$caligned only
		lex()
		align:=1
	end

	sttype:=getduplst(owner, nameptr, typeid)
	adddef(owner, sttype)
	m:=createusertype(sttype)

	mrec:=createrecordmode(owner, m, (dmode|trecord|tstruct))
	storemode(owner, mrec, sttype.mode)

!	storemode(owner, baseclass, sttype.baseclass)
	sttype.caligned:=align

	closetoken:=checkbegin(1)

	startline:=lx.pos

	++insiderecord
	readblock(sttype)
	--insiderecord

	checkbeginend(closetoken, tk_record, startline)

	sttype.scope:=scope
end

global proc readtabledef(symbol owner, int scope=0)=
!at 'tabledata' symbol
	int i, ncols, nrows, enums, nextenumvalue, firstval, lastval, startline, closetoken
	int ltype
	symbol stvar, stenum, stgen
	const maxcols=20
	[maxcols]symbol varnameptrs
	[maxcols]int varlisttypes
	[maxcols]unit plist, plistx
	const maxrows=500
	[maxrows]int enumvalues

	enums:=lx.subcode				! means enumdata
	lex()

	tabledataname:=nil

	if lx.token=tk_lbrack then		!tabledata(...) read enum type
		if not enums then serror("Use 'enumdata'") end
		enums:=1
		lex()
		checktokenlex(tk_rbrack)
!		lex()
	end


	nextenumvalue:=1
	nrows:=0			!number of data rows appearing
	ncols:=0			!number of data columns (varnames appearing)

!loop reading variable names
	while not (lx.token=tk_binop and lx.subcode=bin_eq) do

		if dmode then
			ltype:=tvar
		else
			ltype:=readtypespec(owner)
		end
		checktoken(tk_name)
		if ++ncols>maxcols then
			serror("tabledata/too many columns")
		end
		varnameptrs[ncols]:=lx.symptr
		varlisttypes[ncols]:=ltype

		lex()
		if lx.token=tk_comma then
			lex()
		else
			exit
		end
	end

	lex()					!skip =

	skipsemi()
	startline:=lx.pos
	closetoken:=checkbegin(0)

	skipsemi()
	firstval:=lastval:=0

	for i:=1 to ncols do
		plist[i]:=plistx[i]:=nil
	end

	intabledata:=1
	do			!loop per row
		skipsemi()
		if ncols>0 then
			checktokenlex(tk_lbrack)
!			lex()
		end
		if ++nrows>maxrows then
			serror("tabledata:too many rows")
		end

		if enums then
			checktoken(tk_name)
			stgen:=lx.symptr				!generic symbol entry
			tabledataname:=stgen.name		!allow to be picked up by $ lx.token
			lex()
			if lx.token=tk_binop and lx.subcode=bin_eq then
				if nrows<>1 then serror("enum=x, 1st row only") end
				lex()
				nextenumvalue:=readconstint()
			end
			enumvalues[nrows]:=nextenumvalue

			stenum:=getduplst(owner, stgen, constid)
			stenum.mode:=tint
			stenum.code:=createintconstunit(nextenumvalue, tint)
			stenum.scope:=scope
			adddef(owner, stenum)
			if scope=export_scope then
				addlinear(stenum)
			end

			if nrows=1 then firstval:=nextenumvalue end
			lastval:=nextenumvalue

			++nextenumvalue
			if ncols then				!comma always expected
				checktokenlex(tk_comma)		!check it
!				lex()
			end
		end

		for i:=1 to ncols do
			addlistunit(plist[i], plistx[i], readunit())
			if i=ncols then
				checktokenlex(tk_rbrack)
			else
				checktokenlex(tk_comma)
			end
!			lex()
		end

		if lx.token<>tk_comma then exit end
		lex()					!should be ( for next entry
		if lx.token=closetoken then exit fi		!allow trailing comma on last entry
	end

	intabledata:=0

	skipsemi()
	checkbeginend(closetoken, tk_tabledata, startline)

!Here, I have:

!enum				1 means enum 0th column present, 0 means not
!ncols				0, or number of actual expression columns
!nrows				Number of data rows
!enumtypename			"", or enum user type name to be created for enum names/values

!varnameptrs[1..ncols]		!Names of the list variables ([]strec]
!varlisttypes[1..ncols]		!Type of each list (or 0 if not provided)
!varelemttypes[1..ncols]	!Type of each element (or 0 if not provided)
!plist[1..ncols]		Each entry is a list of expression units for the column

!enumnames[1..nrows]	When enum=1, list of names/values in 0th column
!enumvalues[1..nrows]

	if nrows=0 then serror("No table data") end

!for each variable, add a vardef initialised to the list
!add the decls for the vars

	for i:=1 to ncols do
		stvar:=getduplst(owner, varnameptrs[i], staticid)
		stvar.code:=createunit(u_makelist, plist[i])
		stvar.code.length:=nrows
!		stvar.istabdata:=1

		storemode(owner, varlisttypes[i], stvar.mode)
		stvar.scope:=scope

		adddef(owner, stvar)
		addlinear(stvar)
	end
end

proc readimportmodule(symbol owner)=
!at 'importmodule' symbol
	int isnew, startline, closetoken, olddmode
	symbol stname, stname0

	if insidedllimport then serror("nested importdll") end
!	libtype:=lx.subcode

	lex()
	if lx.token=tk_stringconst then
		stname:=addnamestr(lx.svalue)
	else
		checktoken(tk_name)
		stname:=lx.symptr
	end

	lex()
	checkequals()
	lex()

!stname points to a nullid symbol
!check whether this module already exists

	isnew:=1

	for i to nlibfiles do
		if eqstring(libfiles[i], stname.name) then
			isnew:=0
			exit
		end
	end

	if isnew then			!new
		addlib(stname.name)
	end

	startline:=lx.pos
	closetoken:=checkbegin(0)

	insidedllimport:=1
	olddmode:=dmode
	dmode:=0					!functions, records, vars all in m-mode

	readimportbody(owner)

	dmode:=olddmode
	insidedllimport:=0

	checkbeginend(closetoken, tk_importmodule, startline)

end

proc readimportbody(symbol owner)=
!positioned at first symbol of statement (which can be empty)
!return knode containing statement, or nil if not found (at 'end etc)
	int pos
	symbol d
!	const scope = global_scope
	const scope = program_scope

	pos:=lx.pos
	do
		skipsemi()
		case lx.token
		when tk_func then
			d:=readprocdecl(owner, program_scope, lx.subcode)
			if ndllproctable>=maxdllproc then
				serror("Too many dll procs")
			end
			dllproctable[++ndllproctable]:=d
!			addlinear(d)

		when tk_type then
			readtypedef(owner, scope)

		when tk_const then
			readconstdef(owner, scope)

		when tk_record then
			readrecorddef(owner, scope)

		when tk_stdtype, tk_name, tk_ref, tk_ptr, tk_lsq then
			readvardef(owner, dllvarid,  scope)

		when tk_eof then
			exit

		when tk_end then
			exit
		else
			PS("symbol")
			serror("Not allowed in importmodule")
		end case
	end
end

proc readmacrodef(symbol owner, int scope)=
!positioned at 'macro'
!read expression macro-definition; global=1 if to be exported
!int kwd, varparams, try_level, prettype, nparams, rettype2, rettype3, nretvalues
!ichar metadata, truename
!symbol pequiv, stproc, owner, paramlist, nameptr

	symbol nameptr, stmacro, paramlist, paramlistx, stname

	lexchecktoken(tk_name)

	nameptr:=lx.symptr
	stmacro:=getduplst(owner, nameptr, macroid)
	adddef(owner, stmacro)

	owner:=stmacro

	lex()

	paramlist:=paramlistx:=nil

	if lx.token=tk_lbrack then			!may have parameters
		lex()
		if lx.token<>tk_rbrack then
			do
				case lx.token
				when tk_name then
					stname:=getduplst(owner, lx.symptr, macroparamid)
					adddef(owner, stname)
					addlistparam(paramlist, paramlistx, stname)

					lex()
					if lx.token=tk_rbrack then
						exit
					end
					checktokenlex(tk_comma)
				else
					serror("macro def params")
				end case
			end
		end
		lex()						!skip )
	end
	stmacro.nextparam:=paramlist
	stmacro.scope:=scope

	checkequals()
	lex()
	stmacro.code:=readunit()
end

func readrefproc(symbol owner, int typedefx)int=
!'ref' was seen, now positioned at 'proc' 'func' or 'method'
!read proc params and any result, return a complete ^proc spec
	int kwd, prettype, m, varparams, nparams
	int retmode
	symbol paramlist, stproc
	ichar name
	byte isfunc:=lx.subcode			!1/2 means function

	lex()

	paramlist:=nil
	prettype:=tvoid
	varparams:=0

!need to create suitable holding typename in advance
	name:=nextautotype()
	stproc:=getduplst(stmodule, addnamestr(name), typeid)
	adddef(stmodule, stproc)
	retmode:=tvoid

	if isfunc then
		if lx.token=tk_lbrack then		!possible params
			lex()
			if lx.token<>tk_rbrack then
				paramlist:=readparams(owner, stproc, varparams, nparams)
				checktoken(tk_rbrack)
			end
			lex()
			if lx.token=tk_colon or lx.token=tk_sendto then
				lex()
				retmode:=readtypespec(owner)
			elsif typestarterset[lx.token] or lx.token=tk_name then
				retmode:=readtypespec(owner)
			end
		elsif lx.token=tk_colon or lx.token=tk_sendto then
			lex()
			retmode:=readtypespec(owner)
		end

		if retmode=tvoid then
			serror("Function needs return type")
		end

		if retmode and not isfunc then		!proc: result given
			serror("Proc can't return value")
		end
	else					!proc with no result
		if lx.token=tk_lbrack then		!possible params
			lex()
			if lx.token<>tk_rbrack then
				paramlist:=readparams(owner, stproc, varparams, nparams)
				checktoken(tk_rbrack)
			end
			lex()
		end
		if typestarterset[lx.token] or lx.token=tk_colon or lx.token=tk_sendto then
			serror("proc can't have ret value")
		end
	end

	m:=createrefprocmode(owner, stproc, paramlist, prettype, typedefx)

	storemode(owner, retmode, stproc.mode)
!	stproc.nretvalues:=nretvalues

	ttnamedef[m]:=stproc

	stproc.varparams:=varparams

	return m
end

func readif:unit p =
!at 'if'
	int pos, kwd
	unit pcond, pthen, pelse

	pos:=lx.pos
	kwd:=lx.token			!in case coming from elsecase etc
	lex()
	skipsemi()
	if lx.token=tk_elsif then
		lex()
	end

	pcond:=readsunit()
	skipsemi()

	checktokenlex(tk_then)
!

	pthen:=readsunit()

	case lx.token
	when tk_elsif then
		lx.token:=kwd
		pelse:=readif()

	when tk_else then		!get r=any else stmt or nil
		lex()
		pelse:=readsunit()
		checkend(tk_end, kwd)

	when tk_elsecase, tk_elseswitch then
		lx.token:=kwd
		pelse:=makeblock(readswitchcase())
	else
		pelse:=nil
		checkend(tk_end, kwd)
	esac

	p:=createunit(u_if, pcond, pthen)
	p.a.nextunit:=pelse
	p.pos:=pos

	return p
end

func readswitchcase:unit=
	int pos1, kwd, opc, pos2, rangeused, nwhen
	unit pexpr, pwhenlist, pwhenlistx, pwhen, pwhenx, pelse, p, pthen, pwhenthen, pjump

	pos1:=lx.pos
	kwd:=lx.token			!remember tk_case etc

!CPL "READCASE", TOKENNAMES[KWD]

	opc:=lx.subcode			!pick up tag: kcase etc
	pjump:=nil
!
	lex()

	skipsemi()

	if opc=u_doswitchx then
		checktokenlex(tk_lbrack)
		pjump:=readunit()
		checktokenlex(tk_rbrack)
		stcurrproc.hasdoswx:=1
	end

	if lx.token=tk_when then
		if kwd=tk_switch then
			serror("switch expr missing")
		end
		pexpr:=nil
	else
		pexpr:=readsunit()			!index expression
		pexpr.nextunit:=pjump		!for doswitchx
	end

	pwhenlist:=pwhenlistx:=nil
	rangeused:=0
	nwhen:=0

	skipsemi()
	while lx.token=tk_when do	!read list of when-then pairs
		pos2:=lx.pos
		lex()
		pwhen:=pwhenx:=nil
		do
			p:=readunit()
			++nwhen
			p.pos:=pos2
			if p.tag=u_makerange then rangeused:=1 end
			addlistunit(pwhen, pwhenx, p)
			if lx.token<>tk_comma then exit end
			lex()
		end
		if lx.token<>tk_sendto then
			checktoken(tk_then)
		end
		lex()
		pthen:=readsunit()
		pwhenthen:=createunit(u_whenthen, pwhen, pthen)
		pwhenthen.pos:=pos2
		addlistunit(pwhenlist, pwhenlistx, pwhenthen)
	end

	if opc=u_switch and not rangeused then
		if nwhen<=8 then
			opc:=u_case
		end
	end

	case lx.token
	when tk_else then		!get r=any else stmt or nil
		lex()
		pelse:=readsunit()
		checkend(tk_end, kwd)

	when tk_elsif then
		lx.token:=kwd
		pelse:=makeblock(readif())
	when tk_elsecase, tk_elseswitch then
		lx.token:=kwd
		pelse:=makeblock(readswitchcase())
	else
		PELSE:=NIL
		checkend(tk_end, kwd)
	end case

	p:=createunit(opc, pexpr, pwhenlist)

	p.a.nextunit:=pelse
	p.pos:=pos1
	return p
end

func readrecase:unit=
	lex()
	if lx.token=tk_else then
		lex()
		return createunit(u_recase)
	else
		return createunit(u_recase, readunit())
	end
end

proc readbitfields(symbol owner, stname)=
!read bitfields names inside a record
!positioned at ':'; stname is the field they will belong to
	int offset
	symbol stbitfield

	lexchecktoken(tk_lbrack)

	repeat
		lexchecktoken(tk_name)
		stbitfield:=getduplst(owner, lx.symptr, fieldid)
		stbitfield.mode:=tbitfield
		adddef(owner, stbitfield)

		stbitfield.atfield:=1
		stbitfield.equivfield:=stname

		lexchecktoken(tk_colon)
		lexchecktoken(tk_intconst)
		stbitfield.bitfieldwidth:=lx.value
		lex()

	until lx.token<>tk_comma
	checktokenlex(tk_rbrack)
end

func readread:unit=
	int oldinreadprint, opc, newline
	unit pformat, pdev, readlist, readlistx, p, pread

	oldinreadprint:=inreadprint
	inreadprint:=1
	newline:=lx.subcode
	lex()

	readlist:=readlistx:=nil
	pformat:=pdev:=nil

	if lx.token=tk_at then
		if not newline then
			serror("@ on read")
		end
		lex()
		pdev:=readunit()
		if lx.token=tk_comma then lex() end
	end

	if newline then
		addlistunit(readlist, readlistx, createunit(u_readln, pdev))
	end

	if not exprstarter[lx.token] then
		goto finish
	end

	do
		p:=readunit()
		if lx.token=tk_colon then
			lex()
			pformat:=readunit()
		else
			pformat:=nil
		end

		pread:=createunit(u_read, pformat)

		p:=createunit(u_assign, p, pread)

		addlistunit(readlist, readlistx, p)
		if lx.token<>tk_comma then exit end
		lex()
	end

	finish:
	inreadprint:=oldinreadprint
	if not newline and readlist=nil then
		serror("No read items")
	end

	return createunit(u_block, readlist)
end

func readtry:unit=
	unit ptry, pexceptlist, pexceptlistx, px, q, exlist, exlistx
	lex()

	ptry:=readsunit()
	pexceptlist:=pexceptlistx:=nil			!list of kexcept items

	while lx.token=tk_except do
		lex()
		exlist:=exlistx:=nil				!list of exception codes for this 'except'
		do
			addlistunit(exlist, exlistx, readunit())
			if lx.token<>tk_comma then exit fi
			lex()
		od
		checktokenlex(tk_then)
		px:=readsunit()
		addlistunit(pexceptlist, pexceptlistx, createunit(u_except, exlist, px))
	od
	checkend(tk_end, tk_try)
!	lex()

	return createunit(u_try, ptry, pexceptlist)
end

func readdollarexpr:unit p=
!do $(...) for reading type and operator values, positioned at '$'
	int t
CPL $LINENO
	lex()				!skip (
	lex()

	case lx.token
	when tk_stdtype, tk_ref, tk_lsq, tk_name, tk_var then
		t:=readtypespec(stcurrproc)
maketype:
		p:=createunit(u_typeconst)
		p.mode:=t
		
!	when tk_var then
!		t:=tvar
!		lex()
!		maketype
	when tk_record then
		t:=trecord
		lex()
		maketype

	when tk_binop, tk_unary then
makeop:
		p:=createunit(u_operator)
		p.optoken:=lx.token
		p.binop:=lx.subcode			!will do all the rest too
		lex()

	when tk_dot then
		lex()
		if lx.token=tk_prop then
			makeop
		end
		recase else
	else
		serror("$()")
	end
	checktokenlex(tk_rbrack)


	return p
end

func readlambda:unit p=
!at {
	symbol oldstcurrproc, stproc, d
	symbol plist, plistx
	[20]char str
	int nparams
	byte byref

	
	if stcurrproc.nameid=anonprocid then
		serror("Nested {}")
	end

	oldstcurrproc:=stcurrproc

	print @str, "$F", ,++nextlambdaindex
	stproc:=getduplst(stcurrproc, addnamestr(str), anonprocid)
	stcurrproc:=stproc
	adddef(oldstcurrproc, stproc)
	addlinear(stproc)

	lex()
	nparams:=0
	byref:=0
	plist:=plistx:=nil

PS($STRLINENO)
	if lx.token=tk_addr then lex(); byref:=1 fi

	if lx.token=tk_name and nextlx.token in [tk_comma, tk_colon] then
		do
			checktoken(tk_name)

			d:=getduplst(stproc, lx.symptr, paramid)
			adddef(stproc, d)
			addlistparam(plist, plistx, d)
			d.byref:=byref
			byref:=0

			lex()

			if lx.token<>tk_comma then exit fi
			lex()
		od
		checktokenlex(tk_colon)
	fi

!	stproc.nparams:=nparams
	stproc.nextparam:=plist
	stproc.mode:=tvar
PS($STRLINENO)

!read body of lambda

	stproc.code:=readsunit()
PS($STRLINENO)
	checktokenlex(tk_rcurly)

!	p:=createunit1(jmakeclosure, createname(stproc))
	p:=createname(stproc)

	stcurrproc:=oldstcurrproc
	return p
end

global proc lexchecktoken(int token)=
	lex()
	checktoken(token)
end

global proc checktokenlex(int token)=
	checktoken(token)
	lex()
end

global proc checktoken(int token)=
	[100]char str

	if lx.token<>token then
		fprint @str, "# expected, not #", tokennames[token], tokennames[lx.token]
		serror(str)
	end
end

global proc skipsemi=
	while lx.token=tk_semi do lex() end
end

!global proc checktoken2(int token, subcode)=
!	if lx.token<>token or lx.subcode<>subcode then
!		fprint @str, "#:# expected, not #:#", tokennames[token], subcode,
!					 tokennames[lx.token], lx.subcode
!		serror(str)
!	end
!end

global proc checkequals=
	unless lx.token=tk_binop and lx.subcode=bin_eq then
		serror("'=' expected")
	end
end

global func checkbegin(int fbrack)int=
!look for ( or [ or begin, return close symbol expected
!positioned at this opening symbol
!fbrack=1 to allow left "("
	int closetoken

	skipsemi()

	if lx.token=tk_lbrack and fbrack then
		closetoken:=tk_rbrack
		lex()
	else
		closetoken:=tk_end
	end
	return closetoken
end

global proc checkbeginend(int closetoken, kwd, startline=0)=
!look for ) or ] or end [kwd] depending on closetoken
!positioned at this symbol; exit at following symbol
	skipsemi()
!	if closetoken=tk_rbrack or closetoken=tk_rcurly then
	if closetoken=tk_rbrack then
		checktokenlex(closetoken)
!		lex()
	else
		checkend(closetoken, kwd, startline:startline)
	end
end

global proc checkend(int endtoken, endkwd1, endkwd2=0, startline=0)=
!at terminator symbol such as ), eof or 'end'
!check it matches what is expected
!tk_end is symbol expected to match
!'end' can have optional keyword following; if present, it must match endkeyword
!Some loop ends (indicated by endkeyword=tk_for, etc) can be also be terminated with 'od'
!tk_end should be tk_lbrack or kendsym
	[100]char str

!CPL "CHECKEND",TOKENNAMES[ENDTOKEN], TOKENNAMES[ENDKWD1], TOKENNAMES[ENDKWD2]
!PS("CHECKEND1")
	skipsemi()

!exit pointing to current symbol (to 'end', keyword after 'end', or ')')
	if endtoken=lx.token=tk_rbrack then
		return
	end

	if lx.token<>tk_end then
		serror("'End' expected")
	end

	if lx.subcode then
		if lx.subcode in [endkwd1, endkwd2] then
			lex()
			return
		else
error:
			strcpy(str, "Mismatched end ")
			if startline then
				fprint @(&str[1]+strlen(str)), " (from line #)", startline
			end
			serror(str)
		end
	end

!only end was used, so skip that now
!PS("CHECKEND2")
	lex()
!PS("CHECKEND3")
!CPL "KWD1/2=", TOKENNAMES[ENDKWD1], TOKENNAMES[ENDKWD2]
!now, should be semi, or possibly kwd1/2
	if lx.token in [endkwd1, endkwd2] then
		lex()
	elsif lx.token<>tk_semi then
		error
	end
end

global proc initparser(imodule pm)=
	dmode:=1
	unless nullunit then
		nullunit:=createunit(u_null)
	end unless
end

global func istypestarter:int=
	if typestarterset[lx.token] then return 1 end
	if lx.token=tk_name then				!name ...
		case nextlx.token
		when tk_name then					!name name
			return 1
		when tk_addr then
			return 1
		end case
	end
	return 0
end

proc start=
	for i:=1 to D_typestarterset.len do typestarterset[D_typestarterset[i]]:=1 end
end

global func fixcond(unit p)unit=
	checknotempty(p)
	if not isbooltag[p.tag] then
		insertunit(p, u_istruel)
	end
	return p
end

global proc checknotempty(unit p)=
	if p=nil or p.tag=u_block and p.a=nil then
		serror("Empty sunit")
	end
end

global func readtuple(int tag, n=2)unit =
!read (a,b) or (a,b,c) sequence; should be at '('
!return unit (tag, a,b), with any c being linked to b
!actually any number of elements is allowed

!should be at '('; read (x,y) or just (x) is opt is 1
!return (px, py)
	unit p, a,b,c

	checktokenlex(tk_lbrack)
	a:=readunit()
	checktokenlex(tk_comma)
	b:=readunit()
	c:=nil

	if n=3 and lx.token=tk_comma then				!optional 3rd element
		lex()
		c:=readunit()
	end
	checktokenlex(tk_rbrack)

	b.nextunit:=c							!c may be nil

	return createunit(tag, a, b)
!
!	case lx.token
!	when tk_comma then
!		lex()
!		q:=readunit()
!		checktokenlex(tk_rbrack)
!	when tk_rbrack then
!		if not opt then checktoken(tk_comma) end
!		lex()
!		q:=nil
!	else
!		checktoken(tk_rbrack)			!error; report missing bracket
!	end
!
!	return (p, q)
end

global func readcompilervar:unit=
	[100]char str
	rsystemtime tm
	static []ichar monthnames=("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
	unit p
	imodule currmodule:=modules[currmoduleno]

	switch lx.subcode
	when cv_nil then
		p:=createunit(u_nil)
		p.mode:=tref
		lex()
		return p

	when cv_pi then
!		p:=createconstunit(i64@(3.14159'265358'979'3238'4626'433'832), treal)
		p:=createrealconstunit(pi, treal)
		lex()
		return p

	when cv_infinity then
		p:=createrealconstunit(infinity, treal)
		lex()
		return p

	when cv_lineno then
!		tc_gen(kloadimm, getlineno(lx.pos)
		p:=createintconstunit(lx.lineno, ti64)
!		p:=createunit0(cv_lineno)
		lex()
		return p

	when cv_strlineno then
		getstrint(lx.lineno, str)

	when cv_modulename then
		strcpy(str, stmodule.name)

	when cv_filename then
		strcpy(str, sources[currmodule.fileno].filespec)

	when cv_func then
		strcpy(str, stcurrproc.name)

	when cv_date then
		os_getsystime(&tm)
		fprint @str, "#-#-#", tm.day, monthnames[tm.month], tm.year:"4"

	when cv_time then
		os_getsystime(&tm)
		fprint @str, "#:#:#", tm.hour:"z2", tm.minute:"z2", tm.second:"z2"

	when cv_version then
		strcpy(str, "Compiler:M6.4")

	when cv_true, cv_false then
		p:=createintconstunit(lx.subcode=cv_true, ti64)
		lex()
		return p
	
	else
		serror_s("compiler var not impl: #", cvnames[lx.subcode])
	end switch
	lex()

	return createstringconstunit(pcm_copyheapstring(str), -1)
end

global func makeblock(unit p)unit=
	unless p and p.tag=u_block then
		p:=createunit(u_block, p)
	end
	p
end

global proc pushproc(symbol p)=
	if nprocstack>=maxprocstack then
		serror("Too many nested proc")
	end
	procstack[++nprocstack]:=stcurrproc
	stcurrproc:=p
end

global proc popproc=
	if nprocstack then
		stcurrproc:=procstack[nprocstack--]
	else
		stcurrproc:=stmodule
	end
end
!
!global func readname:unit p=
!	p:=readterm2()
!	if p.tag<>jname then serror("Name expected") end
!	return p
!end
!
!
global proc addstructflag(symbol owner, int id)=
	static int structseqno
	[32]char str
	symbol d

	print @str, "$$",,++structseqno
	d:=getduplst(owner, addnamestr(str), id)
	adddef(owner, d)
end

global func readconstint:int=
!read expression that must yield a constant int value *now*; return value
	i64 x

!keep it simple for now
	if lx.token=tk_intconst then
		x:=lx.value
		lex()
		return x
	elsif lx.token=tk_binop and lx.subcode=bin_sub then
		lex()
		if lx.token=tk_intconst then
			x:=lx.value
			lex()
			return -x
		end
	end

!later can only arbitrary expressions, provided they can be evaluated in this pass
	serror("Not const int")
	return 0
end


