!Q standard library - Windows

!===============================
module sysp
module clibp
module winapi
module windows

module gxlib
module bmlib
module console
module winconsts
module wingxlib
module winmessages
module gxmisc
module dates
module smlib
!===============================

