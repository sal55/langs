writestrfile("kkk3", "abc")
