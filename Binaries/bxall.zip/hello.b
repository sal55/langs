$sourcepath "/mx/"
import msyswin
$sourcepath "/bx/"

mmode


proc main=
	println "Hello World"
end

