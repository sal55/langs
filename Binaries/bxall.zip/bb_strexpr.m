strbuffer exprstrvar
^strbuffer exprstr=&exprstrvar

^strbuffer jdest

global func strexpr(unit p)^strbuffer=
!vx_makestring("", exprstr)
	gs_init(exprstr)
	strunit(p)
	return exprstr
end

global proc strexevalx2(^strbuffer dest, unit p)=			!JEVAL
	jdest:=dest
	strunit(p)
end

global proc strunit(unit p)=			!JEVAL
!p represents an expression. It can be a unitrec only, not a list (lists only occur inside
!kmakelist and kmakeset units, which specially dealt with here)
!dest is a destination string. Special routines such as gs_additem() are used, which take care
!of separators so that successive alphanumeric items don't touch
	unit q, a, b
	[1024]char str
	int length

	if p=nil then
		return
	end

	a:=p.a
	b:=p.b

	case p.tag
	when u_intconst then

		case ttbasetype[p.mode]
		when ti64 then
			getstrint(p.value, str)
		when tu64 then
			strcpy(str, strword(p.value))
		else
			strcpy(STR, "intconst?")
		end case
		uuitem(str)

	when u_realconst then

		case ttbasetype[p.mode]
		when tr64, tr32 then
			print @str, p.xvalue
		else
			strcpy(STR, "realconst?")
		end case
		uuitem(str)

	when u_stringconst then
		case ttbasetype[p.mode]
		when tref then
			if p.mode=trefchar and p.isastring then
				if p.slength>str.len/4 then
					strcpy(str, "LONGSTR)")
				else
					convertstring(p.svalue, str, p.slength)
				end
				uuitem("""")
				uuitem(str)
				uuitem("""")
				return
			else
				print @str, ^void(p.value)
			end
		else
			strcpy(STR, "<EVAL/CONST PROBABLY VOID>")
		end case
		uuitem(str)

	when u_name then
		uuitem(p.def.name)

	when u_bin then
		uulb()
		strunit(a)
		uuitem(binstr[p.binop])
		strunit(b)
		uurb()

	when u_unary then

		uuitem(unarystr[p.unaryop])
		uulb()

		if a.tag=u_typeconst then
			uuitem(strmode(a.value))
		else
			strunit(a)
		end
		uurb()

	when u_prop then
		uulb()
		strunit(a)
		uurb()
		uustr(".")
		uuitem(propnames[p.propop])

	when u_call then
		strunit(a)
		uulb()

		q:=b
		while q do
			strunit(q)
			q:=q.nextunit
			if q then uuitem(", ") end
		end
		uurb()

	when u_index, u_dotindex, u_dotslice then
		strunit(a)
		if p.tag in [u_dotindex, u_dotslice] then
			uuitem(".")
		end
		uuitem("[")
		strunit(b)
		uuitem("]")

	when u_dot then
		strunit(a)
		uuitem(".")
		strunit(b)

	when u_makelist then
		uulb()

		q:=a
		while q do
			strunit(q)
			q:=q.nextunit
			if q then uuitem(", ") end
		end
		uurb()

	when u_makerange then
!		uulb()
		strunit(a)
		uuitem("..")
		strunit(b)
!		uurb()

	when u_assign then
		strunit(a)
		uuitem(":=")
		strunit(b)

	when u_if then
		uulb()
		strunit(a)
		uuitem("|")
		strunit(b)
		uuitem("|")
		strunit(p.a.nextunit)
		uurb()

	when u_typeconst then
		uuitem(strmode(p.mode))

	when u_convert, u_typepun then
		uuitem(strmode(p.mode2))
		if p.tag=u_typepun then
			uustr("@")
		end
		uulb()
		strunit(a)
		uurb()

	when u_autocast then
		uuitem("cast(")
		strunit(a)
		uurb()

	when u_dim then
		strunit(a)
		uuitem(":")
		if b then
			strunit(p.b)
		else
			uustr("-")
		end

	when u_ptr then
		strunit(a)
		uuitem("^")

	when u_block then
		uuitem("<JBLOCK>")

	when u_null then
		uustr("<nullunit>")

	when u_addrof then
		uuitem("&")
		strunit(a)
		if b then
			uustr("+")
			uustr(strint(b.value))
		end

!	when u_addroffirst then
!		uuitem("")
!		strunit(a)

	when u_typestr then
		uuitem("TYPESTR(")
		strunit(a)
		uurb()

!	when u_cvlineno, jcvfilename, jcvmodulename then
	when u_compilervar then
		uustr("$")
		uustr(cvnames[p.cvindex]+3)

	when u_bitfield then
		strunit(a)
		uustr(".")
		uustr(bitfieldnames[p.bfcode])

	when u_fmtitem then
		strunit(a)
		uustr(":")
		strunit(b)

	when u_syscall then
		uustr(sysfnnames[p.fnindex]+3)
		uulb()
		if a then strunit(a) end
		uustr(")")
	when u_incr then
		uustr("incr ")
		strunit(a)
	when u_strinclude then
		uustr("sinclude ")
		strunit(a)

	else
		CPL utagnames[p.tag]
		loaderror("CAN'T DO STREXPR")
	end
end

proc uulb=
	uuitem("(")
end

proc uurb=
	uuitem(")")
end

proc uustr(ichar str)=
	gs_str(exprstr, str)
end

proc uuitem(ichar s)=
!ensure alphanumerics have space between them
	ichar d
	int lastchar, nextchar

	d:=exprstr^.strptr

	if exprstr^.length then
		lastchar:=(d+exprstr^.length-1)^
		nextchar:=s^
		if isalphanum(lastchar) and isalphanum(nextchar) then
			gs_str(exprstr, " ")
		end
	end
	gs_str(exprstr, s)
end

global func isalphanum(int c)int=
	if c in 'A'..'Z' or c in 'a'..'z' or c in '0'..'9' then
		return 1
	end
	return 0
end

