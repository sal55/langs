!Q Main Library

mmode
export record rkey=
	u16	charcode
	byte	keycode
	byte	shift
end
qmode

export var ncmdparams
export var cmdparams
export var stclock=0

export const tab="\t"

export var readfilesize

!export var infinity=$infinity()
export var nan=$nan()

proc start=

	ncmdparams:=getcmdparam()

	cmdparams:=new(list,1..ncmdparams)

	s::=""
	for i:=1 to ncmdparams do
		cmdparams[i]:=getcmdparam(i)
		s+:=cmdparams[i]+" "
    od

	sreadln(s)
end

export proc reporterror(m)=
#print "Error:" followed by message m. Is that it? Count as being deprecated

	println "Error:",m
end

export func splitstring(s,?sep)=
#split up the string s into strings separated by the sep sequence
#return a list of all the individual strings, excluding the sep seq

	if s="" or sep="" then return (s,) fi

	a::=()
	ns:=0

	if sep.isvoid then			!use any white space of variable width

		whitespace:=(' ','\t',13,10)

		s:=s+chr(0)
		p:=&s
		t::=""
		instr:=0

		while c:=p++^ do
			if c in whitespace then
				if instr then
					a[++ns]:=t
					t::=""
					instr:=0
				fi
			else
				instr:=1
				t+:=c
			fi
		od
	
		if t then
			a[++ns]:=t
		fi

		return a

	else
		do
			n:=sep inx s
			if not n.isfound then
				a[++ns]:=s
				return a
			fi
			t:=leftstr(s,n-1)
			a[++ns]:=t
			s:=rightstr(s,-(n+sep.len-1))
		od
	fi
	return ""
end

export func joinstrings(a,sep)=
#join the strings in list, using the given separator string
#return new single string
	if a.upb=0 then return "" fi
	s:=a[1]
	for i:=2 to a.upb do
		s:=s+sep+a[i]
	od
	return s
end

export proc abort(s)=
#Print message, pause for keypress, then stop the interpreter with stopcode 1

	println "Abort:",s,"Error"
	waitkey()
	stop 1
end

export func extractpath(fs)=
#fs is a full filespec string
#extract any path from it and return that; ie, strip the filename
#otherwise return ""
	l:=fs.len
	for i:=l downto 1 do
		if chr(fs.[i]) in "\\/:" then
			return leftstr(fs,i)
		fi
	od
	return ""
end

export func extractfile(fs)=
#return filename portion of path fs
	p:=extractpath(fs)
	if p="" then return fs fi
	return rightstr(fs,-p.len)
end

export func extractbasefile(fs)=
#return filename portion of path fs
	f:=extractfile(fs)
	if f="" then return "" fi
	e:=extractext(f)
	if e.len then
		f:=leftstr(f,-e.len)
	fi
	if rightstr(f)="." then
		f:=leftstr(f,-1)
	fi
	return f
end

export func extractext(fs,period=0)=
#extract extension part of filespec fs
#endings of "xxx" (no extension) and "xxx." both return ""
#with period=1, then "xxx" returns "" and "xxx." returns . (so can be used to
#override default extensions)

	f:=extractfile(fs)
	if f="" then return "" fi
	e:=""
	do
		n:="." inx f
		if n.isfound then
			e:=rightstr(f,-n)
			if e="" then		!. ending
				return (period.defined and period|"."|"")
			fi

			f:=e
		else
			exit
		fi
	od

	return e
end

export func changeext(file,newext,soft=0)=
#normally face a change of extension to the file spec
#use soft=1 to only change extension if no extension is present (a "." ending is an extension)
	ext:=extractext(file)

	p:=extractpath(file)
	bf:=extractbasefile(file)
	ep:=extractext(file,1)

	if soft and ep<>"" then return file fi		!has extension, don't change!

	if newext="" then
		return p+bf
	elsif leftstr(newext)="." then
		return p+bf+newext
	else
		return p+bf+"."+newext
	fi
end

export func addpath(path,file)=
#If file doesn't already have an absolute path (here, starting with \ / or ?:)
#then prepend 'path', which must end with \ or /
	if leftstr(file) in "/\\." or file.len>=2 and file.[2]=":" then
		return file
	fi
	return path+file
end

export func addext(file,ext)=
#add extension to filename, if it doesn't already have it's own extenstion

	if extractext(file,1)="" then
		return changeext(file,ext)
	fi
	return file
end

export func replacestr (s,a,b)=
#if string a exists in s, then replace with b
#return original or modified s
	do
		n:=a inx s
		if not n.isfound then return s fi
		s:=leftstr(s,n-1)+b+rightstr(s,1-n-a.len)
	od
	return ""
end

export func parsecmdparams(cmd)=
#cmd consists of:
#blocks of text separated by whitespace or commas
#each block is one of these formats
# ...		param only
# /...		consists of switches only
# .../...	param followed by switches
#return of (params,switches), where each is a list of strings
#note that any correspondence between params and switches is lost; all switches assumed
#to be global, but can appear anywhere
#NOTE: cmd can also already be a list of blocks

	const dash="-"

	if cmd.islist then
		blocks:=cmd
	else
		sreadln(cmd)
		blocks::=()
		do
			read a:"s"
			if a="" then exit fi
			blocks append:=a
		od
	fi

	params::=()
	switches::=()

	for x in blocks do
		n:=dash inx x
!		if n=0 then		!pure param
!			params append:=x
		if n=1 then		!pure switches
			switches concat:=splitstring(convlc(rightstr(x,-1)),"/")
		else			!param followed by switches
			params append:=x
!			params append:=leftstr(x,n-1)
!			switches concat:=splitstring(convlc(rightstr(x,-n)),"/")
		fi
	od

	return (params,switches)
end

export proc waitsec(secs)=
#wait for given number of seconds, which can be a float. Call sleep()
	sleep(int(secs*1000))
end

export func cmd_getswitches=
#params is a list of strings, which
#read all switches, and return a list of switch names (minus the "/")
#each string can have more than one switch
#some switches can follow a name in a string

	switches::=()
	for i:=1 to cmdparams.upb do		!use 1..len in case called on <cmdparams> which has lwb 0
		s:=cmdparams[i]
		if leftstr(s) in "-/" then
			switches append:=convlc(rightstr(s,-1))
		fi
	od
	return switches
end

export func cmd_getparams=
#params is a list of strings
#return list of actual params, not including any switches
#switches are read separately using cmd_getswitches, but are not associated with
#specific params. That would need to be done here (when / is detected in the middle
#of a param, then make use readswitches. But to return that info, may be best to
#create a parallel function)

	cmds::=()

	for i:=1 to cmdparams.upb do
		pm:=cmdparams[i]
!for pm in params do
		if leftstr(pm) in "/-" then
			nextloop
		fi
!	n:="/" in pm
!	if n=0 then
			cmds append:=pm
!	else
!		cmds append:=leftstr(pm,n-1)
!	fi
	od
	return cmds
end

export func starttimer=
#Start timer and remember ticks at this point
	return stclock:=ticks()
end

export func stoptimer=
#Return number of ticks since starttimer was called, or last stoptimer
#as the count is reset

 	d:=ticks()-stclock
	stclock:=ticks()
	return d
end

export func bnfact(n)=
#n is limited to 9 million million million

	if n<=2 then
		return longint(n)
	fi

	f:=1L
	g:=2L
	to n-1 do
		f:=f*g
		g:=g+1L

	od
	return f
end

export proc isort(a,?ll,?rr)=
#inplace quicksort of a, which is anything that is indexable
#ll rr are used for recursive calls
	if ll.isvoid then
		ll:=a.lwb
		rr:=a.upb
	fi

	i:=ll
	j:=rr

	pivot:=a[(ll+rr)%2]

	repeat
		while pivot>a[i] and i<rr do ++i od
		while pivot<a[j] and j>ll do --j od
		if i<=j then
			swap(a[i],a[j])
			++i
			--j
		fi
	until i>j
	if ll<j then isort(a,ll,j) fi
	if i<rr then isort(a,i,rr) fi
end

export func sort(a)=
#quicksort a and return newly sorted list. Duplicates a then uses isort
	b::=a
	isort(b)
	return b
end

export func pcerror(m)=
#Force an interpreter error; advantage is that source location is reported.

	println "Internal error:",m
	a:=b+c
	return 0
end



!=========================================
export proc insert(&a, b, c)=
#insert value c just before index b
#c is always a single value; to insert a sequence c, use insertn()
	n:=a.upb
	a[n+1]:=c
	for i:=n downto b do
		swap(a[i+1],a[i])
	od
end

export proc isort2(a,b,?ll,?rr)=
#Like isort but also sorts b in parallel; sort order is determined by a however
	if ll.isvoid then
		ll:=a.lwb
		rr:=a.upb
	fi

	i:=ll
	j:=rr

	pivot:=a[(ll+rr)%2]

	repeat
		while pivot>a[i] and i<rr do ++i od
		while pivot<a[j] and j>ll do --j od
		if i<=j then
			swap(a[i],a[j])
			swap(b[i],b[j])
			++i
			--j
		fi
	until i>j
	if ll<j then isort2(a,b,ll,j) fi
	if i<rr then isort2(a,b,i,rr) fi
end

export func left(a,n=1)=
#return leftmost n elements of a (default left element)
#when n is negative, all except rightmost -n

	if n>=0 then
		return take(a,n)
	else
		return take(a,a.len+n)
	fi
end

export func right(a,n=1)=
#return rightmost n elements of a (default right element)
#when n is negative, all except leftmost -n

	if n>=0 then
		return drop(a,a.len-n)
	else
		return drop(a,-n)
	fi
end

export func reverse(a)=
#return reversed version of a
#when 0, returns empty
#when 1 element, returns a distinct, writeable copy

	if a.len=0 then
		return makeempty(a)
	fi
	b::=a

	if a then
		for i in a.bounds do
			b[a.upb-i+a.lwb]:=a[i]
		od
	fi
	return b
end

export func expandrange(a,step=1)=
#Turn range a into a list of inclusive values
	x::=()
	i:=a.lwb
	while i<=a.upb do
		x append:=i
		i+:=step
	od
	return x
end

export func head(a)=
#return first element, or empty when empty

	if a.len then
		return a[a.lwb]
	else
		return makeempty(a)
	fi
end

export func tail(a)=
#return all except the first element
#returns empty when only 0 or 1 elements

	case a.len
	when 0,1 then
		return makeempty(a)
	esac
	return a[2..$]
end

export func init(a)=
#return all except last element
#returns empty when only 0 or 1 elements
	case a.len
	when 0,1 then
		return makeempty(a)
	esac
	return a[a.lwb..$-1]
end

export func last(a)=
#return last element, or empty
	if a.len then
		return a[$]
	else
		return makeempty(a)
	fi
end

export func take(a,n)=
#return first n elements from list/string a
#returns () or "" when a is empty
#n > 0 (n<=0 returns empty)

	if a.len=0 or n<=0 then
		return makeempty(a)
	fi
	if n>=a.len then
		return a
	fi
	return a[a.lwb..a.lwb+n-1]
end

export func drop(a,n)=
#skips first n elements of a then returns the rest
#returns () when empty, or skipping the whole list
#n >= 0

	if a.len=0 or n>=a.len then
		return makeempty(a)
	fi
	if n<=0 then
		return a
	fi
	return a[a.lwb+n..$]
end

export func zip(a,b)=
#return a list consisting of alternate elements from a and b
#uses smaller of the two dimensions

	n:=min(a.len,b.len)
	c::=()

!	j:=a.lwb; k:=b.lwb
	(j, k) := (a.lwb, b.lwb)

	to n do
		c append:=a[j++]
		c append:=b[k++]
	od
	return c
end

export func repeatlist(a,n)=
#duplicate a n times, and return the result
#this ought to be built-in as a*n, but that's only implemented for a.len=1

	b:=makeempty(a)
	to n do
		b concat:=a
	od
	return b
end

!export func minimum(a)=
!#return minimum value of elements in a
!	if not a then
!		return void
!	fi
!	x:=head(a)
!	for y in tail(a) do
!		x min:=y
!	od
!	return x
!end
!
!export func maximum(a)=
!#return maximum value of elements in a
!	if not a then
!		return void
!	fi
!	x:=head(a)
!	for y in tail(a) do
!		x max:=y
!	od
!	return x
!end
!
!export func sumlist(a)=
!# apply "+" between all elements of a, and return result
!# all elements must be compatble (all strings or all numbers for example)
!# returns void then a is empty, or head(a) when just one element
!
!	if not a then
!		return void
!	fi
!	x:=head(a)
!	for y in tail(a) do
!		x +:=y
!	od
!	return x
!end

export proc delete(&a,?b)=
#delete element b
	n:=a.upb
	if b.isvoid then b:=n fi

	if n=b=1 then
		a::=()
		return
	fi

	if b>n then return fi
	if b<a.lwb then return fi
	for i:=b to n-1 do
		swap(a[i],a[i+1])			!swap is faster for complex elements
	od
!a[n]:=0		!don't leave any heap data beyond new end of list

	resize(a,n-1)
end

export proc resize(&a,n)=
#hange the upper bound of a to n

	if n<a.lwb then
		a:=makeempty(a)
		return
	fi

	a::=a[a.lwb..n]			!duplication forces original to be freed
end
 
export func makebits(data,t=bit)=
#turn data (list, array, or bit array of different type) into a bit array

	a:=new(bits,t,data.bounds)
	for i:=data.lwb to data.upb do
		a[i]:=data[i]
	od
	return a
end

export func makearray(data,t=i64)=
#turn data (list, array of different type, or bit array) into an array of 
#given element type

	a:=new(array,t,data.bounds)
	for i:=data.lwb to data.upb do
		a[i]:=data[i]
	od
	return a
end

export func tolist(a)=
#convert a, a string, array or bits, to a list, and return that list

	case a.basetype
	when array,string,bits then
		b:=new(list,a.bounds)
		for i,x in a do
			b[i]:=x
		od
		return b
!	when string then
!		b:=new(list,a.len)
!		i:=1
!		for i,x in a do
!			b[i++]:=x
!		od
!		return b

	when list then
		return a
	else
		pcerror("tolist:"+tostr(a.type))
	esac
	return 0
end

export func toarray(a,?t)=
#convert a, a list, string, array or bits, to an array, and return that array
#can be used to turn one array type into another
	case a.basetype
	when list then
		if t.isvoid then
			if a then
				t:=a[a.lwb].type
			else
				t:=i32
			fi
		fi

	when bits then
		if t.isvoid then
			t:=byte
		fi

	when string then
		if t.isvoid then t:=byte fi
		b:=new(array,t,a.len)
		foreach i,x in a do
			b[i]:=x
		od
		return b
	when array then
		if t.isvoid then
			return a
		fi
		u:=e.elemtype
		if t=u then return a fi
	else
		pcerror("toarray:"+tostr(a.type))
	esac
	b:=new(array,t,a.bounds)

	for i,x in a do
		b[i]:=x
	od
	return b
end

export func tobits(a,t=bit)=
#convert a, a list, array or other bit array, into a bit array

	case a.basetype
	when list,array then

	when bits then
		if a.elemtype=t then
			return a
		fi

	else
		pcerror("tobits:"+tostr(a.type))
	esac
	b:=new(bits,t,a.bounds)
	for i,x in a do
		b[i]:=x
	od
	return b
end

export func listtostring(a)=
#a should be a list or array
#interpreter elements as characters and form a single string
	s:=""
	for x in a do
		s+:=chr(x)
	od
	return s
end

export func qversion=
	return "4.0"
end

export proc issort(a,?ll,?rr)=
#Version of isort that works with dot-indexing

	if ll.isvoid then
		ll:=a.lwb
		rr:=a.upb
	fi

	i:=ll
	j:=rr

	pivot:=a.[(ll+rr)%2]

	repeat
		while pivot>a.[i] and i<rr do ++i od
		while pivot<a.[j] and j>ll do --j od
		if i<=j then
			swap(a.[i],a.[j])
			++i
			--j
		fi
	until i>j
	if ll<j then issort(a,ll,j) fi
	if i<rr then issort(a,i,rr) fi
end

export func ssort(a)=
#Version of sort() with dot-indexing, eg. strings, or int bits

	b::=a
	issort(b)
	return b
end

export func maketable(rows, cols, initval=0)=
#Create a table: a rectangular list, set to either 0 or to initval
#Each rows/cols is a range, or length

	row:=new(list,cols,initval)

	table::=new(list,rows)
	if rows.isint then rows:=1..rows fi

	for i in rows do
		table[i]::=row
	od

	return table
end

export func mapv(op,a)=
#Apply operator or suitable unary func to all elements of vector a,
#and return new list 
	b::=makeempty(a)
	for i,x in a do
			b[i]:=mapss(op,x)
	od
	return b
end

export func mapvv(op,a,b)=
#Apply op or func between corresponding elements of vectors a and b
	c::=makeempty(a)
	for i,x in a do
		c[i]:=mapss(op,x,b[i])
	od
	return c
end

export func mapvs(op,a,bs)=
#Apply op or func between elements of vector a and single value bs
	c::=makeempty(a)
	for i,x in a do
		c[i]:=mapss(op,x,bs)
	od
	return c
end

export func mapsv(op,as,b)=
#Apply op or func between elements of single value as and vector b
!	c::=makeempty(b)
	c::=()
	for i,x in b do
		c[i]:=mapss(op,as,x)
	od
	return c
end

export func openfile(name,option="rb")=
#Open a file for reading. Uses C's fopen and default option is for binary mode
#Return a valid file handle, which is an i64 value, or 0 when not found
	if not name.isstring or name="" then
		return 0
	fi
	return fopen(name,option)
end

export func createfile(name,options="wb")=
#Create a new file and return its handle, or 0 if there was an error
	if not name.isstring or name="" then return 0 fi
	return fopen(name,options)
end

export func closefile(f)=
#close the file associated with handle f
	return fclose(f)=0
end

export func checkfile(name)=
#return 1 if file name exists, otherwise 0
	file:=fopen(name,"rb")
	if file=0 then return 0 fi
	fclose(file)
	return 1
end

export func eof(f)=
#return 1 if at eof on currently open file handle f
	c:=fgetc(f)
	if c=-1 then return 1 fi

	ungetc(c,f)
	return 0
end

export func getfilesize(f)=
#return size of bytes of currently open file f
	p:=ftell(f)			!p=current position
	fseek(f,0,2)		!get eof position
	size:=ftell(f)		!size in bytes
	fseek(f,p,0)		!restore file position
	return size
end

export func getfilesize64(f)=
#return size of bytes of currently open file f
	p:=_ftelli64(f)			!p=current position
	_fseeki64(f,0,2)		!get eof position
	size:=_ftelli64(f)		!size in bytes
	_fseeki64(f,p,0)		!restore file position
	return size
end

export func setfilepos(f,offset)=
#set position in file f to given byte offset
	return fseek(f,offset,0)
end

export func getfilepos(f)=
#return current file position
	return ftell(f)
end

export func readrandom(f,mem,offset,size)=
#read size bytes from file f, to memory at mem, from given offset
#returns number of bytes read
#mem needs to be a pointer
#new file offset will be offset+size (or offset+byte read if smaller)
	fseek(f,offset,0)
	return fread(mem,1,size,f)
end

export func writerandom(f,mem,offset,size)=
#write size bytes from memory at mem, to current file f from given offset
#returns bytes written
	fseek(f,offset,0)
	return fwrite(mem,1,size,f)
end

export func readbytes(f,mem,size)=
#read size bytes from current position in file f to mem
	return fread(mem,1,size,f)
end

export func writebytes(f,mem,size)=
#write size bytes from mem to current position in f
	return fwrite(mem,1,size,f)
end

export func inbyte(file)=		!INBYTE
	return fgetc(file)
end

export func inword(file)=		!INWORD
	bb:=fgetc(file)
	return fgetc(file)<<8+bb
end

export func inlong(file)=		!INLONG
	ww:=inword(file)
	return inword(file)<<16+ww
end

export proc outbyte(file,x)=		!OUTBYTE
!writerandom(file,&x,getfilepos(file),1)
	fputc(x,file)
end

export proc outword(file,x)=		!OUTWORD
	outbyte(file,x iand 255)
	outbyte(file,x.[15..8])
end

export proc outlong(file,x)=		!OUTLONG
	outword(file,x iand 65535)
	outword(file,x>>16)
end

export func instring(file)=		!INSTRING
	s::=""
	do
		c:=inbyte(file)
		if c=0 then return s fi
		s+:=c
	od
	return s
end

export func appendfile(a,b)=
#append line-based text file a to file b

	f:=openfile(a)
	if f=0 then return 0 fi

	h:=openfile(b,"ab")
	if h=0 then return 0 fi

	while not eof(f) do
		readln @f,x:"l"
		println @h,x
	od

	closefile(f)
	closefile(h)
	return 1
end

export func readblockfile(filename,doetx=0)=
#read text file into a memory block
#block is allocated here
#return byte pointer to start of block, or nil
#doetx=1 to add etx byte to end

	f:=openfile(filename)
	if f=0 then return nil fi

	n:=getfilesize(f)
	readfilesize:=n

	s:=malloc(n+doetx)
	if s=0 then abort("Readfile/Malloc fails") fi
	sptr:=makeref(s,byte)

!	readrandom(f,&s,0,n)
	readrandom(f,s,0,n)

	if doetx then
		(sptr+n)^:=26
	fi

	closefile(f)
	return sptr
end

export func readstrfile(filename,doetx=0)=
#read text file into a single string
#return string, or 0 if there was an error

	f:=openfile(filename)
	if f=0 then return 0 fi

	n:=getfilesize(f)
	readfilesize:=n

	ptr:=malloc(n+1+doetx)
	if ptr=0 then abort("Readfile/Malloc fails") fi

	readrandom(f,ptr,0,n)
	if doetx then
		(makeref(ptr,byte)+n)^:=26
	fi

	closefile(f)

	s::=makestr(ptr,n+doetx)

	free(ptr)
	return s
end

export func writestrfile(filename,s)=
#read text file from a single string
#return status

	f:=createfile(filename)
	if f=0 then return 0 fi

	writerandom(f,makeref(s,byte),0,s.len)

	return closefile(f)
end

export func readbinfile(filename)=
#read binary file into byte array
#return () (empty list not array) on error

	f:=openfile(filename)
	if f=0 then return 0 fi

	n:=getfilesize(f)
	readfilesize:=n

	a:=new(array,byte,n)
	readrandom(f,&a,0,n)

	closefile(f)
	return a
end

export func writebinfile(filename,a)=
#write binary file from byte array a
#return status 1/0

	f:=createfile(filename)
	if f=0 then return 0 fi

	writerandom(f,(&a),0,a.len)

	closefile(f)
	return 1
end

export func writeblockfile(filename,p,length)=
#return status 1/0

	f:=createfile(filename)
	if f=0 then return 0 fi

	if not writerandom(f,p,0,length) then return 0 fi

	closefile(f)
	return 1
end

export func erasefile(filename)=
#delete given file, return status (check msdn)
	return remove(filename)
end

export func renamefile(oldfilename,newfilename)=
#rename file, return status (check msnd)
	return rename(oldfilename,newfilename)
end

export func readtextfile(file)=
#read text file into a list of strings; one per line
#return list, or 0 on error
	f:=openfile(file)
	if not f then
		return 0 
	fi

	readfilesize:=getfilesize(f)
	a::=()

	while not eof(f) do
		a append:= sreadln(f)
	od
	closefile(f)
	return a
end

export func writetextfile(file,a)=
#write list of strings <a> as a text file <file>
	f:=createfile(file)
	if not f then return 0 fi

	for i:=a.lwb to a.upb do
		println @f,a[i]
	od
	closefile(f)
	return 1
end

export func readbinaryfile(filename,t)=
#read binary file consisting of an array of type t values, into array of t
#return () (empty list not array) on error

	f:=openfile(filename)
	if f=0 then return () fi

	n:=getfilesize(f)
	readfilesize:=n
	elems:=n%t.bytes

	a:=new(array,t,elems)
	readrandom(f,&a,0,n)

	closefile(f)
	return a
end

export func writebinaryfile(filename,data)=
#write binary file from array of a fixed type to a file
#return 1/0 status
	return writeblockfile(filename,&data,data.bytes)
end

export func confirm(m,caption="Confirm",default=1)=
#Pop-up box to ask for confirmationdefault=1/2/3 for yes/no/cancel button
#Return 1 or 0

	flags:=0x20000+0x20	!foreground window/question mark icon
	flags ior:=3		!yes/no/cancel

	flags ior:=(default|0,0x100,0x200|0)

	status:=messagebox(nil,m,caption,flags)
	return status=6
end

export func messagebox(a=nil,mess,caption="Caption",d=0)=
#Standard Windows' Messagebox
	return messageboxa(nil,mess,caption,d)
end

export proc beep1=
#Standard beep
	messagebeep(0)
end

export proc mem(mess)=
	static var startmem
	if startmem.isvoid then
		startmem:=$smallmemtotal()
	fi
	println mess,,":",$smallmemtotal()-startmem
end

export func reduce(op, a)=
	x:=head(a)
	for y in tail(a) do
		x:=mapss(op,x,y)
	od
	x
end
