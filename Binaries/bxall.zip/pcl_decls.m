global type object	= ref objrec
global type variant	= ref varrec
global type pcl		= ref pclrec

global record varrec =
	union
		struct
			union
				struct
					byte	tag
					byte	hasref
					byte	bitoffset
					union
						byte	bitlength		!for refbit/tbit: 0=1 bit, N=bitfield
						byte	exceptiontype
!						byte	genmarker		!1 means is a generator used as a marker
					end
				end
				u32		tagx
			end
			union
				u32 		elemtag
				u32 		frameptr_low
				struct
					i16		frameoffset
					i16		nexceptions
				end
			end
		end
		i64 dummy: (skip:16, range_lower:48)
	end
	union
		i64		value
		r64		xvalue
		u64		uvalue
		u64		range_upper
		object		objptr				!objects where hasref=1
		variant		varptr				!for refvar
		ref byte	ptr					!for refproc etc
		symbol		def					!for tsymbol
		pcl			retaddr
		pcl			labelref
	end
end

global record objrec =
!1st 8 bytes
	u32 refcount
	struct
		byte flags: (lower:1, mutable:1, bittag:2)
		byte objtype
		union
			u16 elemtag
			u16 usertag
			u16 itertag
			struct
				byte bitoffset
				byte indexoffset
			end
			i16 lower16
!			i16 iterended		!0/1 = running/ended
		end
	end

!second 8 bytes (and end of short objects)
	union
		struct
			union
				i64		value
				r64		xvalue
				u64		uvalue
				ichar		strptr
				variant		varptr
				variant		genstack
				ref byte	ptr
!*!				ref[0:]elemtype num
				u64 b
				ref int		retaddr
			end

!3rd 8 bytes
			union
				i64 length
				i64 lower64
				struct
					u32 rows
					u32 columns
				end
				u64 c
				ref byte frameptr
!				symbol		stgen
				struct
					i32 iterpos
					i32 iterupper
				end
			end

!4th 8 bytes (and end of long objects)
			union
				i64 alloc64				!object/item counts, not bytes
				object objptr2
				struct
					i16 neg
					i16 numtype
					i32 expon
				end
				struct
					u32 alloc32
					u32 dictitems
				end
				struct
					u16		genstacksize		!in varrecs
					byte	ngenparams			!params to gen func
				end
				u64 d
			end
		end
		[24]byte bignumdescr
	end
end

global record pclrec =
	ref label labaddr
	byte opcode
	byte n						! n		nargs/etc
	byte SPARE					! t		0/void, or optional type annotation info, or pushas code
	byte flags:(haslabel:1,		!       1 when this instr is referenced as a label
				isaux:1)		!		1 when part of a compound bytecode seq
	union
		struct
			i16 x, y					! x y	Misc
		end
		i32 xy
	end

	union						! Main operand codes
		symbol	def				! d v p
		i64		value			! i
		u64		uvalue			! w
		r64		xvalue			! r
		ichar	svalue			! s
		int		labelno			! l
		int		index			! g
		pcl		labelref		! l
		i64		offset			!
		object	objptr			! z
		i64		typecode		! z
		byte	mathscode		! m		for kmaths/2: mm_sqrt etc
		byte	pclop			! o		for (+) etc
		byte	bintoindex		! b		index into bintotable
		i64		hostindex		! x		
		variant	varptr			!
		struct
			i32	usertag			! u		!these attributes overlap main operand
			i32	usertag2		! v
		end
	end

	union
		u64 pos: (dummy:16, lineno:24, column:10, fileno:10)
		posrec posx
		u16 mode				! var, or annotated type code
	end
end

global enumdata [0:]ichar opndnames=
							!   PCL1		PCL2
	(cnone=0,	$),
	(cstatic,	$),			! m Symbol		varptr = address of static variable
	(cframe,	$),			! f Symbol		offset = offset of stack frame var
	(cproc,		$),			! p Symbol		labelref = address of kprocent instr for proc
	(cdllproc,	$),			! x Int			index = index into dllproc table

	(cgenfield,	$),			! g Symbol		index = index into genfieldtable

	(clabel,	$),			! l labelref*	labelref = addr of pcl instr, displayed as pc index
!											(* will be label index until end of codegen)
	(cint,		$),			! i
	(creal,		$),			! r
	(cstring,	$),			! s Stringz		objptr = address of static Object with string
	(cstringz,	$),			! z Stringz
	(ctype,		$),			! t Int			Typecode
	(csymbol,	$),			! d Symbol		Symbol
	(coperator,	$),			! o Int			Operator
	(cmaths,	$),			! m Int			Mathsop
	(chost,		$),			! h Int			Host index
	(cbinto,	$),			! b Int	pclop	Index into bintotable

	(clast,		"?")
end

!these aliases are used so that the enum table is tidier
const p = cproc
const m = cstatic
const f = cframe
const l = clabel
const x = cdllproc
const g = cgenfield
const i = cint
const r = creal
const s = cstring
const z = cstringz
const t = ctype
const d = csymbol
const o = coperator
const b = cbinto
const y = cmaths
const h = chost

global enumdata  [0:]ichar pclnames, [0:]byte pclopnd, [0:]u32 pclattrs =
	(knop = 0,  $,  0, '    '),   ! simple nop
	(kskip,     $,  0, '    '),   ! ignore on pcl listing

	(kprocdef,  $,  d, '    '),   ! 
	(kprocent,  $,  0, 'n   '),   ! n=number of locals; 
	(kprocend,  $,  0, '    '),  
	(kendmod,   $,  0, '    '),
	(kcomment,  $,  0, '    '),
                                   
	(kpushm,    $,  m, '    '),   ! Push v
	(kpushf,    $,  f, '    '),   ! Push v
	(kpushmref, $,  m, '    '),   ! push &v
	(kpushfref, $,  f, '    '),   ! push &v
	(kpushlab,  $,  l, '    '),   ! push L
	(kpushci,   $,  i, '    '),   ! Push i
	(kpushvoid, $,  0, '    '),   ! Push void 
	(kpushnil,  $,  0, '    '),   ! Push nil (ref void)
	(kpushcr,   $,  r, '    '),   ! Push r
	(kpushcs,   $,  s, '    '),   ! Push constant string object

	(kpushtype, $,  t, '    '),   ! Push type constant
	(kpushopc,  $,  o, '    '),   ! Push operator constant
	(kpushsym,  $,  d, '    '),   ! Push symbol reference
	(kpushptr,  $,  0, '    '),   ! Z' := Z^

	(kpopm,     $,  m, '    '),   ! v := Z
	(kpopf,     $,  f, '    '),   ! v := Z
	(kpopptr,   $,  0, '    '),   ! Z^ := Y

	(kzpopm,    $,  m, '    '),   ! v := Z; don't free v first (static should be zeroed)
	(kzpopf,    $,  f, '    '),   ! v := Z; don't free v first

	(kdupl,     $,  0, '    '),   ! (Z',Y') := (share(Z), Z)
	(kcopy,     $,  0, '    '),   ! Z' := deepcopy(Z)
	(kswap,     $,  0, '    '),   ! swap(Z^, Y^)

	(kconvrefp, $,  0, '    '),   ! Change ref in Z to refpacked

	(kjump,     $,  l, '    '),   ! Jump to L
	(kjumpptr,  $,  0, '    '),   ! Jump to Z

	(kjumpt,    $,  l, '    '),   ! Jump to L when Z is true
	(kjumpf,    $,  l, '    '),   ! Jump to L when Z is false

	(kjumpeq,   $,  l, '    '),   ! Jump to L when Y = Z
	(kjumpne,   $,  l, '    '),   ! Jump to L when Y <> Z
	(kjumplt,   $,  l, '    '),   ! Jump to L when Y < Z
	(kjumple,   $,  l, '    '),   ! Jump to L when Y <= Z
	(kjumpge,   $,  l, '    '),   ! Jump to L when Y >= Z
	(kjumpgt,   $,  l, '    '),   ! Jump to L when Y > Z

!	(kjmpltfci, $,  l, '    '),   ! Jump to L when B < C (B/C in next two ops)

	(kwheneq,   $,  l, '    '),   ! Y = Z:  pop both, jump to L
								  ! Y <> Z: pop Z only, step to next

	(kwhenne,   $,  l, '    '),	  ! Y <> Z:  pop Z only, jump to L
								  ! Y = Z:   pop both, step to next

	(kjumplab,  $,  l, '    '),   ! Jumptable entry

!	(kswitch,   $,  l, 'xy  '),   ! Jumptable has y-x+1 entries
	(kswitch,   $,  0, 'xy  '),   ! Jumptable has y-x+1 entries

	(ktom,      $,  l, '    '),   ! --v; jump to l when v<>0 in next op
	(ktof,      $,  l, '    '),   ! --v; jump to l when v<>0 in next op

	(kformci,   $,  l, '    '),   ! ++v; jump to l when v<=i in next 2 ops: pushm/pushci
	(kforfci,   $,  l, '    '),   ! ++v; jump to l when v<=i in next 2 ops: pushm/pushci

	(kformm,    $,  l, '    '),   ! ++v; jump to l when v<=v in next 2 ops
	(kforff,    $,  l, '    '),   ! ++v; jump to l when v<=v in next 2 ops

	(kcallproc, $,  p, 'n   '),   ! Call &A; n is no. args
	(kcallptr,  $,  0, 'n   '),   ! Call X^; n is no. of params supplied; x is stack adjust
	(kretproc,  $,  0, 'nx  '),   ! n/x are params/locls to free; Return from proc
	(kretfn,    $,  0, 'nxy '),   ! n/x are params/locals to free; y=retval offset in caller; ret from fn
!	(kpopret,   $,  i, '    '),   ! pop stack to caller's return slot; i = offset

	(kmodcall,  $,  d, '    '),   ! 
	(kmodret,   $,  0, '    '),   ! 

	(kcalldll,  $,  x, 'n   '),   ! Call dll function d (sysmbol); n=nargs

	(kcallhost, $,  h, '    '),   ! Call Q host function h (Host index)

	(kunshare,  $,  0, 'n   '),   ! Unshare and pop A var values on stack
	(kaddsp,    $,  0, 'n   '),   ! SP+:=A; note: positive A will push, negative will pop (reverse of the hardware)

	(kstop,     $,  0, 'n   '),   ! Stop program with stopcode Z; n=1 to stop runproc instead

	(kmakelist, $,  0, 'xy  '),   ! x items on stack; make list with lwb y
	(kmakevrec, $,  0, 'xu  '),   ! x items on stack; make record of type u
	(kmakeax,   $,  0, 'xyuv'),   ! x items on stack; make array with lwb y, type u and elemtype v
	(kmakebits, $,  0, 'xyuv'),   ! x items on stack; make bits with lwb y, type u and elemtype v
	(kmaketrec, $,  0, 'xu  '),   ! x items on stack; make struct with type u
	(kmakeset,  $,  0, 'x   '),   ! x items on stack; make set
	(kmakerang, $,  0, '    '),   ! 2 items on stack; make range
	(kmakedict, $,  0, 'x   '),   ! x*2 items on stack (x key:val items); make dict
	(kmakedec,  $,  0, '    '),   ! Turn string on stack to decimal number

	(kincrptr,  $,  0, 'x   '),   ! Z^ +:= x
	(kincrtom,  $,  m, 'x   '),   ! v +:= x
	(kincrtof,  $,  f, 'x   '),   ! v +:= x
	(kloadincr, $,  0, 'x   '),   ! T := Z^; Z^ +:= x; Z' := T
	(kincrload, $,  0, 'x   '),   ! Z^ +:= x; Z' := Z^

	(kneg,      $,  0, '    '),   ! Z':= -Z
	(kabs,      $,  0, '    '),   ! Z' := abs Z
	(knotl,     $,  0, '    '),   ! Z' := not Z
	(kbitnot,   $,  0, '    '),   ! Z' := inot Z
	(kistruel,  $,  0, '    '),   ! Z' := istrue Z
	(kasc,      $,  0, '    '),   ! Z' := asc(Z)
	(kchr,      $,  0, '    '),   ! Z' := chr(Z)
	(ksqr,      $,  0, '    '),   ! Z' := Z*Z

	(kmaths,    $,  y, '    '),   ! Z' := op(Z)
	(kmaths2,   $,  y, '    '),   ! Z' := op(Y, Z)

	(kunaryto,  $,  o, '    '),   ! Z^ op:= Z
	(knotlto,   $,  0, '    '),   ! Z^ not:= Z

	(klen,      $,  0, '    '),   ! Z' := Z.len
	(klwb,      $,  0, '    '),   ! Z' := Z.lwb
	(kupb,      $,  0, '    '),   ! Z' := Z.upb
	(kbounds,   $,  0, 'n   '),   ! Z' := Z.bounds; n=1: one range value; n=2: two dims
	(kbytesize, $,  0, '    '),   ! Z' := Z.bytesize

	(ktype,     $,  0, 'n   '),   ! Z' := n=0/1/2 = basetype/elemtype
	(kdictsize, $,  0, '    '),   ! Z' := Z.dictsize
	(kisfound,  $,  0, '    '),   ! Z' := Z.isfound
	(kminval, 	$,  0, '    '),   ! Z' := Z.minvalue
	(kmaxval, 	$,  0, '    '),   ! Z' := Z.maxvalue

	(kistype,   $,  t, '    '),   ! Z' := Z.type/etc = t
	(kisvoid,   $,  0, 'n   '),   ! Z' := Z.isvoid (n=0) or not Z.isdef (n=1)
	(kconvert,  $,  t, '    '),   ! Z' := t(Z)
	(ktypepun,  $,  t, '    '),   ! Z' := t@(Z)

	(kadd,      $,  0, '    '),   ! Z' := Y + Z
	(ksub,      $,  0, '    '),   ! Z' := Y - Z
	(kmul,      $,  0, '    '),   ! Z' := Y * Z
	(kdiv,      $,  0, '    '),   ! Z' := Y / Z
	(kidiv,     $,  0, '    '),   ! Z' := Y % Z
	(kirem,     $,  0, '    '),   ! Z' := Y rem Z
	(kidivrem,  $,  0, '    '),   ! (Y', Z') := Y divrem Z
	(kbitand,   $,  0, '    '),   ! Z' := Y iand Z
	(kbitor,    $,  0, '    '),   ! Z' := Y ior Z
	(kbitxor,   $,  0, '    '),   ! Z' := Y ixor Z
	(kshl,      $,  0, '    '),   ! Z' := Y << Z
	(kshr,      $,  0, '    '),   ! Z' := Y >> Z
	(kin,       $,  0, 'n   '),   ! Z' := Y in Z (n=0) or Y not in Z (n=1)
	(kinx,      $,  0, '    '),   ! Z' := Y inx Z
	(kcmp,      $,  0, 'c   '),   ! Z' := Y c Z
	(kmin,      $,  0, '    '),   ! Z' := min(Y, Z)
	(kmax,      $,  0, '    '),   ! Z' := max(Y, Z)
	(kconcat,   $,  0, '    '),   ! Z' := concat(Y, Z) or Y && Z
	(kappend,   $,  0, '    '),   ! Z' := append(Y, Z) or Y & Z
	(ksame,     $,  0, '    '),   ! Z' := Y == Z

	(kpower,    $,  0, '    '),   ! Z' := Y ** Z

	(kbinto,    $,  b, '    '),   ! Z^ op:= Y

	(kandlto,   $,  0, '    '),   ! Y^ and:= Z
	(korlto,    $,  0, '    '),   ! Y^ or:= Z
	(kconcatto, $,  0, '    '),   ! Y^ concat:= Z or Y^ &&:= Z
	(kappendto, $,  0, '    '),   ! Y^ append:= Z or Y^ &:= Z

	(kdot,      $,  g, '    '),   ! Z' := Z.g
	(kpopdot,   $,  g, '    '),   ! Z.g := Y
	(kdotref,   $,  g, '    '),   ! Z' := &Z.g

	(kindex,    $,  0, '    '),   ! Z' := Y[Z]
	(kpopix,    $,  0, '    '),   ! Z' := Y[Z]:=X
	(kindexref, $,  0, '    '),   ! Z' := &Y[Z]

	(kkeyindex, $,  0, '    '),   ! Z' := X{Y, Z}
	(kpopkeyix, $,  0, '    '),   ! Y{Z} := X
	(kkeyixref, $,  0, '    '),   ! Z' := &X{Y, Z}

	(kdotix,    $,  0, '    '),   ! Z' := Y.[Z]
	(kpopdotix, $,  0, '    '),   ! Y.[Z] := X
	(kdotixref, $,  0, '    '),   ! Z' := &Y.[Z]

	(kexpand,   $,  0, 'n   '),   ! Z' := Expand Z into n objects are needed

	(kpushtry,  $,  l, 'xy  '),   ! Push try/except into; label/except code/no. exceptions
	(kraise,    $,  0, 'x   '),   ! Raise exception Z
	(kmap,      $,  0, '    '),   ! Z' := map(Y, Z)

	(kbox,      $,  0, '    '),   ! To be worked out
	(kunbox,    $,  0, '    '),   !

end

global record genfieldrec=
	symbol def
	ref genfieldrec nextdef
end

global const maxgenfield=1000
global [maxgenfield]ref genfieldrec genfieldtable
global int ngenfields

global pcl stopseq		!point to a 'stop 0' sequence
global pcl raiseseq		!point to a sequence of several 'raise' cmdcodes
