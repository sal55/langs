
export type wt_word		= u16
export type wt_bool		= u32
export type wt_dword	= u32
export type wt_wchar	= u16
export type wt_char		= byte
export type wt_ichar	= ref char
export type wt_string	= ref char
export type wt_ptr		= ref byte
export type wt_wndproc	= u64

export type wt_handle	= ref void
export type wt_int		= i32
export type wt_uint		= u32
export type wt_long		= i32
export type wt_wparam	= u64
export type wt_lparam	= u64
export type wt_size		= u64

export type wt_wparam32	= u32
export type wt_lparam32	= u32
export type wt_handle32	= u32
export type wt_ptr32	= u32
export type wt_string32	= u32
export type wt_wndproc32	= u32

export type wt_wparam64	= u64
export type wt_lparam64	= u64
export type wt_handle64	= u64
export type wt_ptr64	= u64
export type wt_string64	= u64
export type wt_wndproc64= u64

export type wt_result	= u64
export type wt_intptr	= u64
export type wt_coord	= u32

export type ws_spoint= struct
	i16 x,y
end

export type ws_srect=struct
	i16 leftx,top, rightx,bottom
end

export type ws_charinfo=struct
	union
		wt_word	unicodechar
		wt_char	asciichar
	end union
	wt_word		attributes
end

export type ws_palette16=[0..15]i32

export type ws_console=struct
	ws_spoint size,pos
	wt_word attributes
	ws_srect window
	ws_spoint maxwindowsize
end

export type ws_consoleex=struct
	i32 recsize
	ws_spoint size,pos
	wt_word attributes
	ws_srect window
	ws_spoint maxwindowsize
	wt_word wpopup
	i32 fullscreen
	ws_palette16 palette
end

export type ws_keyevent = struct $caligned
	wt_word	eventtype
		wt_bool	keydown
		wt_word	repeatcount
		wt_word	virtualkeycode
		wt_word	virtualscancode
		union
			wt_word unicodechar
			wt_char asciichar
		end
		wt_dword controlkeystate
end

export type ws_cursor=struct
	i32 size,visible
end

export var hconsole, hconsolein

export const stdoutputhandle=0xffff_fff5
export const stdinputhandle=0xfffffff6
export const stderrorputhandle=0xfffffff4
export const invalidhandlevalue=0xffffffff

export const maxpathlen=260

type spath=[maxpathlen]char
type sshort=[14]char
!
export type ws_filetime=struct
	i32 ftlow
	i32 fthigh
end

export type ws_finddata=struct
	i32		fileattributes
	ws_filetime	creationtime
	ws_filetime	lastaccesstime
	ws_filetime	lastwritetime
	i32		filesizehigh
	i32		filesizelow
	i32		reserved0
	i32		reserved1
	spath		filename
	sshort		shortfilename
end

export type ws_systemtime = struct
	u16	year
	u16	month
	u16	dayofweek
	u16	day
	u16	hour
	u16	minute
	u16	second
	u16	milliseconds
end

export type ws_msg64 = struct $caligned
	ref void	hwnd
	i32		message
	i64		wparam
	i64		lparam
	i32		time
	i32		ptx
	i32		pty
end

export type ws_point = struct
	i32 x, y
end

export type ws_rect=struct		!rect record occupying 16 bytes
	union
		struct
			i32 leftx,top, rightx,bottom
		end
		struct
			union i32 x,x1 end
			union i32 y,y1 end
			i32 x2,y2
		end
	end
end

export type ws_logbrush = struct
	i32 lbstyle
	i32 lbcolour
	i32 lbhatch
end

export type ws_textmetrics = struct
	i32	height
	i32	ascent
	i32	descent
	i32	i32ernalleading
	i32	externalleading
	i32	avecharwidth
	i32	maxcharwidth
	i32	weight
	i32	overhang
	i32	digitizedaspectx
	i32	digitizedaspecty
	byte	firstchar
	byte	lastchar
	byte	defaultchar
	byte	breakchar
	byte	italic
	byte	underlined
	byte	struckout
	byte	pitchandfamily
	byte	charset
end
!=========================================

export type ws_bitmapv5header = struct
	i32	size
	i32	width
	i32	height
	u16	planes
	u16	bitcount
	i32	compression
	i32	sizeimage
	i32	xpelspermeter
	i32	ypelspermeter
	i32	clrused
	i32	clrimportant
	i32	redmask
	i32	greenmask
	i32	bluemask
	i32	alphamask
	i32	cstype
	[1..9]i32 endpoints
	i32	redgamma
	i32	greengamma
	i32	bluegamma
	i32	intent
	i32	profiledata
	i32	profilesize
	i32	reserved
end

export type ws_bitmapfileheader = struct
	wt_word		typex
	wt_dword	size
	wt_word		res1, res2
	wt_dword	offbits
end

export type ws_bitmapinfoheader = struct
	wt_dword 	size
	wt_long		width
	wt_long		height
	wt_word		planes
	wt_word		bitcount
	wt_dword	compression
	wt_dword	sizeimage
	wt_long		xpelspermetre
	wt_long		ypelspermetre
	wt_dword	clrused
	wt_dword	clrimportant
end

export type ws_paintstruct = struct
!	i64		hdc
	i64		hdc
	i32		erase
	ws_rect		paintrect
	i32		restore
	i32		incupdate
	[32]byte	rgbreserved
end

!32-BIT VERSION
export type ws_openfilename32 = struct
	wt_dword		structsize
	wt_handle32		owner
	wt_handle32		instance
	wt_string32		filter
	wt_string32		customfilter
	wt_dword		maxcustfilter
	wt_dword		filterindex
	wt_string32		file
	wt_dword		maxfile
	wt_string32		filetitle
	wt_dword		maxfiletitle
	wt_string32		initialdir
	wt_string32		title
	wt_dword		flags
	wt_word			fileoffset
	wt_word			fileextension
	wt_string32		defext
	wt_lparam32		custdata
	wt_wndproc32	hook
	wt_string32		templatename
	wt_ptr32		reserved1
	wt_dword		reserved2
	wt_dword		flagsex
end

!64-BIT VERSION
export type ws_openfilename64 = struct $caligned
	wt_dword		structsize
	wt_handle64		owner
	wt_handle64		instance
	wt_string64		filter
	wt_string64		customfilter
	wt_dword		maxcustfilter
	wt_dword		filterindex
	wt_string64		file
	wt_dword		maxfile
	wt_string64		filetitle
	wt_dword		maxfiletitle
	wt_string64		initialdir
	wt_string64		title
	wt_dword		flags
	wt_word			fileoffset
	wt_word			fileextension
	wt_string64		defext
	wt_lparam64		custdata
	wt_wndproc64	hook
	wt_string64		templatename
	wt_ptr64		reserved1
	wt_dword		reserved2
	wt_dword		flagsex
end

importdll kernel32=
	func	"GetLastError"					:wt_dword
	func	"GetStdHandle"					(wt_dword)wt_handle
	func	"WriteConsoleA" as writeconsole				(wt_handle,wt_string,wt_dword,wt_ptr,wt_ptr)wt_bool
	func	"SetConsoleCursorPosition"		(wt_handle,wt_coord)wt_bool
	func	"GetConsoleScreenBufferInfo"	(wt_handle,wt_ptr)wt_bool
	func	"SetConsoleMode"				(wt_handle,wt_dword)wt_bool
	func	"WriteConsoleOutputA" as writeconsoleoutput			(wt_handle,wt_ptr,wt_coord,wt_coord,wt_ptr)wt_bool

	func	"GetConsoleScreenBufferInfoEx"	(wt_handle,wt_ptr)wt_bool
	func	"SetConsoleScreenBufferInfoEx"	(wt_handle,wt_ptr)wt_bool
	func	"GetConsoleWindow"				:wt_handle

	func	"SetConsoleTextAttribute"		(wt_handle,wt_word)wt_bool
	func	"SetConsoleTitleA" as setconsoletitle				(wt_string)wt_bool
	func	"ReadConsoleInputA" as readconsoleinput			(wt_handle,wt_ptr,wt_dword,wt_ptr)wt_bool
	func	"PeekConsoleInputA"			(wt_handle,wt_ptr,wt_dword,wt_ptr)wt_bool
	func	"FlushConsoleInputBuffer"		(wt_handle)wt_bool
	func	"SetConsoleWindowInfo"			(wt_handle,wt_bool,wt_ptr)wt_bool
	func	"SetConsoleScreenBufferSize"	(wt_handle,wt_coord)wt_bool
	func	"GetConsoleCursorInfo"			(wt_handle,wt_ptr)wt_bool
	func	"SetConsoleCursorInfo"			(wt_handle,wt_ptr)wt_bool
	func	"GetNumberOfConsoleInputEvents"(wt_handle,wt_ptr)wt_bool

	func	"FindFirstFileA" as findfirstfile		(ref char,ref i32)i32
	func	"FindNextFileA"  as findnextfile			(i32,ref i32)i32
	func	"FindClose"					(i32)i32
	func	"SetCurrentDirectoryA" as setcurrentdirectory	(ref char)i32
	func	"GetCurrentDirectoryA" as getcurrentdirectory	(i32,i32)i32
	func	"CreateDirectoryA" as createdirectory		(ref char,i32)i32
	func	"GetFileAttributesA"			(ref char)i32
	func	"GetModuleHandleA" as getmodulehandle		(wt_string)wt_handle
	func	"GetTickCount"								:wt_dword
	func	"GlobalAlloc"									(wt_uint,wt_size)wt_handle
	func	"GlobalLock"									(wt_handle)wt_ptr
	func	"GlobalUnlock"								(wt_handle)wt_bool
	func	"GlobalSize"									(wt_handle)wt_size

	func	"GetSystemTime"(ref byte)i32
	func	"Beep"							(wt_dword, wt_dword)wt_bool
	func	"SetConsoleCP"								(wt_uint)wt_bool
	func	"GetCommandLineA" : ref char
end

importdll user32=
	func	"CreateWindowExA" as createwindowex		(wt_dword, wt_string, wt_string, wt_dword, wt_int,wt_int,wt_int,wt_int,
													 wt_handle, wt_handle, wt_handle, wt_ptr)wt_handle

	func "GetMessageA" as getmessage				(wt_ptr, wt_handle, wt_uint, wt_uint)wt_bool
	func "TranslateMessage"							(wt_ptr)wt_bool
	func "DispatchMessageA" as dispatchmessage		(wt_ptr)wt_result
	func "SetTimer"									(wt_handle,wt_intptr,wt_uint,wt_ptr)wt_intptr
	func "KillTimer"								(wt_handle,wt_intptr)wt_bool
	func "SystemParametersInfoA"					(wt_uint,wt_uint,wt_ptr,wt_uint)wt_bool
	func "GetSystemMetrics"							(wt_int)wt_int
!	func "CreateMenu"								:int
	func "AppendMenuA" as appendmenu				(wt_handle,wt_uint,wt_intptr,wt_string)wt_bool
	func "GetDC"									(wt_handle)wt_handle
	func "ReleaseDC"								(wt_handle,wt_handle)wt_int

	func "SendMessageA" as sendmessage				(wt_handle,wt_uint,wt_wparam,wt_lparam)wt_result
	func "PostMessageA" as postmessage				(wt_handle,wt_uint,wt_wparam,wt_lparam)wt_bool
	func "PeekMessageA" as peekmessage				(wt_ptr,wt_handle,wt_uint,wt_uint,wt_uint)wt_bool
	func "BeginPaint"								(wt_handle,wt_ptr)wt_handle
	func "EndPaint"									(wt_handle,wt_ptr)wt_bool
	proc "PostQuitMessage"							(wt_int)
	func "LoadIconA" as loadicon					(wt_handle,wt_string)wt_handle
	func "LoadCursorA" as loadcursor				(wt_handle,wt_string)wt_handle
	func "SetCursor"								(wt_handle)wt_handle
	func "DrawMenuBar"								(wt_handle)wt_bool
	func "GetSystemMenu"							(wt_handle,wt_bool)wt_handle
	func "CreateMenu"								:wt_handle
	func "CreatePopupMenu"							:wt_handle
	func "DestroyMenu"								(wt_handle)wt_bool
	func "CheckMenuItem"							(wt_handle,wt_uint,wt_uint)wt_dword
	func "EnableMenuItem"							(wt_handle,wt_uint,wt_uint)wt_bool
	func "GetSubMenu"								(wt_handle,wt_int)wt_handle
	func "GetMenuItemID"							(wt_handle,wt_int)wt_uint
	func "GetMenuItemCount"							(wt_handle)wt_int
	func "InsertMenuA" as insertmenu				(wt_handle,wt_uint,wt_uint,wt_intptr,wt_string)wt_bool
	func "ModifyMenuA" as modifymenu				(wt_handle,wt_uint,wt_uint,wt_intptr,wt_string)wt_bool
	func "RemoveMenu"								(wt_handle,wt_uint,wt_uint)wt_bool
	func "DeleteMenu"								(wt_handle,wt_uint,wt_uint)wt_bool

	func "DestroyWindow"							(wt_handle)wt_bool
	func "InvalidateRect"							(wt_handle,wt_ptr,wt_bool)wt_bool
	func "ValidateRect"							(wt_handle,wt_ptr)wt_bool
	func "ShowWindow"								(wt_handle,wt_int)wt_bool
	func "GetClassLongA" as getclassint			(wt_handle,wt_int)wt_word
	func "SetClassLongA" as setclasslong			(wt_handle,wt_int,wt_dword)wt_word
	func "SetWindowTextA" as setwindowtext			(wt_handle,wt_string)wt_bool
	func "GetWindowTextA" as getwindowtext			(wt_handle,wt_string,wt_int)wt_int
	func "GetWindowTextLengthA" as getwindowtextlength	(wt_handle)wt_int
	func "GetKeyState"								(wt_int)wt_word

!	func "GetWindowLongPtrA" as getwindowlongptr	(wt_handle,wt_int)i64
!	func "SetWindowLongPtrA" as setwindowlongptr	(wt_handle,wt_int,wt_int)i64
	func "GetWindowLongA" as getwindowlongptr		(wt_handle,wt_int)i64
	func "SetWindowLongA" as setwindowlongptr		(wt_handle,wt_int,i64)i64

	func "GetClientRect"							(wt_handle,wt_ptr)wt_bool
	func "ClientToScreen"							(wt_handle,wt_ptr)wt_bool
	func "ScreenToClient"							(wt_handle,wt_ptr)wt_bool
	func "GetWindowRect"							(wt_handle,wt_ptr)wt_bool
	func "GetSysColor" as getsyscolour				(wt_int)wt_dword
	func "GetScrollInfo"							(wt_handle,wt_int,wt_ptr)wt_bool
	func "GetMenu"									(wt_handle)wt_handle
	func "SetMenu"									(wt_handle,wt_handle)wt_ptr
	func "TrackPopupMenu"							(wt_handle,wt_uint,wt_int,wt_int,wt_int,wt_handle,wt_ptr)wt_bool
	func "GetMenuState"								(wt_handle,wt_uint,wt_uint)wt_uint
	func "MessageBoxA" 								(wt_handle a=nil,wt_string message, wt_string caption="Caption", wt_uint b=0)wt_int
	func "OpenClipboard"							(wt_handle)wt_bool
	func "CloseClipboard"							:wt_bool
	func "EmptyClipboard"							:wt_bool
	func "GetClipboardData"							(wt_uint)wt_handle
	func "SetClipboardData"							(wt_uint,wt_handle)wt_handle
	func "MessageBeep"								(wt_uint x=0)wt_bool
	func "SetActiveWindow"							(wt_handle)wt_handle
	func "SetForegroundWindow"						(wt_handle)wt_bool
end

importdll gdi32=
	func "Rectangle"								(wt_handle,wt_int,wt_int,wt_int,wt_int)wt_bool
	func "RoundRect"								(wt_handle,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int)wt_bool
	func "Ellipse"									(wt_handle,wt_int,wt_int,wt_int,wt_int)wt_bool
	func "Arc"										(wt_handle,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int)wt_bool
	func "Chord"									(wt_handle,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int)wt_bool
	func "Pie"										(wt_handle,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int)wt_bool
	func "Polygon"									(wt_handle,wt_handle,wt_int)wt_bool
	func "TextOutA" as textout						(wt_handle,wt_int,wt_int,wt_string,wt_int)wt_bool
	func "TextOutW" 								(wt_handle,wt_int,wt_int,wt_ptr,wt_int)wt_bool
	func "GetStockObject"							(wt_int)wt_handle
	func "SelectObject"								(wt_handle,wt_handle)wt_handle
	func "CreateDCA" as createdc					(wt_string,wt_string,wt_string,wt_ptr)wt_handle
	func "MoveToEx"									(wt_handle a,wt_int b,wt_int c,wt_ptr d=nil)wt_bool
	func "CreatePen"								(wt_int,wt_int,wt_dword)wt_handle
	func "CreateSolidBrush"							(wt_dword)wt_handle
	func "CreateBrushIndirect"						(wt_ptr)wt_handle
	func "LineTo"									(wt_handle,wt_int,wt_int)wt_bool
	func "GetPixel"									(wt_handle,wt_int,wt_int)wt_dword
	func "SetPixel"									(wt_handle,wt_int,wt_int,wt_dword)wt_dword
	func "SetGraphicsMode"							(wt_handle,wt_int)wt_int
	func "CreateFontIndirectA" as createfontindirect	(wt_ptr)wt_handle
	func "CreateFontA" as createfont \
			(wt_int height, wt_int width=0, wt_int escapement=0, wt_int orientation=0, wt_int bold=0,
			 wt_dword italic=0, wt_dword underline=0, wt_dword strikeout=0, wt_dword charset=0,
			 wt_dword outprec=0, wt_dword clipprec=0, wt_dword quality=0, wt_dword pitch=0, wt_string facename)wt_handle
	func "SaveDC"									(wt_handle)wt_int
	func "GetTextMetricsA" as gettextmetrics		(wt_handle,wt_ptr)wt_bool
	func "DeleteObject"								(wt_handle)wt_bool
	func "RestoreDC"								(wt_handle,wt_int)wt_bool
	func "GetTextExtentPoint32A" as gettextextentpoint32	(wt_handle,wt_string,wt_int,wt_ptr)wt_bool
	func "GetObjectA" as getobject					(wt_handle,wt_int,wt_ptr)wt_int
	func "CreatePalette"							(wt_ptr)wt_handle
	func "GetWindowExtEx"							(wt_handle,wt_ptr)wt_bool
	func "CreateCompatibleBitmap"					(wt_handle,wt_int,wt_int)wt_handle
	func "SetBitmapBits"							(wt_handle,wt_dword,wt_ptr)wt_long
	func "SelectPalette"							(wt_handle,wt_handle,wt_bool)wt_handle
	func "RealizePalette"							(wt_handle)wt_uint
	func "SetDIBitsToDevice"						(wt_handle,wt_int,wt_int,wt_dword,wt_dword,wt_int,wt_int,wt_uint,wt_uint,wt_ptr,wt_ptr,wt_uint)wt_int
	func "StretchDIBits"							(wt_handle,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int,wt_int,wt_ptr,wt_ptr,wt_uint,wt_dword)wt_int
	func "SetStretchBltMode"						(wt_handle,wt_int)wt_int
	func "PatBlt"									(wt_handle,wt_int,wt_int,wt_int,wt_int,wt_dword)wt_bool
	func "BitBlt"									(wt_handle,wt_int,wt_int,wt_int,wt_int,wt_handle,wt_int,wt_int,wt_dword)wt_bool
	func "SetROP2"									(wt_handle,wt_int)wt_int
	func "CreateCompatibleDC"						(wt_handle)wt_handle
	func "DeleteDC"									(wt_handle)wt_bool
	func "CreateBitmap"								(wt_int,wt_int,wt_uint,wt_uint,wt_ptr)wt_handle
	func "CreateBitmapIndirect"						(wt_ptr)wt_handle
	func "CreateDIBitmap"							(wt_handle,wt_ptr,wt_dword,wt_ptr,wt_ptr,wt_uint)wt_handle
	func "CreateDIBSection"							(wt_handle,wt_ptr,wt_uint,wt_ptr,wt_handle,wt_dword)wt_handle
	func "StretchBlt"								(wt_handle,wt_int,wt_int, wt_int,wt_int,wt_handle, wt_int,wt_int,wt_int, wt_int,wt_dword)wt_bool
	func "PlgBlt"									(wt_handle,wt_ptr,wt_handle, wt_int,wt_int,wt_int,wt_int, wt_handle, wt_int,wt_int)wt_bool
	func "SetTextColor"  as settextcolour			(wt_handle,wt_dword)wt_dword
	func "SetTextAlign"								(wt_handle,wt_uint)wt_uint
	func "SetTextJustification"						(wt_handle,wt_int,wt_int)wt_bool
	func "SetBkColor"  as setbkcolour				(wt_handle,wt_dword)wt_dword
	func "SetBkMode"								(wt_handle,wt_int)wt_int
	func "GetBkColor"  as getbkcolour				(wt_handle)wt_dword
	func "GetBkMode"								(wt_handle)wt_int
	func "StartDocA" as startdoc					(wt_handle,wt_ptr)wt_int
	func "StartPage"								(wt_handle)wt_int
	func "EndPage"									(wt_handle)wt_int
	func "EndDoc"									(wt_handle)wt_int
	func "AbortDoc"									(wt_handle)wt_int
	func "GetViewportOrgEx"							(wt_handle,wt_ptr)wt_bool
	func "GetDIBits"								(wt_handle,wt_handle,wt_uint,wt_uint,wt_ptr,wt_ptr,wt_uint)wt_int
	func "GetDIBColorTable" as getdibcolourtable	(wt_handle,wt_uint,wt_uint,wt_ptr)wt_uint
	func "SetDIBColorTable" as setdibcolourtable	(wt_handle,wt_uint,wt_uint,wt_ptr)wt_uint
	func "GetTextAlign"								(wt_handle)wt_uint
end

importdll comdlg32=
	func "GetOpenFileNameA"							(wt_ptr)wt_bool
	func "GetSaveFileNameA"							(wt_ptr)wt_bool
end
