del *.asm
del ?.exe
del *.zip
del *.log
del AST?
del MCL?
del PCL
del PST
del SS
del *.ml
del *.mx
del *.obj
del *.ppm
del *.pgm
del *.pcl
del *.tcl
rem del *.c
ren bb.exe bb.eee
del *.exe
ren bb.eee bb.exe

rem del *.list


call backupproject bx
copy bxall.zip c:\test

