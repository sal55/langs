mmode

type elemtype = i32

!type fred = ref elemtype

!fred bill


func makesmallnum:ref elemtype=
	nil
end

