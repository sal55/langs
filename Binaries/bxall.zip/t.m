!import msyswin
!import u
!mmode
!module u
import u
mmode

proc main=
	int a,b

	systest()
!	pcm_alloc()
end
