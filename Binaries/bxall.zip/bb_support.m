int autotypeno=0
int nextsvindex=0

global macro isref(t) = ttbasetype[t]=tref

global proc lxerror_gen(ichar mess)=

	reportpos(nextlx.posx)

!	println "On line",nextlx.lineno,"in file",sources[nextlx.fileno].filespec
!CPL NEXTLX.LINENO
!	println "On line",nexlx.lineno,"in file",lx.fileno

	println
	println "**** Lex Error:",mess,"****"
	println

!	STOP 1
	stopcompiler(nextlx.posx)
end

!global


global proc lxerror(ichar mess)=
	lxerror_gen(mess)
end

proc reportpos(posrec pos)=
	println "Line:", pos.lineno, "in", sources[pos.fileno].filespec
end

global proc stopcompiler(posrec pos)=
	filehandle f
	f:=fopen("$error.tmp","w")
	println @f, sources[pos.fileno].filespec, pos.lineno
	fclose(f)
CPL "PRESS key"; OS_GETCH()
	println
	println
	stop 1
end

global proc loaderror(ichar mess,mess2="",mess3="")=
	println "Load Error:",mess,mess2,mess3
	println "Stopping"
	stop 1
end

global proc gerror(ichar mess,unit p=nil)=
!CPL "G1"
	gerror_s(mess, "", p)
end

global proc gerror_s(ichar mess, param,unit p=nil)=
	[300]char str
	posrec pos:=(p|p.posx|qpos)
	print @str, "Code gen error:", mess, param
	reportpos(pos)
	stopcompiler(pos)
end

global proc serror(ichar mess)=
	println "*"*87
	println "Syntax Error:",MESS

	reportpos(lx.posx)
!	showerrorsource(lx.pos, currproc)

	println mess

	stopcompiler(lx.posx)
end

global proc serror_s(ichar mess,a)=
	[256]char str
	fprint @str,mess,a
	serror(str)
end

global func allocunitrec(int tag)unit p=
!	p:=pcm_allocnfz(unitrec.bytes)
	p:=PCM_ALLOCZ(unitrec.bytes+16)

IF TAG>UTAGNAMES.UPB THEN
CPL TAG
	LOADERROR("ALLOC/BAD TAG")
FI


	p.tag:=tag
	p.pos:=lx.pos
	p.moduleno:=currmoduleno
	p.subprogno:=moduletosub[currmoduleno]
	return p
end

global func createunit(int tag, unit a=nil, b=nil)unit u=
	u:=allocunitrec(tag)
	u.a:=a
	u.b:=b
	return u
end

global func getduplst(symbol owner,symptr, int id, ato=0)symbol=
!create new proc entry
!symptr is the generic st entry for proc's name
!ato is one to add to owner's deflist
	symbol p

	p:=newstrec()

	p.name:=symptr.name
	p.namelen:=symptr.namelen
	p.token:=tk_name
	p.owner:=owner
	p.nameid:=id

	p.nextdupl:=symptr.nextdupl
	symptr.nextdupl:=p

	p.firstdupl:=symptr

	if ato and owner then
		if owner.deflist=nil then			!first def
			owner.deflist:=owner.deflistx:=p
		else
			owner.deflistx.nextdef:=p
			owner.deflistx:=p
		fi
	fi

	return p
end

global proc adddef(symbol owner,p)=
!add new st def p, to existing deflist of owner
!assumes p already has a .owner link to owner, but is not yet part of owner's deflist
!pgeneric points to the 'generic' entry for this name in the main hash table.
!this is needed as it contains the head of the dupl list for this name (linking
!all instances of this name).
!Usually the dupl list is checked to ensure that there are no existing names
!with this same owner. (pgeneric can be nil to avoid this check.)
!ASSUMES THAT P IS LAST THING ADDED TO HEAD OF DUPLLIST (just after PGENERIC)
	symbol q

	if q:=p.nextdupl then
		if q.owner=owner then
			cpl q.name,"in",owner.name
			serror("Duplicate name")
		end
	end

	if owner.deflist=nil then			!first def
		owner.deflist:=p
	else
		owner.deflistx.nextdef:=p
	end

	owner.deflistx:=p
end

global proc addlinear(symbol d)=
	if stlinear=nil then
		stlinear:=stlinearx:=d
	else
		stlinearx.nextlinear:=d
		stlinearx:=d
	end
end

global func createname(symbol p)unit u=
	u:=allocunitrec(u_name)
	u.def:=p
	return u
end

global func newstrec:symbol p=
	p:=pcm_allocnfz(strec.bytes)

	p.pos:=lx.pos
	p.moduleno:=currmoduleno
	p.subprogno:=moduletosub[currmoduleno]

	return p
end

global func typename(int m)ichar=
	if m>=0 then
		return ttname[m]
	end
	return typenames[-m].def.name
end

global proc gs_copytostr(^strbuffer source,^char s)=
	if source^.length then
		memcpy(s,source^.strptr,source^.length)
		(s+source^.length)^:=0
	else
		s^:=0
	end
end

global proc mcerror(ichar mess)=
	println "MC Error:",mess

	stop 1
end

global proc init_tt=
	int i,size,bitsize
	int s,t,u,v

!Initialise type tt-tables from std types first all fields initially zero

	for i:=0 to tlast-1 do

		ttname[i]:=stdnames[i]
		ttbasetype[i]:=i
		bitsize:=stdbits[i]

		switch bitsize
		when 0 then
			size:=0
		when 1,2,4 then
			size:=1
		else
			size:=bitsize/8
		end switch

		ttsize[i]:=size

!		case i
!		when ti8,ti16,ti32,ti64 then
!			ttsigned[i]:=1
!			ttisinteger[i]:=1
!		when tu8, tu16, tu32, tu64, tc8, tc64 then
!			ttisinteger[i]:=1
!		when tr32, tr64 then
!			ttisreal[i]:=1
!		when tref, trefchar then
!			ttisref[i]:=1
!		end case
!
!!		if stdcat[i]=intcat and size<8 then
!		if ttisinteger[i] and size<8 then
!			ttisshort[i]:=1
!		end

		ttlower[i]:=1

	end

	ttbasetype[trefchar]:=tref
	tttarget[trefchar]:=tu8

	ntypes:=tlast-1

	trefproc:=createrefmode(nil, tproc,0)
	treflabel:=createrefmode(nil, tlabel,0)
end

global func createrefmode(symbol owner, int target, typedefx=0)int=
	int k,m
!	int a,b

	if typedefx=0 then		!anon type
		for k:=tlast to ntypes when isref(k) do
			if tttarget[k]=target then
				return k
			end
		end
!		FI
		m:=createusertypefromstr(nextautotype())
	else
		m:=typedefx
	end

	storemode(owner,target,tttarget[m])
	ttbasetype[m]:=tref
	ttsize[m]:=ttsize[tref]

	return m
end

global func storemode(symbol owner, int m, i32 &pmode)int =
	^typenamerec r

	if m>=0 then
		pmode:=m
		return m
	end

	r:=&typenames[-m]

	if r.pmode=nil then
		r.owner:=owner
		pmode:=m
		r.pmode:=&pmode

	IF R.PMODE=NIL THEN SERROR("PMODE=NIL") FI

		return m
	end

!Already one instance of this mode; need a new slot
	m:=newtypename(r.def)
	r:=&typenames[-m]

	r.owner:=owner
	pmode:=m
	r.pmode:=&pmode
	return m
end

global func createusertype(symbol stname)int=
!create new, named user type
	if ntypes>=maxtype then
	cpl ntypes,stname.name
		serror("Too many types")
	end

	++ntypes
	ttname[ntypes]:=stname.name

	ttnamedef[ntypes]:=stname
	ttbasetype[ntypes]:=tvoid
	ttpos[ntypes]:=lx.posx

	stname.mode:=ntypes

	return ntypes
end

global func createusertypefromstr(ichar name)int=
!create new, named user type
	symbol stname

	stname:=getduplst(stmodule,addnamestr(name),typeid)
	return createusertype(stname)
end

global func nextautotype:ichar=
	static [32]char str

	print @str,"$T",,++autotypeno
	return str
end

global func newtypename(symbol d)int=
	if ntypenames>=maxtypename then
		serror("Too many type names")
	end
	++ntypenames
	typenames[ntypenames].def:=d			!.owner/.pmode to be filled in
	typenames[ntypenames].pos:=lx.pos

	return -ntypenames
end

global func createintconstunit(u64 a, int t)unit u=
	u:=allocunitrec(u_intconst)
	u.value:=a
	u.mode:=t

	u.isconst:=1
	return u
end

global func createrealconstunit(r64 x, int t)unit u=
	u:=allocunitrec(u_realconst)
	u.xvalue:=x
	u.mode:=t
	u.isconst:=1
	return u
end

global func createarraymode(symbol owner, int target, unit dimexpr, int typedefx)int=
!lower is lower bound of array
!length is length, unless lx<>nil!
	int k,m

	if typedefx=0 then		!anon type
		m:=createusertypefromstr(nextautotype())
	else
		m:=typedefx
	end

	ttbasetype[m]:=tarray
	ttlower[m]:=1
	ttdimexpr[m]:=dimexpr
	storemode(owner,target,tttarget[m])
	ttowner[m]:=owner

	return m
end

global func createarraymodek(symbol owner, int target, int lower, length, int typedefx)int=
!lower is lower bound of array
	int atype,m

	atype:=tarray

	if typedefx=0 then		!anon type
		m:=createusertypefromstr(nextautotype())
	else
		m:=typedefx
	end

	ttbasetype[m]:=atype
	ttlower[m]:=lower
	ttlength[m]:=length

	IF TARGET<0 THEN
		SERROR("CREATEARRAYMODEK/TARGET NOT RESOLVED")
	FI
	ttsize[m]:=length*ttsize[target]

	storemode(owner,target,tttarget[m])
	ttowner[m]:=owner

	return m
end

global func duplunit(unit p)unit q=
	if p=nil then return nil end

	q:=createunit(p.tag)

	q^:=p^
	q.nextunit:=nil

	if usubs[q.tag] then
		q.a:=duplunit(q.a)
		if usubs[q.tag]=2 then
			q.b:=duplunit(q.b)
		end
	end

	return q
end

global proc deleteunit(unit p,q)=
!delete p, replace by q, so that what was addressed by p now contains q
	unit r:=p.nextunit
	p^:=q^
	p.nextunit:=r
end

global proc addlistunit(unit &ulist, &ulistx, unit p)=
!add unit p to unit structure ulist,^ulistx  which can be null
	if ulist=nil then		!first
		ulist:=ulistx:=p
	else
		ulistx.nextunit:=p
	end
	ulistx:=p			!update end-of-list pointer
end

global proc insertunit(unit p,int tag)=
!wrap extra unit around p, with given tag
!p itself is effectively changed
	unit q,nextunit
	int mode

	q:=allocunitrec(u_null)
	q^:=p^
	mode:=q.mode
	nextunit:=q.nextunit
	q.nextunit:=nil

	clear p^

	p.tag:=tag
	p.pos:=q.pos
	p.a:=q
	p.mode:=mode
	p.nextunit:=nextunit
	p.resultflag:=q.resultflag
end

global func createstringconstunit(ichar s, int length)unit u=
	u:=allocunitrec(u_stringconst)
	u.svalue:=s
	u.mode:=trefchar
	u.isastring:=1

	if length=-1 then
		u.slength:=strlen(s)+1
	else
		u.slength:=length
	end
	return u
end

proc showerrorsource(int pos, symbol stproc=nil)=
	posrec p
	p.pos:=pos

!	ichar errorline,s

	fprintln "    Line:     #", p.lineno
	if stproc and stproc.nameid=dprocid then
		fprintln "    Function: #()", stproc.name
	end
	fprintln "    Module:   # (#)", sources[p.fileno].name, sources[p.fileno].filespec
!	showdivider('-')
!
!	s:=errorline:=getsourceline(pos)
!	lineoffset:=getsourcepos(pos)-errorline
!
!	to 6 do print " " end
!	while s^ not in [10,0] do
!		print s++^
!	end
!	println
!	s:=errorline
!	to 6 do print " " end
!	to lineoffset do
!		if s^=9 then print '\t' else print ' ' end
!		++s
!	end
!	println "^"
!	showdivider('-')
end

global proc addlistparam(symbol &ulist, &ulistx, symbol p)=
!add unit p to unit structure ulist, ^ulistx  which can be null
	if ulist=nil then		!first
		ulist:=ulistx:=p
	else
		ulistx.nextparam:=p
	end
	ulistx:=p			!update end-of-list pointer
end

global func getavname(symbol owner,int id=frameid)symbol=
!create auto-var name and return pointer to st entry
	symbol p
	[32]char str
	ichar name

	if id=frameid and owner.nameid<>dprocid then
		serror("Auto frame not in proc")
	end

	if id=frameid then
		print @str,"av_",,++nextavindex
	else
		print @str,"sv_",,++nextsvindex
	end

	name:=pcm_copyheapstring(str)
	addnamestr(name)

	p:=getduplst(owner,addnamestr(name),id)
	p.used:=1

	p.mode:=tint

	adddef(owner,p)
	return p
end

global func getrangelwbunit(unit p)unit=
	if p.tag=u_makerange then
		return p.a
	else
		p:=createunit(u_prop,p)
		p.propop:=prop_lwb
		return p
	end
end

global func getrangeupbunit(unit p)unit=
	if p.tag=u_makerange then
		return p.b
	else
		p:=createunit(u_prop,p)
		p.propop:=prop_upb
		return p
	end
end

global func createrecordmode(symbol owner,int typedefx, rectype)int=
!typedef is nil, or an empty moderec belonging to a user type
!owner is an strec for the name def:
! * user-supplied name belonging to the typedef (same as typedef.namedef)
! * user-supplied optional name from a stand-alone enum typespec
! * auto-generated name
	int m

	if typedefx=0 then
		m:=createusertype(owner)
	else
		m:=typedefx
	end
	ttbasetype[m]:=rectype

	return m
end

global func createrefprocmode(symbol owner,stproc, paramlist, int prettype,typedefx)int=
!create a ^proc mode; (can't create a proc mode by itself, as it's meaningless)
	int m, mproc

	mproc:=createusertype(stproc)
	stproc.nextparam:=paramlist

	stproc.mode:=prettype
	ttbasetype[mproc]:=tproc

!don't bother looking for similar proc sig; each one is unique
	if typedefx=0 then		!anon type
		m:=createusertypefromstr(nextautotype())
	else
		m:=typedefx
	end

	tttarget[m]:=mproc
	ttbasetype[m]:=tref

	ttsize[m]:=ttsize[tref]
!	ttisref[m]:=1

	return m
end

global func convertstring(ichar s, t, int length)int=
!convert string s, that can contain control characters, into escaped form
!return new string in t, so that ABC"DEF is returned as ABC\"DEF
!length is that of s; final length may be up to 4 times as long

!returns actual length of t
	int c
	ichar t0:=t
	[16]char str

CPL "NEWCONVSTR", LENGTH
	to length do
		case c:=s++^
		when '"' then
			t++^:='\\'
			t++^:='"'
		when 10 then
			t++^:='\\'
			t++^:='n'
		when 13 then
			t++^:='\\'
			t++^:='r'
		when 9 then
			t++^:='\\'
			t++^:='t'
		when '\\' then
			t++^:='\\'
			t++^:='\\'
!		when 0 then
!			t++^:='\\'
!			t++^:='x'
!			t++^:='0'
!			t++^:='0'
!		when 7,8,26,27 then
!			t++^:='<'
!			t++^:=c/10+'0'
!			t++^:=(c rem 10)+'0'
!			t++^:='>'
		elsif c in 32..126 then
			t++^:=c
		else
!			t++^:='\\'			!hex
!			t++^:='x'
!			print @str,c:"z2h"
!			t++^:=str[1]
!			t++^:=str[2]

			t++^:='\\'			!octal
!			t++^:='x'
			print @str,c:"z3x8"
			t++^:=str[1]
			t++^:=str[2]
			t++^:=str[3]
		end case
	end

	t^:=0

	return t-t0
end

global proc rxerror(ichar mess,unit p=nil)=
CPL "RXERROR", MESS
	reportpos(qpos)
	stopcompiler(qpos)
end

global proc rxerror_s(ichar mess,a,unit p=nil)=
!	[256]char str
!	fprint @str,mess,a
CPL "RXERRORS", MESS, A
	reportpos(qpos)
	stopcompiler(qpos)
end

