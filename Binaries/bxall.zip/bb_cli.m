
global enumdata []ichar passnames =
!								Output (when this is the final step)
	(load_pass,		$),
	(parse_pass,	$),

	(type1_pass,	$),
	(type2_pass,	$),
	(name_pass,		$),

	(ba_pass,		$),			! .ma     These are are special
	(getst_pass,	$),			! .list
	(getproj_pass,	$),			! .prog

	(pcl_pass,		$),			! to pcl/mil
	(mcl_pass,		$),			! mil to mcl
	(fixup_pass,	$),			! fixup pcl and mcl->ss
	(run_pass,		$),			! run in-memory
end

enumdata []ichar optionnames, []byte optionvalues =
!special outputs
	(ba_sw,			"ba",			ba_pass),
	(getst_sw,		"getst",		getst_pass),
	(getproj_sw,	"getproj",		getproj_pass),

!normal production outputs
	(load_sw,		"load",			load_pass),
	(parse_sw,		"parse",		parse_pass),
	(name_sw,		"name",			name_pass),
	(type1_sw,		"type1",		type1_pass),
	(type2_sw,		"type2",		type2_pass),
	(pcl_sw,		"pcl",			pcl_pass),
	(mcl_sw,		"mcl",			mcl_pass),
	(fixup_sw,		"fixup",		fixup_pass),
	(run_sw,		"r",			run_pass),

	(sys_sw,		"sys",			2),
	(minsys_sw,		"min",			1),
	(nosys_sw,		"nosys",		0),

	(noopt_sw,		"no",			0),			!affect mil->mcl
	(opt0_sw,		"o0",			0),
	(opt1_sw,		"o1",			1),
	(opt2_sw,		"o2",			2),
!	(opt3_sw,		"o3",			3),

!diagnostic outputs
	(ast1_sw,		"ast1",			0),
	(ast2_sw,		"ast2",			0),
	(showpcl1_sw,	"pcl1",			0),
	(showpcl2_sw,	"pcl2",			0),
	(showasm_sw,	"asm",			0),
	(st_sw,			"st",			0),
	(types_sw,		"types",		0),
	(showmodules_sw,"modules",		0),
	(pst_sw,		"pst",			0),

	(shortnames_sw,	"shortnames",	0),

	(time_sw,		"time",			0),
	(v_sw,			"v",			2),
	(vv_sw,			"vv",			3),
	(quiet_sw,		"q",			0),

	(ext_sw,		"ext",			0),
	(unused_sw,		"unused",		0),

	(norip_sw,		"norip",		0),
	(himem_sw,		"himem",		2),

	(decons_sw,		"decons",		0),			!deconstruc ba file
end

global int passlevel
global byte foptimise

global byte fshowdiags
global byte fshowmodules
global byte fshowasm
global byte fshowast1
global byte fshowast2
global byte fshowpcl1
global byte fshowpcl2
global byte fshowtypes
global byte fshowst
global byte fshowpst
global byte fshowtiming
global byte fverbose
global byte fdointlibs
global byte fcheckunusedlocals
global byte fshortnames
global byte fhighmem
global byte fdeconsba

GLOBAL SYMBOL CURRFUNC
GLOBAL SYMBOL CURRPARSEPROC


global const logfile="mx.log"

!CONST INFILE = "C:/BX/FANN.M"
!CONST INFILE = "C:/mx/big/fann4.m"
!CONST INFILE = "C:/mx/big/abcd.m"
!CONST INFILE = "C:/mx/bigm"
ichar inputfile

proc main=
	getinputs()

	initdata()
	loadproject(inputfile)

	compilesp(subprogs[1])

	showlogfile()
end

proc compilesp(isubprog sp)=

	parsemodules(sp)

	fixusertypes() when passlevel>=type1_pass
	dotypetables() when passlevel>=type2_pass

	resolvemodules(sp)

!	GENCODETEST()
	gencodesp(sp)

	if fshowpcl1 then showpcl(sp, 1) fi

end

proc getinputs=
	int paramno, pmtype
	ichar name, value

	paramno:=1

	while pmtype:=nextcmdparamnew(paramno, name, value, "b") do
		case pmtype
		when pm_option then
			convlcstring(name)
			for sw to optionnames.len do
				if eqstring(name,optionnames[sw]) then
					do_option(sw,value,paramno)
					exit
				end
			else
				println "Unknown option:",name
				stop 99
			end

		when pm_sourcefile then
			if inputfile then
				loaderror("Specify one lead module only")
			end
			convlcstring(name)
			inputfile:=pcm_copyheapstring(name)
		else
			loaderror("Invalid params")
		end case

	end

	if inputfile=nil then
		println "No input file"
		stop
	end

	if passlevel=0 then
		passlevel:=parse_pass
	end

end

proc do_option(int sw, ichar value, int paramno=0)=
	static byte outused, outpathused
	byte newpass

!CPL "DOOPTION", OPTIONNAMES[SW], PASSLEVEL

	if sw in ba_sw..run_sw then
		newpass:=optionvalues[sw]
		if passlevel and newpass<>passlevel then
			loaderror("Conflicting pass:", optionnames[sw])
		end
		passlevel:=newpass

		return
	end

	if sw in ast1_sw..pst_sw then
		fshowdiags:=1
	end

	if sw in noopt_sw..opt2_sw then
		foptimise:=optionvalues[sw]
	end

	case sw
	when ast1_sw then fshowast1:=1
	when ast2_sw then fshowast2:=1
	when showasm_sw then fshowasm:=1
	when showpcl1_sw then fshowpcl1:=1
	when st_sw then fshowst:=1
	when pst_sw then fshowpst:=1
	when types_sw then fshowtypes:=1
	when showmodules_sw then fshowmodules:=1

	when sys_sw, minsys_sw, nosys_sw then syslevel:=optionvalues[sw]

	when time_sw then fshowtiming:=1
	when v_sw, vv_sw, quiet_sw then fverbose:=optionvalues[sw]

	when ext_sw then fdointlibs:=0

	when unused_sw then fcheckunusedlocals:=1

	when shortnames_sw then fshortnames:=1

	when norip_sw, himem_sw then fhighmem:=optionvalues[sw]

	when decons_sw then fdeconsba:=1

!	WHEN DEBUG_SW THEN DEBUG:=1


	end case

end

proc initdata=
	imodule pm

	lexsetup()

!PRINTHASHTABLE()
!STOP
!



	init_tt()

	pm:=pcm_allocz(modulerec.bytes)
	pm.name:="PROGRAM"
	stprogram:=getduplst(nil,addnamestr("$prog"),programid)
	pm.stmodule:=stprogram
	modules[0]:=pm

end

proc gencodetest=
	imodule pm

CPL "GENCODETEST"
	pm:=modules[1]

!*!	resetpcl(sources[pm.fileno].size)

	CPL "---------MODULE", PM.NAME

	pcomment("HELLO THERE")
	pcomment("HELLO THERE")

	pgen(kadd)
	pgen(kadd)
	pgen(kadd)
	pgen(kendmod)

	pm.pcstart:=pcstart
	pm.pcend:=pccurr

!	gs_init(pcldest)
!	gs_str(pcldest, "PROC PCL")
!
!	writemodpcl(pm, 1)
!
!	gs_println(pcldest, nil)
end
