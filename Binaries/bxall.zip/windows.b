export func dirlist(s,t=1)=
#s is a export filename (eg. "*.dwg") with possible drive/path; scan
#directory for all matching files and return as a list of names
#also returns total no. of files so far
#t= +1	Include normal files, no sub-directory names
#t= +2  Include directories
#t= +3  Include all files including directories
#t= +4  Convert to lower case
#t=  0  Defaults to +1

!CPL "DIRLIST/WINLIB"

	if t.isvoid then t:=1 fi			!files only

	nfiles:=0
	data::=()
	file:=new(ws_finddata)

	if (hfind:=findfirstfile(s,&file))<>-1 then	!at least one file
		repeat
			if (file.fileattributes iand 16) then		!this is a directory
				if (t iand 2)=0 then goto skip fi		!no directories
			else						!this is a file
				if (t iand 1)=0 then goto skip fi
			fi
			++nfiles
			if (t iand 4) then				!to lower case
				data[nfiles]:=convlc(file.filename)
			else
				data[nfiles]::=file.filename
			fi
	skip:
		until not findnextfile(hfind,&file)
		findclose(hfind)
	fi
	return data
end

export func setcurrdir(newdir)=
#Set current directory; return Windows' status code
	return setcurrentdirectory(newdir)
end

export func getcurrdir=
#Return current directory name, always ends with \ or /
	a:=new(array,byte,256)
	n:=getcurrentdirectory(a.len,&a[1])

	if n then
		dir::=makestr(&a[1],n)
	else
		dir:=""
	fi

	if not (rightstr(dir) in "\\/") then dir +:= "\\" fi
	return dir
end

export func createdir(name)=
#Create a new directory
	return createdirectory(name,0)
end

export func direxists(path)=
#Return 1 if directory path exists
	const file_attribute_directory=16
	const invalid_file_attributes=-1

	attrib := getfileattributesa(path)

	return attrib<>invalid_file_attributes and (attrib iand file_attribute_directory)
end

