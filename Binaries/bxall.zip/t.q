project qm=
	module a
	module b
	module c
	import p
end

proc main=
!	int a,b,c,d,i
!	real x,y,z

	println a+b*c

end
