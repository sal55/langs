sp3 bb "t" "b" ""
seted 1
setmm 1
setfileno 43
define ew ed work
define w ed work
define cf12 ep
define mm1 setmm 1
define mm6 setmm 6
define ecmd ed ffsetup.cmd
define eloc ed ffloc.cmd
define eew ee work
define err ed errors.tmp
define mdocs cd m\docs
define mdev cd m\langdev
define docs cd m\docs
define pcdoc cd m\pcldoc
define ec ed .c
define eh ed .h
define ebx ed .bx
define eqx ed .qx
define emx ed .mx
define er ed errors.tmp
define np notepad
define f1 sp qq
define cf1 sp qq
define f2 sp qqrun
define f3 sp qqrun
define f4 sp sys
define f5 sp docs
define k1000 st big\k1000
define k2000 st big\k2000
define dec st big\dec
define real st big\real
define hex st big\hex
define bin st big\bin
define big st bignum
define rx st \myapps\readexe
define cci st g:\cci5\cci
define sys st \mx\msyswin.m
