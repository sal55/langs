
global tokenrec lx					!provides access to current token data
global tokenrec nextlx				!provides access to next token

global record tokenrec =
	u16 token
	u16 subcode
	u32 dummy

	union
		^strec symptr		!pointer to symbol table entry for name
		i64 value			!64-bit int
		real xvalue			!64-bit float
		u64 uvalue			!64-bit word
		ichar svalue		!pointer to string or charconst (not terminated)
	end
	int slength				!string length
	union
		u64 pos: (mm:16, lineno:24, column:10, fileno:10)
		posrec posx
		u32 ilineno			!++ may not work directly on .lineno
	end
end

macro hashc(hsum, c)=hsum<<4-hsum+c
!macro hashc(hsum, c)=hsum*15+c
!macro hashw(hsum)=(hsum<<5-hsum)
macro hashw(hsum)=hsum

const maxstackdepth=20
[maxstackdepth]tokenrec lxnextlx_stack
[maxstackdepth]^char lxsource_stack
[maxstackdepth]^char lxlinestart_stack
[maxstackdepth]^char lxstart_stack
[maxstackdepth]^char lxsptr_stack
global int sourcelevel=0

const cr	= 13
const lf	= '\n'
const tab	= '\t'

^char lxsource				!start of entire sourcefile
^char lxstart				!start of current token
^char lxlinestart			!start of currrent line
^char lxsptr				!point to next source char
int lxcolumn

!global const hstsize	= 1024
global const hstsize	= 65536
!global const hstsize	= 65536*4
global const hstmask	= hstsize-1

global [0:hstsize]symbol hashtable
[0..255]byte namemap			!0/1/2 = other/name/name-upper
[0..255]byte spacemap			!0/1 = not space/space

ichar u64maxstr="18446744073709551615"

global proc lex=
	int lena, lenb
	^char p

	lx:=nextlx				!grab that already read basic token
	lx.column:=lxcolumn+1

	docase lexreadtoken(); nextlx.token
	when tk_eol then
		unless keepeol[lx.token] then
			nextlx.token:=tk_semi
			nextlx.subcode:=1
			exit
		end
	when tk_include then
		doinclude()

	when tk_name then
		case nextlx.subcode
		when tk_unitname then
			case lx.token
			when tk_intconst then
				case nextlx.symptr.lexindex
				when million_unit then lx.value *:= 1 million
				when billion_unit then lx.value *:= 1 billion
				else
					lxerror("Can't do this unit index")
				end case
				lx.subcode:=setinttype(lx.value)
			when tk_realconst then
				lxerror("Unit suffix after float not implem")
			else
				nextlx.token:=tk_name
				exit
			end case
		when tk_hostfn then				!M:user ident; Q: hostfn
			if dmode then
				nextlx.token:=tk_hostfn
				nextlx.subcode:=nextlx.symptr.fnindex
			end
			exit

		else
			nextlx.token:=tk_name
			exit
		end case

	when tk_rawname then
		nextlx.token:=tk_name
		exit

	when tk_binop then
		if nextlx.subcode=bin_in and lx.token=tk_unary and lx.subcode=unary_notl then
			lx.token:=tk_binop
			lx.subcode:=bin_notin
		else
			exit
		end

	when tk_prop then
		if lx.token<>tk_dot then
			nextlx.token:=tk_name
			exit
		else
			exit
		end

	else
		exit
	end docase
end

global proc lexreadtoken=
!read next token into nextlx
	int c, hsum
	^char sptr, lxsvalue
	int length, commentseen
	^char p, q
	byte instr
	[256]char str
	symbol d

	nextlx.subcode:=0

!CPL =LXSTART
!CPL =LXSPTR
!CPL =LXSPTR^

!	while lxsptr^ in [' ','\t'] do ++lxsptr od
!	while spacemap[lxsptr^] do
!		++lxsptr
!	end

	doswitch
		lxstart:=lxsptr
		lxcolumn:=lxstart-lxlinestart
		lxsptr++^

	when 'a'..'z', '_', '$' then
		lxsvalue:=lxsptr-1
	doname:
		hsum:=lxsvalue^

!IF NAMEMAP[LXSPTR^] THEN
		sptr:=lxsptr
		c:=sptr^
!
		if c='"' then
			readprefixstring(hsum)
			return
		end
!
		if not namemap[c] then		!one-char name
!			lookup(lxsvalue, 1, hashw(hsum))
			d:=hashtable[hsum]
			if d and d.namelen=1 and d.name^=hsum then
				nextlx.symptr:=d
				nextlx.token:=d.token
				nextlx.subcode:=d.subcode
				return
			end
		end

		docase namemap[c:=sptr^]
		when 1 then
			hsum:=hsum<<4-hsum+c
			++sptr
		when 2 then
			sptr^:=c+' '
			hsum:=hsum<<4-hsum+c+' '
			++sptr
		else
			lxsptr:=sptr
			exit
		end docase
!FI

!		if c='"' then
!			if lxsvalue+1=^char(lxsptr) then
!				case c:=toupper(lxsvalue^)
!				when  'F', 'R' then 
!					readrawstring()
!					return
!				when  'S', 'B' then 
!					readarraystring(c)
!					return
!				end case
!			end
!		end

		lookup(lxsvalue, lxsptr-lxsvalue, hashw(hsum))

		return

	when 'A'..'Z' then
		lxsvalue:=lxsptr-1
		lxsvalue^+:=32
		goto doname

	when '0'..'9' then
		lxstart:=lxsptr-1
		case lxsptr^
		when ')', cr, ', ', ' ' then		!assume single digit decimal
			nextlx.token:=tk_intconst
			nextlx.subcode:=tint
			nextlx.value:=lxstart^-'0'
		when 'x', 'X' then
			case lxstart^
			when '0' then		!0x
				++lxsptr
				readhex()
			when '2' then
				++lxsptr
				readbin()
			else
				lxerror("Bad base")
			end case
		else
			--lxsptr
			readdec()
		end case
		return

	when '!', '#' then			!comment to eol
docomment:
		docase c:=lxsptr++^
		when cr then
			++nextlx.ilineno
			++lxsptr
			exit
		when lf then
			++nextlx.ilineno
			exit
		when 0 then
			--lxsptr
			exit
		end
		nextlx.token:=tk_eol
		return

!	when '#' then
!		nextlx.token:=hashsym
!		return

	when '\\' then			!line continuation

!two stages:
! 1: read chars until any eol chars (unless further '\' seen)
! 2: read until non-white space
		commentseen:=0
		docase lxsptr++^			!read until end of this line
		when cr then
			++lxsptr				!skip lf
			exit
		when lf then
			++nextlx.ilineno
			lxlinestart:=lxsptr
			exit
		when 0 then
			nextlx.token:=tk_eof
			--lxsptr
			return
		when ' ', tab then
		when '!' then
			commentseen:=1
		else
			if not commentseen then
				lxerror("\\ not followed by eol")
			end
		end docase
!eol seen: now skip 0 or more further eol chars, plus any white space (ie. multiple blank lines)

		docase lxsptr++^
		when cr then
			++lxsptr				!skip lf
		when lf then
			++nextlx.ilineno
			lxlinestart:=lxsptr
		when ' ', tab then
		else
			--lxsptr
			exit
		end docase

	when '{' then
		nextlx.token:=tk_lcurly
		return

	when '}' then
		nextlx.token:=tk_rcurly
		return

	when '.' then
		case lxsptr^
		when '.' then				!.. or ...
			++lxsptr
			if lxsptr^='.' then
				++lxsptr
				nextlx.token:=tk_ellipsis
			else
				nextlx.token:=tk_binop
				nextlx.subcode:=bin_range		!helps treat as opsym which all have k-code as subcode
			end
			return
		elsif lxsptr^ in '0'..'9' then			!real const: deal with this after the switch
			--lxsptr
LXERROR(".123 not done")
!			readrealnumber(nil, 0, 10)
			return
		else
			nextlx.token:=tk_dot
			return
		end case

	when ',' then
		nextlx.token:=tk_comma
		return

	when ';' then
		nextlx.token:=tk_semi
		return

	when ':' then
		case lxsptr^
		when '=' then
			++lxsptr
			nextlx.token:=tk_binop
			nextlx.subcode:=bin_assign		!helps treat as opsym which all have k-code as subcode
		when ':' then
			++lxsptr
			case lxsptr^
			when '=' then
				++lxsptr
				nextlx.token:=tk_binop
				nextlx.subcode:=bin_copy
			else
				lxerror("::")
			esac
		else
			nextlx.token:=tk_colon
		end case
		return

	when '(' then
		nextlx.token:=tk_lbrack
		return

	when ')' then
		nextlx.token:=tk_rbrack
		return

	when '[' then
		nextlx.token:=tk_lsq
		return

	when ']' then
		nextlx.token:=tk_rsq
		return

	when '|' then
!		if lxsptr^='|' then
!			++lxsptr
!			nextlx.token:=tk_dbar
!		else
			nextlx.token:=tk_bar
!		end
		return

	when '^' then
		nextlx.token:=tk_ptr
		return

	when '@' then
!		if lxsptr^='@' then
!			++lxsptr
!			nextlx.token:=tk_dat
!		else
			nextlx.token:=tk_at
!		end
		return

	when '?' then
!		p:=str; q:=lxsptr+1
!		while q^ not in [cr, lf, 0] do
!			p++^:=q++^
!		end
!		p^:=0
!
!		nextlx.svalue:=pcm_copyheapstring(str)
		nextlx.token:=tk_question
		return
!

	when '~' then
		nextlx.token:=tk_curl
		return

	when '+' then
		nextlx.token:=tk_binop
		nextlx.subcode:=bin_add
		if lxsptr^='+' then
			++lxsptr
			nextlx.token:=tk_incr
			nextlx.subcode:=0
			return
		end
		return

	when '-' then
		nextlx.token:=tk_binop
		nextlx.subcode:=bin_sub
		case lxsptr^
		when '-' then
			++lxsptr
			nextlx.token:=tk_incr
			nextlx.subcode:=1
			return
		when '>' then
			++lxsptr
			nextlx.token:=tk_pipe
			return
		end case
		return

	when '*' then
		nextlx.token:=tk_binop
		if lxsptr^='*' then
			++lxsptr
			nextlx.subcode:=bin_power
		else
			nextlx.subcode:=bin_mul
		end
		return

	when '/' then
		nextlx.token:=tk_binop
		nextlx.subcode:=bin_div
		return

	when '%' then
		nextlx.token:=tk_binop
		nextlx.subcode:=bin_idiv
		return

	when '=' then
		case lxsptr^
		when '>' then
			nextlx.token:=tk_sendto
			++lxsptr
		when '=' then
			nextlx.token:=tk_binop
			nextlx.subcode:=bin_same
			++lxsptr
		else
			nextlx.token:=tk_binop
			nextlx.subcode:=bin_eq
		end case
		return

	when '<' then
		nextlx.token:=tk_binop
		case lxsptr^
		when '=' then
			++lxsptr
			nextlx.subcode:=bin_le
		when '>' then
			++lxsptr
			nextlx.subcode:=bin_ne
		when '<' then
			++lxsptr
			nextlx.subcode:=bin_shl
		else
			nextlx.subcode:=bin_lt
		end case
		return

	when '>' then
		nextlx.token:=tk_binop
		case lxsptr^
		when '=' then
			++lxsptr
			nextlx.subcode:=bin_ge
		when '>' then
			++lxsptr
			nextlx.subcode:=bin_shr
		else
			nextlx.subcode:=bin_gt
		end case
		return

	when '&' then
		nextlx.token:=tk_addr
		return

	when '\'' then
		lxreadstring('\'')
		return

	when '"' then
		lxreadstring('"')
		return

	when '`' then
		readnamex()
		return

	when ' ', tab then

	when cr then
		++lxsptr				!skip lf
		nextlx.token:=tk_eol
		return
	when lf then			!only lfs not preceded by cr
		nextlx.token:=tk_eol
		++nextlx.ilineno
		lxlinestart:=lxsptr
		return

	when 0 then
		if sourcelevel then
			unstacksource()
			RETURN
		else
			nextlx.token:=tk_eof
			--lxsptr
			return
		end

	WHEN 26 THEN
CPL "ETX?", NEXTLX.LINENO

	else
CPL INT((LXSPTR-1)^)
		lxerror("Unknown char")
!		nextlx.token:=tk_error
		return

	end doswitch

end

global proc lexsetup=
!do one-time setup:
! clear the hash table and populated it with reserved words

	inithashtable()
end

proc readrawstring=
!positioned at " of F"
!read raw string
	ichar dest
	int c

	nextlx.token:=tk_stringconst
	nextlx.svalue:=++lxsptr

	dest:=lxsptr				!form string into same buffer

	docase c:=lxsptr++^
	when '"' then
		if lxsptr^='"' then		!repeated, assume embedded term char
			dest++^:='"'
			++lxsptr
		else			!was end of string
			(lxsptr-1)^:=0
			exit
		end
	when cr, lf, 0 then
		lxerror("Raw string not terminated")
		--lxsptr
		exit
	else
		dest++^:=c
	end docase

	nextlx.slength:=lxsptr-nextlx.svalue
	nextlx.svalue:=pcm_copyheapstringn(nextlx.svalue, nextlx.slength)
end

proc lookup(^char name, int length, hashindex)=
!lookup rawnamesym with details in nextlx
!hash value already worked out in lxhashvalue
!in either case, lx.symptr set to entry where name was found, or will be stored in
	int wrapped, j
	symbol d

	j:=hashindex iand hstmask

	d:=hashtable[j]
	wrapped:=0

!IF LENGTH=1 THEN
!
!	do
!		if d=nil then exit end
!
!		if d.namelen=1 and d.name^=name^ then	!match
!			nextlx.symptr:=d
!			nextlx.token:=d.token
!			nextlx.subcode:=d.subcode
!			return
!		end
!
!		if ++j>=hstsize then
!			if wrapped then
!				abortprogram("HASHTABLE FULL")
!			end
!			wrapped:=1
!			j:=0
!		end
!		d:=hashtable[j]
!	end
!
!ELSE
	while d do
		if d.namelen=length and memcmp(d.name, name, length)=0 then	!match
			nextlx.symptr:=d
			nextlx.token:=d.token
			nextlx.subcode:=d.subcode
			return
		end

		if ++j>=hstsize then
			if wrapped then
				abortprogram("HASHTABLE FULL")
			end
			wrapped:=1
			j:=0
		end
		d:=hashtable[j]
	end
!FI

!exit when not found; new name will go in entry pointed to by lxsymptr

	d:=pcm_allocnfz(strec.bytes)

	hashtable[j]:=d

	d.name:=pcm_copyheapstringn(name, length)
	d.namelen:=length
	d.token:=tk_name

	nextlx.symptr:=d
	nextlx.token:=d.token
!	nextlx.subcode:=d.subcode
end

func lookupsys(^char name)int=
!lookup rawnamesym with details in nextlx
!hash value already worked out in lxhashvalue
!return 1 (found) or 0 (not found)
!in either case, lx.symptr set to entry where name was found, or will be stored in
	int j, wrapped, hashvalue

	j:=gethashvaluez(name) iand hstmask

	lx.symptr:=hashtable[j]
	wrapped:=0

	do
		if lx.symptr=nil then
			exit
		elsif eqstring(lx.symptr.name, name) then	!match
			println "Lex dupl name:", name
			stop 1 
!			lxerror("sys dupl name?")
		end

		if ++j>=hstsize then
			if wrapped then
				abortprogram("SYS:HASHTABLE FULL")
			end
			wrapped:=1
			j:=0
		end
		lx.symptr:=hashtable[j]
	end

!exit when not found; new name will go in entry pointed to by lxsymptr
	lx.symptr:=pcm_allocnfz(strec.bytes)
	hashtable[j]:=lx.symptr

	lx.symptr.name:=name				!assume can be shared (stored in a table)
	lx.symptr.namelen:=strlen(name)
	lx.symptr.token:=tk_name			!usually replaced with actual symbol details

	return 0
end

func gethashvaluez(ichar s)int=
!get identical hash func to that calculated by lexreadtoken
!but for a zero-terminated string
!ASSUMES S is lower-case, as conversion not done
	int c, hsum

	if s^=0 then return 0 end

	hsum:=s++^

	do
		c:=s++^
		exit when c=0
		hsum:=hashc(hsum, c)
	end
	return hashw(hsum)
end

proc inithashtable=
!populate hashtable with standard symbols
	int token
	ichar name
!	memset(&hashtable, 0, hashtable.bytes)

	for i:=1 to stnames.len do
		token:=stsymbols[i]

		if token<>tk_unitname then
			addreservedword(stnames[i], token, stsubcodes[i])
		else
			addreservedword(stnames[i], tk_name, token)
			lx.symptr.fnindex:=stsubcodes[i]
		end
	end

	for i to hostfnnames.upb when not hostinternal[i] do
		addreservedword(hostfnnames[i], tk_name, tk_hostfn)
		lx.symptr.fnindex:=i
	od

	for i in mathsnames.bounds do
		addreservedword(mathsnames[i], tk_maths, i)
	end

	for i in propnames.bounds do
		addreservedword(propnames[i], tk_prop, i)
	end

	for i in cvnames.bounds do
		addreservedword(cvnames[i], tk_compilervar, i)
	end

	for i in binstr.bounds do
		name:=binstr[i]
		if isalpha(name^) then
			addreservedword(binstr[i], tk_binop, i)
		end
	end

	for i in tvoid..tu4 do
		addreservedword(stdnames[i], tk_stdtype, i)
	end

end

proc addreservedword(ichar name, int token, subcode)=
	lookupsys(name)
	lx.symptr.token:=token
	lx.symptr.subcode:=subcode
!	lx.symptr.lexindex:=index			!sets also .fnindex
end

proc doinclude=
	ichar file
	ifile pf

lxERROR("DOINCL")
!	lexreadtoken()
!	if nextlx.token<>tk_stringconst then lxerror("include: string expected") end
!	file:=nextlx.svalue
!	convlcstring(file)
!	file:=addext(file, "m")		!add in extension if not present; assume same as source
!
!	pf:=getsupportfile(file, path:sources[lxfileno].path)
!	lexreadtoken()
!	stacksource(pf.fileno)
end

global proc startlex(ifile file)=
!start processing one of the file in sourcefile tables as source code
!assume it is a complete header or module

	lxlinestart:=lxsource:=lxsptr:=file.text

	nextlx.lineno:=nextlx.column:=1
	nextlx.fileno:=file.fileno

	nextlx.token:=tk_semi
	nextlx.subcode:=0
end

global proc startlextest(ichar source)=
!start processing one of the file in sourcefile tables as source code
!assume it is a complete header or module

	lxlinestart:=lxsource:=lxsptr:=source

	nextlx.lineno:=nextlx.column:=1
	nextlx.fileno:=1

	nextlx.token:=tk_semi
	nextlx.subcode:=0
end

global func addnamestr(ichar name)^strec=
	tokenrec oldlx
	^strec symptr

	oldlx:=nextlx
	lookup(name, strlen(name), gethashvaluez(name))
	symptr:=nextlx.symptr
	nextlx:=oldlx

	return symptr
end

global proc ps(ichar caption)=
!	PRINT REF VOID(LXSOURCE),$
!	PRINT REF VOID(LXSPTR),$
	print "PS:", caption, ,": "
	printtoken(&lx)
end

global proc ps2(ichar caption)=
!	PRINT REF VOID(LXSOURCE),$
!	PRINT REF VOID(LXSPTR),$
	print "PS2:", caption, ,": "
	printtoken(&nextlx)
end

!global proc psnext(ichar caption)=
!	print caption, ,": "
!	printsymbol(&nextlx)
!end
!
!global proc psx(ichar caption)=
!	print caption, ,": "
!	printsymbol(&lx)
!	print "	"
!	printsymbol(&nextlx)
!end

global proc stacksource(int fileno, isimport=0)=
!introduce new source level for macros or include files
!not used for main source

	if sourcelevel>=maxstackdepth then
		lxerror("Include file/macro overflow")
	end

	++sourcelevel
	lxnextlx_stack[sourcelevel]		:= nextlx
	lxlinestart_stack[sourcelevel]	:= lxlinestart
	lxstart_stack[sourcelevel]		:= lxstart
	lxsource_stack[sourcelevel]		:= lxsource
	lxsptr_stack[sourcelevel]		:= lxsptr

	lxlinestart:=lxsource:=lxsptr:=sources[fileno].text

	nextlx.lineno:=1
	nextlx.fileno:=fileno

	nextlx.token:=tk_semi
	nextlx.subcode:=0
end

global proc unstacksource=
	if sourcelevel>0 then			!check that some source is stacked
		nextlx		:= lxnextlx_stack[sourcelevel]
		lxlinestart	:= lxlinestart_stack[sourcelevel]
		lxstart		:= lxstart_stack[sourcelevel]
		lxsource	:= lxsource_stack[sourcelevel]
		lxsptr		:= lxsptr_stack[sourcelevel]

		--sourcelevel
	end
end

proc readarraystring(int prefix)=
	++lxsptr
	lxreadstring('"')

	if prefix='s' then
		nextlx.subcode:='S'
!CPL "RAX/STR"
	else
		--NEXTLX.SLENGTH
		nextlx.subcode:='B'
!CPL "RAX/BIN"
	end
end

func setinttype(u64 a)int=
	if a<=u64(0x7FFF'FFFF'FFFF'FFFF) then
		return ti64
	else
		return tu64
	end
end

proc readnamex=
	int c, hsum, length

	nextlx.svalue:=lxsptr
	hsum:=0

	while namemap[c:=lxsptr++^] do
		hsum:=hsum<<4-hsum+c
	end
	--lxsptr

	length:=lxsptr-nextlx.svalue

	if length=0 then
		lxerror("Bad ` name")
	end
	lookup(nextlx.svalue, length, hashw(hsum))
	nextlx.token:=tk_rawname

	return
end

proc lxerror_s(ichar mess, s)=
	lxerror(mess)
end

proc lxreadstring(int termchar)=
!start from char just after " or ' (termchar will be " or ')

	ichar s, t
	int c, d, length, hasescape, a, n
	[8]char str

	if termchar='"' then
		nextlx.token:=tk_stringconst
	else
		nextlx.token:=tk_charconst
		nextlx.subcode:=tint
	end

!do a first pass that terminates length of final string
	length:=0
	hasescape:=0
	t:=nil

	for pass:=1 to 2 do
		s:=lxsptr
		do
			case c:=s++^
			when '\\' then			!escape char
				hasescape:=1
				c:=s^
				if c>='A'  and c<='Z' then c+:=' ' end
				++s
				case c
				when 'a' then			!bell ('alert')
					c:=7
				when 'b' then			!backspace
					c:=8
				when 'c', 'r' then		!carriage return
					c:=cr
				when 'e' then			!escape
					c:=27
				when 'f' then			!formfeed
					c:=12
				when 'h' then
					while s^ <> '\\' do
						c:=readhexcode(&s, 2, 1)
						if pass=2 then
							t^:=c
						end
						++t
					end
					++s
					--t					!will overwrite last byte

				when 'l', 'n' then		!linefeed, or linux/c-style newline
					c:=lf
				when 't' then			!tab
					c:=9
				when 'u', 'v' then		!reserved for unicode, like \x but with 4 hex digits
					t +:= getutf8(readhexcode(&s, (c='u'|4|6)), (pass=2|t|nil))
					nextloop

				when 'w' then			!windows-style cr-lf
					if pass=2 then
						t^:=cr
					end
					++t
					c:=lf
				when 'x' then	!2-digit hex code follows
					c:=readhexcode(&s, 2)
				when 'y' then			!CCI/SM backwards tab
					c:=16
				when 'z' then			!null (not fully supported in code)
					c:=0
				elsecase c
				when '"' then			!embedded double quote
					c:='"'
				when '\\' then
					c:='\\'
				when '\'' then			!embedded single quote
					c:='\''
				when '0' then
					c:=0
				else
					str[1]:=c; str[2]:=0
					lxerror_s("Unknown string escape: \\%s", str)
				end
			when '"', '\'' then		!possible terminators
				if c=termchar then		!terminator char
					if s^=c then		!repeated, assume embedded term char
						++s
					else			!was end of string
						exit
					end
				end
HASESCAPE:=1
			when cr, lf, 0 then
				lxerror("String not terminated")
			end case

			if pass=2 then
				t^:=c
			end
			++t

		end

		if pass=1 then
			length:=int(t)
			nextlx.slength:=length
!CPL "LXREADSTRING", LENGTH, NEXTLX.SLENGTH
			if hasescape then
				nextlx.svalue:=t:=pcm_alloc(length)
			elsif length=0 then
				nextlx.svalue:=""
				lxsptr:=s
				return
			else
				nextlx.svalue:=pcm_copyheapstringn(lxsptr, length)
				lxsptr:=s

				return
			end

		else
!			t^:=0
			lxsptr:=s
		end
	end
end

func readhexcode(^ref char s, int n, sp=0)int a=
!read n hex digits from from char ptr, and step ptr in the caller
	int c
	a:=0
	for i to n do

		if sp and i.odd then
			repeat
				c:=(s^)++^
			until c<>' '
		else
			c:=(s^)++^
		end

		if c in 'A'..'F' then
			a:=a*16+c-'A'+10
		elsif c in 'a'..'f' then
			a:=a*16+c-'a'+10
		elsif c in '0'..'9' then
			a:=a*16+c-'0'
!		elsif c='\\' then
!			--(s^)
!			exit
		else
			lxerror("Bad hex digit")
		end
	end
	a
end

func getutf8(int c, ^char s)int n =
!convert unicode char c to utf8 sequence at s, consisting of 1-4 bytes, and
!return the number of bytes. s will be zero-terminated
!On error, return zero
	[16]char str
	if s=nil then s:=str end

	if c<=0x7F then
		n:=1
		s++^:=c

	elsif c<=0x7FF then
		n:=2
		s++^:=2x110_00000 + c.[10..6]
		s++^:=2x10_000000 + c.[5..0]

	elsif c<=0xFFFF then
		n:=3
		s++^:=2x1110_0000 + c.[15..12]
		s++^:=2x10_000000 + c.[11..6]
		s++^:=2x10_000000 + c.[5..0]
	elsif c<=0x10FFFF then
		n:=4
		s++^:=2x11110_000 + c.[20..18]
		s++^:=2x10_000000 + c.[17..12]
		s++^:=2x10_000000 + c.[11..6]
		s++^:=2x10_000000 + c.[5..0]
	else
		n:=0
	end

	s^:=0
	n
end

proc readdec=
	int c
	^char dest, destend, pstart
	int islong, length
	[1024]char str
	word a

	islong:=0

	pstart:=lxsptr

	dest:=str
	destend:=dest+str.len-10
	a:=0

	do
		if (c:=lxsptr++^) in '0'..'9' then
			a:=a*10+c-'0'
			dest++^:=c
		elsecase c
		when 'e', 'E' then
			lxsptr:=pstart
			readreal()
			return
		when '.' then
			if lxsptr^<>'.' then
				lxsptr:=pstart
				readreal()
				return
			end
			--lxsptr
			exit

		when '_', '\'' then

		when 'b', 'B' then
			length:=dest-&str[1]
			if length>64 then lxerror("bin overflow") end
			dest:=str
			a:=0
			to length do
				if dest^>='2' then lxerror("bad bin digit") end
				a:=a*2+dest++^-'0'
			end
			finish

		else
			--lxsptr
			exit
		end

		if dest>=destend then lxerror("Numlit too long") end
	end
	length:=dest-&str[1]

	if length>20 or length=20 and strncmp(str, u64maxstr, 20)>0 then
		nodecimal()
	end

finish:
	nextlx.token:=tk_intconst
	nextlx.subcode:=setinttype(a)
	nextlx.value:=a
end

proc readhex=
	int c
	^char dest, destend, pstart
	int length
	[1024]byte str
	word a

	pstart:=lxsptr

	dest:=str
	destend:=dest+str.len-10
	a:=0

	do
		if (c:=lxsptr++^) in '0'..'9' then
			a:=a*16+c-'0'
			dest++^:=c

		elsif c in 'A'..'F' then
			dest++^:=c
			a:=a*16+c-'A'+10
		elsif c in 'a'..'f' then
			dest++^:=c-32
			a:=a*16+c-'a'+10

		elsecase c
		when '_', '\'' then

		when '.' then
			--lxsptr
			exit

		else
			--lxsptr
			exit
		end

		if dest>=destend then lxerror("Numlit too long") end
	end
	length:=dest-&str[1]

	if length>16 then
		LXERROR("MAKEDEC")
		return
	end

	nextlx.token:=tk_intconst
	nextlx.subcode:=setinttype(a)
	nextlx.value:=a
end

proc readbin=
	int c
	^char dest, destend, pstart
	int length
	[1024]byte str
	word a

	pstart:=lxsptr

	dest:=str
	destend:=dest+str.len-10
	a:=0

	do
		case c:=lxsptr++^
		when '0', '1' then
			a:=a*2+c-'0'
			dest++^:=c

		when '_', '\'' then

		when '.' then
			--lxsptr
			exit

		elsif c in '2'..'9' then
			lxerror("bin bad digit")
		else
			--lxsptr
			exit
		end case

		if dest>=destend then lxerror("bin overflow") end
	end
	length:=dest-&str[1]

	if length>64 then
		nodecimal()
	end

	nextlx.token:=tk_intconst
	nextlx.subcode:=setinttype(a)
	nextlx.value:=a
end

proc readreal=
!at '.', or had been in middle of int where . or e were seen, back at the start

	int c, negexpon, dotseen, length, fractlen, expon, expseen
	real x
	[1024]char str
	ichar dest, destend
	u64 a

	dest:=str
	destend:=dest+str.len-100
	length:=negexpon:=dotseen:=expseen:=expon:=fractlen:=0

	do
		if (c:=lxsptr++^) in '0'..'9' then
			dest++^:=c
			++length
			if dotseen then ++fractlen end
		elsecase c
		when '.' then
			if dotseen then --lxsptr; exit end
			dotseen:=1
			dest++^:=c

		when 'e', 'E' then
			if expseen then lxerror("double expon") end
			expseen:=1
			dest++^:=c
			while lxsptr^=' ' do ++lxsptr end
			if lxsptr^ in ['+', '-'] then
				if lxsptr^='-' then negexpon:=1 end
				dest++^:=lxsptr++^
			end

			expon:=0
			do
				if (c:=lxsptr++^) in '0'..'9' then
					expon:=expon*10+c-'0'
					dest++^:=c
					if dest>=destend then lxerror("expon?") end
				elsecase c
				when '_', '\'' then
				else
					--lxsptr
					exit all
				end
			end

		when '_', '\'' then

		else
			--lxsptr
			exit
		end

		if dest>=destend then lxerror("r64lit too long") end
	end
	dest^:=0

	if expseen and expon>=0 and not dotseen then		!read as integer
		a:=0
		for i to length do				!digits already range checked
			a:=a*10+str[i]-'0'
		end
		to expon do
			a:=a*10
		end
		nextlx.token:=tk_intconst
		nextlx.subcode:=setinttype(a)
		nextlx.value:=a
		return
	end


!------------------------------------------------------------
! Fast way to convert for ordinary numbers (1e100 migt be slower!)
!------------------------------------------------------------
	if negexpon then expon:=-expon end
	expon-:=fractlen
	x:=0.0

	for i:=1 to length+dotseen do		!digits already range-checked
		c:=str[i]
		if c<>'.' then
			x:=x*10.0+c-'0'
		end
	end

	if expon>=0 then
		to expon do
			x*:=10.0
		end
	else
		to -expon do
			x/:=10.0
		end
	end

	nextlx.xvalue:=x
!------------------------------------------------------------
! Best way to covert: more accurate representation, but slower
!------------------------------------------------------------
!	nextlx.xvalue:=strtod(str, nil)
!------------------------------------------------------------

	nextlx.token:=tk_realconst
	nextlx.subcode:=treal

!IF EXPSEEN AND NOT DOTSEEN THEN
!	CPL "READREAL NO DOT", X
!FI
end

proc nodecimal=
	lxerror("u64 const overflow")
end

proc start=
	for c in namemap.bounds do
		if c in 'a'..'z' or c in '0'..'9' or c in ['_', '$'] then
			namemap[c]:=1
		elsif c in 'A'..'Z' then
			namemap[c]:=2				!upper case
		end

		if c in [' ', '\t'] then
			spacemap[c]:=1
		end

	end

	for i in keepeol.bounds do
		if i in [tk_comma, tk_lsq, tk_lbrack, tk_binop] then
			keepeol[i]:=1
		end
	end
end

proc readprefixstring(int c)=
	case c
	when  'f', 'r' then 
		readrawstring()
	when  's', 'b' then 
		readarraystring(c)
	else
		lxerror("Bad str prefix")
	end case
end
!
!global proc skipsemi=
!	while lx.token=tk_semi do lex() end
!end

