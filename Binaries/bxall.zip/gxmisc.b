export enumdata optionnames =
	(wf_border,		$),		! wbs_simple
	(wf_resize,		$),		! 0
	(wf_hscroll,	$),		! 0
	(wf_vscroll,	$),		! 0
	(wf_menu,		$),		! 0
	(wf_caption,	$),		! 1
	(wf_max,		$),		! 0
	(wf_minmax,		$),		! 1
	(wf_sysmenu,	$),		! 1
	(wf_desktop,	$),		! 0
	(wf_clip,		$),		! 0
	(wf_show,		$),		!
	(wf_iframe,		$),		! 1
	(wf_cent,		$),		!
	(wf_toolwind,	$)		!
end

!Windows border styles, used for pop-up windows. Could also be used for
!some child windows
export enumdata wbsnames=
	(wbs_none=0,$),
	(wbs_simple,$),
	(wbs_thick,$),
	(wbs_resize,$),
	(wbs_sunken,$),
	(wbs_sunken2,$),
	(wbs_sunkenrs,$),
	(wbs_dummy,$)
end
