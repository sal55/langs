!MODULE winmessages
!module sysp
!
!module winconsts
!module winapi
!module wingxlib
!module gxmisc

VAR GGDI

export var debug=0

export var messhandlertable=9000	!message by windowclass table of message handlers
export var actionhandlertable

export var chx,chy		!default text sizes for menus
export var cha,chd		!ascender/descender heights
export const smx=3		!margins around button text in pixels (both sides)
export const smy=4
export var arrowdim
export var markdim
export var buttonheight
export var listrowheight
export const labelfont=1

export var tabstops=(8,)*20

export var wmouse=nil
export var wfocus=nil
export var wprinter=nil
export var lastmousepos=nil
export var lastmousewindow=nil
export var currmousewindow=nil

export var mousepos
export var mousesw
export var quitmess=0
export var dragmode=0
export var lastbuttontime=0

export var buttonstate=0
export var wmessagetable		!see initdata
export var buttontable		!see initdata

const maxqueuesize=100
export var messagequeue=()
export var nmessages=()

const dragtol=1

export var copymode=4

var vktomesstable

!Describe gx window (also bitmap, control or child window)
export record rwindow =

	var windclass					! type of window (popup, control, etc)
	var flags						! general purpose flags
	var style						! stylerec entry
	var name						! Optional debugging name

	var owner						! owner when this is a child window
	var index						! index 1..n when part of a list (eg. .childlist of owner)
	var childlist					! list of child windows

!framepos/dim describe the overall window size including Windows or gx-drawn borders,
	var frameposx, frameposy		! top left of frame, in screen or owner window client coords
	var framedimx, framedimy		! pixels dims including frame and caption

	var	posx, posy					! Pixel pos client area as seen by application
	var	dimx, dimy					! Pixel dims of client area as seen by application

	var gdi							! (rgdistate)	gdi state record

	var enable						! 1 to enable toggle/button/arrow etc, 0 to disable and show greyed out
	var id							! button/et al: command code associated with control
	var text						! caption or label or primary data
!		var data 	@text
	var linkvar						! pointer to linked var for toggle/select/scroll
	var gindex						! window export index

	var attrs						! general purpose attributes, depends on window class

!bitmap data
	var pixelbits					! 1, 4, 16, 24, 32 bits per pixel
	var pixelptr					! pointer to image data
	var pixelbytes					!bytes/pixel (round up to next whole byte)
	var linebytes					!bytes/per row, also pitch
	var framebytes
	var paltype						!0, or palette type

	var closed
end

export enumdata paltypenames =
	(no_pal=0,		$),
	(greyscale_pal,	$),
	(tinted_pal,	$),
	(colour_pal,	$),
	(uv_pal,		$),
end

export type rgdistate = struct
	ref void hwnd				! win32 handle (hwnd)
	ref void hdc				! 0 or device context handle for hwnd
	ref void hwnd2				! secondary window/memory backup
	ref void hdc2				! 0 or hwnd3 DC screen or memory hdc
	i64 originalwndproc	! win32 control handling proc
	union
		i64 menuhandle		! win32 handle to any menubar
		i64 oldbmobj			!used for bitmaps
	end
	i32 drawmode			! see dm- drawcodes
	i32 updated				! 1 when pixels have changed

	i32 posx,posy			!current drawing position
	i32 pencolour			! current line colour (rgb)
	i32 penwidth			! current line width

	i32 penstyle			! current line dotted style

	i32 xormode				! 0=normal, 1=xor
	i32 brushcolour			! current brush colour
	i32 brushstyle			! current brush style (bs_solid/etc)
	i32 brushpattern		! current brush hatch/bitmap pattern

	i32 font				! current font number
end

export enumdata marktypenames =
	(no_mark=0,			$),
	(radio_mark,		$),
	(tick_mark,			$),
	(check_mark,		$),
	(invert_mark,		$),
	(outline_mark,		$),
	(bold_mark,			$),
end

export enumdata hilitetypenames =
	(no_hilite=0,		$),
	(invert_hilite,		$),
	(outline_hilite,	$),
end

export record togglerec=		!for toggle and select
	var textoffset
	var onvalue
end

export record scrollbarrec=		!scroll bars
	var limits						!range
	var span						!portion of limits represented by visible data (0 means not relevant)
	var thumbsize					!pixel length of thumb (vert or hoz extent along scrollbar)
	var thumbspan					!pixels that the thumb can move
	var thumbpos					!current thumb position in pixels from start of scrollbar
	var currpos						!current position, will be in limits range
	var dragmode					!1 if thum currently being dragged
end

export record editboxrec=		!edit boxes
!current char position within edit text
!if text has N characters, then position will be 1..N+1
!The position is just /before/ the stated character
!This matches column position within the MED text editor
	var currpos						!cursor position, 1 to N+1 (N=chars in edit text)
	var caretpos					!current pixel position of any caret
	var textpos						!start x,y pixel position of text, set by gxjust_text
end

export record listboxrec=
	var rows						!number of displayed rows
	var pagepos						!data position corresponding to row 1 of display
	var length						!all data items, same as linkvar^.len
	var currpos						!cursor position within the data, 1 to N (can be 0 when N=0)
	var pitch, offset				!pixel dims of each row
end

export record rmessage=
	var		wind		!main window/button associated with message
	var		menuwind	!top-level window owning button
	var		message		!message number
	var		state		!button/shift key state at time of message
	var		a,b			!general purpose data, depends on message
	var		x,y			!current mouse position
end

!contains many different flags and style codes for assorted controls
!But at one mostly byte each, is very low overhead (32 values is same as two vars)

export type stylerec = struct
	byte	border				!bs_ code
	byte	justify				!'L', 'R', 'C'
	byte	vjustify			!'T', 'B', 'M'
	byte	windbgnd			!colour index for window background
	byte	textfgnd			!colour index
	byte	textbgnd			!
	byte	bgndmode			!
	byte	textfont			!font index
	byte	textsize			!pixel size
	byte	textbold			!1 if bold
	byte	textitalic			!1 if italic
	byte	ispassword			!1 when edit field is a password
	byte	fieldwidth			!edit field maximum char width
	byte	dir					!'L','R','U','D'
	byte	marktype			!xxx_mark style, or:
	byte	hilitetype			!xxx_hilite style
	byte	iframe				!1: pos/dim include frame
	byte	imark				!1: pos/dim include mark for toggle/select
	byte	hscroll				!1: include windows-drawn hoz scroll bar
	byte	vscroll				!1: include windows-drawn vert scroll bar
	byte	lbchange			!1: return mm_change on list boxes when row has changed
	byte	returnmess			!1: return id code when clicking toggle/select/editbox
	byte	noupdate			!1: don't change or allow editing on toggle/select/editbox
end

export record rpoint = var x,y end
export record rrect  =
	var pos,dim
end

export record rframe =
	var x1,y1,x2,y2
end

export record getrec=
	fun getbounds(&self)= 0
	fun getitem(&self,n)= 0
	fun getstritem(&self,n)= ""
end

export enumdata stylenames =	! (default)
	(ss_border,			$),		! Border style (wbs_simple)
	(ss_justify,		$),		! 'L' 'C' 'R'	Horizontal text justify ('L')
	(ss_vjustify,		$),		! 'T' 'M' 'B'	Vertical text justify ('M' for buttons)
	(ss_textfgnd,		$),		! Text colour index (black)
	(ss_textbgnd,		$),		! Text background colour index (if opaque mode) (0)
	(ss_bgndmode,		$),		! 0
	(ss_textfont,		$),		! Text font number (1)
	(ss_textsize,		$),		! (0)
	(ss_textbold,		$),		! (0)
	(ss_textitalic,		$),		! (0)
	(ss_ispassword,		$),		! (0)
	(ss_marktype,		$),		! Toggle/select mark style (radio_mark)
	(ss_hilitetype,		$),		! Toggle/select hilite style (no_hilite)
	(ss_iframe,			$),		! Whether pos and dim include frame width (also caption bar/menu for windows)
	(ss_windbgnd,		$),		! Background colour of window or button (ltgrey)
	(ss_imark,			$),		! Background colour of window or button (ltgrey)
	(ss_hscroll,		$),		! (0)
	(ss_vscroll,		$),		! (0)
	(ss_lbchange,		$),		! (0)
	(ss_returnmess,		$),		! (0) Toggle/select/editbox, return id when clicked
	(ss_noupdate,		$),		! (0) Toggle/select/editbox, don't change or allow edit
end

export enumdata drawmodenames =
								!HDC	HDC2	Restore
	(dm_screen=0,		$),		!screen	--		Custom routine	Draw directly to screen; no mem backup
	(dm_memory,			$),		!memory	--		NA				Draw to memory only; no screen hdc (eg. bitmap)
	(dm_screenmemory,	$),		!screen	memory	Blit mem->scr	Draw to both screen and memory at same time
	(dm_memoryscreen,	$),		!memory	screen	Blit mem->scr	Draw to memory; update screen periodically
end

!var windowlist=nil

export enumdata wfnames =
	(wa_rightclick=0,	$),		!allow right click
	(wa_middleclick,	$),		!allow middle click
	(wa_leftdbl,		$),		!allow left double click
	(wa_rightdbl,		$),		!allow right double click
	(wa_middledbl,		$),		!allow middle double click
	(wa_leftdrag,		$),		!allow left drag
	(wa_rightdrag,		$),		!etc
	(wa_middledrag,		$),
	(wa_autoupdate,		$),		!auto update screen for toggles/etc
	(wa_tab,			$), 	!allow tab to switch to next button which has watab
	(wa_strvar,			$), 	!1 for listbox linkvar to use string not index
	(wa_retmess,		$), 	!1 for button to return .value as mess not qmcommand
	(wa_retsel,			$), 	!1 for button to return .value as mess not qmcommand
	(wa_memory,			$), 	!1 when hdc/hdcmem have been switched, hdc points to memory dev
	(wa_maximised,		$),		!1 when maximised, 0 when normal/minimised
	(wa_param1,			$), 	!general purpose control-specific flags
	(wa_param2,			$), 
	(wa_useenter,		$),
	(wa_closed,			$),		!whether window has been closed

	(wa_$last,			$)
end

const wa_needdbl	= wa_param1	!1 requires double-click on listbox to return wmcommand
const wa_editdd		= wa_param2	!1 means editable dropdown box

!GX border styles, used for child windows.
!some child windows
export enumdata bsnames, bscat, bswidths=
	(bs_none=0,		$,	0,	ws_rect(0,0,0,0)),			!no border
!	(bs_windows,	$,	'W',	ws_rect(0,0,0,0)),			!windows-drawn, but no own-drawn border
	(bs_simplew,	$,	'W',	ws_rect(1,1,1,1)),			!single 1-pixel black line, windows drawn
	(bs_simple,		$,	'X',	ws_rect(1,1,1,1)),			!single 1-pixel black line
	(bs_thick,		$,	'X',	ws_rect(2,2,2,2)),			!2-pixel border
	(bs_panel,		$,	'X',	ws_rect(1,1,1,1)),			!raised panel, 1-pixel
	(bs_inset,		$,	'X',	ws_rect(1,1,1,1)),			!inset panel, 1-pixel
	(bs_ownsimple,	$,	'I',	ws_rect(0,0,0,0)),			!included inset panel, 1-pixel (drawn as part of client area)
	(bs_ownpanel,	$,	'I',	ws_rect(0,0,0,0)),			!included inset panel, 1-pixel (drawn as part of client area)
	(bs_owninset,	$,	'I',	ws_rect(0,0,0,0)),			!included inset panel, 1-pixel
	(bs_testext,	$,	'X',	ws_rect(10,10,10,10)),
	(bs_testint,	$,	'I',	ws_rect(8,8,8,8)),
	(bs_dummy,		$,	0,	ws_rect(0,0,0,0))
end

export enumdata windowclassnames, defaultborderstyles =
	(no_class=0,		$,	bs_none),			!Unassigned
	(window_class,		$,	wbs_resize),		!Main window
	(memwindow_class,	$,	wbs_none),			!memory backup to any window
	(popup_class,		$,	wbs_thick),			!Pop-up window (forms a stack)
	(float_class,		$,	bs_thick),			!Independent window
	(bitmap_class,		$,	bs_none),			!(image handling)
	(screen_class,		$,	bs_none),			!Describes the desktop screen (not owned by my app)
	(printer_class,		$,	bs_none),			!Used for printing

	(group_class,		$,	bs_inset),			!Used mainly for grouping other buttons (eg. for Smdefblock)
	(panel_class,		$,	bs_inset),			!General purpose panel for drawing in etc
!	(button_class,		$,	bs_panel),			!Click button
	(button_class,		$,	bs_simplew),		!Click button
	(toggle_class,		$,	bs_none),			!Toggle button (can be composite, eg mark and label)
	(select_class,		$,	bs_none),			!Select from several choices
	(editbox_class,		$,	bs_simplew),		!Single-line edit control
	(scrollbar_class,	$,	bs_simplew),		!Hoz or vert scroll bar (Some windows can also have Windows-drawn scroll bars)
	(listbox_class,		$,	bs_simplew),		!List of options (scrollable usually)
	(dropdown_class,	$,	bs_none),			!Button revealing attached listbox when clicked
	(framebar_class,	$,	bs_panel),			!Left or right full-height panel used for toolboxes etc
	(statusbar_class,	$,	bs_panel),			!Top or bottom full-width panel used for scrollbars
	(tooltip_class,		$,	bs_simplew),		!Tooltops displayed when hovering over enabled buttons
	(arrow_class,		$,	bs_ownpanel),		!Click button normally displaying an error in one of 4 orientations
	(mark_class,		$,	bs_none),			!Toggle or select mark
	(label_class,		$,	bs_none),			!Contains unclickable text usually
	(dummy_class,		$,	bs_none)
end

export enumdata actionnames=
	(draw_w,		$),
	(update_w,		$),
	(last_w,		$),
end

!MM Message Numbers

export enumdata messagenames=

!all messages have x,y coord relative to top most window or child window
!
	(mm_null=0,			$),		! empty message

!window messages
	(mm_activate,		$),		! (w,a) a=1/0 activate/deactivate window
	(mm_close,			$),		! (w) close window (X button clicked)
	(mm_sizewindow,		$),		! (w...) resize window
	(mm_movewindow,		$),		! (w...) move window
	(mm_restore,		$),		! (w...) repaint window

!cursor/focus messages
	(mm_setcursor,		$),		! (w...) update cursor type
	(mm_setfocus,		$),		! (w...) set focus to w
	(mm_killfocus,		$),		! (w...) lose focus from w

!basic mouse messages (click messages can be promoted to other messages eg mm_command)
	(mm_move,			$),		! (w,x,y,b) mouse move, btns up/down (also drag messages when down)
	(mm_click,			$),		! (w,x,y) left btn click, can be promoted to mm_command etc depending on context
	(mm_dblclick,		$),		! (w,x,y) left btn dbl click, usu promoted
	(mm_clickup,		$),		! (w,x,y) left btn released
	(mm_rclick,			$),		! (w,x,y) right click in window, these usu. promoted
	(mm_rdblclick,		$),		! (w,x,y) right double click
	(mm_rclickup,		$),		! (w,x,y) right button released
	(mm_mclick,			$),		! (w,x,y) middle button versions of above
	(mm_mdblclick,		$),		! (w,x,y)
	(mm_mclickup,		$),		! (w,x,y)
	(mm_hover,			$),		! (w,x,y) paused over button

	(mm_onwindow,		$),		! (w,x,y) newly over a window
	(mm_offwindow,		$),		! (w,x,y) just came off window
	(mm_draw,			$),		! (w,x,y) redraw window
	(mm_update,			$),		! (w,x,y) update window (change of pos etc)

!drag messages
	(mm_startdrag,		$),		! (w) start mouse movement with some btns down
	(mm_rstartdrag,		$),		! (w)
	(mm_mstartdrag,		$),		! (w)
	(mm_drag,			$),		! (w,x,y) moving mouse with buttons down (also qmmove sent)
	(mm_enddrag,		$),		! (w,x,y) all buttons up after drag

!left command
	(mm_command,		$),		! (w,id) button clicked, id and sub-event given
	(mm_dblcommand,		$),		! (w,id) button double clicked

!right command
	(mm_rcommand,		$),		! (w,id) right click button
	(mm_rdblcommand,	$),		! (w,id) right double click button

!middle command
	(mm_mcommand,		$),		! (w,id)
	(mm_mdblcommand,	$),		! (w,id)

!general key messages
	(mm_char,			$),		! (w,ch)
	(mm_key,			$),		! (w,k,shift)
	(mm_keyup,			$),		! (w,k,shift)

!scroll/select/wheel messages
	(mm_sethozpos,		$),		! (w,pos)		New logical position set by hoz scrollbar
	(mm_setvertpos,		$),		! (w,pos)		from vertical scrollbar
	(mm_select,			$),		! (w,n)			Set nth item as current/highlighted/selected item
	(mm_pick,			$),		! (w,n)			Pick and return item n
	(mm_wheel,			$),		! (w,delta)		Move log pos etc but depends on context
	(mm_lbchange,		$),		! (w,n)			A listbox position has changed

!misc messages
	(mm_timer,			$),		! (w)

!high level window messages
	(mm_cancel,			$),		! (w)
	(mm_ok,				$),		! (w)
	(mm_help,			$),		! (w,id)
	(mm_cmdline,		$),		! (w,s)

!specific key messages
	(mm_leftkey ,		$),		! (w,shift)
	(mm_rightkey,		$),		! (w,shift)
	(mm_upkey,			$),		! (w,shift)
	(mm_downkey,		$),		! (w,shift)
	(mm_pageupkey,		$),		! (w,shift)
	(mm_pagedownkey,	$),		! (w,shift)
	(mm_homekey,		$),		! (w,shift)
	(mm_endkey,			$),		! (w,shift)
	(mm_tabkey,			$),		! (w,shift)
	(mm_bskey,			$),		! (w,shift)
	(mm_deletekey,		$),		! (w,shift)
	(mm_enterkey,		$),		! (w,shift)
	(mm_insertkey,		$),		! (w,shift)
	(mm_functionkey,	$),		! (w,shift)

!Other messages for controls, mainly for attached arrow buttons
	(mm_up,				$),		! (w,id) Arrow up/etc
	(mm_down,			$),		! (w,id)
	(mm_right,			$),		! (w,id)
	(mm_left,			$),		! (w,id)
	(mm_edit,			$),		! (w,id)	Update of edit box
	(mm_edited,			$),		! (w,id)	Finished edit box entry (tab etc)
	(mm_last,			$)
end

!export const mm_scroll	= mm_hscroll	!general scroll independent of orientation

!!other messages wmuser+ are user assigned, usually applied as
!ids to controls. Depending on the options to Waitmess(), a wm_commmand message
!is coverted to a direct message number. So (wm_command, 230) is covered to
!message 230. So message ids have to start from 200 so that they occupy a different
!number space from normal message codes.
export const mm_user	= 200

export const kb_lbutton	= 0x1	!used in buttonstate
export const kb_rbutton	= 0x2
export const kb_mbutton	= 0x4

export const kb_shift	= 0x8	!used in shiftstate
export const kb_ctrl	= 0x10
export const kb_alt		= 0x20
export const kb_capslock	= 0x40
export const kb_dblclick	= 0x80	!used for some messages that don't have dblclick versions,

export const kb_rshift	= 0x100
export const kb_rctrl	= 0x200
export const kb_ralt	= 0x400

export enumdata colournames, colourvalues =
!					   BB'GG'RR
	(black,		$,	0x_00'00'00),
	(red,		$,	0x_00'00'C0),
	(dkred,		$,	0x_00'00'90),
	(red3,		$,	0x_00'00'70),
	(green,		$,	0x_00'C0'00),
	(dkgreen,	$,	0x_00'90'00),
	(green3,	$,	0x_00'70'00),
	
	(blue,		$,	0x_C0'00'00),
	(dkblue,	$,	0x_90'00'00),
	(blue3,		$,	0x_70'00'00),

	(cyan,		$,	0x_c0'c0'00),
	(dkcyan,	$,	0x_90'90'00),
	(cyan3,		$,	0x_70'70'00),

	(magenta,	$,	0x_c0'00'c0),
	(dkmagenta,	$,	0x_90'00'90),
	(magenta3,	$,	0x_70'00'70),

	(yellow,	$,	0x_00'C0'C0),
	(dkyellow,	$,	0x_00'90'90),
	(yellow3,	$,	0x_00'70'70),
	(yellow4,	$,	0x_00'50'50),

	(white,		$,	0x_FF'FF'FF),
	(ltgrey,	$,	0x_C0'C0'C0),
	(grey,		$,	0x_90'90'90),
	(dkgrey,	$,	0x_70'70'70),

	(ltorange,	$,	0x_00'A0'FF),
	(orange,	$,	0x_00'60'FF),
	(flesh,		$,	0x_70'85'EE),
	(pink,		$,	0x_9A'32'DB),
	(dkpink,	$,	0x_72'24'A9),
	(brown,		$,	0x_46'43'7D),
	(blue4,		$,	0x_B7'1C'5E),
	(blue5,		$,	0x_6F'3D'0D),
	(olive,		$,	0x_05'A0'88),
	(ltbrown,	$,	0x_00'70'B0),

	(blue6,		$,	0x_9C'63'1C),
	(green4,	$,	0x_12'51'11),
	(purple,	$,	0x_5E'0D'73),
	(blue7,		$,	0x_E6'27'1C),
	(crimson,	$,	0x_15'2A'D3),
	(violet,	$,	0x_54'16'A0),
	(blue8,		$,	0x_86'68'1E),
	(dkorange,	$,	0x_25'6A'D4),
	(green5,	$,	0x_09'46'41),
	(blue9,		$,	0x_65'0A'1D),

	(ltred,		$,	0x_00'00'FF),
	(ltgreen,	$,	0x_00'FF'00),
	(ltblue,	$,	0x_FF'00'00),
	(ltcyan,	$,	0x_FF'FF'00),
	(ltmagenta,	$,	0x_FF'00'FF),
	(ltyellow,	$,	0x_00'FF'FF),

!The following are the Windows system colours, set up as indices
!Init needs need to retrieve the values and set up the rgb values in this table
	(button_col,	$,	0),		!button colour
	(window_col,	$,	0),		!window colour
	(text_col,		$,	0),		!text in windows
end

export const skipmess = 1		!message has been processed; caller must wait for another message
export const thismess = 0		!caller should deal with this message (it has not been processed, or has been but caller can process it too)

export var bmbgnd
export var defstyle			!set initdata
export var currmess=nil

export var wapplic=nil
export var wscreen=nil

var data,ndata
var tabstack,ntab
var breakflag

const k_menu=30000
const kdivide=30001
const kcolumn=30002
const kfilehistory=30003

var caretdrawn=0
var dkcolour=0x000000
var ltcolour=0xFFFFFF
var thumbdragmode=0
var thumbstartpos=0

var dirtomess=['L':mm_left,'R':mm_right,'U':mm_up,'D':mm_down]

proc start=
!CPL "GXLIB START"

	initdata()
	mxinit()
	initmenuhandlers()
end

export proc setupgdi(w,hwnd)=			!SETUPGDI
!NOTE: rare care of a func within a data header. This is to allow bitmap module
!to be higher up the hierarchy than gx, but still let it use some gx functions.

!set up the default gdi descriptor for window w

	if w.gdi then
		return			!assume already done
	fi

	gdi:=new(rgdistate)
	gdi.hwnd:=hwnd

!start with default drawmodes of dm_screen, or dm_memory for bitmaps
!These can be converted later using gxdrawmode

	if w.type=rwindow then
		gdi.hdc:=getdc(hwnd)
		gdi.drawmode:=dm_screen
	else						!assume bitmap
		gdi.hdc:=createcompatibledc(nil)
		gdi.drawmode:=dm_memory
	fi

	gdi.posx:=gdi.posy:=0
	gdi.updated:=0
	gdi.font:=0
	gdi.pencolour:=getsyscolour(colour_windowtext)
	gdi.penwidth:=0
	gdi.penstyle:=ps_solid
	gdi.xormode:=0
	gdi.brushcolour:=0xff'ff'ff
	gdi.brushstyle:=bs_solid
	gdi.brushpattern:=0
	w.gdi:=gdi
	end

export const arleft = "<"
export const arright = ">"
export const arup = "^"
export const ardown = "V"

export var allwindows::=()			!list of all windows and controls

export func ctrlpressed = return (currmess.state iand kb_ctrl) end
export func shiftpressed = return (currmess.state iand kb_shift) end

proc initdata=
	messagequeue:=new(list,100)
	nmessages:=0

	colourvalues::=colourvalues

	colourvalues[button_col]:=getsyscolour(colour_btnface)

	colourvalues[window_col]:=getsyscolour(colour_window)
	colourvalues[text_col]:=getsyscolour(colour_windowtext)

	defstyle:=new(stylerec)
	defstyle.border		:= bs_simplew
	defstyle.justify	:= 'L'
	defstyle.vjustify	:= 'M'
	defstyle.textfgnd	:= black
	defstyle.marktype	:= check_mark
	defstyle.hilitetype	:= no_hilite
	defstyle.windbgnd	:= button_col
	defstyle.imark		:= 1
!defstyle.windbgnd	:= window_col

	init_handlertables()
	d:=gxchardim(labelfont)
	chx:=d.x
	chy:=d.y

	d:=gxchardim(0,1)
	cha:=d.x
	chd:=d.y
	arrowdim:=chy+2
	markdim:=arrowdim-2

	buttonheight:=chy+smy*2
	listrowheight:=chy+smy*2
end

export func gxcreatewindow(?caption,?pos,?dim,?options,owner=nil)=		!CREATEWINDOW
	#create a popup window which is not a child window.
	#(nevertheless, it can have an owner window, such as the main window of the
	#application)
	#returns an rwindow handle
	#caption	optional caption txt
	#pos		(x,y) is pixel pos of top left corner in screen coordinates (of frame?)
	#		"cent" to place centrally
	#		omitted: use default placement
	#dim		(width,height) overall pixel size
	#		"max" maximised
	#		"desktop" fill desktop screen
	#		omitted: use (640,480)
	#owner	optional owner window (default nil)
	#options	option dict, default is [wf_caption:1, wf_border:wbs_resize]

	hwnd:=wx_createpopup(caption,pos,dim,options,(owner|owner.gdi.hwnd|nil))

	w:=newwindow(hwnd,0,no_class,bs_windows)

	if wapplic=nil then
		wapplic:=w
	fi

	W.STYLE:=NEW(STYLEREC)
	W.STYLE.BORDER:=0
	W.WINDCLASS:=WINDOW_CLASS
	W.STYLE.WINDBGND:=WINDOW_COL
	W.ENABLE:=1
	W.FLAGS.[WA_LEFTDRAG]:=1
	W.FLAGS.[WA_LEFTDBL]:=1

	setwindowdims_w(w,hwnd)

	setupgdi(w,hwnd)
	gxfont(w,1)

	GXDRAWMODE(W,DM_SCREENMEMORY)
	GXCLEAR(W)

	return w
end

proc setwindowdims_w(w,hwnd)=			!SETWINDOWDIMS
!use windows functions to set up client and frame pos and dims of top-level window

	box:=new(ws_rect)
	getwindowrect(hwnd,&box)
	w.frameposx:=box.x
	w.frameposy:=box.y
	w.framedimx:=box.x2-box.x
	w.framedimy:=box.y2-box.y

	getclientrect(hwnd,&box)

	w.dimx:=box.x2-box.x
	w.dimy:=box.y2-box.y

	pt:=ws_point(0,0)
	clienttoscreen(hwnd,&pt)		!pos starts at 0,0
	w.posx:=pt.x
	w.posy:=pt.y
end

proc setwindowdims_c(w,hwnd)=			!SETWINDOWDIMS
!use windows functions to set up client and frame pos and dims of child window


	box:=new(ws_rect)
	getwindowrect(hwnd,&box)			!client dims also Windows frame dims as has no Windows border
	w.posx:=box.x-w.owner.posx
	w.posy:=box.y-w.owner.posy
	w.dimx:=box.x2-box.x
	w.dimy:=box.y2-box.y

	widths:=bswidths[w.style.border]
	if bscat[w.style.border]='I' then widths:=ws_rect(0,0,0,0) fi

	w.frameposx:=w.posx-widths.x1
	w.frameposy:=w.posy-widths.y1
	w.framedimx:=w.dimx+widths.x1+widths.x2
	w.framedimy:=w.dimy+widths.y1+widths.y2
end

export proc gxclear(w,?colour)=			!GXCLEAR
	#fill window w with <colour>, or with current background if omitted

!RETURN
	gdi:=w.gdi
	gdi.updated:=1

	gxcolour(w,getrgb(black))
	gxstyle(w,0)

	if colour.isvoid then
		colour:=getrgb(w.style.windbgnd)
	fi

	oldpenstyle:=gdi.penstyle
	oldbrushstyle:=gdi.brushstyle

	gxbrushstyle(w,bs_solid)
	gxstyle(w,ps_null)

	gxfillrect(w,0,0,w.dimx,w.dimy,colour)
	gxbrushstyle(w,oldbrushstyle)
	gxstyle(w,oldpenstyle)
end

export func gxstyle(w,?style)=			!GXSTYLE
	#style omitted: get pen current pen style
	#style supplied: set pen style for subsequent line drawing
	#Style is a char code or int refering to a small variety of Windows dotted styles:
	#	0 S |		Solid
	#	Space		Null (pen up?)
	#	-			Dotted
	#	:			Dashdotdot
	#	!			Dashdotd
	#	F			Inside frame

	gdi:=w.gdi

	if style.isdef and gdi.penstyle<>style then
		case style
		when '!' then style:=ps_dashdot
		when ':' then style:=ps_dashdotdot
		when '-' then style:=ps_dot
		when ' ' then style:=ps_null
		when 'D' then style:=ps_alternate
		when '|','S',0 then style:=ps_solid
		when 'F' then style:=ps_insideframe
		esac

		gdi.penstyle:=style
		if style>=10 then style:=ps_dot fi
		deleteobject(selectobject(gdi.hdc,createpen(style,gdi.penwidth,gdi.pencolour)))
		if gdi.drawmode=dm_screenmemory then
			deleteobject(selectobject(gdi.hdc2,createpen(style,gdi.penwidth,gdi.pencolour)))
		fi
	fi
	return gdi.penstyle
end

export proc gxbrushstyle(w,?style,?pattern)=		!GXBRUSHSTYLE
	#Set Windows brush style and pattern
	#Style supplied:	set style
	#pattern supplied:	set style
	#style is:		S, H, Space, B for Solid, Hatched, Null, DIB
	#pattern is:	- | \ / + x/X for Hoz, Vert, Diag, Fwd Diag, Cross, Diag Cross

	gdi:=w.gdi
	brush:=new(ws_logbrush)

	if style.isdef then
		if style<>gdi.brushstyle then
			case style
			when 'S' then style:=bs_solid
			when 'H' then style:=bs_hatched
			when ' ' then style:=bs_null
			when 'B' then style:=bs_dibpattern
			esac

			gdi.brushstyle:=style
		fi
		gdi.brushpattern:=0		!default to no pattern, will be changed by pattern if supplied
	fi

	if pattern.isdef and pattern<>gdi.brushpattern then
		case pattern
		when '-' then pattern:=hs_horizontal
		when '|' then pattern:=hs_vertical
		when '\\' then pattern:=hs_fdiagonal
		when '/' then pattern:=hs_bdiagonal
		when '+' then pattern:=hs_cross
		when 'x','X' then pattern:=hs_diagcross
		esac
		gdi.brushpattern:=pattern
	fi

	brush.lbstyle:=gdi.brushstyle
	brush.lbcolour:=gdi.brushcolour
	brush.lbhatch:=gdi.brushpattern

	deleteobject(selectobject(gdi.hdc,createbrushindirect(&brush)))
	if gdi.drawmode=dm_screenmemory then
		deleteobject(x:=selectobject(gdi.hdc2,createbrushindirect(&brush)))
	fi
end

export func gxbrushcolour(w,?colour)=			!GXBRUSHCOLOUR
	#colour supplied:	set current fill colour
	#colour omitted:	return current fill colour

	gdi:=w.gdi

	if colour.isdef and colour<>gdi.brushcolour then
		gdi.brushcolour:=colour
		brush:=new(ws_logbrush)
		brush.lbstyle:=gdi.brushstyle
		brush.lbcolour:=colour
		brush.lbhatch:=gdi.brushpattern

		deleteobject(selectobject(gdi.hdc,createbrushindirect(&brush)))
		if gdi.drawmode=dm_screenmemory then
			deleteobject(selectobject(gdi.hdc2,createbrushindirect(&brush)))
		fi
	fi
	return gdi.brushcolour
end

export proc gxfillrect(w,x,y,width,height,?colour,mode=0)=		!GXFILLRECT
	#Draw filled rectangle with optional outline
	#x,y are top-left coordinates
	#width, height are overall pixel dimensions, inclusive; they include any outline
	#(When the outline is drawn, the filled region is 1 pixel smaller all round)
	#colour is the colour of the filled region (current brush colour when omitted)
	#mode=1 to draw the outline, or mode=0 (default) to omit it
	#The outline is drawn in the current pen colour

	gdi:=w.gdi
	gdi.updated:=1

	oldbrushcolour:=gdi.brushcolour
	if colour.isdef then
		gxbrushcolour(w,colour)
	fi

	oldpenstyle:=gdi.penstyle
	if mode=0 then		!inside only
		gxstyle(w,ps_null)
	fi

	if height<0 then y:=y+height+1; height:=-height fi
	if width<0 then x:=x+width+1; width:=-width fi

	if mode=0 then		!inside only, needs extra pixel width
		rectangle(gdi.hdc,x, y,x+width+1,y+height+1)
		if gdi.drawmode=dm_screenmemory then
			rectangle(gdi.hdc2,x,y,x+width+1,y+height+1)
		fi
	else			!inside and outside
		rectangle(gdi.hdc,x, y, x+width, y+height)
		if gdi.drawmode=dm_screenmemory then
			rectangle(gdi.hdc2,x,y,x+width,y+height)
		fi
	fi
	gxstyle(w,oldpenstyle)
	gxbrushcolour(w,oldbrushcolour)
end

export func gxcolour(w,?colour)=		!GXCOLOUR
	# colour supplied:	set current outline colour for subsequent line drawing
	# colour omitted:	return current outline colour

	gdi:=w.gdi

	if colour.isdef and gdi.pencolour<>colour then
		gdi.pencolour:=colour
		gdi.xormode:=0
		deleteobject(selectobject(gdi.hdc,createpen(gdi.penstyle,gdi.penwidth,gdi.pencolour)))
		setrop2(gdi.hdc,r2_copypen)
		if gdi.drawmode=dm_screenmemory then
			deleteobject(selectobject(gdi.hdc2,createpen(gdi.penstyle,gdi.penwidth,gdi.pencolour)))
			setrop2(gdi.hdc2,r2_copypen)
		fi

	fi

	return gdi.pencolour
end

export proc gxsetpen(w,pen)=
	gxcolour(w,getrgb(pen))
end

export proc gxline(w,x,y,?x2,?y2)=		!GXLINE
	#gxline(w,x,y)			Draw line from current position to x,y
	#gxline(w,x,y,x2,y2)	Draw line from x,y to x2,y2

	gdi:=w.gdi

	if x2.isvoid then		!assume 2 params
		x2:=x
		y2:=y

		movetoex(gdi.hdc,gdi.posx, gdi.posy)
		if gdi.drawmode=dm_screenmemory then
			movetoex(gdi.hdc2,gdi.posx, gdi.posy)
		fi
	else
		movetoex(gdi.hdc,x, y)
		if gdi.drawmode=dm_screenmemory then
			movetoex(gdi.hdc2,x, y)
		fi
		gdi.posx:=x
		gdi.posy:=y
	fi

	lineto(gdi.hdc,x2,y2)

	if gdi.drawmode=dm_screenmemory then
		lineto(gdi.hdc2,x2,y2)
	fi
	gdi.posx:=x2
	gdi.posy:=y2
end

export func gxwidth(w,width)=
!get/set pen width for subsequent line drawing
	gdi:=w.gdi
	if width.isvoid then
		return gdi.penwidth
	fi

	if gdi.penwidth<>width then
		gdi.penwidth:=width
		deleteobject(selectobject(gdi.hdc,createpen(gdi.penstyle,gdi.penwidth,gdi.pencolour)))
		if gdi.drawmode=dm_screenmemory then
			deleteobject(selectobject(gdi.hdc2,createpen(gdi.penstyle,gdi.penwidth,gdi.pencolour)))
		fi

	fi
	return width
end

export proc gxlinerel(w,dx,dy)=		!GXLINEREL
	#Draw line from current position, to current position + (dx,dy)

	gdi:=w.gdi
	movetoex(gdi.hdc, gdi.posx, gdi.posy)
	if gdi.drawmode=dm_screenmemory then
		movetoex(gdi.hdc2, gdi.posx, gdi.posy)
	fi
	x:=gdi.posx+dx
	y:=gdi.posy+dy
	gxline(w,x,y)
	gdi.posx:=x
	gdi.posy:=y
end

export proc gxmove(w,x2,y2)=		!GXMOVE
	#Set current position to x2,y2

	gdi:=w.gdi

	movetoex(gdi.hdc, x2, y2)
	if gdi.drawmode=dm_screenmemory then
		movetoex(gdi.hdc2,x2, y2)
	fi
	gdi.posx:=x2
	gdi.posy:=y2
end

export proc gxmoverel(w,dx,dy)=		!GXMOVEREL
	#	Set current position to current position+(dx,dy)
	gdi:=w.gdi

	gdi.posx+:=dx
	gdi.posy+:=dy

	movetoex(gdi.hdc,gdi.posx, gdi.posy)
	if gdi.drawmode=dm_screenmemory then
		movetoex(gdi.hdc2,gdi.posx, gdi.posy)
	fi
end

export proc gxrect(w,x,y,width,height)=		!GXRECT
	#draw outline rectangle starting from x,y at top left, in current pen colour
	#overall size is width by height pixels inclusive (x,y to x+width+1,y+height-1)
	#outline is 1 pixel wide

	gdi:=w.gdi
	gdi.updated:=1
	if height<0 then y:=y+height+1; height:=-height fi
	if width<0 then x:=x+width+1; width:=-width fi

	oldbrushstyle:=gdi.brushstyle
	gxbrushstyle(w,bs_hollow)

	rectangle(gdi.hdc,x, y, x+width, y+height)
	if gdi.drawmode=dm_screenmemory then
		rectangle(gdi.hdc2,x, y, x+width,y+height)
	fi
	gxbrushstyle(w,oldbrushstyle)
end

export proc gxcircle(w,x,y,r)=		!GXCIRCLE
	#draw circle at centre x,y in window w, of radius r, using current pen colour
	#outline is 1 pixel wide

	gdi:=w.gdi
	gdi.updated:=1
	oldbrushstyle:=gdi.brushstyle
	gxbrushstyle(w,bs_hollow)

	ellipse(gdi.hdc,x-r, y-r, x+r-1, y+r-1)
	if gdi.drawmode=dm_screenmemory then
		ellipse(gdi.hdc2,x-r, y-r, x+r-1, y+r-1)
	fi
	gxbrushstyle(w,oldbrushstyle)
end

export proc gxfillcircle(w,x,y,r,?colour,mode=0)=		!GXFILLCIRCLE
	#Draw filled circle with optional outline
	#x,y is the centre, r is the radius
	#(When the outline is drawn, the filled region is 1 pixel smaller all round)
	#colour is the colour of the filled region (current brush colour when omitted)
	#mode=1 to draw the outline, or mode=0 (default) to omit it
	#The outline is drawn in the current pen colour
	gdi:=w.gdi

	gdi.updated:=1
	oldbrushcolour:=gdi.brushcolour
	if colour.isdef then
		gxbrushcolour(w,colour)
	fi

	oldpenstyle:=gdi.penstyle
	if mode=0 then		!inside only
		gxstyle(w,ps_null)
	fi

	ellipse(gdi.hdc,x-r, y-r, x+r-1, y+r-1)
	if gdi.drawmode=dm_screenmemory then
		ellipse(gdi.hdc2,x-r, y-r, x+r-1, y+r-1)
	fi

	gxstyle(w,oldpenstyle)
	gxbrushcolour(w,oldbrushcolour)
end

export func gxpixel(w,x,y,?colour)=		!GXPIXEL
	#colour provided: set pixel at point x,y of window w to colour
	#colour omitted: return pixel colour from point x,y
!set pixel at x,y with given rgb colour, or return pixel value if omitted (-1)
	w.gdi.updated:=1

	if colour.isvoid then		!get pixel
		res:=getpixel(w.gdi.hdc, x, y)
		if w.gdi.drawmode=dm_screenmemory then
			getpixel(w.gdi.hdc2, x, y)
		fi
		return res
	else
		setpixel(w.gdi.hdc,x, y, colour)
		if w.gdi.drawmode=dm_screenmemory then
			setpixel(w.gdi.hdc2,x,y,colour)
		fi
		return colour
	fi
end

export func gxcaption(w,?caption)=		!GXCAPTION
	#caption omitted:  return current window caption text
	#caption provided: set new window caption text

	case w.windclass
	when window_class,popup_class then

		if caption.isdef then		!set text
			setwindowtext(w.gdi.hwnd,caption)
			return caption
		else
			buffer:=new(array,byte,512)
			n:=getwindowtext(w.gdi.hwnd,int(&buffer),buffer.len)
			if n then
				s:=makestr(&buffer,n)		!needs assigment to ensure a copy is made befor buffer
											!is freed (assignment of return value might do the same)
			else
				s:=""
			fi
			return s
		fi
	esac

	if caption.isdef then		!set text
		w.text:=caption
		gxdraw(w)
	fi

	return w.text
end

export proc gxtext(w,s,?x,?y)=		!GXTEXT
	#Display text s
	#Text is drawn starting at (x,y) when provided, otherwise at current position
	#insertion point refers either to base line, or to top left of cell (not sure)
	#Text is drawn in current font, size, style and mode
	#Text typically contains no control codes, but can also contain cr and lf (also
	#tabs, but currently position isn't changed). However, text with control codes is
	#drawn a character at a time
	#Finishes with current position set to the end of the text

!uses chr(16) for reverse tab. Reverse tabs are usually encoded as:
!  chr(9)+chr(16), ie. normal tab then reverse tab
!Reverse tab, after tabbing to next stop, then moves position back by width
!of next substring

	return when s=""

	gdi:=w.gdi

	if x.isvoid then x:=gdi.posx fi
	if y.isvoid then y:=gdi.posy fi
	gdi.updated:=1

!scan the string and create a table of substrings and control codes
	startpos::=lengths::=()
	ngroups:=0

	foreach i,c in s do
		if c<32 then
			++ngroups
			startpos[ngroups]:=i
			lengths[ngroups]:=0
		else
			if ngroups and lengths[ngroups] then		!extend this group
				++lengths[ngroups]
			else										!start new substring group
				++ngroups
				startpos[ngroups]:=i
				lengths[ngroups]:=1
			fi
		fi
	od

	for i,l in lengths do
		pos:=startpos[i]
		if l then
			slicex:=pos..pos+l-1
			textout(gdi.hdc,x, y,s.[slicex],l)

			if gdi.drawmode=dm_screenmemory then
				textout(gdi.hdc2,x,y,s.[slicex],l)
			fi
			x +:= gxtextwidth(w,s.[slicex])

		else				!Deal with control codes
			case s.[pos]
			when 13 then
				x:=0
			when 10 then
				y+:=20				!NEEDS TO PICK CURRENT FONT DIMS

			when 9,16 then			!16 will be used as reverse tab
				currx:=x
				x:=0
				for t in tabstops do
					x+:=t*chx				!MUST BE CURRENT FONT NOT CHX
					if x>currx then exit fi
				od
				while x<=currx do x+:=chx*8 od

				if s.[pos]=16 and i<ngroups and lengths[i+1] then	!reverse offset for next substring
					pos:=startpos[i+1]
					x -:= gxtextwidth(w,s.[pos..pos+lengths[i+1]-1])+1
				fi

			esac	
		fi
	od

	gdi.posx:=x
	gdi.posy:=y
end

export func gxtextcolour(w,?colour,?bgndcolour)=		!GXTEXTCOLOUR
	#Set either text foreground colour or background colour, or both, or neither,
	#depending on which are supplied
	#Text colours will be colour indices, not rgb
	#Always returned current or new foreground

	gdi:=w.gdi

	if colour.isdef and colour<>w.style.textfgnd then
		w.style.textfgnd:=colour
		settextcolour(gdi.hdc,getrgb(colour))
		if gdi.drawmode=dm_screenmemory then
			settextcolour(gdi.hdc2,getrgb(colour))
		fi
	fi
	if bgndcolour.isdef and bgndcolour<>w.style.textbgnd then
		gxbgndcolour(w,bgndcolour)
	fi

	return w.style.textfgnd
end

export func gxtextwidth(font,?s)=		!GXTEXTWIDTH
	# font is a window, or a font number within fonttable
	# font can be zero (then uses font 1)
	# return total pixel width of string s, using given font

	if s="" then return 0 fi

!if not font.isint then			!aasume font is window
!CPL =FONT
!CPL =FONT.TYPE


!if not font.ispointer then			!aasume font is window
	if not font.isint then			!aasume font is window
		font:=font.gdi.font
	fi
	if font=0 then font:=1 fi

	selectobject(screendc,fonttable[font])
	widthheight:=new(ws_point)

!CPL =S

	gettextextentpoint32(screendc,s,s.len,&widthheight)

	return widthheight.x
end

export func gxloadfont(n,facename,?style,height=0,width=0)=		!GXLOADFONT
	#define new font
	#N is index into fonttable
	#facename is the name of the font
	#Style is optional font style, a string containing any of:
	#	B,b		Bold
	#	I,i		Italic
	#	U,u		Underline
	#	S,s		Strikeout
	#Height is height of text (default 0, gives default height?)
	#Weight is width; defautl 0 normally used for normal aspect of text

	CPL "GXLOADFONT"

	if n<=0 then return 0 fi
!n:=min(n,nglobalfonts)

	if style.isvoid then style:="" fi

	if n<=nglobalfonts and fonttable[n] then			!remove existing font
		igxremovefont(n)
	fi

	p:=style
	bold:=400
	italic:=0
	underline:=0
	strikeout:=0
	for c in style do
		case asc(convuc(c))
		when 'B' then bold:=700
		when 'I' then italic:=1
		when 'U' then underline:=1
		when 'S' then strikeout:=1
		esac
	od

	hfont:=createfont(
		facename:	facename,
		height:		height,
		width:		width,
		bold:		bold,
		italic:		italic,
		underline:	underline,
		charset:	0,
		quality:	2,
		escapement:	0,
		orientation:0)

	if hfont=0 then
		hfont:=getstockobject(system_font)
	fi

	fonttable[n]:=hfont
	nglobalfonts:=max(n,nglobalfonts)

	selectobject(screendc,fonttable[n])

	tm:=new(ws_textmetrics)

	gettextmetrics(screendc,&tm)

	fontdimtable[n]::=ws_point(tm.avecharwidth, tm.height+tm.externalleading)
	fontvdimtable[n]::=ws_point(tm.ascent, tm.descent)

	selectobject(screendc,getstockobject(system_font))

	return n
end

proc igxremovefont(n)=
!unload font n, free table entry

	unless n in 1..nglobalfonts then return end
	if fonttable[n]=0 then return fi	!already freed

!w:=windowlist
!while w<>nil do
!	if w.gdi.hdc and w.gdi.font>0 then		!font was in use, set as undefined
!		w.gdi.font:=1
!		selectobject(w.gdi.hdc,fonttable[w.gdi.font])
!		if w.gdi.hdc2 then
!			selectobject(w.gdi.hdc2,fonttable[w.gdi.font])
!		fi
!	fi
!	w:=w.nextwind
!od

	deleteobject(fonttable[n])		!get rid of this font
	fonttable[n]:=0
end

export func gxfont(w,font=1)=		!GXFONT
	# select font from font table for subsequent text display; default is font 1

	if not w then w:=wapplic fi
	if not w then w:=wscreen fi

	gdi:=w.gdi

	if font.isdef and font<>gdi.font then
		if font not in 1..nglobalfonts then
			abort("Bad font number "+tostr(font))
		fi
		gdi.font:=font
		if fonttable[font]=0 then
			abort("Font not in use "+tostr(font))
		fi

		oldhfont:=selectobject(gdi.hdc,fonttable[font])
		sendmessage(gdi.hwnd,wm_setfont,fonttable[font],0)

		if gdi.drawmode=dm_screenmemory then
			oldhfont:=selectobject(gdi.hdc2,fonttable[font])
			sendmessage(gdi.hwnd2,wm_setfont,fonttable[font],0)
		fi
		if fontdimtable[font].x=0 then		!set up dims
			gxchardim(font,0)
		fi
	fi
	return gdi.font
end

func hascontrolchars(s)=		!TESTCTRLCHAR
!scan string s looking for control chars
!return 1 if control chars (<20H) are present

	foreach c in s do
		if c<32 then return 1 fi
	od
	return 0
end

export func gxchardim(font,vert=0)=			!GXCHARDIM
	#return font char average width/height info as a point rec
	#wfont is a font number, or hwindow when the current font in that window is used
	#vert=1 means get ascent/descent pair instead of (vert=0) average width/height

	if not font.isint then
		font:=font.gdi.font
	fi
	if font=0 then font:=1 fi

!CPL =FONTDIMTABLE,=FONT

	if fontdimtable[font].x=0 then		!probably stock fonts not setup with gxloadfont
		selectobject(screendc,fonttable[font])
		tm:=new(ws_textmetrics)
		gettextmetrics(screendc,&tm)

		fontdimtable[font]::=ws_point(tm.avecharwidth, tm.height+tm.externalleading)

		fontvdimtable[font]::=ws_point(tm.ascent, fontvdimtable[font].y:=tm.descent)

		selectobject(screendc,getstockobject(ansi_var_font))
	fi

	if vert then
		return fontvdimtable[font]
	fi

	return fontdimtable[font]
end

export func gxbgndcolour(w,?colour)=		!GXBGNDCOLOUR
	#Set background colour (for text mainly)
	#colour will be a colour index
	#return current colour when omitted
	gdi:=w.gdi

	if colour.isdef then

		if colour<>w.style.textbgnd then
			w.style.textbgnd:=colour
			setbkcolour(gdi.hdc,getrgb(colour))
			if gdi.drawmode=dm_screenmemory then
				setbkcolour(gdi.hdc2,getrgb(colour))
			fi
		fi
		gxbgndmode(w,(colour<>w.style.windbgnd|1|0))
	fi
	return w.style.textbgnd
end

export func gxbgndmode(w,?mode)=		!GXBGNDMODE
	#	mode supplied: set new background mode:
	#		1 y Y T		Set opaque (T for True? Looks like Transparent)
	#		0 n N F		Set Transparent

	gdi:=w.gdi

	if mode.isdef  then
		case mode
		when 1,'y','Y','T' then
			w.style.bgndmode:=opaque
		else
			w.style.bgndmode:=transparent
		esac

		setbkmode(gdi.hdc,mode+1)
		if gdi.drawmode=dm_screenmemory then
			setbkmode(gdi.hdc2,mode+1)
		fi
	fi
	return w.style.bgndmode
end

export proc gxhighlight(w,x,y,width,height)=		!GXHIGHLIGHT
	#Invert rectangular region
	const dstinvert=0x00550009	!patblt
	gdi:=w.gdi

	gdi.updated:=1
	patblt(gdi.hdc, x, y, width,height,dstinvert)
	if gdi.drawmode=dm_screenmemory then
		patblt(gdi.hdc2, x,y, width,height,dstinvert)
	fi
end

export proc gxbitblt(w,x2,y2,width,height,x,y)=			!GXBITBLT
	#Copy rectangular region of window to another location
	gdi:=w.gdi
	gdi.updated:=1
	bitblt(gdi.hdc, x2, y2, width,height,
				gdi.hdc,x,y,srccopy)

	if gdi.drawmode=dm_screenmemory then
		bitblt(gdi.hdc2,x2,y2,width,height,gdi.hdc2,x,y,srccopy)
	fi
end

export func gxaskmess(mode=0)=
	#wait for next message and return message number
	#return 0 if close or quit message seen
	#some messages will be ignored here (processsed via procmess) and will wait for next
	#mode=0		Return currmess.message
	#mode=1		Return currmess.message, but if a mm_command message, then return
	#			the command id. This means message numbers and command ids share the
	#			same space. This should work because messages are below 200, and ids above 200

!CPL "AM1",$REFCOUNT(WAPPLIC)
	repeat
		if mxwait_mm_message()=0 then
CPL "GXAM MAXWAIT =0"
			return mm_cancel
		fi
		if quitmess then return mm_cancel fi
		x:=process_message(currmess)

		if currmess.message=mm_key and currmess.a=27 then
			return mm_cancel
		fi

	until x=thismess					!message ready to return

	if mode=1 and currmess.message=mm_command then
		return currmess.a
	fi

	return currmess.message
end

func process_message(mess)=
	#user or default event processing for mm message
	#will call event handler if there is one
	#returns 1 (skipmess) if message has been processed here; caller must wait for another message
	#returns 0 (thismess) caller should deal with this message (it has not been processed, or has beenbut caller can process it too)

!	CP "	";SHOWMESSAGE("PROCMESS",MESS)


	if mess.wind=nil then
		return thismess
	fi

	case mess.message
	when mm_close then
		return thismess
	esac

!CPL "PROCESS MESSAGE"

	status:=domessage(mess)
!CPL =STATUS,"AFTER DOMESS"

	return status
end

export proc docs=
!export proc where dostringzs for entire lib can go
	#Option dicts: used as args to gccreatewindow/gxcreatechildwindow:
	#	wf_border		Border style; see wbs_ enums
	#	wf_resize		1 for resizable border (for top-level windows)
	# wf_hscroll		1 for horizontal scrollbar
	# wf_vscroll		1 for vertical scrollbar
	# wf_menu			1 for a menubar
	# wf_caption		1 for a caption bar (needs to be the right kind of border too)
	# wf_max			1 for a max button
	# wf_minmax		1 for a min/max buttons
	# wf_sysmenu		1 for a system menu (right-click on top left I think)
	# wf_desktop		1 to fill desktop
	# wf_clip			1 to clip windows to desktop
	# wf_show			1 to show window after creating
	# wf_iframe		1 for pos/dim to refer to frame rather than client area
	# wf_cent			1 to centre window
	# wf_toolwind		1 for tool window (not sure what this means)

end

func newwindow(hwnd,index,windclass,borderstyle)=

	w:=new(rwindow,0)
	w.windclass:=windclass
!w.style.borderstyle:=borderstyle
	w.index:=index
	w.childlist::=()
	w.owner:=nil
	w.closed:=0

	addwindow(w)
	wx_setw(hwnd,w.gindex)
	return w
end

export func getrgb(index)=
	if index=0 then return 0 fi
	return colourvalues[index]
end

func readstyle(owner,windclass,options)=
!process gx options stored in the given dict type
!return a stylerec all filled in

	if options.type=stylerec then			!already a stylerec
		return options
	fi

	ss:=new(stylerec)
	if options.isvoid then				!use bunch of defaults
		d::=defstyle
		d.border:=defaultborderstyles[windclass]
		return d
	fi

	ss.border	:=options{ss_border,defaultborderstyles[windclass]}
	ss.justify	:=options{ss_justify,defstyle.justify}
	ss.vjustify	:=options{ss_vjustify,defstyle.vjustify}
	ss.textfgnd	:=options{ss_textfgnd,defstyle.textfgnd}
	ss.textbgnd	:=options{ss_textbgnd,defstyle.textbgnd}
	ss.bgndmode	:=options{ss_bgndmode,defstyle.bgndmode}

	ss.iframe	:=options{ss_iframe,0}

	ss.hilitetype	:=options{ss_hilitetype,defstyle.hilitetype}
	ss.marktype	:=options{ss_marktype,(ss.hilitetype|0|defstyle.marktype)}
	ss.imark	:=options{ss_imark,defstyle.imark}

	if windclass in [toggle_class, select_class,mark_class] and ss.marktype then
		def:=owner.style.windbgnd
	else
		def:=defstyle.windbgnd
	fi

	ss.windbgnd	:=options{ss_windbgnd,def}
	ss.hscroll	:=options{ss_hscroll,0}
	ss.vscroll	:=options{ss_vscroll,0}
	ss.lbchange	:=options{ss_lbchange,0}
	ss.returnmess	:=options{ss_returnmess,0}
	ss.noupdate	:=options{ss_noupdate,0}

	return ss
end

export func gxpanel(owner,pos,dim,?style)=
	ss:=readstyle(owner,panel_class,style)
	w:=gxcontrol(owner,panel_class,pos,dim,ss)
	gxdraw(w)

	return w
end

export func gxgroup(owner,pos,dim,?style)=
	ss:=readstyle(owner,group_class,style)
	w:=gxcontrol(owner,group_class,pos,dim,ss)
	gxdraw(w)

	return w
end

export func gxstatusbar(owner,pos,dim,?style)=

	ss:=readstyle(owner,statusbar_class,style)

	if ss.iframe=0 then					!frame not included, but can't have it leaking outside owner
		bs:=ss.border
		if bscat[bs]<>'I' then			!do adjustments
			dim+:=bswidths[bs].y1+bswidths[bs].y2
		fi
		ss.iframe:=1					!stop gxcontrol expanding dims
	fi

	(ecapos,ecadim):=gxclientarea(owner)

	if pos.isint then pos:=chr(pos) fi
!if pos.ispointer then pos:=chr(pos) fi
	if convuc(pos) in "T TOP" then			!along the top
		pos:=ecapos
		dir:='T'
	else									!along the bottom
		pos:=(ecapos[1],ecadim[2]-dim+ecapos[2])
		dir:='B'
	fi
	dim:=(ecadim[1],dim)

	ss.dir:=dir

	w:=gxcontrol(owner,statusbar_class,pos,dim,ss)

	gxdraw(w)

	return w
end

export func gxframebar(owner,pos,dim,?style)=

	ss:=readstyle(owner,framebar_class,style)
	if ss.iframe=0 then					!frame not included, but can't have it leaking outside owner
		bs:=ss.border
		if bscat[bs]<>'I' then			!do adjustments
			dim+:=bswidths[bs].y1+bswidths[bs].y2
		fi
		ss.iframe:=1					!stop gxcontrol expanding dims
	fi

	(ecapos,ecadim):=gxclientarea(owner)

!if pos.isint then pos:=chr(pos) fi
	if pos.ispointer then pos:=chr(pos) fi
	if convuc(pos) in "L LEFT" then			!along the left
		pos:=ecapos
		dir:='L'
	else									!along the right
		pos:=(ecadim[1]-dim+ecapos[1],ecapos[2])
		dir:='R'
	fi
	dim:=(dim,ecadim[2])

	ss.dir:=dir

	w:=gxcontrol(owner,	framebar_class,pos,dim,ss)

	gxdraw(w)

	return w
end

export func gxbutton(owner,pos,dim,caption,?style,id=201,enable=1)=
	#create clickable button
	#returns rwindow

	ss:=readstyle(owner,button_class,style)

	w:=gxcontrol(owner,button_class,pos,dim,ss)
	w.id:=id

	w.text:=caption
	w.enable:=enable
	gxdraw(w)

	return w
end

export func gxlabel(owner,pos,dim,caption,?style)=
	#create static label button
	#returns rwindow

	ss:=readstyle(owner,label_class,style)

	w:=gxcontrol(owner,label_class,pos,dim,ss)

	w.text:=caption
	gxdraw(w)

	return w
end

func gxcontrol(owner,windclass=button_class,pos,dim,?ss)=

	if ss.type=dict or ss.isvoid then
		ss:=readstyle(owner,windclass,ss)
	fi
	wb:=wbs_none
	case ss.border			!find wbs- version of windows-drawn borders
	when bs_simplew then
		wb:=wbs_simple
	esac

	if ss.iframe and bscat[ss.border]<>'I' then
		widths:=bswidths[ss.border]
		pos[1]+:=widths.x1
		pos[2]+:=widths.y1
		dim[1]-:=widths.x1+widths.x2
		dim[2]-:=widths.y1+widths.y2
	FI

	hwnd:=wx_createcontrol(pos:pos,dim:dim,border:wb,owner:owner.gdi.hwnd)

	if hwnd=0 then
		abort("Can't create control window")
	fi

	w:=newwindow(hwnd,0,no_class,ss.border)
	w.windclass:=windclass
	w.style:=ss
	w.owner:=owner
	w.enable:=1

	setwindowdims_c(w,hwnd)
	setupgdi(w,hwnd)

	gxdrawmode(w,dm_screenmemory)

	gxfont(w,labelfont)

	gxtextcolour(w,w.style.textfgnd,w.style.textbgnd)

	gxbgndmode(w,w.style.bgndmode)

!link into owner
	w.owner.childlist append:=w
	w.index:=w.owner.childlist.upb

	return w
end

export func gxtoggle(owner,pos,dim,caption="",linkvar,?style,id=201,enable=1)=

	(posx,posy):=pos
	(dimx,dimy):=dim
	textoffset:=0


	ss:=readstyle(owner,toggle_class,style)

!work out whether an auxiliary window is needed

	if ss.marktype then
		if ss.imark=0 then			!dims don't include the mark
			posx-:=markdim
			dimx+:=markdim
			textoffset:=markdim
		fi
	fi

	w:=gxcontrol(owner,toggle_class,(posx,posy),(dimx,dimy),ss)
!RETURN 0
	w.linkvar:=linkvar
	w.id:=id
	w.text:=caption
	w.attrs:=togglerec(textoffset,1)
	w.enable:=enable

	if w.style.marktype then
!	gxmark(owner:w,pos:(0,(w.dimy-markdim)%2),id:id,style:style)
		gxmark(owner:w,pos:(0,(w.dimy-markdim)%2),id:id, style:ss)
	fi

	gxdraw(w)
	return w
end

export func gxselect(owner,pos,dim,caption="",linkvar,onvalue,?style,id=201,enable=1)=

	(posx,posy):=pos
	(dimx,dimy):=dim
	textoffset:=0

	ss:=readstyle(owner,select_class,style)

!work out whether an auxiliary window is needed
	if ss.marktype and ss.imark=0 then			!dims don't include the mark
		posx-:=markdim
		dimx+:=markdim
		textoffset:=markdim
	fi

	w:=gxcontrol(owner,select_class,(posx,posy),(dimx,dimy),ss)

	w.linkvar:=linkvar
	w.id:=id
	w.text:=caption
	w.attrs:=togglerec(textoffset,onvalue)
	w.enable:=enable
	if w.style.marktype then
		gxmark(owner:w,pos:(0,(w.dimy-markdim)%2),id:id, style:style)
	fi

	gxdraw(w)
	return w
end

export proc showmessage(caption,mess)=
!RETURN
!	CPL MESS.MESSAGE
	cp caption,,":",leftstr(messagenames[mess.message],14)
	cp "A:",,mess.a,"B:",,mess.b
	cp " (X:",,mess.x,"Y:",,mess.y,,") Buttons:",mess.state:"b"

	if mess.wind then
		cpl "	Window:",mess.wind.name
	else
		cpl
	fi
end

func domessage(mess)=

	m:=mess.message
	w:=mess.wind

	case m
	when mm_move,mm_setcursor then
		return skipmess
	esac

!CPL "DOMESSAGE",MESSAGENAMES[M]

!	CPL messhandlertable[m,w.windclass]
	x:=messhandlertable[m,w.windclass](mess,w)

	return x
end

proc init_handlertables=
	messhandlertable:=maketable(mm_null..mm_last, no_class..dummy_class, nil)
	actionhandlertable:=maketable(actionnames.bounds, no_class..dummy_class, nil)

	messalltable:=new(list,mm_null..mm_last,0)		!for all mess_mess_all handlers
	fnallall:=nil									!for single mess_all_all handler
	fnfixups:=nil

	actionalltable:=new(list,actionnames.bounds,0)

	for d to $nprocs() do
		fnptr:=$procref(d)
		fnname:=$procname(d)

		(name,messname,windname):=splitstring(fnname,"_")			!split func name

		if fnname="gxhandler_fixups" then
			fnfixups:=fnptr
		elsif leftstr(fnname,5)="mess_" then
			if messname="all" and windname="all" then
				fnallall:=fnptr
			else
				message:=("mm_"+messname) inx messagenames
				if not message.isfound then
					ABORT("CAN'T FIND MESSAGE <"+messname+">")
				fi

				if windname="all" then				!assume <mess> all
					messalltable[message]:=fnptr
				else
					messhandlertable[message,WX:=findwindclass(windname)]:=fnptr
				fi
			fi

		elsif leftstr(fnname,8)="do_draw_" or leftstr(fnname,10)="do_update_" then
			action:=messname+"_w" inx actionnames
			if not action.isfound then
				ABORT("CAN'T FIND ACTION "+MESSNAME)
			fi
			if windname="all" then
				actionalltable[action]:=fnptr
			else
				windclass:=findwindclass(windname)
				actionhandlertable[action,windclass]:=fnptr
			fi
		fi
	od

!!do some manual fixups
	if fnfixups then
		fnfixups()
	fi

	for mx:=0 to mm_last do
		for wx:=0 to dummy_class do
			if not messhandlertable[mx,wx] then
				messhandlertable[mx,wx]:=(messalltable[mx]|messalltable[mx]|fnallall)
			fi
		od
	od

	if not fnallall then
		pcerror("Can't find all/all mess handler")
	fi

	for ax:=1 to DRAW_w do
		for wx:=0 to dummy_class do
			if not actionhandlertable[ax,wx] then
				if not actionalltable then
					pcerror("No DO/ALL handler for:"+actionnames[ax])
				fi
				actionhandlertable[ax,wx]:=actionalltable[ax]
			fi
		od
	od
end

func findwindclass(name)=
		windclass:=name+"_class" inx windowclassnames
		unless windclass.isfound then
			ABORT("CAN'T FIND WINDOW "+windname)
		end
		return windclass
end

export proc gxdraw(w)=
	fnptr:=actionhandlertable[draw_w,w.windclass]

	if fnptr then
		fnptr(w)
	else
		cpl "NO DRAW HANDLER",windowclassnames[w.windclass],w.name
		waitkey()
		stop
	fi
end

export proc gxupdate(w)=
	fnptr:=actionhandlertable[update_w,w.windclass]
	if fnptr then
		fnptr(w)
	else
		gxdraw(w)
	fi
end

export proc eventloop=
	do
		m:=gxaskmess()

		SHOWMESSAGE("EVENTLOOP",CURRMESS)

		case m
		when 0,mm_cancel then
			return
		esac

	od
end

export func gxeditbox(owner,pos,dim,linkvar,?style,id=201,enable=1)=

	ss:=readstyle(owner,editbox_class,style)

	w:=gxcontrol(owner,editbox_class,pos,dim,ss)

	w.linkvar:=linkvar
	w.id:=id
	w.attrs:=new(editboxrec)
	w.attrs.currpos:=linkvar^.len+1
	w.enable:=enable

	gxdraw(w)
	return w
end

export proc gxebchange(w,?linkvar,charpos=-1)=

	if linkvar.isdef then
		w.linkvar:=linkvar
	fi

	if charpos=-1 then
		w.attrs.currpos:=w.linkvar^.len+1
	else
		w.attrs.currpos:=charpos
	fi
	gxupdate(w)
end

export proc gxsetlbdata(w,linkvar,?pos)=
	w.linkvar:=linkvar
	if pos.isvoid then
		pos:=(linkvar^|1|0)
	fi
	w.attrs.currpos:=pos

	if w.childlist[1] then
!	gxsetscrolllimits(ws,linkvar^.bounds,w.attrs.rows)
		gxsetscrolllimits(ws,getlvbounds(linkvar),w.attrs.rows)
		gxscrollpos(ws,pos)
	fi
end

export proc gxsetlbpos(w,pos)=
!change in pos
	w.attrs.currpos:=pos

!work out screen row
	if pos then
		oldpagepos:=w.attrs.pagepos
		if pos<oldpagepos then
			w.attrs.pagepos:=pos
		elsif pos>oldpagepos+w.attrs.rows-1 then
			w.attrs.pagepos:=pos-w.attrs.rows+1
		fi
		if w.attrs.pagepos<>oldpagepos then
			if w.childlist then
				gxscrollpos(w.childlist[1],w.attrs.pagepos)
			fi
			m:=mm_draw
		else
			m:=mm_update
		fi
	else
		m:=mm_draw
	fi

	postmess(w,m)
	if w.style.lbchange then
		postmess(w,mm_lbchange,w.attrs.currpos)
	fi
end

export proc gxsetlbpage(w,pagepos)=
!change in pagepos (originates from scrollbar message)
	w.attrs.pagepos:=pagepos

	oldpos:=w.attrs.currpos
	if oldpos<pagepos then
		w.attrs.currpos:=pagepos
	elsif oldpos>=pagepos+w.attrs.rows then
		w.attrs.currpos:=pagepos+w.attrs.rows-1
	fi

	if w.childlist then
		gxscrollpos(w.childlist[1],pagepos)
	fi

	postmess(w,mm_draw)
	if w.style.lbchange and oldpos<>w.attrs.currpos then
		postmess(w,mm_lbchange,w.attrs.currpos)
	fi
end

export func gxlistbox(owner,pos,dim,linkvar,?style,id=201,rows=0,pitch=0,offset=0)=

	ss:=readstyle(owner,listbox_class,style)

	(dimx,dimy):=dim
	if ss_vscroll and ss_imark=0 then			!dims don't include the scrollbar
		dimx+:=arrowdim
	fi

	w:=gxcontrol(owner,listbox_class,pos,(dimx,dimy),ss)
	w.linkvar:=linkvar
	w.id:=id
	w.attrs:=new(listboxrec)

	if pitch=0 then								!calculate all these here
		pitch:=listrowheight
		offset:=0
		rows:=w.dimy%pitch
	fi
	w.attrs.rows:=rows
	w.attrs.pitch:=pitch
	w.attrs.offset:=offset

	w.attrs.pagepos:=1
	w.attrs.currpos:=(getlvbounds(linkvar).len|1|0)

	if w.style.vscroll then
		ws:=gxvertscrollbar(owner:w,pos:(w.dimx-arrowdim,0),dim:w.dimy,id:id,style:style)
		gxsetscrolllimits(ws,getlvbounds(linkvar),w.attrs.rows)

		gxscrollpos(ws,getlvbounds(linkvar).lwb)
	fi

	gxdraw(w)
	return w
end

export func gxarrow(owner,pos,?dim,dir,?style,id=201)=

	ss:=readstyle(owner,arrow_class,style)
	if dim.isvoid then
		dim:=(arrowdim,arrowdim)
	fi

	w:=gxcontrol(owner,arrow_class,pos,dim,ss)
	w.id:=id
	if dir.isstring then dir:=asc(dir) fi
	case dir					!allow compass bearings too, but convert to UDLR
	when 'N' then dir:='U'
	when 'E' then dir:='R'
	when 'S' then dir:='D'
	when 'W' then dir:='L'
	esac

	w.style.dir:=dir			!don't dir allow via style options
	gxdraw(w)

	return w
end

export proc gxsetscrolllimits(w,limits,span=0)=
!set up or change scrollbar limits
!span=0:
!	Pure ranging control. Limits are actual range of the thumb.
!	Thumb is drawn at a fixed, nominal size. Might be suppressed when limits are <=1
!	Initial position set to limits.lwb
!span=M:
!	Paging control, such as used on a listbox or text editor.
!	Span can be the number of rows display at one time.
!	Limit can be single number N, or range 1..N.
!	Actual scroll bar range will be 1..N-M+1. When upper limit<1 then
!	limit will be 1..1, and thumb might not be drawn
!	Data position will: actually there /is/ not data position, except for the
!	data position represented by the top row, which will be the same as the scroll
!	position.
!Arrows should be disabled (and perhaps thumb suppressed) when scroll range if 1..1,
!or data range is nor larger than a span

	w.attrs.span:=span
	if w.style.dir='H' then
		width:=w.dimx
	else
		width:=w.dimy
	fi
	m:=width-arrowdim*2				!number of pixels movement between arrows

	if span=0 then						!pure scrolling control
		w.attrs.limits:=limits
		w.attrs.currpos:=limits.lwb
		w.attrs.thumbsize:=arrowdim
		enable:=limits.len>1
		w.attrs.thumbsize:=arrowdim*enable
	else
		if limits.isrange then
			length:=limits.len
		else
			length:=limits
		fi
		if length<=span then
			enable:=0
			w.attrs.limits:=1..1
			w.attrs.thumbsize:=0
		else
			w.attrs.limits:=1..length-span+1
			enable:=1
			w.attrs.thumbsize:=max(10,int(m*(span/length)))
		fi
	fi

	w.attrs.currpos:=w.attrs.limits.lwb
	w.enable:=enable

	w.attrs.thumbspan:=m-w.attrs.thumbsize		!movement available to thumb
	w.attrs.thumbpos:=arrowdim
	postmess(w,mm_draw)
end

export func gxscrollpos(w,pos,u=0)=
!
	if pos.isvoid then
		return w.attrs.currpos
	fi

	CPL =POS
	CPL =W.ATTRS.CURRPOS
	CPL =W.ATTRS.LIMITS

	w.attrs.currpos:=pos
	if pos not in w.attrs.limits then
		pcerror("Bad scroll pos")
	fi

	tpos:=int(w.attrs.thumbspan*((pos-w.attrs.limits.lwb)/(w.attrs.limits.len-1)))
	w.attrs.thumbpos:=arrowdim+tpos

	w.childlist[1].enable:=pos>w.attrs.limits.lwb
	w.childlist[2].enable:=pos<w.attrs.limits.upb

	if u then
		postmess(w,mm_update)
	fi
	return 0
end

export func gxhozscrollbar(owner,pos,dim,?style,id=201)=

	ss:=readstyle(owner,scrollbar_class,style)
	width:=arrowdim
	if dim.isint then
!if dim.ispointer then
		dim:=(dim,width)
	else
		width:=dim[1]
	fi

	w:=gxcontrol(owner,scrollbar_class,pos,dim,ss)
	w.id:=id
	w.style.dir:='H'

	w.attrs:=new(scrollbarrec)
	w.flags.[wa_leftdrag]:=1

!Now, create the arrows at each end. The thumbbar is not an explicit control,
!it's just a drawn box
	wa:=gxarrow(owner:w, pos:(0,0), dim:(width,width),dir:'L')
	wb:=gxarrow(owner:w, pos:(dim[1]-width,0), dim:(width,width),dir:'R')

	gxsetscrolllimits(w,1..200,20)
	gxscrollpos(w,1)

	gxdraw(w)

	return w
end

export func gxvertscrollbar(owner,pos,dim,?style,id=201)=
	ss:=readstyle(owner,scrollbar_class,style)
	width:=arrowdim
	if dim.isint then
!if dim.ispointer then
		dim:=(width,dim)
	else
		width:=dim[2]
	fi

	w:=gxcontrol(owner,scrollbar_class,pos,dim,ss)
	w.id:=id
	w.style.dir:='V'

	w.attrs:=new(scrollbarrec)
	w.flags.[wa_leftdrag]:=1

!Now, create the arrows at each end. The thumbbar is not an explicit control,
!it's just a drawn box
	wa:=gxarrow(owner:w, pos:(0,0), dim:(width,width),dir:'U')
	wb:=gxarrow(owner:w, pos:(0,dim[2]-width), dim:(width,width),dir:'D')
	gxsetscrolllimits(w,100..200,2)

	gxscrollpos(w,100)

	gxdraw(w)

	return w
end

export func gxmark(owner,pos,?dim,?style,id=201)=

	ss:=readstyle(owner,mark_class,style)
	if dim.isvoid then
		dim:=(markdim,markdim)
	fi

	w:=gxcontrol(owner,mark_class,pos,dim,style)
	w.id:=id
	gxdraw(w)

	return w
end

export proc gxfocus(w)=
!switch focus to window w
	if wfocus==w then
		return
	fi

	if wfocus then
		domessage(makemess(wfocus,mm_killfocus))
	fi
	caretdrawn:=0
	domessage(makemess(w,mm_setfocus))
end

export proc gxkillfocus=
	if wfocus then
		drawcaret(0)
	fi
	wfocus:=nil
end

export func gxcopy(w,?bm,x=0,y=0,scalex=1.0,scaley=0,sx=0,sy=0,dimx=0,dimy=0)=		!GXCOPY
!copy bitmap bm to window w, at position x,y in w. Scalex/y can be 0 for 1:1,
!or Scalex/y can be any real value for unequal x/y scaling
!For equal x/y scaling, Scaley can be 0
!Entire bitmap is copied (sx,sy,w,h all 0); for portion, set sx,sy to top left of rect
!and w,h to size to be copied
![1..100]char str

	if bm.isvoid then
		bm:=w
		w:=nil
	fi
	if bm.isvoid then
		return nil
	fi

	if dimx=0 then dimx:=bm.dimx-sx fi
	if dimy=0 then dimy:=bm.dimy-sy fi

	if scalex=0 then scalex:=1.0 fi
	if scaley=0 then scaley:=scalex fi

	if w=nil then		!create appropriate window
		w:=gxcreatewindow(caption:"Bitmap "+tostr(bm.pixelbits)+" bit",pos:(500,500),
				dim:(bm.dimx*scalex,bm.dimy*scaley))
		w.gdi.drawmode:=dm_screenmemory			!default when using auto-window
	fi

	gdi:=w.gdi
	gdi.updated:=1

	mode:=copymode

	setstretchbltmode(gdi.hdc,mode)
	stretchblt(gdi.hdc, x, y,int(dimx*scalex),int(dimy*scaley),
												bm.gdi.hdc,sx,sy,dimx,dimy, srccopy)
	if gdi.drawmode=dm_screenmemory then
		setstretchbltmode(gdi.hdc2,mode)
		stretchblt(gdi.hdc2,x,y,int(dimx*scalex),int(dimy*scaley),
												bm.gdi.hdc,sx,sy,dimx,dimy, srccopy)
	fi

	return w
end

export proc gxrestore(w,?r)=
!repaint window w
!only called when repaint can be done from a backup
!r is the region to restore within w; or restore all if omitted

	if r.isvoid then
		x1:=y1:=0

		width:=w.dimx
		height:=w.dimy
	else
		x1:=r.x1
		y1:=r.x2
		width:=r.x2-x1+1
		height:=r.y2-y1+1
	fi

	case w.gdi.drawmode
	when dm_screen then			!can't restore; need to call gx_draw
		gxdraw(w)
	when dm_screenmemory then
		destdc:=w.gdi.hdc
		sourcedc:=w.gdi.hdc2
	when dm_memoryscreen then
		destdc:=w.gdi.hdc2
		sourcedc:=w.gdi.hdc
	else
		abort("gxrest/?")
	esac

	bitblt(destdc,x1,y1, width,height, sourcedc, x1,y1, srccopy)

end

export func gxdrawmode(w,?drawmode)=
!set or get drawmode
!really requires window to be cleared afterwards.

	olddrawmode:=w.gdi.drawmode
	if drawmode.isvoid then
		return olddrawmode
	fi

	if olddrawmode=drawmode then		!already set
		return drawmode
	elsif olddrawmode<>dm_screen then	!can only change screen => screenmemory/memoryscreen
		abort("gxdrawmode2")			!not memory to anything else
	fi

!assuming currently on screen, will need extra compatible bitmap
	memhwnd:=createcompatiblebitmap(screendc,w.dimx,w.dimy)
	memhdc:=createcompatibledc(nil)
	selectobject(memhdc,memhwnd)

!need to change draw mode
	case drawmode
	when dm_screenmemory then
		w.gdi.hwnd2:=memhwnd
		w.gdi.hdc2:=memhdc
	when dm_memoryscreen then
		w.gdi.hwnd2:=w.gdi.hwnd			!screen becomes secondary
		w.gdi.hdc2:=w.gdi.hdc
		w.gdi.hwnd:=memhwnd
		w.gdi.hdc:=memhdc
	else
		abort("gxdrawmode?")
	esac

	w.gdi.drawmode:=drawmode
	return drawmode
end

export proc switchdest(w)=
!for a window with screenmemory drawmode, switch things around so that
!it's drawing into the memory area only
	gdi:=w.gdi

	case gdi.drawmode
	when dm_screenmemory then
		t:=gdi.hwnd; gdi.hwnd:=gdi.hwnd2; gdi.hwnd2:=t
		t:=gdi.hdc; gdi.hdc:=gdi.hdc2; gdi.hdc2:=t
		gdi.drawmode:=dm_memory
	when dm_memory then
		t:=gdi.hwnd; gdi.hwnd:=gdi.hwnd2; gdi.hwnd2:=t
		t:=gdi.hdc; gdi.hdc:=gdi.hdc2; gdi.hdc2:=t
		gdi.drawmode:=dm_screenmemory
	esac
end

export proc gxclose(w)=

!CPL "GXCLOSE1",$REFCOUNT(W)

	case w.windclass
	when bitmap_class then
	else
!ID:=$ID(W)
		if issubwindow(w,wfocus) then
			wfocus:=nil
		fi

		if issubwindow(w,wmouse) then	
			lastmousewindow:=nil
			wmouse:=nil
		fi

		destroywindow(w.gdi.hwnd)

!IF $ID(CURRMESS.WIND)=ID THEN
!CPL "-------CLOSED CURRMESS.WIND"
!CURRMESS.WIND:=NIL
!FI
!CPL "GXCLOSE2",$REFCOUNT(W)

		gxfreewindow(w)
!CPL "GXCLOSE3",$REFCOUNT(W)

	IF W=WAPPLIC THEN WAPPLIC:=NIL FI

	esac
end

proc gxfreewindow(w)=
!recover memory used by this window and all childwindows
	for wc in w.childlist do
		gxfreewindow(wc)
	od

	removewindow(w)

!CPL "FREEING2",$ID(W),$ID(W.GDI), $REFCOUNT(W), $REFCOUNT(W.GDI)
	w.gdi:=0

!	w:=0
end

export func gxmsgbox(message,caption="",options="")=

	const mb_abortretryignore	= 0x02
	const mb_applmodal			= 0x00
	const mb_defbutton1			= 0x00
	const mb_defbutton2			= 100
	const mb_defbutton3			= 200
	const mb_defbutton4			= 300
	const mb_help				= 4000
	const mb_iconasterisk		= 40
	const mb_iconerror			= 10
	const mb_iconexclamation	= 30
	const mb_iconhand			= mb_iconerror
	const mb_iconinformation	= mb_iconasterisk
	const mb_iconquestion		= 20
	const mb_iconstop			= mb_iconhand
	const mb_iconwarning		= mb_iconexclamation
	const mb_ok					= 0x00
	const mb_okcancel			= 0x01
	const mb_retrycancel		= 0x05
	const mb_right				= 80000
	const mb_setforeground		= 10000
	const mb_systemmodal 		= 1000
	const mb_taskmodal			= 2000
	const mb_yesno				= 0x04
	const mb_yesnocancel		= 0x03
	const mb_topmost			= 0x040000

!return values
	const idfail	= 0
	const idok		= 1
	const idcancel	= 2
	const idabort	= 3
	const idretry	= 4
	const idignore	= 5
	const idyes		= 6
	const idno		= 7

	static var rettable=(0:"fail","ok","cancel","abort","retry","ignore","yes","no",
			"","","tryagain","continue")

	static var styletable=(
	("bari",mb_abortretryignore),
	("bo",mb_ok),
	("boc",mb_okcancel),
	("brc",mb_retrycancel),
	("byn",mb_yesno),
	("bync",mb_yesnocancel),
	("ix",mb_iconexclamation),
	("iw",mb_iconwarning),
	("ii",mb_iconinformation),
	("iq",mb_iconquestion),
	("is",mb_iconstop),
	("ie",mb_iconerror),
	("ih",mb_iconhand),
	("d1",mb_defbutton1),
	("d2",mb_defbutton2),
	("d3",mb_defbutton3),
	("d4",mb_defbutton4),
	("h",mb_help),
	("rj",mb_right),
	("sm",mb_systemmodal))

	hwnd:=nil

	style:=0
	optioncodes:=splitstring(options," ")

	for opt in optioncodes do
		for i to styletable.len do
			if styletable[i,1]=opt then style ior:=styletable[i,2] fi
		od
	od

	style ior:=0x10000

	x:=messageboxa(hwnd,message,caption,style)
	return rettable[x]
end


export proc gxhandler(windclass,mess,fnptr)=
!windclass is a window, or a window class
!override the current message handler for w's window class, and fo message mess

!if not windclass.isint then
	if not windclass.ispointer then
		windclass:=windclass.windclass
	fi

!CPL "SETTING GXHANDLER",MESS,WINDCLASS,FNPTR
	messhandlertable[mess,windclass]:=fnptr
end

export func gxaskfile(caption="File",filespec="*.*",deffile="",startdir="")=

	save:=0
	if caption='*' then
		save:=1
		caption:=rightstr(caption,-1)
	fi

	filters:=array(filespec+"@@@")		!turn into a byte-array

	for i,bb in filters do			!convert all @ into embedded zeros
		if bb='@' then filters[i]:=0 fi
	od

	ofn:=new((iswin32|ws_openfilename32|ws_openfilename64))

	ofn.structsize:=ofn.bytes
	ofn.owner:=wapplic.gdi.hwnd
	ofn.instance:=getmodulehandle(0)
	ofn.filter:=int(&filters)
	ofn.flags:=ofn_explorer ior ofn_nochangedir ior ofn_hidereadonly !IOR OFN_NOVALIDATE

	ofn.initialdir:=getstringz(startdir)

	ofn.defext:=getstringz("")

	result:=new(array,byte,300)

	result[1]:=0
	if deffile<>"" then
		memcpy(&result,&deffile,deffile.len)
	fi

	ofn.file:=int(&result)

	ofn.maxfile:=256
	ofn.title:=getstringz(caption)

	if not (not save | getopenfilenamea(&ofn) | getsavefilenamea(&ofn)) then
		result[1]:=0		!return "" on error
	fi

	return string(result)
end

export func gxcurrpos(w)=
	return w.attrs.currpos
end

export func gxtabstops(?tabs,signed=0)=
	if tabs.isdef then
		tabstops::=tabs
		if signed then
			for i,x in tabstops do
				tabstops[i]:=abs(x)
			od
		fi
	fi
	return tabstops

end

export func getlvbounds(linkvar)=
	if linkvar.ispointer and linkvar^.islist then
		return linkvar^.bounds
	else
		return linkvar.getbounds()
	fi
	return 0
end

export func getlvitem(linkvar,n)=
	if linkvar.ispointer and linkvar^.islist then
		return linkvar^[n]
	else
		PCERROR("GETLVITEM")
	fi
	return 0
end

export func getlvstritem(linkvar,n)=
	if linkvar.ispointer and linkvar^.islist then
		return tostr(linkvar^[n])
	else
		return linkvar.getstritem(n)
	fi
	return 0
end

export proc gxtext16(w,s,n,x=0,y=0)=		!GXTEXT
		gdi:=w.gdi

		textoutw(gdi.hdc,x, y,&s,n)
		if gdi.drawmode=dm_screenmemory then
			textoutw(gdi.hdc2,x,y,&s,n)
		fi
end

export func gxenable(w,flag)=
	if flag.isdef then
		w.enable:=flag
		gxupdate(w)
	fi
	return w.enable
end

export func gxclientarea(w)=
!scan child windows of w, work out remaining client area after taking account of
!framebars etc
!return (pos, dim), each being a 2-element list

	aposx:=aposy:=0

	adimx:=w.dimx
	adimy:=w.dimy

	centx:=(aposx+adimx)%2
	centy:=(aposy+adimy)%2

!for cw in w.childlist when cw.windclass in [statusbar_class,framebar_class] do
	for cw in w.childlist do

		(posx,posy):=(cw.frameposx,cw.frameposy)
		(dimx,dimy):=(cw.framedimx,cw.framedimy)

!need to find out which of the four sides the bar is against, and set up side= L R T B
		case cw.style.dir
		when 'B' then				!bottom
			if posy<(aposy+adimy) then
				adimy-:=dimy
			fi

		when 'T' then				!top
			if (posy+dimy)>aposy then		!
				aposy+:=(posy+dimy)
				adimy-:=(posy+dimy)
			fi

		when 'R' then				!right
			if posx<(aposx+adimx) then
				adimx-:=dimx
			fi

		when 'L' then				!LEFT
			if (posx+dimx)>aposx then		!
				aposx+:=(posx+dimx)
				adimx-:=(posx+dimx)
			fi
		else

			if dimx>dimy then			!assume hoz
				if posy>centy then			!assume bottom
					if posy<(aposy+adimy) then
						adimy-:=dimy
					fi

				else					!top
					if (posy+dimy)>aposy then		!
						aposy+:=(posy+dimy)
						adimy-:=(posy+dimy)
					fi
				fi
			else					!assume vert
				if posx>centx then			!assume right

					if posx<(aposx+adimx) then
						adimx-:=dimx
					fi

				else					!left

					if (posx+dimx)>aposx then		!
						aposx+:=(posx+dimx)
						adimx-:=(posx+dimx)
					fi

				fi
			fi
		esac
	od

	return ((aposx,aposy), (adimx,adimy))
end

export func addwindow(w)=
!w is a newly created window
!add it to all windows
	n:=nil inx allwindows
	if not n.isfound then
		n:=allwindows.len+1
	fi

	allwindows[n]:=w
	w.gindex:=n
	return n
end

export proc removewindow(w)=
!remove w from all windows
	n:=w inx allwindows
	if n.isfound then
		allwindows[n]:=nil
	fi

	for i to nmessages do
		m:=messagequeue[i]
		if m.wind==w then
			m.wind:=nil
		fi
	od

!	if currmess.wind==w then
!		currmess.wind:=nil
!	fi

end

func process_wmmessage(msg)=
!STATIC VAR CC=0
!CPL "PROCESS/WMMESSAGE",++CC
!CPL "PROC/WM1",MSG, MSG.HWND
		x:=process_wmmessage2(msg)
!CPL "RETURN X:",X
!$SETDEBUG(1)
		return x
end

func process_wmmessage2(msg)=
!msg is a windows rmsg record
!Called from MainWndProc callback func (via mechanisms for B code to call into MPL code)
!this func processes some wm_ Windows messages and converts them
!into mm_ messages as necessary
!It returns:
!	0 The wm_ message has been processed
!	1 The wm_ message has not been processed, and the caller should call DefWindowProc.
!	  Or, the DefWindowProc should also be called anyway.

!CPL "PROCESSWMM2",MSG.MESSAGE, WINMESSAGENAMES{MSG.MESSAGE}

	hwnd:=msg.hwnd
!CPL "PM2",=HWND,MSG.HWND
	w:=getwindow(hwnd)
!CPL "AFTER GW1"

	message:=msg.message
	wparam:=msg.wparam
	lparam:=msg.lparam

	case msg.message
	when wm_command then
		w:=getwindow(lparam)			!w was owner, use control window
!CPL "AFTER GW2"
		i:=wparam iand 0xffff			!id
		j:=wparam>>16				!notify code
		m:=mm_command

		if not w then
			w:=wapplic
		fi

		postmess(w,m,i,j,0)

		return 0

	when wm_activate then
		if wparam then				!being activated
		fi

	when wm_syskeydown,wm_syskeyup,wm_keydown,wm_keyup then
!
!	STATIC VAR COUNT=0
!
!	IF MSG.MESSAGE=WM_KEYDOWN THEN
!	CPL "KEY",++COUNT
!	FI

		if dokeymessage(hwnd,message,wparam,lparam) then
			return 0
		fi

	when wm_char then
		postmess((wfocus|wfocus|w),mm_char,wparam,lparam,0)

	when wm_close then
		if w==wapplic then
			postmess(w,mm_close,0,0,0)
			return 0
		else
			postmess(w,mm_cancel,0,0,0)
			return 0
		fi

	when wm_timer then
		if not background and not stationary then		!test for pausing of mouse
			if gettickcount()-lastxytime>pausetime then
				stationary:=1
			fi
		fi

	when wm_destroy then
		if w and wapplic and w==wapplic then
			killtimer(hwnd,1)
!*		if tick then killtimer(hwnd,1) fi
!CPL "**********************POSTING QUIT WM",WAPPLIC


!			postquitmessage(0)			!mm_quit message
			return 0
		else
			return 1
		fi

!when wm_setcursor then
!	postmess(w,mm_setcursor,wparam,lparam,0)

	when wm_mousemove then

		buttonstate:=wparam iand (kb_lbutton ior kb_rbutton ior kb_mbutton)
		mousepos.x:=lparam iand 65535
		mousepos.y:=lparam>>16

	domousemove:
		xyvalid:=1				!known again
		setnewmousewindow(w)

		wmouse:=w
		postmess(wmouse,mm_move)

		lastxy::=getscreencoords(wmouse,mousepos)
		lastxytime:=gettickcount()
		stationary:=0

!do drag processing; states are:
!pen up/recent pen down/first drag/subsequent drag
!any drag messages are sent as well as mm_move messages
!dragmode=1/2/3 indicates drag has started (reset by buttonswitching)

		if buttonstate<>0 and lastmousewindow<>nil then		!switch pressed
			pt:=getscreencoords(lastmousewindow,lastmousepos)
			dx:=lastxy.x-pt.x
			dy:=lastxy.y-pt.y

			if dragmode then		!1st drag message already generated
				postmess(lastmousewindow,mm_drag,dx,dy,-1)			!send latest drag coords

			else				!test for drag enabling
				if ((mousesw=1 and lastmousewindow.flags.[wa_leftdrag]<>0) or \
								(mousesw=2 and lastmousewindow.flags.[wa_rightdrag]<>0) or \
								(mousesw=3 and lastmousewindow.flags.[wa_middledrag]<>0)) and \
							(abs(dx)>dragtol or abs(dy)>dragtol) then
					dragmode:=mousesw
					postmess(lastmousewindow,mm_startdrag,dx,dy,-1)		!send latest drag coords
				fi

			fi
		else
			if dragmode then
				postmess(lastmousewindow,mm_enddrag,dx,dy,-1)	!send latest drag coords
				dragmode:=0
			fi
		fi

		return 0

	when wm_enteridle then		!enter idle
		idlemode:=1
		return 0

	when wm_paint then

		if w<>nil then
			ps:=new(ws_paintstruct)
			rect:=new(ws_rect)
			beginpaint(hwnd,&ps)
			postmess(w,mm_restore,0,0,0)
			endpaint(hwnd,&ps)
			return 0
		fi

	when wm_erasebkgnd then

	when wm_move then
		if w<>nil then
!*!		gxmovewindow(w,lparam iand 65535,lparam>>16)
		fi

	when wm_size then
		x:=lparam iand 0xffff
		y:=lparam>>16
		if w<>nil  and (w.dimx<>x or w.dimy<>y) then
!*!		gxmplresize(w,x,y,wparam)
			return 0
		fi

!when wm_killfocus,wm_setfocus then

	when wm_contextmenu then
		sendmess(w,mm_rclick,wparam>>16,wparam iand 0xffff,0)
		return 0

	when wm_mousewheel then
		if not wmouse then wmouse:=w fi
		postmess(wmouse,mm_wheel,int(wparam>>16),wparam iand 0xffff,0)
		return 0

	when wm_nclbuttondown,wm_nclbuttondblclick then

	when wm_activateapp then
		if wparam then
			postmess(w,mm_activate,1,0,0)
		fi

	else
	btnmessages:
!check for sequential messages
!CPL "FALLTHROUGH"
		if message>=wm_lbuttondown and message<=wm_mbuttondblclk then
			buttonmessages(hwnd,message,wparam,lparam)
			return 0
		fi
	esac
!end
!fall-through here to do default message processing instead of/in addition to local processing
	return 1	!defwindowproc(hwnd,imsg,wparam,lparam)
end

export proc mxinit=
	wmessagetable := [\
		wm_lbuttondown:		mm_click,
		wm_lbuttonup:		mm_clickup,
		wm_lbuttondblclk:	mm_dblclick,

		wm_rbuttondown:		mm_rclick,
		wm_rbuttonup:		mm_rclickup,
		wm_rbuttondblclk:	mm_rdblclick,

		wm_mbuttondown:		mm_mclick,
		wm_mbuttonup:		mm_mclickup,
		wm_mbuttondblclk:	mm_mdblclick]

!table gives button number 1,2,3 for Windows button message (always 0 for button up)
	buttontable	:= [\
		wm_lbuttondown:		1,
		wm_lbuttonup:		0,
		wm_lbuttondblclk:	1,

		wm_rbuttondown:		2,
		wm_rbuttonup:		0,
		wm_rbuttondblclk:	2,

		wm_mbuttondown:		3,
		wm_mbuttonup:		0,
		wm_mbuttondblclk:	3]

	mousepos:=new(ws_point)

	setmesshandler(process_wmmessage)
!CPL =PROCESS_WMMESSAGE
!setmesshandler(bill)

	vktomesstable:=[\
		vkleft:		mm_leftkey,
		vkright:	mm_rightkey,
		vkup:		mm_upkey,
		vkdown:		mm_downkey,
		vkpageup:	mm_pageupkey,
		vkpagedown:	mm_pagedownkey,
		vkhome:		mm_homekey,
		vkend:		mm_endkey,
		vktab:		mm_tabkey,
		vkbackspace:	mm_bskey,
		vkdelete:	mm_deletekey,
		vkenter:	mm_enterkey,
		vkinsert:	mm_insertkey,
		vkescape:	mm_cancel
	]
end

export func postmess(w,mess,a=0,b=0,c=0)=
!add message m to end of message queue
!use mess+1000 to add message to start of queue rather than the end

	if w=nil then w:=wapplic fi
	if w=nil then
 return 0 fi

	if w.flags.[wa_closed] then

 return 0 fi

	if mess>=1000 then
		headx:=1; mess-:=1000
	else
		headx:=0
	fi

!check if new message can be combined with an old message
	case mess
	when mm_sethozpos,mm_setvertpos,mm_draw,mm_restore,mm_update then
		for i:=1 to nmessages do
			m:=messagequeue[i].message
			if m=mess and w==messagequeue[i].wind then				!use the old message but update any params
				messagequeue[i].a:=a
				messagequeue[i].b:=b
				return 0
			elsif mess=mm_draw and m=mm_update then		!convert update to draw
				messagequeue[i].message:=mm_draw
				return 0
			fi
		od
	esac

	if quitmess or nmessages>=maxqueuesize then
		return 0
	fi

	postmsg(makemess(w,mess,a,b,c))

	return 0					!return zero for use in mainwndproc
end

export func postmsg(msg,headx=0)=
!add complete message msg to end of message queue
!use head=1 to add to start of queue rather than the end

	if quitmess or nmessages>=maxqueuesize then
		return 0
	fi

	if msg.wind.flags.[wa_closed] then return 0 fi

	if headx then

!avoid dupl paint messages
		++nmessages
		for i:=nmessages downto 2 do
			messagequeue[i]:=messagequeue[i-1]
		od
		messagequeue[1]:=msg

	else
		++nmessages
		messagequeue[nmessages]:=msg
	fi

	return 0					!return zero for use in mainwndproc
end

export proc sendmess(w,mess,a=0,b=0,c=0)=
!add message m to head of message queue
!(may be 100% handled in q smlib)

	if w=nil then return fi
	if w.flags.[wa_closed] then return fi

	sendmsg(makemess(w,mess,a,b,c))
end

proc sendmsg(msg)=
!call event handler for msg or add to head of queue
	if msg.wind.flags.[wa_closed] then return fi
	postmsg(msg,1)
end

export func makemess(w,mess,a=0,b=0,state=-1)=
!turn params into a new messrec @nemm_ess
!the q version makemess also accepts makemess(w,msg)

	if w=nil then w:=wapplic fi

	m:=new(rmessage,0)

	m.wind:=w

	m.message:=mess
	m.a:=a
	m.b:=b
	m.state:=state

	m.x:=mousepos.x
	m.y:=mousepos.y

	if m.state=-1 then m.state:=getshiftstate() fi

	return m
end

func dokeymessage(hwnd,msg,wparam,lparam)=
!return 1 if message has been dealt with

	case msg
	when wm_syskeydown then
		if wparam=vkf10 then msg:=wm_keydown; goto dokey fi

	when wm_syskeyup then
		if wparam=vkf10 then msg:=wm_keyup; goto dokey fi

	when wm_keydown,wm_keyup then
	dokey:
		case wparam
		when vkshift,vkctrl,vkalt,vkcapslock then
		else
			w:=wfocus
!		if not w then w:=wx_getw(hwnd) fi
!CPL "XXXXX"
			if not w then w:=getwindow(hwnd)
!CPL "AFTER GW3"
 fi
!CPL =GETSHIFTSTATE()
!		postmess(w,(msg=wm_keydown|mm_key|mm_keyup),wparam,getshiftstate(),lparam)
			postmess(w,(msg=wm_keydown|mm_key|mm_keyup),wparam,lparam,-1)
			return 1
		esac
	esac
	return 0
end

func getshiftstate=
	state:=0

	if getkeystate(vklshift) iand 0x8000 then state ior:=kb_shift fi
	if getkeystate(vklcontrol) iand 0x8000 then state ior:=kb_ctrl fi
	if getkeystate(vklalt) iand 0x8000 then state ior:=kb_alt fi

	if getkeystate(vkrshift) iand 0x8000 then state ior:=kb_rshift fi
	if getkeystate(vkrcontrol) iand 0x8000 then state ior:=kb_rctrl fi
	if getkeystate(vkralt) iand 0x8000 then
		state ior:=kb_ralt
		state iand:=(inot kb_ctrl)			!AltGr gives Lctrl+Ralt; return Ralt only
	fi
	if getkeystate(vkcapslock) iand 1 then state ior:=kb_capslock fi

	return state ior buttonstate
end

proc buttonmessages(hwnd,msg,wp,lp)=
!process Windows mouse message <msg>

!update button from wparam, excluding ctrl/shift (which are updated from key msgs)
	buttonstate:=wp iand (kb_lbutton ior kb_rbutton ior kb_mbutton)

!update mouse position
	mousepos.x:=lp iand 0xffff
	mousepos.y:=int(lp)>>16
	wmouse:=getwindow(hwnd)
!CPL "AFTER GW4"

!set mousesw to last pressed button (1,2,3) or 0 if one just released
!(note other buttons may still be down, used for drag processing)
	mousesw:=buttontable{msg}

	if mousesw then			!down up on click or dblclick
		lastbuttontime:=gettickcount()
		lastmousepos::=mousepos
		lastmousewindow:=wmouse
	else
		mousesw:=0

		if dragmode then
			postmess(lastmousewindow,mm_enddrag,0,0,-1)
			dragmode:=0
		fi

		lastbuttontime:=0
		lastmousewindow:=nil
	fi

	newmess:=wmessagetable{msg}

!filter double-click messages and convert to repeated click if not enabled
	case newmess
	when mm_dblclick then unless wmouse.flags.[wa_leftdbl] then newmess:=mm_click end
	when mm_rdblclick then unless wmouse.flags.[wa_rightdbl] then newmess:=mm_click end
	esac

	postmess(wmouse,newmess,wmouse.id,0,-1)
end

proc setnewmousewindow(w)=
	return when not currmousewindow
	unless w==currmousewindow then		!changed
		if currmousewindow<>nil then
			postmess(currmousewindow,mm_offwindow,0,0,0)
		fi

		currmousewindow:=w
		postmess(w,mm_onwindow,0,0,0)
	end unless
end

proc frame2rect(f,r)=
	r^.x:=f^.x
	r^.y:=f^.y

	r^.dimx:=f^.x2-f^.x1+1
	r^.dimy:=f^.y2-f^.y1+1
end

export func mxwait_mm_message=
	#do windows dispatch loop
	#calling dispatchmessage() results in mainwndproc being called in interpreter,
	#which passes the Windows message params on to process_wmmessage() in this module
	#process_wmmessage() converts wm-messages to mpl mm-messages
	#return when at least one mm message is ready; (will return immediately if there
	#is already one in the queue)
	#return value is normall 1, or 0 when quitmess has been encountered

	if quitmess then				!quit message already seen
CPL "-----------------QUITMESS SEEN"
		return 0
	fi

	windmsg:=new((iswin32|ws_msg32|ws_msg64))

	while nmessages<=0 do
		if x:=getmessage(&windmsg,nil,0,0)<>0 then
			w:=windmsg.hwnd
			translatemessage(&windmsg)
			dispatchmessage(&windmsg)
		else
CPL "----GETMESSAGE RETURMS 0"
			quitmess:=1
			exit
		fi
	od

	if not nmessages then			!assume quit message seen
CPL "----------NO MESSAGES"
		return 0
	fi	

	currmess:=messagequeue[1]
	--nmessages

	xlatkeyboard()

	for i:=1 to nmessages do
		messagequeue[i]:=messagequeue[i+1]
	od
	return 1
end

proc xlatkeyboard=
!expand any mm_key messages to special key messages
!uses and modified currmess
	m:=currmess.message

	if m=mm_key then

		k:=currmess.a
		if k>=vkf1 and k<=vkf12 then
			newmsg:=currmess
			currmess.message:=mm_functionkey
			currmess.a:=k-vkf1+1
		else
			keymess:=vktomesstable{k,0}
			if keymess then
				currmess.message:=keymess
			fi
		fi
	fi
end

func getscreencoords(w,pos)=
	pt::=pos
	if not w then
		PCERROR("GSC/W=0")
	fi

	clienttoscreen(w.gdi.hwnd,&pt)		!pos starts at 0,0
	return pt
end

export func getwindow(hwnd)=
!convert hwnd to window
!return nil if any problem
	if hwnd=0 then
		return nil
	fi

	index:=wx_getw(hwnd)
	if index then
		return allwindows[index]
	fi
	return nil
end

proc initmenuhandlers=
	ltcolour:=getrgb(ltgrey)
	dkcolour:=getrgb(dkgrey)
end

proc gxhandler_fixups=
!do some manual fixups for various shared handlers
!(the automatic fixup routine allows multiple window classes per message, but not
! multiple message per window class)
	messhandlertable[mm_startdrag,scrollbar_class]:=mess_drag_scrollbar
	messhandlertable[mm_enddrag,scrollbar_class]:=mess_drag_scrollbar
	messhandlertable[mm_leftkey,scrollbar_class]:=mess_upkey_scrollbar
end

func mess_all_all(mess,w)=
!CPL "MESSAA1"
	case mess.message
	when mm_startdrag,mm_drag,mm_enddrag then
	when mm_command then
	when mm_ok,mm_cancel then
	when mm_click then
		case w.windclass
		when label_class, group_class then
			return skipmess
		esac
	when mm_key then
	when mm_sethozpos,mm_setvertpos then
	when mm_pick,mm_lbchange then
	when mm_leftkey,mm_rightkey,mm_upkey,mm_downkey,mm_enterkey,mm_tabkey then
	when mm_pageupkey,mm_pagedownkey then
	when mm_homekey, mm_endkey then
	when mm_functionkey then
	when mm_wheel then
	when mm_edited then
	else
!CPL "MESSAA2"
		return skipmess
	esac
!CPL "MESSAA3"

	return thismess
end

func mess_restore_all(mess,w)=
	gxrestore(W)

	return skipmess
end

func mess_killfocus_all(mess,w)=
!note: can be called from mess_setfocus_all, with a different mess, but correct w
!assume w is same as wfocus

	drawcaret(0)
	wfocus:=nil

	return skipmess
end

func mess_setfocus_all(mess,w)=
	if wfocus then
		mess_killfocus_all(mess,wfocus)
	fi

	wfocus:=w
	drawcaret(1)
	return skipmess
end

func mess_update_all(mess,w)=
	gxupdate(w)
	return skipmess
end

func mess_draw_all(mess,w)=
	gxdraw(w)
	return skipmess
end

func mess_click_select(mess,w)=
	if w.enable then
		if not w.style.noupdate then
			p:=w.linkvar
			p^:=w.attrs.onvalue
			for wc in w.owner.childlist do
				if wc.windclass=select_class and wc.linkvar=p then
					gxdraw(wc)
				fi
			od
		fi
		if w.style.returnmess then
			postmess(w,mm_command,w.id)
		fi
	fi
	return skipmess
end

func mess_click_toggle(mess,w)=
	if w.enable then
		if not w.style.noupdate then
			w.linkvar^:=not w.linkvar^
			gxdraw(w)
		fi
		if w.style.returnmess then
			postmess(w,mm_command,w.id)
		fi
	fi
	return skipmess
end

func mess_click_button(mess,w)=

	if w.enable=0 then
		beep1()
		return skipmess
	fi

	if w.id in 0..199 then				!speficies an actual message number (but no params)
		postmess(w,w.id)
	else
		postmess(w,mm_command,w.id)
	fi
	return skipmess
end

func mess_click_editbox(mess,w)=
	if w.enable then
		if not w.style.noupdate then
			unless w==wfocus then
				gxfocus(w)
			end
		fi
		if w.style.returnmess then
			postmess(w,mm_command,w.id)
		fi
	fi

	return skipmess
end

func mess_click_arrow(mess,w)=

	case w.owner.windclass
	when scrollbar_class then
		postmess(w.owner,dirtomess{w.style.dir},w.id,0,-1)
	else
		mess.message:=dirtomess{w.style.dir}
		mess.a:=w.id
		return thismess
	esac
	return skipmess
end

func mess_click_mark(mess,w)=

	case w.owner.windclass
	when toggle_class,select_class then
		postmess(w.owner,mess.message,w.id,0,-1)
	esac
	return skipmess
end

func mess_click_listbox(mess,w)=
	gxfocus(w)

	y:=max(w.attrs.offset,mess.y)

	pos:=(y-w.attrs.offset)%w.attrs.pitch+w.attrs.pagepos
	if pos<=getlvbounds(w.linkvar).len then
		gxsetlbpos(w,pos)
		postmess(w,mm_pick,pos)
	fi

	return skipmess
end

func mess_click_scrollbar(mess,w)=
	onthumb:=isonthumb(w,(w.style.dir='H'|mess.x|mess.y))
	step:=w.attrs.span
	a:=w.attrs.currpos

	case w.owner.windclass
	when listbox_class then
		case onthumb
		when -1 then
			if a>w.attrs.limits.lwb then
				a:=max(a-step,w.attrs.limits.lwb)
				gxsetlbpage(w.owner,a)
			fi
		when 1 then
			if a<w.attrs.limits.upb then
				a:=min(a+step,w.attrs.limits.upb)
				gxsetlbpage(w.owner,a)
			fi
		esac
	else
		if not step then step:=10 fi

		case onthumb
		when -1 then
			if a>w.attrs.limits.lwb then
				a:=max(a-step,w.attrs.limits.lwb)
				gxscrollpos(w,a,1)
				postmess(w,mm_sethozpos,a)
			fi
		when 1 then
			if a<w.attrs.limits.upb then
				a:=min(a+step,w.attrs.limits.upb)
				gxscrollpos(w,a,1)
				postmess(w,mm_sethozpos,a)
			fi
		esac
	esac
	return skipmess
end

func mess_wheel_scrollbar(mess,w)=
	delta:=currmess.a
	n:=abs(currmess.a%120)
	to n do
		case w.windclass
		when scrollbar_class then
	doscroll:
			postmess(w,(delta>0|mm_up|mm_down))
		when listbox_class then
			if w.childlist then
				w:=w.childlist[1]
				goto doscroll
			fi
			postmess(w,(delta>0|mm_upkey|mm_downkey))
		esac
	od
	return skipmess
end

func mess_up_scrollbar(mess,w)=
	a:=w.attrs.currpos
	if a<=w.attrs.limits.lwb then
		return skipmess
	fi
	case w.owner.windclass
	when listbox_class then
		gxsetlbpage(w.owner,a-1)
		return skipmess
	else
		--a
		gxscrollpos(w,a,1)
		postmess(w,mm_setvertpos,a)
	esac
	return skipmess
end

func mess_left_scrollbar(mess,w)=

	case w.owner.windclass
	when listbox_class then
		return skipmess
	else
		a:=w.attrs.currpos
		if a>w.attrs.limits.lwb then
			--a
			gxscrollpos(w,a,1)
			postmess(w,mm_sethozpos,a)
		fi
	esac
	return skipmess
end

func mess_right_scrollbar(mess,w)=

	case w.owner.windclass
	when listbox_class then
		return skipmess
	else
		a:=w.attrs.currpos
		if a<w.attrs.limits.upb then
			++a
			gxscrollpos(w,a,1)
			postmess(w,mm_sethozpos,a)
		fi

	esac
	return skipmess
end

func mess_down_scrollbar(mess,w)=

	a:=w.attrs.currpos
	if a>=w.attrs.limits.upb then
		return thismess
	fi
	case w.owner.windclass
	when listbox_class then
		gxsetlbpage(w.owner,a+1)
		return skipmess
	else
		++a
		gxscrollpos(w,a,1)
		postmess(w,mm_setvertpos,a)

	esac
	return skipmess
end

func mess_drag_scrollbar(mess,w)=
	case mess.message
	when mm_startdrag then
		if isonthumb(w,(w.style.dir='H'|mess.x|mess.y))=0 then
			thumbdragmode:=1			!then treat as mm_drag
			thumbstartpos:=w.attrs.thumbpos-arrowdim		!use thumb pos at start of drag
		else							!dragging other part of scrollbar
			return skipmess
		fi
	when mm_enddrag then
		thumbdragmode:=0
		return skipmess
	elsif not thumbdragmode then
		return skipmess
	esac

	offset:=(w.style.dir='H'|mess.a|mess.b)		!pixel offset from initial drag start pos
	newpos:=thumbstartpos+offset						!could outside thumb span range

	pos:=int(round((newpos/w.attrs.thumbspan)*(w.attrs.limits.len-1)+w.attrs.limits.lwb))
	pos:=clamp(pos,w.attrs.limits.lwb,w.attrs.limits.upb)

	case w.owner.windclass
	when listbox_class then
		gxsetlbpage(w.owner,pos)
	else
		gxscrollpos(w,pos,1)
		postmess(w,(w.style.dir='H'|mm_sethozpos|mm_setvertpos),pos)
	esac
	return skipmess
end

func mess_move_button(mess,w)=
	return skipmess
end

func mess_move_all(mess,w)=
	return skipmess
end

func mess_char_editbox(mess,w)=
!	SHOWMESSAGE("CHAREDIT",MESS)

		if mess.a not in 32..255 then
!	cpl "CHAR/EDIT2",MESS.A,VKENTER
			case mess.a
			when vkenter then
				CPL "ENTER"
				m:=mm_edited
			else
				m:=mm_key
			esac

			if wapplic then
!	CPL "CHAR/EDIT CONTROL",=MESS.A,MESS.B
				postmess(wapplic,m, mess.a,mess.b,mess.state)
			fi
			return skipmess
		fi
		if not w.enable or w.style.noupdate then return skipmess fi
		s:=w.linkvar^
		n:=w.attrs.currpos
		c:=chr(mess.a)

		if n>s.len then				!at end
			s+:=c
		elsif n=1 then				!at start
			s:=c+s
		else						!in middle
			s:=leftstr(s,n-1)+c+rightstr(s,-(n-1))
		fi

		w.linkvar^:=s
		++w.attrs.currpos
		gxdraw(w)

		return skipmess
end

func mess_key_editbox(mess,w)=
!	CPL "KEY/EDITBOX"

	postmess(wapplic,mm_key,mess.a,mess.b,mess.state)

	return skipmess
end

func mess_leftkey_editbox(mess,w)=
	if ctrlpressed() then
		postmess(wapplic,mm_leftkey,mess.a,mess.b,mess.state)
		return skipmess
	fi

	if w.attrs.currpos>1 then
		drawcaret(0)
		--w.attrs.currpos
		drawcaret(1)
	fi
	return skipmess
end

func mess_rightkey_editbox(mess,w)=
	if ctrlpressed() then
		postmess(wapplic,mm_rightkey,mess.a,mess.b,mess.state)
		return skipmess
	fi

	if w.attrs.currpos<=w.linkvar^.len then
		drawcaret(0)
		++w.attrs.currpos
		drawcaret(1)
	fi
	return skipmess
end

func mess_bskey_editbox(mess,w)=
	s:=w.linkvar^
	if not s then return skipmess fi
	n:=w.attrs.currpos
	if n=1 then return skipmess fi

	if n>s.len then				!at end
		s:=leftstr(s,-1)
	else						!in middle
		s:=leftstr(s,n-2)+rightstr(s,-(n-1))
	fi

	w.linkvar^:=s
	--w.attrs.currpos
	gxdraw(w)

	return skipmess
end

func mess_deletekey_editbox(mess,w)=
	s:=w.linkvar^
	if not s then return skipmess fi
	n:=w.attrs.currpos
	if n>s.len then return skipmess fi

	if n=1 then				!at start
		s:=rightstr(s,-1)
	else						!in middle
		s:=leftstr(s,n-1)+rightstr(s,-n)
	fi
	w.linkvar^:=s
	gxdraw(w)

	return skipmess
end

func mess_homekey_editbox(mess,w)=
	if ctrlpressed() then
		postmess(wapplic,mm_homekey,mess.a,mess.b,mess.state)
		return skipmess
	fi

	drawcaret(0)
	w.attrs.currpos:=1
	drawcaret(1)

	return skipmess
end

func mess_homekey_listbox(mess,w)=
	if w.attrs.currpos>1 then
		gxsetlbpos(w,1)
	fi

	return skipmess
end

func mess_endkey_editbox(mess,w)=
	if ctrlpressed() then
		postmess(wapplic,mm_endkey,mess.a,mess.b,mess.state)
		return skipmess
	fi

	drawcaret(0)
	w.attrs.currpos:=w.linkvar^.len+1
	drawcaret(1)

	return skipmess
end

func mess_endkey_listbox(mess,w)=
!if w.attrs.currpos<w.linkvar^.len then
	if w.attrs.currpos<getlvbounds(w.linkvar).len then
!	gxsetlbpos(w,w.linkvar^.len)
		gxsetlbpos(w,getlvbounds(w.linkvar).len)
	fi

	return skipmess
end

func mess_upkey_listbox(mess,w)=
	if w.attrs.currpos>1 then
		gxsetlbpos(w,w.attrs.currpos-1)
	fi

	return skipmess
end

func mess_upkey_scrollbar(mess,w)=
!assume that this is independent scrollbar
!(linked scrollbar wouldn't get the focus)

	a:=w.attrs.currpos
	if a>w.attrs.limits.lwb then
		--a
		gxscrollpos(w,a,1)
		postmess(w,mm_setvertpos,a)
	fi
	return skipmess
end

func mess_downkey_listbox(mess,w)=
!if w.attrs.currpos<w.linkvar^.len then
	if w.attrs.currpos<getlvbounds(w.linkvar).len then
		gxsetlbpos(w,w.attrs.currpos+1)
	fi

	return skipmess
end

func mess_pageupkey_listbox(mess,w)=
	if (a:=w.attrs.currpos)>1 then
		a:=max(a-w.attrs.rows,1)
		gxsetlbpos(w,a)
	fi

	return skipmess
end

func mess_pagedownkey_listbox(mess,w)=
	if (a:=w.attrs.currpos)<getlvbounds(w.linkvar).len then
		a:=min(a+w.attrs.rows,getlvbounds(w.linkvar).len)
		gxsetlbpos(w,a)
	fi

	return skipmess
end

func mess_enterkey_listbox(mess,w)=
	if w.attrs.currpos then
		postmess(w,mm_pick,w.attrs.currpos)
	fi

	return skipmess
end

proc do_draw_all(w)=
	gxclear(w)
	drawborder(w)
	drawchildborders(w)
end

proc do_draw_button(w)=
	gxclear(w)

	gxtext_just(w,w.text,0,w.enable)

	drawborder(w)

end

proc do_draw_label(w)=
	do_draw_button(w)
end

proc do_draw_toggle(w)=
	gxclear(w)

	VALSTR:=""

	turnedon:=istrue w.linkvar^

	if w.style.marktype then
		drawmark(w.childlist[1],turnedon,w.enable)

		gxtext_just(w,w.text+valstr,markdim,w.enable)
	else
!	case w.style.hilitetype
!	when invert_hilite then
			if turnedon then
				gxclear(w,getrgb(green))
			fi
!	esac

		gxtext_just(w,w.text+valstr)
	fi
end

proc do_draw_select(w)=
	gxclear(w)

	turnedon:=w.linkvar^=w.attrs.onvalue

	if w.style.marktype then
		drawmark(w.childlist[1],turnedon,w.enable)
		gxtext_just(w,w.text,markdim,w.enable)
	else
		case w.style.hilitetype
		when invert_hilite then
			if turnedon then
				gxclear(w,getrgb(white))
			fi
		esac
			gxtext_just(w,w.text)
	fi
end

proc do_draw_editbox(w)=
	gxclear(w)

	gxtext_just(w,w.linkvar^,enable:w.enable)

!Now, have to draw the cursor
	unless wfocus==w then			!only draw it when this window has the focus
		return
	end

	caretdrawn:=0

	drawcaret(1)
end

proc do_draw_arrow(w)=
	gxclear(w)

	drawborder(w)
	drawarrow(w,w.enable)
end

proc do_draw_mark(w)=

	case w.owner.windclass
	when toggle_class, select_class then
		return					!mark drawn by owner
	esac

	gxclear(w,getrgb(w.owner.style.windbgnd))

	drawborder(w)
end

proc do_draw_scrollbar(w)=
	gxclear(w)
	drawborder(w)
	gxdraw(w.childlist[1])			!arrows
	gxdraw(w.childlist[2])

!now draw the thumb
	if w.attrs.thumbsize then
		if w.style.dir='H' then
			x:=w.attrs.thumbpos
			dx:=w.attrs.thumbsize
			drawthumb(w,x,0,dx,w.dimy)
		else
			y:=w.attrs.thumbpos
			dy:=w.attrs.thumbsize
			drawthumb(w,0,y,w.dimx,dy)
		fi
	fi
end

proc do_draw_listbox(w)=
	gxclear(w)
	drawborder(w)
	if w.childlist then			!scrollbar
		gxdraw(w.childlist[1])
	fi

	for i:=1 to w.attrs.rows do
		k:=i+w.attrs.pagepos-1
		if k<=getlvbounds(w.linkvar).len then
			drawlbtext(w,i,getlvstritem(w.linkvar,k),0,k=w.attrs.currpos)
		fi
	od
end

proc do_update_all(w)=
	gxdraw(w)
end

proc do_update_listbox(w)=
	gxdraw(w)
end

proc drawcaret(x)=
!x=1: draw caret in wfocus window at current position
!x=0: delete caret in wsfocus window
!returns x-pixel position of caret

	if wfocus=nil then		!no window has focus
		caretdrawn:=0
		return
	fi

	case wfocus.windclass
	when editbox_class then
		if x then			!new caret
			if caretdrawn then return fi	!already drawn
			xpos:=getcaretpos(wfocus.linkvar^,wfocus.attrs.currpos,0)
			wfocus.attrs.caretpos:=xpos			!record position
		else			!delete caret
			if not caretdrawn then return fi	!already deleted
			xpos:=wfocus.attrs.caretpos		!use stored value
		fi

		caretwidth:=2

		gxhighlight(wfocus,xpos+wfocus.attrs.textpos[1],wfocus.attrs.textpos[2]-chd,caretwidth,20)

		caretdrawn:=x
	esac
end

func getcaretpos(s,pos,offset)=
!return pixel position of in front of pos'th character in string s
!offset is no. of chars not shown, to left of string
	if pos=1 then return 0 fi

	return wx_gettextwidth(wfocus.gdi.hdc, leftstr(s,pos-1))
end

proc drawborder(w)=
!do own-drawn borders
!other kinds of borders are windows-drawn, no-border, and the main bs- style
!borders which exist in the owner's client area
!for own-drawn borders, the window should have been cleared first

	case bscat[w.style.border]
	when 0 then					!no border
		return
	when 'W' then				!windows-drawn
		return
	when 'X' then				!external (drawn in owner's client space
		posx:=w.frameposx
		posy:=w.frameposy
		dimx:=w.framedimx
		dimy:=w.framedimy
		bs:=w.style.border

		bs:=w.style.border
		wo:=w.owner
		case bs
		when bs_simple then			!USUALLY BS_SIMPLE converts to BS_WINDOWS; must be override
			gxcolour(wo,0)
			gxrect(wo,posx,posy,dimx,dimy)
		when bs_thick then
		when bs_panel then
			gxcolour(wo,ltcolour)
			gxline(wo,posx+dimx-1,posy, posx,posy)
			gxline(wo,posx,posy+dimy-1)
			gxcolour(wo,dkcolour)
			gxline(wo,posx+dimx-1,posy+dimy-1)
			gxline(wo,posx+dimx-1,posy)
		when bs_inset then
			gxcolour(wo,dkcolour)
			gxline(wo,posx+dimx-1,posy, posx,posy)
			gxline(wo,posx,posy+dimy-1)
			gxcolour(wo,ltcolour)
			gxline(wo,posx+dimx-1,posy+dimy-1)
			gxline(wo,posx+dimx-1,posy)
		when bs_testext then
			gxcolour(wo,0)
			gxrect(wo,posx,posy,dimx,dimy)
			gxrect(wo,posx+9,posy+9,dimx-18,dimy-18)
		esac
	when 'I' then				!internal (drawn within window's client space
		posx:=w.frameposx
		posy:=w.frameposy
		dimx:=w.dimx
		dimy:=w.dimy

		case w.style.border
		when bs_ownpanel then
			gxcolour(w,ltcolour)
			gxline(w,w.framedimx-1,0,0,0)
			gxline(w,0,w.framedimy-1)
			gxcolour(w,dkcolour)
			gxline(w,w.framedimx-1,w.framedimy-1)
			gxline(w,w.framedimx-1,0)

		when bs_owninset then
			gxcolour(w,dkcolour)
			gxline(w,w.framedimx-1,0,0,0)
			gxline(w,0,w.framedimy-1)
			gxcolour(w,ltcolour)
			gxline(w,w.framedimx-1,w.framedimy-1)
			gxline(w,w.framedimx-1,0)
		when bs_ownsimple then
			gxcolour(w,0)
			gxrect(w,0,0,w.framedimx,w.framedimy)
		when bs_testint then
			gxcolour(w,0)
			gxrect(w,0,0,dimx,dimy)
			gxrect(w,7,7,dimx-14,dimy-14)
		esac
	esac
end

proc drawchildborders(w)=
	if not w.childlist then
		return
	fi
	for wc in w.childlist do
		if wc.style.border in [bs_simple,bs_thick,bs_panel,bs_inset] then
			drawborder(wc)
		fi
	od
end

proc drawarrow(w,enable)=
!w has already been cleared
!e=1/omitted to enable, 0 to disable (shown grey)
	const factor=0.3

	gxsetpen(w,(enable|black|dkgrey))

	width:=w.dimx
	height:=w.dimy

	case w.style.dir
	when 'D' then
		x:=int(round(width/2)-1)

		wd:=0

		h:=int(round(min(height,width)*factor))
		if h<3 then h:=3 fi
		y:=int((height+h)*0.5)-1

		to h do
			gxline(w,x,y,x+wd,y)
			x-:=1
			y-:=1
			wd+:=2
		od

	when 'U' then
		x:=int(round(width/2)-1)
		wd:=0

		h:=int(round(min(height,width)*factor))
		if h<3 then h:=3 fi
		y:=int(round((height-h)*0.5))
		to h do
			gxline(w,x,y,x+wd,y)
			x-:=1
			y+:=1
			wd+:=2
		od

	when 'L' then
		y:=height%2

		ht:=0
		wd:=y

		wd:=int(round(min(height,width)*factor))
		if wd<3 then wd:=3 fi
		x:=int(round((width-wd)*0.5)-1)

		to wd do
			gxline(w,x,y,x,y+ht)
			y-:=1
			x+:=1
			ht+:=2
		od

	when 'R' then
		y:=height%2
		ht:=0

		wd:=int(round(min(height,width)*factor))
		if wd<3 then wd:=3 fi
		x:=int(round((width+wd)*0.5)-1)

		to wd do
			gxline(w,x,y,x,y+ht)
			y-:=1
			x-:=1
			ht+:=2
		od
	esac
end

export proc gxtext_just(w,s,offset=0,enable=1)=
		dimx:=w.dimx
		dimy:=w.dimy
		width:=wx_gettextwidth(w.gdi.hdc, s)
		height:=chy				!assume basic font

		case w.style.justify
		when 'L' then	x:=smx
		when 'R' then	x:=dimx-width-smx
		else
					x:=(dimx-width)%2
		esac

		case w.style.vjustify
		when 'T' then	y:=smy
		when 'B' then	y:=dimy-height-smy
		else
					y:=(dimy-height)%2!		-smy%2
		esac

		if not enable then
			oldtextfgnd:=w.style.textfgnd
			gxtextcolour(w,grey)
		fi

		gxtext(w,s,x+offset,y)

		if not enable then
			gxtextcolour(w,oldtextfgnd)
		fi
		if w.windclass=editbox_class then
			w.attrs.textpos:=(x+offset,y)
		fi
end

proc drawthumb(w,x,y,dx,dy)=
!w is a scrollbar, vert or hoz
!draw thumb within w, as a simple rectangle starting at x,y at top left of size dx,dy

	gxcolour(w,0)
	gxrect(w,x,y,dx,dy)
	gxfillrect(w,x+1,y+1,dx-2,dy-2,getrgb(grey))
end

func isonthumb(w,d)=
!w is a scrollbar, d is a pixel position along it (0 being at left or top)
!return:
! -1	is before the thumb
!  0	is on the thumb
! +1	if after the thumb
!d can specify a spot off the thumbar if being dragged

	a:=w.attrs.thumbpos
	b:=w.attrs.thumbsize

	if d<a then
		return -1
	elsif d>(a+b) then
		return 1
	else
		return 0
	fi
end

proc drawmark(w,turnedon,enable)=
!!w has already been cleared
!draw checked check mark, tick, or radio button, according to whether
!turnedon is 1 or 0
!e=1 to enable, 0 to disable (shown grey)

	gxclear(w,getrgb(w.owner.style.windbgnd))
	gxsetpen(w,(enable|black|red))

	width:=w.dimx
	height:=w.dimy
	x:=y:=1
	wd:=width-2
	ht:=height-2
	gxrect(w,x,y,wd,ht)
	if not turnedon then return fi

	case w.style.marktype
	when radio_mark then

		gxfillrect(w,x+3,y+3,wd-6,ht-6,getrgb(red))

	when check_mark then

		gxline(w,x,y,x+wd-1,y+ht-1)
		gxline(w,x+wd-1,y,x,y+ht-1)

	when tick_mark then

		gxline(w,x+3,y+ht%2,x+wd%2,y+ht-4)
		gxline(w,x+wd-3,y+2)

	esac
end

proc drawlbtext(w,row,text,clr=0,hilite=0)=
!draw text inside given row of listbox w
!clr=1 to clear the background first (not needed when entired lb has been cleared)
!hilite=1 to highlight this row

	x:=0
	y:=(row-1)*w.attrs.pitch+w.attrs.offset

	if clr or hilite then
		gxfillrect(w,x,y,w.dimx,w.attrs.pitch,(hilite|getrgb(grey)|getrgb(w.style.windbgnd)))
	fi

	if hilite then
		oldtextcolour:=gxtextcolour(w)
		gxtextcolour(w,white)
	fi
!RETURN

	gxtext(w,text,x+smx,y+smy)
	if hilite then
		gxtextcolour(w,oldtextcolour)
	fi
end

func readnextitem(a)=
!return (level,value,labelx,options)
!special values used for divider, new column, new menu
!next line of file should already have been read

	if a="" then return (0,0,0,0) fi

	level:=1
	tabs:=0
	options:=""

	while asc(a) in [9,' '] do tabs+:=1; a:=rightstr(a,-1) od

	if a="" then return (0,0,0,0) fi

	case asc(a)
	when '!' then
		return (0,0,0,0)
	esac

	if tabs then
		j:=0
		for i:=1 to ntab do
			if tabs=tabstack[i] then j:=i; exit fi
		od

		if j=0 then
			if tabs>tabstack[ntab] then
				ntab+:=1
				tabstack[ntab]:=tabs
			fi
			level:=ntab
		else
			level:=j
			if j<ntab then ntab:=j fi
		fi
	fi

	if asc(a) in ['0'..'9'] then
		value:=strtoval(a)
		n:=" " inx a
		if not n.isfound then
			n:=chr(9) in a
		fi
		if n.isfound then
			labelx:=rightstr(a,-n)
		else
			labelx:="?"
		fi

	else			!no preceding number, maybe top-level menu

		if "=" in a then	!command def for mpl
			return (0,0,0,0)
		fi

		value:=k_menu
		labelx:=a
		case convlc(labelx)
		when "hozbreak","divider" then
			value:=kdivide
		when "vertbreak" then
			value:=kcolumn
		when "filehistory" then
			value:=kfilehistory
		else
			if leftstr(labelx)="-" then value:=kdivide fi
		esac
	fi

	if labelx="" then			!maybe [cmd] only
		return (0,0,0,0)
	fi

	return (level,value,(labelx),options)
end

func readmenu(m,n,level)=
!starting at index n in data, read all following items that are
!at lower level (ie. higher level number) than given level
!insert items into menu handle m
!return index of next item in data, which is at <level> or higher
!will stop at end of data, and return ndata+1

	restartx:
	for i:=n to ndata do
		(l,value,labelx,options):=data[i]

		if l<=level then		!end of this submenu
			return i
		fi

		flags:=breakflag
		enable:=1
		if rightstr(labelx)="?" then
			enable:=0
			labelx:=leftstr(labelx,-1)
		fi

		if options<>"" then
			if "H" in options then flags+:="h" fi
			if "C" in options then flags+:="c" fi
		fi

		case value
		when kdivide then
			gxaddmb(m,style:"d")
		when kcolumn then
			breakflag:="v"
		when k_menu then		!submenu
			newm:=gxcreatemb()
			n:=readmenu(newm,i+1,l)
			gxaddmb(m,labelx,newm,"p"+flags,enable)
			breakflag:=""
			goto restartx
		when kfilehistory then
			nfiles:=8
			gxaddmb(m,"filehistory",1060,breakflag)
		else				!ordinary command
	normalcmd:
			gxaddmb(m,labelx,value,flags,enable)
			breakflag:=""
		esac

	skip:
	od

	return ndata+1			!eod reached
end

func mbreaddata(a)=
!a is a list of tab-indented strings for a menu bar
!a can also be a text file containing the strings

	tabstack::=(0,)
	ntab:=1
	data::=()
	ndata:=0
	breakflag:=""

	if a.isstring then		!read from file
		a:=readtextfile(a)
		if a=0 then
			a:=("CANTOPENFILE",)
		fi
	fi

	for i:=1 to a.upb do
		x:=readnextitem(a[i])

		if x[1] then
			++ndata
			data[ndata]:=x
		fi
	od

	m:=gxcreatemb()
	readmenu(m,1,0)
	return m
end

export func gxmenubar(w,?a)=
!called as:
!	gxmenubar(a):	create standalone menu; return handle
!	gxmenubar(w,a):	add menu to windows w (returns 0)
!a:
!	string:			assume this is a filename containing menubar tabbed layout
!	list:			a list of strings containing the data

	if a.isdef then			!w,m: read menu into window w
		m:=mbreaddata(a)

		if not w.ispointer then
			while w.owner<>nil do
				w:=w.owner
			od
		fi

		gxsetmb(w,m)
		return 0
	else				!create standalone menu, return handle
		return mbreaddata(w)
	fi
end

func gxcreatemb(?s)=
	if s.isdef and s in "Pp" then
		return createpopupmenu()
	else
		return createmenu()
	fi
end

proc gxsetmb(w,m)=

	hwnd:=w.gdi.hwnd
	a:=getmenu(hwnd)
	s:=setmenu(hwnd,m)
	if a then destroymenu(a) fi
end

func gxaddmb(wm,caption="X",id=0,style="",enable=0)=

	if wm.ispointer then				!assume handle
		hmenu:=wm
		wm:=nil
	else
		hmenu:=getmenu(wm.gdi.hwnd)
	fi

	flags:=mf_string ior mf_unchecked

	if not enable then flags ior:=mf_greyed fi

	foreach c in convuc(style) do
		case c
		when 0 then exit
		when 'P' then flags ior:=mf_popup
		when 'D' then flags ior:=mf_separator
		when 'B' then flags ior:=mf_menubreak
		when 'V' then flags ior:=mf_menubarbreak
		when 'H' then flags ior:=mf_help
		when 'C' then flags ior:=mf_checked
		esac
	od

	if appendmenu(hmenu,flags,id,caption) then
		if wm<>nil then drawmenubar(wm.gdi.hwnd) fi
		return hmenu
	fi
	return 0
end

proc gxshowmb(wm,w,x,y)=
!update menu associated with window; call this func if it has been updated
!when wm is a menu handle, draw the popup on the screen at x,y
!if wm.isint then
	if wm.ispointer then

		if not y.isdef then
			x:=w
			y:=x
			w:=nil
			hwnd:=wapplic.gdi.hwnd
		else
			hwnd:=w.gdi.hwnd
		fi

		pos:=ws_point(x,y)

		if w<>nil then
			clienttoscreen(w.gdi.hwnd,&pos)
		fi

		trackpopupmenu(wm,0,pos.x,pos.y,0,hwnd,0)
	else
		drawmenubar(wm.gdi.hwnd)
	fi
end

func gxenablemb(wm,id,enable)=

	if wm.ispointer then				!assume handle
		hmenu:=wm
	else
		hmenu:=getmenu(wm.gdi.hwnd)
	fi

	if enable.isdef then
		return enablemenuitem(hmenu,id,(enable|0|mf_greyed)+mf_bycommand)
	else
		return (getmenustate(hmenu,id,mf_bycommand) iand mf_greyed|0|1)
	fi
end

func gxcheckmb(wm,id,check)=
	if wm.ispointer then				!assume handle
		hmenu:=wm
	else
		hmenu:=getmenu(wm.gdi.hwnd)
	fi

	if check.isdef then
		return checkmenuitem(hmenu,id,(check|mf_checked|mf_unchecked)+mf_bycommand)
	else
		return (getmenustate(hmenu,id,mf_bycommand) iand mf_checked|1|0)
	fi
end

proc gxclosemb(m)=
	destroymenu(m)
end

export func gxconfirm(m)=
	x:=gxmsgbox(m,"Confirm","byn")
	return x="yes"
end

func issubwindow(w,w2)=
	while w2 do
		if w2==w then return 1 fi
		w2:=w2.owner
	od
	return 0
end

export proc flushmessages=

end

PROC CHECKWIND(W, NAME)=
	IF W=NIL THEN RETURN FI
	IF W.NAME=NAME THEN
		CPL "CHECKWIND MATCHES****************"
	FI
END

EXPORT PROC CHECKCLOSED(NAME)=
!CPL "CC:",=NAME
!CPL "CC:",=CURRMESS.WIND

	CHECKWIND(CURRMESS.WIND,NAME)
	CHECKWIND(WFOCUS,NAME)

	for w in allwindows do
		checkwind(w, name)
!CPL =W
!CPL =W.CHILDLIST.TYPE
		if w then
		for wc in w.childlist do
			checkwind(wc, name)
		od
		fi
	od

	for i to nmessages do
		m:=messagequeue[i]
		checkwind(m.wind,name)
	od

	CPL "CC: OK*****"
END
