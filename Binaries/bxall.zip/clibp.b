importdll msvcrt=
!importdll msvcr100=
!importdll msvcr120=
	func "malloc"        (i64)ref byte
	func realloc(i64, i32)i64
	proc free        (i64)
	proc memset      (ref byte, i32, i32)
	proc memcpy      (ref byte, ref byte, i32)
	func memcmp      (ref byte, ref byte, i32)i32
!	func clock       :i32
	func ftell       (i64)i32
	func _ftelli64   (i64)i64
	func fseek       (i64, i32, i32)i32
	func _fseeki64   (i64, i32, i32)i64
	func fread       (ref byte, i32, i32, i64)i32
	func fwrite      (ref byte, i32, i32, i64)i32
	func getc   (i64)i32
	func ungetc (i32, i64)i32
	func fopen       (stringz, stringz)i64
	func fclose      (i64)i32
	func fgets       (ref byte, i32, i64)ref byte
	func remove      (stringz)i32
	func rename      (stringz, stringz)i32
	func getchar     :i32
	proc putchar     (i32)
	proc setbuf      (i64, i64)

	func rand        :i32
	proc srand       (i32)

	func puts        (stringz)i32
	func printf      (stringz, ...)i32

	func sprintf     (stringz, stringz, ...)i32

	func sscanf      (stringz, stringz, ...)i32
	func isalpha     (i32)i32
	func tolower     (i32)i32
	func strlen      (ref byte)i32
	func atoi        (stringz)i32

!   clang func system      (stringz)i32

	func fgetc  (i64)i32
	func fputc  (i32,  i64)i32
	func fprintf     (i64, stringz, ...)i32
	func fputs       (stringz,  i64)i32
	func feof        (i64)i32
!   clang func getch       :i32
	func _getch      :i32
	proc fflush      (ref void)
	proc tcflush     (int, int)

end

global const c_eof     = -1
global const seek_set  = 0
global const seek_curr = 1
global const seek_end  = 2

