runinfo
!	runexe .\mm $.ma
	runexe bb $

!	runopt -parse
!	runopt -type1
!	runopt -type2
!	runopt -name
	runopt -pcl

	runopt -pcl1
	runopt -ast2
	runopt -ast1
!	runopt -decons
	runopt -st
	runopt -types
!	runopt -modules


end

modules
	mmproject bb.m

	file pcl_gen.m
	file oldcodegen.m
	file bb_cli.m
	file pcl_lib.m
	file pcl_decls.m
	file pcl_show.m
	file bb_SUPPORT.m
	file bb_parse.m
	file bb_resolve.m
!	file bb_lex.m
	file bb_TABLES.m
	file bb.m
	file bb_show.m
	file ---
	module bb.m
	module bb_cli.m
	module bb_DECLS.m
	module bb_files.m
	module bb_lex.m
	module bb_parse.m
	module bb_resolve.m
	module bb_show.m
	module bb_strexpr.m
	module bb_support.m
	module bb_tables.m
	file ---
	module pcl_decls.m
	module pcl_gen.m
	module pcl_lib.m
	module pcl_show.m
end

file ---
file blang.txt
!file pclrec.txt
!file oldpclops.txt
!file newpclops.txt
!file newmilops.txt
!file newtypes.txt
!file stnames.txt
!file strec.txt
!file newstrec.txt
!file newunitrec.txt
!file syntax.txt
!file files.txt
!file types.txt
!file types2.txt
!file typesyntax.txt
!file types3.txt
!file types4.txt
!file sunit.txt
!file record.txt
file syslibs.txt
file issues.txt
file msyswin.m
file msys.m
file mlib.m
file mclib.m
file mwindows.m
file mwindll.m
file u.m
file sysp.b
file newblang.txt
