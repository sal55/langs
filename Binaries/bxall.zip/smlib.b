
export var popuplist::=()
export var focuslist::=()
export var npopups=0
export var message
export var messw, messa, messb
export var wpopup=nil

record blockrec=
	var posx, posy				!pixel position of top left of block: relative to other
								!blocks, later within client area of containing window
	var dimx,dimy				!'client' area of block, including margins, cells and gaps
	var celldimx, celldimy		!size of each cell, in pixels
	var cellsx, cellsy			!number of identically-svert hoz and vertical controls
	var gapx, gapy				!gap between cells, in pixels
	var marginx, marginy		!margins around all cells
	var labelwidth				!for edit boxes, how many pixels on left are for label
	var cellposx,cellposy		!position of top left cell within block
	var pitchx,pitchy			!1st cell is at for edit boxes, how many pixels on left are for label
	var blockstyle				!style record for blocks
	var name					!name for debugging
	var dir						!'H' or 'V' for stepping direction

end

var blocklist::=()
var nblocks=0
var	currblock =nil				!current blockrec
var	currgroup =nil				!rwindow corresponding to currblock
var	currpopup =nil				!rwindow for menu to contain current set of blocks
var cellx, celly				!current cell within current block
var slposx,slposy,sldir			!set by smcreate in case sl-functions are used

!proc showblockinfo(block)=
!println "Block:      ",(block.name.isdef|block.name|"")
!println "Pos:        ",block.posx,block.posy
!println "Dim:        ",block.dimx,block.dimy
!println "CellDim:    ",block.celldimx,block.celldimy
!println "Gap:        ",block.gapx,block.gapy
!println "Cells:      ",block.cellsx,block.cellsy
!println "Gaps:       ",block.gapx,block.gapy
!println "Margins:    ",block.marginx,block.marginy
!println "Labelwidth: ",block.labelwidth
!println "Cellpos:    ",block.cellposx,block.cellposy
!println "Pitch:      ",block.pitchx,block.pitchy
!println "Dir:        ",block.dir
!println
!end

export proc sminit=
	blocklist::=()
	nblocks:=0
end

export func smdefblock(?dim,cells=1,style="",gap=0,labeldim="",margin=0,dir='V')=
!define a matrix of cells, all the same size, to be used as controls
!dim	is a the size of each cell, as pixel dims, or as a sample string
!cells	is a the hoz and vert cell count. Or it can be an int for vert column only
!gap	is the inter-cell gap, specified in pixels. Default is to use chx or chy.
!		gap can be (x,y), or just n for the same gap in hoz and vert
!style	Currently, a string containing various styles and options. Will be
!	compatible with old uses of these functions. Or can be replaced with a dict
!label	When specified, is a sample string givibg the length of the label on the left
!		of edit boxes; can also be a pixel width
!return handle to block
!also add block to export blocklist

	block:=new(blockrec,0)
	block.dir:=dir
!block.dir:='H'

	if dim.isstring then
		block.celldimx:=gxtextwidth(labelfont,dim)+smx*2
		block.celldimy:=chy+smy*2
	else
		(block.celldimx,block.celldimy):=dim
	fi

	if cells.isint then
		block.cellsx:=1
		block.cellsy:=cells
	else
		(block.cellsx,block.cellsy):=cells
	fi

	if gap.isint then
		block.gapx:=gap
		block.gapy:=gap
	else
		(block.gapx,block.gapy):=gap
	fi

	if margin.isint then
		block.marginx:=margin
		block.marginy:=margin
	else
		(block.marginx,block.marginy):=margin
	fi

	if labeldim then
		if labeldim.isstring then
			block.labelwidth:=gxtextwidth(labelfont,labeldim)+smx*2
		else
			block.labelwidth:=labeldim
		fi
		block.celldimx+:=block.labelwidth
	fi

	block.blockstyle:=readstylestr(style)

!CPL "BLOCKSTYLE",STYLE,BLOCK.BLOCKSTYLE

!now work out overall size of the block, and the pitch between cells
!this needs to take account of the frame size of each cell, which depends on
!its border style
!block position is done at a higher level using smorder

	bdx:=bdy:=1				!use border widths of 0 for now (and assume same all round)

	block.pitchx:=block.celldimx+bdx*2+block.gapx		!hoz pitch
	block.pitchy:=block.celldimy+bdy*2+block.gapy		!vert

!CPL "PITCHY",BLOCK.PITCHY,=BDY,=BLOCK.GAPY
!CPL "MARGINY",BLOCK.MARGINY

	block.cellposx:=block.marginx+bdx					!position of client area of 1st cell
	block.cellposy:=block.marginy+bdy

	block.dimx:=block.pitchx*block.cellsx-block.gapx+block.marginx*2
	block.dimy:=block.pitchy*block.cellsy-block.gapy+block.marginy*2

	blocklist[++nblocks]:=block

	return block
end

export func smmenusize(margin=chy)=
!work out overall bounding box for all blocks, and relocate blocks (or set their
!pos values) so that each is positioned within to the bounding box rectangle
!return (dimx,dimy)

!get bounding box in (x1,y1), (x2,y2)
	for i,block in blocklist do
		if i=1 then				!first block
			x1:=block.posx
			y1:=block.posy
			x2:=x1+block.dimx-1
			y2:=y1+block.dimy-1
		else
			x1 min:=block.posx
			y1 min:=block.posy
			x2 max:=block.posx+block.dimx-1
			y2 max:=block.posy+block.dimy-1
		fi
	od

!now, need to relocate each block so they stay at the same position relative to
!each other, but are positioned within the client area of an owner window
!this effectively relocates (x1,y1) to (0,0), so the offset to be applied to
!each block is -(x1,y1), plus (margin,margin)

	for block in blocklist do
		block.posx+:=margin-x1
		block.posy+:=margin-y1
	od

!return (x1-margin,y1-margin,x2-y1+margin*2+1,y2-y1+margin*2+1)
	return (x2-x1+margin*2+1,y2-y1+margin*2+1)
end

export proc smorder(blocks,dir='D')=
!take a blocks, and arrange all in a line, relative to the first
!dir is one of "U", "D", "L", "R" (or can be char codes or in lower case)
!some block elements can be an integer specifing a gap between the blocks.
!the gap is specified in pixels. The default gap is chx for hoz and chy for vertical
!(***I THINK that the gap override is only between two blocks, so needs the reset to
!default after. That mean also that the first list item must be a block***)

	if dir.isstring then
		dir:=asc(convuc(dir))			!"r","R" or 'R' possible, but not 'r'
	fi

	bdx:=bdy:=1						!border widths for the blocks

	dx:=chx+bdx
	dy:=chy+bdy
	firstblock:=1

	for block in blocks do
		if block.isint then			!is a gap
			dx:=block+bdx*2
			dy:=block+bdy*2
			nextloop
		fi
		if firstblock then
			lastblock:=block
			firstblock:=0
			nextloop
		fi
		case dir
		when 'D' then			!add below
			block.posx:=lastblock.posx
			block.posy:=lastblock.posy+lastblock.dimy+dy
		when 'R' then
			block.posx:=lastblock.posx+lastblock.dimx+dx
			block.posy:=lastblock.posy
		when 'U' then			!add above
			block.posx:=lastblock.posx
			block.posy:=lastblock.posy-block.dimy-dy
		when 'L' then
			block.posx:=lastblock.posx-block.dimx-dx
			block.posy:=lastblock.posy
		esac
		lastblock:=block
	od
end

proc showtestmenu(dim)=
	wapplic:=gxcreatewindow(dim:dim,caption:"test")

	for block in blocklist do
		gxbutton(pos:(block.posx,block.posy),dim:(block.dimx,block.dimy),caption:block.name,
		owner:wapplic,style:[ss_border:bs_simplew])
	od

	eventloop()
end

export func smcreate(caption="",?dim,?pos)=
!create a pop-up menu window
!dim ix (x,y) client area size in pixels
!?pos is optional position, but can also existing button, then menu is placed nearby
!Normally used after after series of smdefblock etc calls to setup a menu layout
!Dim usually is a call to smmenusize which exactly contains the blocks
!return handle to window

	if dim.isvoid then dim:=smmenusize() fi

	w:=gxcreatewindow(caption:caption, dim:dim, options:[wf_minmax:0],pos:pos)
!	w:=gxcreatewindow(caption:caption, dim:dim)
	w.windclass:=popup_class
	currpopup:=w
	setforegroundwindow(w.gdi.hwnd)

	slposx:=chx
	slposy:=chy
	sldir:=(dim[1]>dim[2]|'H'|'V')

	wpopup:=w

	oldfocus:=wfocus
	if wfocus then
		gxkillfocus()
	fi

	popuplist[++npopups]:=w
	focuslist[npopups]:=oldfocus		!of underlying window

	return w
end

export func smblock(block,border=0)=
!set block as the current block for subsequent 
!unlike old versions of the library, an actual window is created for the block,
!and a handle to that is returned. That is a child group control.

	wblock:=gxpanel(pos:(block.posx,block.posy),dim:(block.dimx,block.dimy),
		owner:currpopup, style:[ss_border:border])
	currblock:=block
	currgroup:=wblock
	cellx:=celly:=1

	return wblock
end

!export func smpanel=
!!set block as the current block for subsequent 
!!unlike old versions of the library, an actual window is created for the block,
!!and a handle to that is returned. That is a child group control.
!
!	return gxpanel(pos:getsmpos(),dim:getsmdim(),
!		owner:currgroup, style:[ss_border:border])
!end
!
export proc smclose=
!NOTE: for nested menus, ie. invoking another popup menu while one is still
!on the screen, requires:
! * blocklist needs to be moved elsewhere, eg. to data field of current popup rwindow
! * Then smclose can close blocks in that list, not the export one
! * Global blocklist can be reused
! * It might require that the owner window is disabled from being clicked on, but
!   that will be awkward to do without disabling each control within it. Or perhaps
!   this is a check that can be done within process_wmmessage, to see if click-window
!   has an owner that has been disabled.
!    Disabling is one with smcreate, and re-enableing here in smclose

	gxclose(wpopup)
!	for block in blocklist do
!		block:=0
!!		freehandle(block)
!	od

	oldfocus:=focuslist[npopups]
	--npopups
	if npopups then
		wpopup:=popuplist[npopups]
		if oldfocus then
			gxfocus(oldfocus)
		fi
	else
		wpopup:=nil
	fi
end

export proc smoff=
	smclose()
end

proc nextcell=
!step cellx,y to next cell within current block
	if currblock.dir='V' then
		++celly
		if celly>currblock.cellsy then
			celly:=1
			++cellx
		fi
	else					!hoz
		++cellx
		if cellx>currblock.cellsx then
			cellx:=1
			++celly
		fi
	fi
end

func getsmpos=
	return ((cellx-1)*currblock.pitchx+currblock.cellposx,
        (celly-1)*currblock.pitchy+currblock.cellposy)
end

func getsmdim=
	return (currblock.celldimx,currblock.celldimy)
end

func getslpos=
	return (slposx,slposy)
end

func getsldim(s)=
	if s.isint then
		return (s*chx+chx*2,chy+smy*2)
	else
		return (gxtextwidth(labelfont,s)+smx*2,chy+smy*2)
	fi
end

proc nextslcell(dim)=
	if sldir='H' then
		slposx+:=dim[1]+chx
	else
		slposy+:=dim[2]+chy
	fi
end

export func smcmd(caption,id=0,enable=1)=
!create button within current block
!caption can also be an integer code:
! 0		skip this cell (just leave a blank space)
! -1	insert divider line
!when id is omitted or is zero, then creates a static label instead

	if caption.isint then
		case caption
		when 0 then
		when -1 then
		esac
		nextcell()
		return nil
	fi

	if id=0 then
		return smlabel(caption)
	fi

	ss:=[ss_border:bs_ownpanel]

	w:=gxbutton(pos:getsmpos(), dim:getsmdim(), caption:caption, id:id,
		owner:currgroup, style:ss, enable:enable)
	nextcell()
	return w
end

export func smhozscrollbar(id=0)=
	w:=gxhozscrollbar(owner:currgroup, pos:getsmpos(), dim:getsmdim(), id:id,
	style:[ss_border:bs_simplew])

	nextcell()
	return w
end

export func smvertscrollbar(id=0)=
	w:=gxvertscrollbar(owner:currgroup, pos:getsmpos(), dim:getsmdim(), id:id,
	style:[ss_border:bs_simplew])

	nextcell()
	return w
end

export func smlabel(caption)=
	pos:=getsmpos()
	dim:=(currblock.celldimx,currblock.celldimy)

	w:=gxlabel(pos:pos,dim:dim,caption:caption,owner:currgroup)
	nextcell()
	return w
end

export func smarrow(dir,id)=
	pos:=getsmpos()
	dim:=(currblock.celldimx,currblock.celldimy)

	w:=gxarrow(pos:pos,dim:dim,dir:dir,owner:currgroup)
	nextcell()
	return w
end

export func smtoggle(caption,linkvar,id=0,enable=1)=
!create toggle control within current block

	w:=gxtoggle(pos:getsmpos(), dim:getsmdim(), caption:caption,
				linkvar:linkvar,id:id,owner:currgroup, enable:enable,
				style:currblock.blockstyle)

	nextcell()
	return w
end

export func smselect(caption,linkvar,onvalue=1,id=0,enable=1)=
!create toggle control within current block

	w:=gxselect(pos:getsmpos(), dim:getsmdim(), caption:caption,
			linkvar:linkvar,onvalue:onvalue,
			id:id,owner:currgroup, enable:enable, style:currblock.blockstyle)

	nextcell()
	return w
end

export func smeditbox(?caption,linkvar,id=0,enable=1,?style)=
!create toggle control within current block
!CPL "SMED",CURRBLOCK
	pos:=getsmpos()
	dim:=getsmdim()

!CPL =DIM

	if caption.isdef then
		gxlabel(pos:pos, dim:(currblock.labelwidth-chx,dim[2]), caption:caption,
		 owner:currgroup)
		pos[1]+:=currblock.labelwidth
		dim[1]-:=currblock.labelwidth
	fi

	w:=gxeditbox(pos:pos, dim:dim,
		linkvar:linkvar,
		id:id,owner:currgroup, enable:enable, style:getstyle(style))
!	gxdrawmode(w,dm_screenmemory)

	nextcell()
	return w
end

export func smlistbox(linkvar,id=0,enable=1)=

!CPL =CURRBLOCK.CELLSY,"(ROWS)"
!CPL =CURRBLOCK.PITCHY,"(PITCH)"
!CPL =CURRBLOCK.CELLDIMY,"(CELLDIMY)"
!CPL =CURRBLOCK.CELLPOSY,"(OFFSET)"
!CPL =CURRBLOCK.GAPY,"(GAPY)"
!CPL =CURRBLOCK.DIMY,"(DIMY)"
!CPL "LBDIMY=",CURRBLOCK.DIMY-CURRBLOCK.MARGINY*2
!CPL =CURRBLOCK.MARGINY

!$SETDEBUG(1)
	w:=gxlistbox(pos:getsmpos(),
		dim:(currblock.dimx-currblock.marginx*2,currblock.dimy-currblock.marginy*2),
		linkvar:linkvar,
		style:[ss_vscroll:1,
		ss_border:bs_simplew],
		rows:currblock.cellsy,
		pitch:currblock.pitchy,
	!	offset:currblock.cellposy,
		id:id,owner:currgroup)
!CPL "SMLB2"
	return w
end

export func sllabel(caption)=
	pos:=getslpos()
	dim:=getsldim(caption)

	w:=gxlabel(pos:pos,dim:dim,caption:caption,owner:currpopup)
	nextslcell(dim)
	return w
end

export func slcmd(caption,id=201,enable=1)=
!create button within current block
!caption can also be an integer code:
! 0		skip this cell (just leave a blank space)
! -1	insert divider line
!when id is omitted or is zero, then creates a static label instead

	pos:=getslpos()
	dim:=getsldim(caption)
	ss:=[ss_border:bs_simplew]

	w:=gxbutton(pos:pos,dim:dim,caption:caption,id:id,owner:currpopup, 
		style:ss)
	nextslcell(dim)
	return w
end

export func sleditbox(linkvar,width=30,id=0,enable=1)=
	pos:=getslpos()
	dim:=getsldim(width)

	w:=gxeditbox(pos:pos, dim:dim,
		linkvar:linkvar,
		id:id,owner:currpopup)

	nextslcell(dim)
	return w
end

export func smok(caption="OK",enable=1)=
	return smcmd(caption,mm_ok,enable)
end

export func smcancel(caption="Cancel",enable=1)=
	return smcmd(caption,mm_cancel,enable)
end

export func slok(caption="OK")=
	return slcmd(caption,mm_ok)
end

export func slcancel(caption="Cancel")=
	return slcmd(caption,mm_cancel)
end

export proc smokcancel=
	smok()
	smcancel()
end

export proc slinit(w)=
	currpopup:=w
	slposx:=chx
	slposy:=0
	sldir:=(w.dimx>w.dimy|'H'|'V')
end

export proc settab(?a,?b,?c,?d,?e,?f,?g,?h,?i)=
	static var oldtabs

	if not a.isdef then
		gxtabstops(oldtabs)
		return
	fi

	oldtabs:=gxtabstops()
	params::=allparams()

!	gxtabstops(allparams())
	gxtabstops(param)
end

export proc smupdatevalue(w)=
	gxupdate(w)
end

export proc setfocus(w,?b)=
	gxfocus(w)
end

export proc askmenu(a)=
	message:=gxaskmess(1)
	messw:=currmess.wind
end

func readstylestr(s)=
!read cell style string s, and return option dict
	d:=new(dict)
	if s="" then return d fi

	s:=convuc(s)

	foreach c in s do
		case c
		when 'X' then d{ss_marktype}:=check_mark
		when 'M' then d{ss_marktype}:=radio_mark
		when 'I' then d{ss_marktype}:=invert_mark
		when 'R' then d{ss_returnmess}:=1
		when 'N' then d{ss_noupdate}:=1
		esac
	od
	return d
end

func getstyle(style)=
	if style.isdef then
		return readstylestr(style)
	else
		return currblock.blockstyle
	fi
end
