symbol currstproc
int allowmodname=0
int noexpand
int macrolevels

const maxmacroparams=50
[maxmacroparams]symbol macroparams
[maxmacroparams]symbol macroparamsgen
[maxmacroparams]unit macroargs
int nmacroparams
int nmacroargs

int ntopfields, nallfields
const maxstructfields=100
[maxstructfields]symbol structfields


global proc resolvemodules(isubprog sp)=
	return when passlevel<name_pass

!	fixusertypes()

!RETURN

	for i in sp.firstmodule+1 .. sp.lastmodule do
		rx_module(i)
	end
	rx_module(sp.firstmodule)

	if fshowast2 then
		showast("AST2")
	end
end

global proc rx_unit(symbol owner, unit p)=
	symbol d
	unit a, b
	int n, oldnoexpand, oldtag, useparams

	a:=p.a
	b:=p.b

	qpos:=p.posx
!CPL =MMPOS.LINENO

	switch p.tag
	when u_name then
		resolvename(owner, p)
		if P.TAG=U_NAME AND p.def.nameid=macroid and not noexpand then
			++macrolevels
			expandmacro(p, p, nil)
			rx_unit(owner, p)
			--macrolevels
		end

	when u_keyword then
		rx_unit(owner, b)		!do param value only

	when u_dot then
		resolvedot(owner, p)

	when u_call then
		oldtag:=p.tag

		if a.tag=u_name then			!can expand possible macro if params not ready
			oldnoexpand:=noexpand; noexpand:=1
			rx_unit(owner, a)
			noexpand:=oldnoexpand
		else
			rx_unit(owner, a)
		end

		rx_unitlist(owner, b)

		if a.tag=u_name then
			d:=a.def
			case d.nameid
			when typeid then		!change to type conversion
				p.tag:=u_convert
				storemode(owner, d.mode, p.mode2)
				p.a:=b
				if b.nextunit then
					p.a:=createunit(u_makelist, b)
					n:=0
					while b do
						++n
						b:=b.nextunit
					end
					p.a.length:=n
				end
			when macroid then
				++macrolevels
				if d.deflist then			!macro uses params
					expandmacro(p, a, b)
					b:=nil
					useparams:=0
				else						!macro has no params
					expandmacro(p, a, nil)
					useparams:=1
				end

				rx_unit(owner, p)
				--macrolevels

				if useparams and p.tag<>u_call then
					insertunit(p, oldtag)
					p.b:=b					!note b may be nil
				FI

			end case
		end

	when u_bin, u_makerange then
		rx_unit(owner, a)
		if not b then rxerror("Binop missing opnd") fi
		rx_unit(owner, b)
		evalbinop(p, a, b)

	when u_unary, u_property then
		rx_unit(owner, a)
		evalmonop(p)

	when u_andl, u_orl then
		rx_unit(owner, a)
		rx_unit(owner, b)
		if not isbooltag[a.tag] then insertunit(a, u_istruel) end
		if not isbooltag[b.tag] then insertunit(b, u_istruel) end

	when u_istruel then
	doistruel:
		rx_unit(owner, a)

		if isbooltag[a.tag] then
			deleteunit(p, a)
		end

	when u_notl then
		rx_unit(owner, a)
		case a.tag
		when u_notl then
			deleteunit(p, a)
			p.tag:=u_istruel
			a:=p.a
			goto doistruel

		when u_istruel then
			a.tag:=u_isfalsel
			deleteunit(p, a)
			a:=p.a
		when u_isfalsel then
			a.tag:=u_istruel
			deleteunit(p, a)
			a:=p.a
		elsif not isbooltag[a.tag] then
			p.tag:=u_isfalsel
			a:=p.a
		end case

	when u_dotindex then
		rx_unit(owner, a)
		rx_unit(owner, b)
		if b.tag=u_makerange then
			p.tag:=u_dotslice
		fi

	when u_strinclude then
		rx_unit(owner,a)
		if a.tag<>u_stringconst then
			rxerror("Not strconst")
		fi

		ifile pm
		pm:=loadsourcefile(a.svalue,0)

		a.svalue:=pm.text
		a.slength:=pm.size

		deleteunit(p,a)

	else
		if usubs[p.tag] then
			rx_unitlist(owner, p.a)
			if usubs[p.tag]=2 then
				rx_unitlist(owner, p.b)
			end
		end
	end switch
end

global func rx_module(int n)int=
	currmoduleno:=n
	rx_passdef(stprogram, modules[n].stmodule)
	return 1
end

global proc rx_deflist(symbol owner, p)=
	symbol pstart:=p
	while p do
		rx_passdef(owner, p)
		p:=p.nextdef
	end
end

global proc rx_passdef(symbol owner, p)=
	symbol d

	case p.nameid
	when moduleid, dllmoduleid then
		rx_deflist(p, p.deflist)

	when dprocid, dprocid then
		rx_deflist(p, p.deflist)
		currstproc:=p
		rx_unit(p, p.code)
		currstproc:=nil

	when dllprocid then
		rx_deflist(p, p.deflist)

	when constid, staticid, frameid, paramid then
		if p.equivvar then
			rx_unit(owner, p.equivvar)
		end
		if p.code then
			rx_unit(owner, p.code)
		end
	when typeid then
		rx_deflist(p, p.deflist)

	else
	end case
end

proc rx_unitlist(symbol owner, unit p)=
	while p do
		rx_unit(owner, p)
		p:=p.nextunit
	end
end

global func resolvetopname(symbol owner, stnewname, int moduleno, allowmod)symbol =
!stnewname points to a symrec with generic nullid
!This is a top-level name (left-most name of any dotted sequence, or standalone name)

!Search through all the duplicate symrecs (all names with identical names have symrecs that
!are linked together, always starting with a nullid symrec) looking for the best match

!moduleno is the module where the currently generic name is encountered
!(derived from a unit if in an expression, or an STREC if a type in a declaration)

	int extcount, subprogno
	symbol p, q, powner, extdef, moddef
	[10]symbol ambiglist

	if owner.nameid in [dprocid, sprocid] then
		q:=owner.deflist
		while q, q:=q.nextdef do
			if q.firstdupl=stnewname then		!immediate match
				return q
			end
		end
	end

	p:=stnewname.nextdupl
	subprogno:=moduletosub[moduleno]

	extcount:=0
	extdef:=moddef:=nil

	while p, p:=p.nextdupl do						!p is next candidate
		powner:=p.owner								!the owner of that entry

		case powner.nameid
		when moduleid then							!candidate is file-scope item
			if powner.moduleno=moduleno then		!same module
				return p
			elsif p.scope then	!matches an external module
				if powner.subprogno=subprogno or		!within same subprog
					 p.scope=program_scope or
					 p.isimport then 				!visible outside subprog
					++extcount			!if an ext match is closest, there can only be one
					extdef:=p
					if extcount<ambiglist.len then
						ambiglist[extcount]:=extdef
					end
				end
			end

		when typeid then					!only for code inside a record def
			if powner=owner or powner=owner.owner then		!immediate match
				return p					!looks at 2 nested record levels only
			end

		when programid then					!p is a module
			case p.nameid
			when moduleid, subprogid then	!match a module/subprog name
				if subprogno=moduletosub[p.moduleno] then
					moddef:=p
				else
					for i to nsubprogs do
						if eqstring(p.name, subprogs[i].name) then
!							p.issubprog:=1				!in case not yet set
							moddef:=p
							exit
						end
					end
				end
			when macroid then
				return p

			end case

		end case
	end

	if allowmod and moddef then
		return moddef
	end

	if extdef then
		if extcount>1 then
			if not eqstring(extdef.owner.name, "mclib") then
				for i:=1 to extcount do
					extdef:=ambiglist[i]
					println i, extdef.owner.name, namenames[extdef.owner.nameid]
				end
				if not eqstring(extdef.owner.name, "mclib") then
					rxerror_s("Ambiguous ext name: #", extdef.name)
				end
			end
		end
		return extdef
	end
	return nil
end

global proc resolvename(symbol owner, unit p)=
!p is a name tag inside given owner
!resolve name
!report error if unresolved, unless mode is not void. Then an unresolved
!name is added as a frame (assumes this is a proc)
	unit q

	symbol d, e
	int moduleno, mode, islet

	d:=p.def
	moduleno:=p.moduleno

	if d.nameid<>nullid then			!assume already resolved
		return
	end

	e:=resolvetopname(owner, d, moduleno, allowmodname)

	if not e then
		e:=addframevar(owner, d, moduleno, tvar)
	end

!	if e.used<255 then ++e.used end
	e.used:=1

	p.def:=e

	case e.nameid
	when constid then		!convert namedconst to const
!		return when symbolmode

		q:=e.code			!q is knamedconst unit; q.c is value
		rx_unit(owner, q)
		if q.tag not in [u_intconst, u_realconst, u_stringconst] then
			rxerror_s("Not const expr: #", utagnames[q.tag])
		fi

		e.mode:=q.mode
		p.tag:=q.tag
		p.value:=q.value
		p.mode:=q.mode
		p.slength:=q.slength

!	when enumid then
!!		return when symbolmode
!
!		p.tag:=u_intconst
!		p.value:=e.index
!		p.mode:=tint

	when typeid then
		p.tag:=u_typeconst
		p.mode:=p.def.mode

!	when linkid then
!		rxerror("FOUND LINK",p)
!	when frameid, paramid then
!		if currproc.nameid=anonprocid and e.owner.nameid<>anonprocid then
!			rxerror("Accessing transient vars from {}")
!		fi
	esac
end

global func finddupl(symbol d, pdupl)symbol=
!trying to resolve a field name, by scanning a dupllist headed by pdupl
!which ought to point to nullid entry
!d will be the owner of the matching entry

	if pdupl.nameid<>nullid then		!assume already resolved
		return pdupl
	end
	pdupl:=pdupl.nextdupl

	while pdupl do
		if pdupl.owner=d then
			return pdupl
		end
		pdupl:=pdupl.nextdupl
	end
	return nil
end

global func finddupl_sub(symbol d, pdupl)symbol=
!version of finddupl where d is a subprog
	int subprogno

	if pdupl.nameid<>nullid then		!assume already resolved
		return pdupl
	end
	pdupl:=pdupl.nextdupl
	subprogno:=d.subprogno

	while pdupl do
		if pdupl.owner.subprogno=subprogno then
			return pdupl
		end
		pdupl:=pdupl.nextdupl
	end
	return nil
end

proc resolvedot(symbol owner, unit p)=
	unit lhs, rhs
	symbol d, e, f, r
	int m, moduleno, subprogno, oldallowmod, nfields

	moduleno:=p.moduleno
	subprogno:=p.subprogno
	lhs:=p.a
	rhs:=p.b
	e:=rhs.def				!p.b will be a name type (could perhaps be stored as p.def)

	oldallowmod:=allowmodname
	allowmodname:=lhs.tag=u_name
	rx_unit(owner, lhs)
	allowmodname:=oldallowmod
	d:=lhs.def				!in case lhs is u_name

	qpos:=lhs.posx

	case lhs.tag
	when u_name then

		case d.nameid
		when moduleid, typeid, dprocid, typeid then

			if d.nameid=moduleid and d.subprogno<>subprogno then
				dosubprogid
			end

			e:=finddupl(d, e)

			if e then
				if d.nameid=moduleid then
					if e.subprogno<>subprogno then
						if e.scope<program_scope AND NOT E.ISIMPORT then
							rxerror_s("Need export to import '#'", e.name)
						end
					elsif e.moduleno<>moduleno then
						if not e.scope then
							rxerror_s("Need global to import '#'", e.name)
						end
					end
				end
domodule:
				p.tag:=u_name			!convert to dot to name
				p.a:=p.b:=nil
				p.def:=e
				case e.nameid
				when constid then
				end case
			else
				rxerror_s("Can't resolve .#", p.b.def.name, p)
			end

		when frameid, staticid, paramid then		!.x applied to normal var
!CPL "FRAME/STATIC/PARAM/DOT", D.NAME, E.NAME
			m:=d.mode
			case ttbasetype[m]
			when trecord, tstruct then
			when tref then
				do
					m:=tttarget[m]
					case ttbasetype[m]
					when trecord, tstruct then
						exit
					when tref then
					else
						rxerror("2:Record expected")
					end case
				end
			when tvar then
				if not dmode then rxerror("var.x?") end
!CPL =E, NAMENAMES[E.NAMEID]

				f:=e.nextdupl
				nfields:=0
!CPL =E
				while f, f:=f.nextdupl do
					r:=f.owner
!CPL =R, R.NAME
					if r and r.nameid=typeid and
							ttbasetype[r.mode] in [trecord, tstruct] then
						++nfields
					end
				od
!CPL =NFIELDS
				if nfields=0 then
					rxerror_s("No such field:", rhs.def.name)
				end
				return

			else
				CPL STRMODE(M), D.NAME
				rxerror("Record expected")
			end case
!			t:=ttnamedef[m]

			e:=finddupl(ttnamedef[m], e)
			if e then
				p.b.def:=e
			else
				rxerror_s("Not a field: #", rhs.def.name)
			end
		when subprogid then
dosubprogid:
			e:=finddupl_sub(d, e)
			if e then
				if e.subprogno<>subprogno then
					if e.scope<program_scope AND NOT E.ISIMPORT then
						rxerror_s("Need export to import '#'", e.name)
					end
				end
				goto domodule
			else
				rxerror_s("Can't resolve sub.#", p.b.def.name, p)
			end

		end case

	else
!Can't fully resolve at this time; leave to next pass
		unless e.nextdupl then
			rxerror_s("Not a field: #", e.name)
		end unless
	end case
end

proc fixmode(^typenamerec p)=
!p refers to a negative mode that is a typename index
!fix that up if possible
	^i32 pmode
	symbol a, d, e, f, owner
	int m, moduleno

	pmode:=p.pmode

	m:=-pmode^					!typename index

	d:=owner:=p.owner
	while d.nameid<>moduleid do
		d:=d.owner
	end
	moduleno:=d.moduleno

	d:=p.def

	if  d then			!simple type name V
		e:=resolvetopname(owner, d, moduleno, 0)
	end

	if e and e.nameid=typeid then
		pmode^:=e.mode

	else
		rxerror_s("2:Can't resolve tentative type: #", d.name)
	end
end

global proc fixusertypes=
	^typenamerec p
	int npasses, notresolved
	symbol d

CPL "FIXUSER"
	npasses:=0
	repeat
		++npasses
		notresolved:=0

		for i to ntypenames do
			p:=&typenames[i]

			if p.pmode^<0 then
				qpos:=p.posx
				fixmode(p)
				if p.pmode^<0 then
					++notresolved
				end
			end
		end

		if npasses>5 then
			println "Type phase errors - check these user types:"

			for i to ntypenames do
				p:=&typenames[i]

				if p.pmode^<0 then
					println "	", p.def.name
				end
			end

			rxerror("Fixtypes: too many passes (cyclic ref?)")
		end

	until notresolved=0
end

func addframevar(symbol owner, d, int moduleno, mode)symbol=
!owner should be a proc; d is a generic st entry
!add frame var with the name of d and given mode to the proc
	symbol e
	e:=getduplst(owner, d, frameid)
	storemode(owner, mode, e.mode)
	adddef(owner, e)
	return e
end

func copylistunit(unit p)unit=
	unit q

	unit plist, plistx
	plist:=plistx:=nil
	while p do
		q:=copyunit(p)
		addlistunit(plist, plistx, q)
		p:=p.nextunit
	end
	return plist
end

func copyunit(unit p)unit=
	unit q
	symbol d

	if p=nil then return nil end

!need to quickly check if a name unit is a macroparam

	if p.tag=u_name then
		d:=p.def
		for i to nmacroparams do
			if macroparamsgen[i]=d then
				return copyunit(macroargs[i])
				exit
			end
		end
	end

	q:=createunit(p.tag)

	q^:=p^
	q.nextunit:=nil
	for i to usubs[q.tag] do
		if usubs[q.tag] then
			q.a:=copylistunit(q.a)
			if usubs[q.tag]=2 then
				q.b:=copylistunit(q.b)
			end
		end
	end

	return q
end

proc replaceunit(unit p, q)=
!replace p with q, keeping same address of p, and same next pointer
!original contents discarded
	unit pnext
	pnext:=p.nextunit
	p^:=q^
	p.nextunit:=pnext
end

proc expandmacro(unit p, a, b)=
!a is a macro name unit, b is a macro parameter list (rx-processed), which
!can be nil
!p is either the call-unit as this may originally have been, or the same as a:
!M => (NAME)
!M(A, B) => (CALL NAME (A, B))
!Need to replace M or M(A, B) with the duplicated AST from a.code.
!When a name appears in the AST which is a local macroparam name, then that is
!replaced by the corresponding argument from B;
!The new code replaces P (either CALL or NAME)
!Supplied args may be more than macro takes (error) or may be less (error, 
!or allow default arg values to be specified)
	symbol d, pm
	unit pnew
	int ignoreargs

	if macrolevels>10 then
		rxerror("Too many macro levels (recursive macro?)")
	end

	d:=a.def

!First step: get list of macro formal parameters

	pm:=d.nextparam
	nmacroparams:=0
	while pm do
		if nmacroparams>=maxmacroparams then
			rxerror("macro param overflow")
		end
		macroparams[++nmacroparams]:=pm
		macroparamsgen[nmacroparams]:=pm.firstdupl

		pm:=pm.nextparam
	end

!now get macro args into a list
	nmacroargs:=0

	while b do
		if nmacroargs>=maxmacroparams then
			rxerror("macro arg overflow")
		end
		macroargs[++nmacroargs]:=b
		b:=b.nextunit
	end

	if nmacroargs<nmacroparams then
		PRINTLN =NMACROARGS, NMACROPARAMS
		rxerror("Too few macro args")
	end

	ignoreargs:=0
	if nmacroargs>0 and nmacroparams=0 then		!ignore extra params
		ignoreargs:=1
		nmacroargs:=nmacroparams:=0

	elsif nmacroargs>nmacroparams then
		rxerror("Too many macro args")
	end

	pnew:=copyunit(d.code)

	if not ignoreargs then				!normal expansion
		replaceunit(p, pnew)
	else								!keep call and paramlist; just replace fn name
		p.a:=pnew						!with expansion
	end
end

proc evalmonop(unit p)=
	int a,c
	real x,z

	case p.tag
!	when u_bytesize then
!		if p.a.tag=u_typeconst then
!			c:=ttsize[p.a.mode]
!			newint
!		fi

	elsecase p.a.tag
	when u_intconst then
		a:=p.a.value

		case p.unaryop
		when unary_neg then c:=-a
		when unary_abs then c:=abs(a)
		else
			return
		esac

newint:
		makeintconst(p,c)

	when u_realconst then
		x:=p.a.xvalue

		case p.unaryop
		when unary_neg then z:=-x
		when unary_abs then z:=abs(x)
		else
			return
		esac

		makerealconst(p,z)
	else
		return 
	esac
end

proc evalbinop(unit p,lhs,rhs)=
	int a,b,c
	real x,y,z

!CPL "EVALBIN", JTAGNAMES[P.TAG],pclnames[p.pclop]

	case pr(lhs.tag,rhs.tag)
	when pr(u_intconst, u_intconst) then
		a:=lhs.value
		b:=rhs.value

		case p.binop
		when bin_add then c:=a+b
		when bin_sub then c:=a-b
		when bin_mul then c:=a*b
		when bin_idiv then
			if b=0 then rxerror("x/0") fi
			c:=a/b
		when bin_power then c:=a**b
		else
			return
		esac

		makeintconst(p,c)

	when pr(u_realconst, u_realconst) then
		x:=lhs.xvalue
		y:=rhs.xvalue

		case p.binop
		when bin_add then z:=x+y
		when bin_sub then z:=x-y
		when bin_mul then z:=x*y
		when bin_div then z:=x/y
		else
			return
		esac

		makerealconst(p,z)
	else
		return 
	esac
end

proc makeintconst(ref unitrec p,i64 value)=
!convert unit p, currently binop or monop, to a const
	p.tag:=u_intconst
	p.a:=p.b:=nil
	p.value:=value
	p.mode:=tint
end

proc makerealconst(ref unitrec p,r64 xvalue)=
!convert unit p, currently binop or monop, to a const
	p.tag:=u_realconst
	p.a:=p.b:=nil
	p.xvalue:=xvalue
	p.mode:=treal
end

global proc dotypetables=
!CPL "TXTYPEABLE"
	for i:=tlast+1 to ntypes do
		converttype(i)
	od
end

function getconstint(symbol owner,unit a)int=
!process unit found in tt-tables, and convert to int
	if a=nil then
		return 0
	end



	rx_unit(owner, a)

	case a.tag
	when u_intconst then
		return a.value
	when u_realconst then
		return a.xvalue
	else
PRINTUNIT(A)

		rxerror_s("Getconstint: not int/real",utagnames[a.tag])
	esac
	return 0
end

global proc converttype(int m)=
!This 'conversion' is mainly about working out lengths and sizes and offsets
	symbol d, f, owner
!	int first, a, b, index, length, lower, elemtype, nbits
	int first, a, b, index, length, elemtype, nbits, offset
	const int maxfield=256
	[maxfield+1]symbol fieldlist
	int xxoldmodno, xxpos, xxownerid
	int maxalign, nfields, size
	unit plength, plower, pdim

	if ttsize[m] then return fi			!assume already done

	owner:=ttowner[m]
	qpos:=ttpos[m]

	case ttbasetype[m]
!	when tpackstrc, tpackstrz then
!		ttsize[m]:=ttlength[m]:=getconstint(owner, plength)
!
	when tarray then
		if m=tarray then CPL "CT:ARRAY/ARRAY" fi
		pdim:=ttdimexpr[m]


!CPL "DIM", =PDIM!, =PDIM.FILENO
!STOP
!
!CPL "ARRAY", MMPOS.LINENO
		case pdim.tag
		when u_makerange then
			plower:=pdim.a
			ttlower[m]:=getconstint(owner, pdim.a)
			ttlength[m]:=getconstint(owner, pdim.b)-ttlower[m]+1
		when u_dim then
			ttlower[m]:=getconstint(owner, pdim.a)
			ttlength[m]:=getconstint(owner, pdim.b)
		else					!intconst or simple expr
			ttlower[m]:=1
			ttlength[m]:=getconstint(owner, pdim)
		end
		ttdimexpr[m]:=nil

		elemtype:=tttarget[m]

		case elemtype
		when tu1, tu2, tu4 then
			nbits:=ttlength[m]*stdbits[elemtype]
			ttsize[m]:=(nbits-1)/8+1
		else
			converttype(tttarget[m])
			ttsize[m]:=ttlength[m]*ttsize[elemtype]
		esac

	when tstruct then
		d:=ttnamedef[m]
		f:=d.deflist

		nfields:=0
		while f, f:=f.nextdef do
			if nfields>=maxfield then rxerror("Too many fields") fi
			fieldlist[++nfields]:=f
		od

		fieldlist[nfields+1]:=nil
		ntopfields:=nallfields:=0
		maxalign:=1
		index:=1

		scanstruct(1, fieldlist, index, size, 0, d.caligned, maxalign, 2)

		if d.caligned then
			size:=roundtoblock(size, maxalign)
			d.maxalign:=maxalign
		else
			d.maxalign:=1
		fi

		ttsize[m]:=size
		ttlower[m]:=1
		ttlength[m]:=ntopfields

		d.topfieldlist:=pcm_alloc(symbol.bytes*ntopfields)
		memcpy(d.topfieldlist, &structfields, symbol.bytes*ntopfields)

	when trecord then
		d:=ttnamedef[m]
		offset:=0
		f:=d.deflist
		while f, f:=f.nextdef do
			if f.nameid=fieldid then
				if f.equivvar then
					pdim:=f.equivvar
					rx_unit(d, pdim)
					f.offset:=pdim.def.offset
				else
					f.offset:=offset
					offset+:=varsize
				end
			end
		end

	else
		if ttsize[m]=0 then
			ttsize[m]:=ttsize[ttbasetype[m]]
		end
		if ttsize[m]=0 then
			CPL "CONVTYPE:", STRMODE(M), strmode(ttbasetype[m])
		end
	esac
end

proc scanstruct(int smode, []symbol &fields, int &index, &isize, offset, 
	calign, &maxalign, countmode)=
!process a span of struct fields
!smode=1/0 for structmode/unionmode
!index is next field in fieldlist
!offset=current offset
!maxalign=current max alignment, which can be updated
!isize returns the size of this span
!countmode=2/1/0 to with counting top-level/nested/union fields
	symbol f
	int newoffset, fieldsize, alignment
	int nfields, structmode, ndepth, size

	size:=0

	while f:=fields[index++] do
		case f.nameid
		when structfieldid then
			converttype(f.mode)
			fieldsize:=ttsize[f.mode]

			if calign then
				alignment:=getalignment(f.mode)
				maxalign max:=alignment
				newoffset:=roundtoblock(offset, alignment)
				size+:=newoffset-offset
			else
				newoffset:=offset
			fi
			f.fieldoffset:=newoffset
			F.INDEX:=INDEX-1
			offset:=newoffset
countfields:
			++nallfields
			if countmode then
				structfields[++ntopfields]:=f

			fi
		when structblockid then
			scanstruct(1, fields, index, fieldsize, offset, calign, maxalign, countmode)

		when unionblockid then
			scanstruct(0, fields, index, fieldsize, offset, calign, maxalign, (countmode|1|0))

		when endblockid then
			isize:=size
			return
		esac

		if smode then
			offset+:=fieldsize
			size+:=fieldsize
		else
			size:=max(size, fieldsize)
			countmode:=0
		fi

	od

	isize:=size				!end of fields; tread as endblock
end

global function getalignment(int m)int=
!return alignment needed for type m, as 1, 2, 4, 8
	int a

	case ttbasetype[m]
	when tarray then
		return getalignment(tttarget[m])
!	when tpstruct then
	when tstruct then
!		return ttnamedef[m].structmaxalign
	esac

	a:=ttsize[m]
	case a
	when 1, 2, 4, 8 then
		return a
	esac
	cpl ttname[m], a
	rxerror("Getalign not 1248")

	return 0
end




