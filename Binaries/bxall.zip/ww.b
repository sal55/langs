type fred=i32
type BILL=i32
type eric=i32



!export type wt_word		= u16
!proc fred(b:wt_word)=
!end
