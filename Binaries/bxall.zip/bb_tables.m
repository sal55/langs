!hello tables


!Lexical tokens (these are called 'symbols')

global enumdata [0:]ichar tokennames =
	(tk_error = 0,		$+3),
	(tk_dot,			$+3),
	(tk_comma,			$+3),
	(tk_semi,			$+3),
	(tk_colon,			$+3),
	(tk_sendto,			$+3),
	(tk_pipe,			$+3),
	(tk_lbrack,			$+3),
	(tk_rbrack,			$+3),
	(tk_lsq,			$+3),
	(tk_rsq,			$+3),
	(tk_lcurly,			$+3),
	(tk_rcurly,			$+3),
	(tk_ptr,			$+3),
	(tk_bar,			$+3),
	(tk_at,				$+3),
	(tk_question,		$+3),
	(tk_addr,			$+3),
	(tk_ellipsis,		$+3),
	(tk_curl,			$+3),
	(tk_eol,			$+3),
	(tk_eof,			$+3),
	(tk_binop,			$+3),
	(tk_unary,			$+3),
	(tk_prop,			$+3),
	(tk_maths,			$+3),
	(tk_bitfield,		$+3),
	(tk_incr,			$+3),
	(tk_intconst,		$+3),
	(tk_realconst,		$+3),
	(tk_charconst,		$+3),
	(tk_stringconst,	$+3),
	(tk_decimalconst,	$+3),
	(tk_name,			$+3),
	(tk_rawname,		$+3),
	(tk_unitname,		$+3),
	(tk_include,		$+3),
	(tk_strinclude,		$+3),
	(tk_stdtype,		$+3),
	(tk_if,				$+3),
	(tk_then,			$+3),
	(tk_elsif,			$+3),
	(tk_else,			$+3),
	(tk_elsecase,		$+3),
	(tk_elseswitch,		$+3),
	(tk_end,			$+3),
	(tk_unless,			$+3),
	(tk_case,			$+3),
	(tk_docase,			$+3),
	(tk_recase,			$+3),
	(tk_when,			$+3),
	(tk_for,			$+3),
	(tk_to,				$+3),
	(tk_by,				$+3),
	(tk_do,				$+3),
	(tk_while,			$+3),
	(tk_repeat,			$+3),
	(tk_until,			$+3),
	(tk_return,			$+3),
	(tk_stop,			$+3),
	(tk_loop,			$+3),
	(tk_goto,			$+3),
	(tk_switch,			$+3),
	(tk_doswitch,		$+3),
	(tk_print,			$+3),
	(tk_read,			$+3),
	(tk_func,			$+3),
	(tk_asmfunc,		$+3),
	(tk_label,			$+3),
	(tk_record,			$+3),
	(tk_union,			$+3),
	(tk_importmodule,	$+3),
	(tk_project,		$+3),
	(tk_header,			$+3),
	(tk_type,			$+3),
	(tk_ref,			$+3),
	(tk_void,			$+3),
	(tk_var,			$+3),
	(tk_stringz,		$+3),
	(tk_let,			$+3),
!	(tk_slice,			$+3),
	(tk_macro,			$+3),
	(tk_const,			$+3),
	(tk_clear,			$+3),
	(tk_global,			$+3),
	(tk_static,			$+3),
	(tk_cast,			$+3),
	(tk_compilervar,	$+3),
	(tk_dollar,			$+3),
	(tk_tabledata,		$+3),
	(tk_swap,			$+3),
	(tk_syscall,		$+3),
	(tk_hostfn,			$+3),
	(tk_istype,			$+3),
	(tk_caligned,		$+3),
	(tk_try,			$+3),
	(tk_except,			$+3),
	(tk_raise,			$+3),
	(tk_eval,			$+3),
	(tk_sysconst,		$+3),
	(tk_map,			$+3),
	(tk_nil,			$+3),
	(tk_assem,			$+3),
	(tk_reg,			$+3),
	(tk_xreg,			$+3),
	(tk_freg,			$+3),
	(tk_mref,			$+3),
	(tk_jmpcc,			$+3),
	(tk_setcc,			$+3),
	(tk_movcc,			$+3),
	(tk_segname,		$+3),
end

!J-Tag codes. These are AST tags

!jisexpr=1/2 when unit returns a value; 1 means unary, 2 binary op,
! 3 means returns a value, but is not a unary or binary op
!jsolo = 1 means unit is allowed standalone without its value being used

!Key
!   A B C		Indicate single subnodes
!   A*			Etc, means a subnode can be a list

!   A+			Etc, means a list with one or two extra elements, so A2, A3

global enumdata [0:]ichar utagnames,
				   [0:]byte usubs, [0:]byte uisexpr, [0:]byte usolo =
!                           N Expr Solo
	(u_null=0,		$+2,	0,	3,	0), ! Place holder unit: means 'param no present' when used where a param is expected
	(u_intconst,	$+2,	0,	3,	0), ! int consant in .value
	(u_realconst,	$+2,	0,	3,	0), ! real consant in .xvalue
	(u_stringconst,	$+2,	0,	3,	0), ! string consant in .svalue/.slength
	(u_nil,			$+2,	0,	3,	0), ! nil pointer value
	(u_name,		$+2,	0,	3,	0), ! .def = ST entry
	(u_block,		$+2,	1,	0,	1), ! A*
	(u_strinclude,	$+2,	1,	3,	0), ! A; should be const string

!Logical Operators

	(u_andl,		$+2,	2,	2,	0), ! A and B; A/B must be bools otherwise ISTRUE applied
	(u_orl,			$+2,	2,	2,	0), ! A or B

	(u_notl,		$+2,	1,	1,	0), ! not A; A must be a bool (compiler generates jisfalsel if not)
	(u_istruel,		$+2,	1,	1,	0), ! istrue A  zero/not-zero => 0/1
	(u_isfalsel,	$+2,	1,	1,	0), ! isfalse A zero/not-zero => 1/0

!Expressions and Operators

	(u_makelist,	$+2,	1,	3,	0), ! (B: A*); B is lower bound; .length=# elements
	(u_makerange,	$+2,	2,	3,	0), ! A..B
	(u_makeset,		$+2,	1,	3,	0), ! [A*]; .length=# elements
!	(u_makeslice,	$+2,	2,	3,	0), ! slice(A, B) A=ptr, B=length
	(u_returnmult,	$+2,	1,	0,	0), ! A*; uses .length; (set in TX from return/makelist

	(u_keyword,		$+2,	2,	3,	0), ! def=st entry
	(u_dim,			$+2,	2,	3,	0), ! [A:] or [A:B] (set array dims by length)
	(u_assign,		$+2,	2,	3,	1), ! A := B
	(u_call,		$+2,	2,	3,	1), ! A(B*)

	(u_cmp,			$+2,	2,	2,	0), ! A cc B
	(u_cmpchain,	$+2,	1,	1,	0), ! A* uses .cmpgenop/.cmpmode
	(u_bin,			$+2,	2,	2,	0), ! A op B
	(u_unary,		$+2,	2,	1,	0), ! op A
	(u_prop,		$+2,	2,	1,	0), ! prop A
	(u_binto,		$+2,	2,	2,	0), ! A op:= b
	(u_unaryto,		$+2,	1,	1,	0), ! op:= A
	(u_incr,		$+2,	1,	3,	0), ! op A, A op

	(u_inrange,		$+2,	2,	2,	0), ! A in B (B is range)
	(u_inset,		$+2,	2,	2,	0), ! A in B (B is set)
	(u_inx,			$+2,	2,	2,	0), ! A in B (return index, or i64.min)

	(u_index,		$+2,	2,	3,	0), ! A[B]
	(u_slice,		$+2,	2,	3,	0), ! A[B..C]

	(u_dot,			$+2,	2,	3,	0), ! A.B (B usu name); uses .offset in later stages
	(u_dotindex,	$+2,	2,	3,	0), ! A.[B]
	(u_dotslice,	$+2,	2,	3,	0), ! A.[B] (B must be jmakerange)

	(u_ptr,			$+2,	1,	3,	0), ! A^
	(u_addrof,		$+2,	2,	3,	0), ! &A

!NOTE conversion handling in the frontend needs to be reviewed, especially
!type punning

	(u_convert,		$+2,	1,	3,	0), ! Used internally; becomes specific node in tx pass

	(u_shorten,		$+2,	1,	3,	0), ! A; convert type of A to type of this node;
										! seems to be used in init data only; must be compile-time
	(u_autocast,	$+2,	1,	3,	0), ! A (changed to jconvert by tx pass)
	(u_typepun,		$+2,	1,	3,	0), ! THIS NEEDS REVISING
	(u_widen,		$+2,	1,	3,	0), !
	(u_fwiden,		$+2,	1,	3,	0), !
	(u_fnarrow,		$+2,	1,	3,	0), !
	(u_fix,			$+2,	1,	3,	0), !
	(u_float,		$+2,	1,	3,	0), !
	(u_truncate,	$+2,	1,	3,	0), !
	(u_toboolt,		$+2,	1,	3,	0), !

	(u_typeconst,	$+2,	0,	3,	0), ! .value is the type code. The node itself has type i64
	(u_operator,	$+2,	0,	3,	0), ! Uses .pclop

	(u_bitwidth,	$+2,	1,	1,	0), ! A.bitwidth
	(u_bytesize,	$+2,	1,	1,	0), ! A.bytes
	(u_typestr,		$+2,	0,	1,	0), ! A.typestr
	(u_bitfield,	$+2,	1,	3,	0), ! A.odd etc (uses .bfcode)

	(u_minvalue,	$+2,	1,	3,	0), ! A.min
	(u_maxvalue,	$+2,	1,	3,	0), ! A.max

	(u_compilervar,	$+2,	0,	3,	0), ! Uses .cvindex to denote compiler var)
	(u_fmtitem,		$+2,	2,	3,	0), ! A:B within print items
	(u_nogap,		$+2,	0,	3,	0), ! 
	(u_space,		$+2,	0,	3,	0), ! 

!Statements

	(u_return,		$+2,	1,	0,	0), ! return [A]
	(u_syscall,		$+2,	1,	3,	1), ! FN(A*); .fnindex = sysfn no.

	(u_to,			$+2,	2,	0,	0), ! to A+ do B end (A2 has optional av temp)
	(u_if,			$+2,	2,	3,	1), ! if A+ then B [else A2] end


	(u_forup,		$+2,	2,	0,	0), ! repeat B1/2 while (A1+:=A3; A1<=A2); then B3
	(u_fordown,		$+2,	2,	0,	0), ! repeat B1/2 while (A1-:=A3; A1>=A2); then B3

!	(u_forup,		$+2,	2,	0,	0), ! for i in from..to [by step] [when u do s [else s] end
!										!  A1 = i
!										!  A2 = from
!										!  A3 = to
!										!  A4 = [step]
!										!  B1 = body (includes when cond)
!										!  B2 = [else]
!	(u_fordown,		$+2,	2,	0,	0), ! Same but using inrev

!	(u_forall,		$+2,	2,	0,	0), ! for [i,]x in L [when u] do s [else s] end
!										! A1 = i
!										! A2 = x
!										! A3 = from
!										! A4 = to
!										! B1 = x:=L[i]	per-iteration assignment
!										! B2 = body (includes when)
!										! B3 = [else]
!	(u_forallrev,	$+2,	2,	0,	0), ! Same but with inrev

	(u_while,		$+2,	2,	0,	1), ! while A+ [,A2] do B end
	(u_repeat,		$+2,	2,	0,	1), ! repeat A until B
	(u_goto,		$+2,	1,	0,	1), ! goto A
	(u_labeldef,	$+2,	0,	0,	0), ! A:
	(u_exit,		$+2,	0,	0,	1), ! exit     .loopindex
	(u_redo,		$+2,	0,	0,	1), ! redoloop .loopindex
	(u_next,		$+2,	0,	0,	1), ! nextloop .loopindex
	(u_do,			$+2,	1,	0,	1), ! do A end

	(u_case,		$+2,	2,	3,	1), ! case A+ <B* = whenthen chain> [else A2] end
	(u_docase,		$+2,	2,	0,	1), ! Same as case
	(u_switch,		$+2,	2,	3,	1), ! Same as case
	(u_doswitch,	$+2,	2,	0,	1), ! Same as case
	(u_doswitchu,	$+2,	2,	0,	1), ! Same as case
	(u_doswitchx,	$+2,	2,	0,	1), ! Same as case
	(u_swap,		$+2,	2,	0,	1), ! swap(A, B)
	(u_select,		$+2,	2,	3,	1), ! (A+ | B* | A2)
	(u_recase,		$+2,	1,	0,	0), ! recase A; must be const
	(u_whenthen,	$+2,	2,	0,	0), ! when A* then B (part of internal case/switch)

	(u_print,		$+2,	2,	0,	1), ! print   [@A,] B*
	(u_println,		$+2,	2,	0,	1), ! println [@A,] B*
	(u_fprint,		$+2,	2,	0,	1), ! print   [@A+,] A2, B*   B is fmtstr
	(u_fprintln,	$+2,	2,	0,	1), ! println [@A+,] A2, B*   B is fmtstr
	(u_sprint,		$+2,	2,	0,	1), !
	(u_sprintln,	$+2,	2,	0,	1), !
	(u_read,		$+2,	2,	0,	1), ! read A*
	(u_readln,		$+2,	2,	0,	1), ! readln [@A] (items are in separate jread node)
	(u_stop,		$+2,	1,	0,	0), ! stop [A]
	(u_eval,		$+2,	1,	3,	1), ! eval A
	(u_clear,		$+2,	1,	1,	1), ! clear A

!above were from MM8; below are from QQ, to be integrated

	(u_try,			$+2,	2,	0,	1), ! try A {except B}*
	(u_except,		$+2,	2,	0,	1), ! except A then B*
	(u_raise,		$+2,	1,	0,	1), ! raise A
	(u_callhost,	$+2,	1,	1,	1), ! callhost A
	(u_map,			$+2,	2,	0,	1), ! map(A, B+ [,B2])
	(u_void,		$+2,	0,	0,	1), ! void
	(u_maths,		$+2,	1,	1,	1), ! maths(A)
	(u_maths2,		$+2,	2,	2,	1), ! maths(A, B) 
	(u_property,	$+2,	1,	1,	1), ! prop(A)
	(u_keyindex,	$+2,	2,	2,	0), ! A{B+,[B2]}
	(u_symbol,		$+2,	1,	1,	0), ! A
	(u_makedict,	$+2,	1,	3,	0), ! A*
end

!Binary op data. These all come under 'binopsym' token

global enumdata []ichar binnames, []ichar binstr, []byte binprio,
				[]byte binassign, []byte binrtl,
				[]byte bintag, []byte binsubcode =

!                   name        str      prio  ass rtl  jtag        subcode
	(bin_assign,	"assign",	":=",		8,	0,	1,	u_bin,		0),
	(bin_copy,		"copy", 	"::=",		8,	0,	1,	u_bin,		0),
	(bin_add,		"add",		"+",		3,	1,	0,	u_bin,		kadd),
	(bin_sub,		"sub",		"-",		3,	1,	0,	u_bin,		ksub),
	(bin_mul,		"mul",		"*",		2,	1,	0,	u_bin,		kmul),
	(bin_div,		"div",		"/",		2,	1,	0,	u_bin,		kdiv),
	(bin_idiv,		"idiv",		"%",		2,	1,	0,	u_bin,		kidiv),
	(bin_irem,	 	"irem",		"rem",		2,	1,	0,	u_bin,		kirem),
	(bin_idivrem,	"idivrem",	"divrem",	2,	0,	0,	u_bin,		kidivrem),
	(bin_power,		"power",	"**",		1,	1,	1,	u_bin,		kpower),
	(bin_iand,		"iand",		"iand",		3,	1,	0,	u_bin,		kbitand),
	(bin_ior,		"ior",		"ior",		3,	1,	0,	u_bin,		kbitor),
	(bin_ixor,		"ixor",		"ixor",		3,	1,	0,	u_bin,		kbitxor),
	(bin_shl,		"shl",		"<<",		2,	1,	0,	u_bin,		kshl),
	(bin_shr,		"shr",		">>",		2,	1,	0,	u_bin,		kshr),
	(bin_min,		"min",		"min",		3,	1,	0,	u_bin,		kmin),
	(bin_max,		"max",		"max",		3,	1,	0,	u_bin,		kmax),
	(bin_andl,		"andl",		"and",		6,	1,	0,	u_andl,		0),
	(bin_orl,		"orl",		"or",		7,	1,	0,	u_orl,		0),
	(bin_eq,		"eq",		"=",		5,	0,	0,	u_cmp,		eq_cc),
	(bin_ne,		"ne",		"<>",		5,	0,	0,	u_cmp,		ne_cc),
	(bin_lt,		"lt",		"<",		5,	0,	0,	u_cmp,		lt_cc),
	(bin_le,		"le",		"<=",		5,	0,	0,	u_cmp,		le_cc),
	(bin_ge,		"ge",		">=",		5,	0,	0,	u_cmp,		ge_cc),
	(bin_gt,		"gt",		">",		5,	0,	0,	u_cmp,		gt_cc),
	(bin_in,		"in",		"in",		5,	0,	0,	u_inrange,	0),
	(bin_notin,		"notin",	"notin",	5,	0,	0,	u_inrange,	1),
	(bin_inrev,		"inrev",	"inrev",	5,	0,	0,	u_inrange,	2),
	(bin_inx,		"inx",		"inx",		5,	0,	0,	u_inx,		0),
	(bin_range,		"range",	"..",		4,	0,	0,	u_makerange,0),
	(bin_append,	"append",	"&",		3,	1,	0,	u_bin,		kappend),
	(bin_concat,	"concat",	"&&",		3,	1,	0,	u_bin,		kconcat),
	(bin_same,		"same",		"==",		5,	0,	0,	u_bin,		ksame),
end

global const maxprio = 9		! needs to be highest+1

!Unary ops
global enumdata []ichar unarynames, []ichar unarystr,
				[]byte unarytag,  []byte unarysubcode =

	(unary_neg,		"neg",		"-",		u_unary,		kneg),
	(unary_abs,		"abs",		"abs",		u_unary,		kabs),
	(unary_inot,	"inot",		"inot",		u_unary,		kbitnot),
	(unary_notl,	"notl",		"not",		u_notl,			0),
	(unary_istruel,	"istruel",	"istrue",	u_istruel,		0),
	(unary_chr,		"chr",		"chr",		u_unary,		kchr),
	(unary_asc,		"asc",		"asc",		u_unary,		kasc),
!	(unary_sign,	"sign",		"sign",		u_unary,		ksign),
end

!Property ops

global enumdata []ichar propnames,	[]byte propsubcode =

	(prop_len,			"len",			klen),
	(prop_lwb,			"lwb",			klen),
	(prop_upb,			"upb",			klen),
	(prop_bounds,		"bounds",		klen),
	(prop_bytes,		"bytes",		klen),
	(prop_isfound,		"isfound",		klen),
	(prop_dictitems,	"dictitems",	klen),
	(prop_type,			"$type",		klen),
	(prop_basetype,		"basetype",		klen),
	(prop_elemtype,		"elemtype",		klen),
	(prop_minval,		"minval",		klen),
	(prop_maxval,		"maxval",		klen),

!Following come under 'istype'

	(prop_isvoid,		"isvoid",		klen),
	(prop_isdef,		"isdef",		klen),
	(prop_isint,		"isint",		klen),
	(prop_isreal,		"isreal",		klen),
	(prop_islist,		"islist",		klen),
	(prop_isstring,		"isstring",		klen),
	(prop_ispointer,	"ispointer",	klen),
	(prop_isarray,		"isarray",		klen),
	(prop_isrecord,		"isrecord",		klen),
	(prop_isset,		"isset",		klen),
	(prop_isrange,		"isrange",		klen),

end

!Maths ops

global enumdata []ichar mathsnames, []byte mathsargs =

	(mm_sqrt, 	"sqrt",		1),			!(not mcode)
	(mm_sqr, 	"sqr",		1),			!(not mcode)
	(mm_sin, 	"sin",		1),
	(mm_cos, 	"cos",		1),
	(mm_tan, 	"tan",		1),
	(mm_asin, 	"asin",		1),
	(mm_acos, 	"acos",		1),
	(mm_atan, 	"atan",		1),
	(mm_log, 	"log",		1),
	(mm_log10, 	"log10",	1),
	(mm_exp, 	"exp",		1),
	(mm_round, 	"round",	1),
	(mm_floor, 	"floor",	1),
	(mm_ceil, 	"ceil",		1),
	(mm_atan2, 	"atan2",	2),
	(mm_fmod, 	"fmod",		2),
	(mm_fract, 	"fract",	1),
end

global enumdata [0:]ichar ccnames, [0:]ichar ccshortnames, [0:]byte ccrev =
	(no_cc=0,	"xx",	"?",		0),
	(eq_cc,		"eq",	" = ",		ne_cc),
	(ne_cc,		"ne",	" <> ",		eq_cc),
	(lt_cc,		"lt",	" < ",		ge_cc),
	(le_cc,		"le",	" <= ",		gt_cc),
	(ge_cc,		"ge",	" >= ",		lt_cc),
	(gt_cc,		"gt",	" > ",		le_cc),
end

!flags used with print/fprint/fprint
global const pr_newline = 1
global const pr_format = 2
global const pr_sprint = 4

global enumdata []ichar cvnames =
	(cv_lineno,		"$lineno"),
	(cv_strlineno,	"$strlineno"),
	(cv_filename,	"$filename"),
	(cv_modulename,	"$modulename"),
	(cv_func,		"$func"),
	(cv_date,		"$date"),
	(cv_time,		"$time"),
	(cv_version,	"$version"),
	(cv_nil,		"nil"),
	(cv_pi,			"$pi"),
	(cv_infinity,	"infinity"),
	(cv_true,		"true"),
	(cv_false,		"false"),
end

global enumdata [0:]ichar scopenames=
	(Module_scope=0,	"Module"), 		!local to this module
	(global_scope,		"Global"),		!share with modules in SP
	(program_scope,		"Program"),		!(export/non-top SP) shared with other SPs
	(export_scope,		"Export"), 		!(export/top SP) exported from program/DLL
end

global enumdata =
	million_unit,
	billion_unit,
end

global tabledata []ichar stnames, []byte stsymbols, []byte stsubcodes=

	("if",			tk_if,				0),
	("then",		tk_then,			0),
	("elsif",		tk_elsif,			u_if),
	("else",		tk_else,			0),
	("elsecase",	tk_elsecase,		u_case),
	("elseswitch",	tk_elseswitch,		u_switch),
	("case",		tk_case,			u_case),
	("docase",		tk_case,			u_docase),
	("recase",		tk_recase,			u_recase),
	("when",		tk_when,			0),
	("for",			tk_for,				0),
	("foreach",		tk_for,				1),
	("to",			tk_to,				0),
	("downto",		tk_to,				1),
	("by",			tk_by,				0),
	("do",			tk_do,				0),
	("end",			tk_end,				0),
	("while",		tk_while,			0),
	("repeat",		tk_repeat,			0),
	("until",		tk_until,			0),
	("always",		tk_until,			0),
	("return",		tk_return,			0),
	("stop",		tk_stop,			0),

	("redoloop",	tk_loop,			u_redo),
	("nextloop",	tk_loop,			u_next),
	("exit",		tk_loop,			u_exit),

	("goto",		tk_goto,			0),
	("switch",		tk_switch,			u_switch),
	("doswitch",	tk_doswitch,		u_doswitch),
	("doswitchu",	tk_doswitch,		u_doswitchu),
	("doswitchx",	tk_doswitch,		u_doswitchx),
	("tabledata",	tk_tabledata,		0),
	("enumdata",	tk_tabledata,		1),
	("maps",		tk_map,				0),
	("mapss",		tk_map,				0),
	("eval",		tk_eval,			0),
	("unless",		tk_unless,			0),
	("try",			tk_try,				0),
	("except",		tk_except,			0),
	("raise",		tk_raise,			0),

	("print",		tk_print,			0),
	("println",		tk_print,			pr_newline),
	("fprint",		tk_print,			pr_format),
	("fprintln",	tk_print,			pr_format + pr_newline),
	("sprint",		tk_print,			pr_sprint),
	("sfprint",		tk_print,			pr_sprint + pr_format),

	("cp",			tk_print,			0),
	("cpl",			tk_print,			pr_newline),

	("read",		tk_read,			0),
	("readln",		tk_read,			pr_newline),

	("cast",		tk_cast,			13),

	("proc",		tk_func,			0),
	("func",		tk_func,			2),
	("fun",			tk_func,			1),
	("function",	tk_func,			2),
	("sproc",		tk_func,			100),
	("sfunc",		tk_func,			102),

	("type",		tk_type,			0),
	("record",		tk_record,			0),
	("struct",		tk_union,			structblockid),
	("union",		tk_union,			unionblockid),
	("ref",			tk_ref,				0),
	("var",			tk_var,				0),
	("stringz",		tk_stringz,			0),

	("macro",		tk_macro,			0),

	("static",		tk_static,			0),
	("$caligned",	tk_caligned,		0),
	
	("const",		tk_const,			0),

	("project",		tk_project,			0),
	("module",		tk_header,			hdr_module),
	("import",		tk_header,			hdr_import),
	("linkdll",		tk_header,			hdr_linkdll),
	("$sourcepath",	tk_header,			hdr_sourcepath),

	("importdll",	tk_importmodule,	'D'),

	("include",		tk_include,			0),
	("binclude",	tk_strinclude,		'B'),
	("sinclude",	tk_strinclude,		'S'),
	("strinclude",	tk_strinclude,		'S'),

	("global",		tk_global,			global_scope),
	("export",		tk_global,			export_scope),

	("swap",		tk_swap,			0),

	("int",			tk_stdtype,			tint),
	("real",		tk_stdtype,			treal),
	("word",		tk_stdtype,			tword),

!	("msymbol",		tk_stdtype,			tmsymbol),
!	("marray",		tk_stdtype,			tmarray),
	("bit",			tk_stdtype,			tu1),
	("byte",		tk_stdtype,			tu8),
	("char",		tk_stdtype,			tu8),
	("label",		tk_stdtype,			tlabel),

	("million",		tk_unitname,		million_unit),
	("billion",		tk_unitname,		billion_unit),
	("as",			tk_unitname,		0),

	("$",			tk_dollar,			0),
	("append",		tk_binop,			bin_append),
	("concat",		tk_binop,			bin_concat),
	
	("not",			tk_unary,			unary_notl),
	("istrue",		tk_unary,			unary_istruel),
	("inot",		tk_unary,			unary_inot),
	("abs",			tk_unary,			unary_abs),
	("asc",			tk_unary,			unary_asc),
	("chr",			tk_unary,			unary_chr),

	("fi",			tk_end,				tk_if),
	("esac",		tk_end,				tk_case),
	("od",			tk_end,				tk_do),
	("clear",		tk_clear,			0),

	("$getnprocs",	tk_syscall,			sf_getnprocs),
	("$getprocname",tk_syscall,			sf_getprocname),
	("$getprocaddr",tk_syscall,			sf_getprocaddr),
end

global enumdata []ichar headerdirnames =
	(hdr_module,		$),
	(hdr_import,		$),
	(hdr_sourcepath,	$),
	(hdr_linkdll,		$),
end

global enumdata [0:]ichar namenames=
	(nullid=0,		"null"),		!Not assigned
	(programid,		"program"),		!Main root
	(subprogid,		"subprog"),
	(moduleid,		"module"),		!Current or imported module
	(dllmoduleid,	"dllmodule"),	!
	(typeid,		"type"),		!Type name in type, proc or module
	(dprocid,		"dproc"),		!Proc/method/func/op name
	(sprocid,		"sproc"),		!Proc/method/func/op name
	(anonprocid,	"anonproc"),	!
	(dllprocid,		"dllproc"),		!Dll Proc/func name
	(dllvarid,		"dllvar"),		!Dll variable name
	(constid,		"const"),		!Named constant in type, proc or module
	(staticid,		"static"),		!Static in type or proc or module
	(frameid,		"frame"),		!Local var
	(paramid,		"param"),		!Local param
	(fieldid,		"field"),		!Field of Record
	(structfieldid,	"strfield"),	!Field of Struct
	(labelid,		"label"),		!Label name in proc only
	(macroid,		"macro"),		!Name of macro
	(macroparamid,	"macroparam"),	!Macro formal parameter name
	(structblockid,	"structblock"),
	(unionblockid,	"unionblock"),
	(endblockid,	"endblock"),
end

global enumdata []ichar bitfieldnames=
	(bf_msb,		$),
	(bf_lsb,		$),
	(bf_msbit,		$),
	(bf_lsbit,		$),
	(bf_msw,		$),
	(bf_lsw,		$),
	(bf_odd,		$),
	(bf_even,		$),
end

global enumdata []ichar sysfnnames, []byte sysfnparams, []byte sysfnres =
	(sf_init,				$,	0,	0),
	(sf_print_startfile,	$,	0,	0),
	(sf_print_startstr,		$,	0,	0),
	(sf_print_startptr,		$,	0,	0),
	(sf_print_startcon,		$,	0,	0),
	(sf_print_setfmt,		$,	0,	0),
	(sf_print_nogap,		$,	0,	0),
	(sf_print_space,		$,	0,	0),
	(sf_print_i64,			$,	0,	0),
	(sf_print_i64_nf,		$,	0,	0),
	(sf_print_u64,			$,	0,	0),
	(sf_print_r64,			$,	0,	0),
	(sf_print_r32,			$,	0,	0),
	(sf_print_str,			$,	0,	0),
	(sf_print_str_nf,		$,	0,	0),
	(sf_print_strsl,		$,	0,	0),
	(sf_print_ptr,			$,	0,	0),
	(sf_print_ptr_nf,		$,	0,	0),
	(sf_print_c8,			$,	0,	0),
	(sf_print_bool,			$,	0,	0),
!	(sf_print_var,			$,	0,	0),
	(sf_print_newline,		$,	0,	0),
	(sf_print_end,			$,	0,	0),
	(sf_read_i64,			$,	0,	0),
	(sf_read_r64,			$,	0,	0),
	(sf_read_str,			$,	0,	0),
	(sf_read_fileline,		$,	0,	0),
	(sf_read_strline,		$,	0,	0),
	(sf_read_conline,		$,	0,	0),

	(sf_getnprocs,			$,	0,	1),		!access funcs
	(sf_getprocname,		$,	0,	1),
	(sf_getprocaddr,		$,	0,	1),

	(sf_power_i64,			$,	0,	1),
	(sf_sign_i64,			$,	0,	1),
	(sf_sign_r64,			$,	0,	1),
	(sf_unimpl,				$,	0,	1),

end
!
!global [sysfnnames.len]symbol sysfnhandlers

global enumdata	[0:]ichar stdnames,
				[0:]byte stdbits,		!bit-width where meaningful
				[0:]byte stdqtag =		! 1 means used as a Q varrec tag

!                          bits   q
    (tvoid=0,       $+1,      0,  1),		!
    (ti8,           $+1,      8,  0),		!
    (ti16,          $+1,     16,  0),		!
    (ti32,          $+1,     32,  0),		!
    (ti64,          $+1,     64,  1),		!

    (tu8,           $+1,      8,  0),		!
    (tu16,          $+1,     16,  0),		!
    (tu32,          $+1,     32,  0),		!
    (tu64,          $+1,     64,  0),		!

    (tr32,          $+1,     32,  0),		!
    (tr64,          $+1,     64,  1),		!

    (trange,        $+1,    128,  1),		!
    (tstring,       $+1,      0,  1),		!
    (tlist,         $+1,      0,  1),		!
    (tdict,         $+1,      0,  1),		!
    (tset,          $+1,      0,  1),		!
    (tarray,        $+1,      0,  1),		!
    (tdecimal,      $+1,      0,  1),		!

    (tu1,           $+1,      1,  0),		!
    (tu2,           $+1,      2,  0),		!
    (tu4,           $+1,      4,  0),		!

    (tref,          $+1,     64,  1),		!
    (trefvar,       $+1,      0,  1),		!
    (trefbit,       $+1,    128,  1),		!

    (trecord,       $+1,      0,  1),		!
    (tstruct,       $+1,      0,  1),		!
    (ttype,         $+1,     64,  1),		!
    (toperator,     $+1,     64,  1),		!
    (tsymbol,       $+1,     64,  1),		!
    (tretaddr,      $+1,      0,  1),		!
    (texception,    $+1,      0,  1),		!

    (tvar,		    $+1,    128,  1),		!

    (tproc,         $+1,      0,  0),		!
    (tlabel,        $+1,      0,  0),		!
    (tpending,      $+1,      0,  0),		!

    (tbitfield,     $+1,      0,  0),		!
    (trefchar,      $+1,     64,  0),		!
    (tvariant,      $+1,     64,  0),		!
    (tobject,       $+1,     64,  0),		!
!
!

    (tlast,         $+1,      0,  0),		!
end

global const tint  = ti64
global const tword = tu64
global const treal = tr64

!!These are set in start-up routines
!global int trefchar				!to ref char
!global int tarray				!to ref tobjrec
!global int tstring				!to ref tobjrec
!global int tset					!to ref tobjrec
!global int tvariant				!to ref tvarrec
global int trefproc
global int treflabel

global [utagnames.bounds]byte isbooltag

global [tokennames.bounds]byte endsexpr
global []byte exprendtokens=(tk_rbrack, tk_rsq, tk_then, tk_elsif,
			tk_else, tk_until, tk_do, tk_end, tk_comma, tk_bar,
			tk_semi, tk_to)

global []byte D_exprstarter = (
	tk_lbrack, tk_lsq, tk_ptr, tk_addr, tk_binop, tk_unary, tk_maths,
	tk_intconst, tk_realconst, tk_charconst, tk_stringconst, tk_decimalconst,
	tk_strinclude, tk_stdtype, tk_name, tk_if, tk_case, tk_switch, tk_ref,
	tk_cast, tk_compilervar, tk_dollar, tk_syscall, tk_incr)

global [tokennames.bounds]byte exprstarter

global enumdata [0:]ichar hostfnnames, [0:]byte hostnparams, [0:]byte hostisfn,
			[0:]byte hostinternal =
!                    name  np isfn int
	(h_dummy=0,			$+2,	0,	0,	1),

	(h_startprint,		$+2,	1,	0,	1),
	(h_startprintcon,	$+2,	0,	0,	1),
	(h_strstartprint,	$+2,	0,	0,	1),
	(h_setformat,		$+2,	1,	0,	1),
	(h_endprint,		$+2,	0,	0,	1),
	(h_strendprint,		$+2,	0,	1,	1),
	(h_print,			$+2,	2,	0,	1),
	(h_print_nf,		$+2,	1,	0,	1),

	(h_println,			$+2,	0,	0,	1),
	(h_printnogap,		$+2,	0,	0,	1),
	(h_printspace,		$+2,	0,	0,	1),

	(h_readln,			$+2,	1,	0,	1),
	(h_sreadln,			$+2,	1,	1,	0),
	(h_sread,			$+2,	1,	1,	0),
	(h_rereadln,		$+2,	0,	0,	0),
	(h_reread,			$+2,	0,	0,	0),

	(h_strtoval,		$+2,	2,	1,	0),
	(h_tostr,			$+2,	2,	1,	0),

	(h_leftstr,			$+2,	3,	1,	0),
	(h_rightstr,		$+2,	3,	1,	0),
	(h_convlc,			$+2,	2,	1,	0),
	(h_convuc,			$+2,	2,	1,	0),

	(h_waitkey,			$+2,	0,	1,	0),
	(h_testkey,			$+2,	0,	1,	0),
	(h_execwait,		$+2,	3,	1,	0),
	(h_execcmd,			$+2,	3,	1,	0),
	(h_system,			$+2,	1,	1,	0),

	(h_makestr,			$+2,	2,	1,	0),
	(h_makeref,			$+2,	2,	1,	0),

	(h_new,				$+2,	4,	1,	0),
!	(h_setoverload,		$+2,	3,	0,	0),

	(h_getcmdparam,		$+2,	1,	1,	0),
	(h_gethostname,		$+2,	0,	1,	0),
	(h_getprogname,		$+2,	0,	1,	0),

!	(h_$setpcerror,		$+2,	1,	0,	0),
	(h_$setdebug,		$+2,	1,	0,	0),
	(h_$test2,			$+2,	2,	1,	0),
	(h_$test,			$+2,	3,	1,	0),
	(h_$refcount,		$+2,	1,	1,	0),

	(h_ticks,			$+2,	0,	1,	0),
	(h_clock,			$+2,	0,	1,	0),
	(h_sleep,			$+2,	1,	0,	0),
	(h_random,			$+2,	1,	1,	0),
	(h_gethash,			$+2,	1,	1,	0),
	(h_getos,			$+2,	0,	1,	0),
	(h_iswindows,		$+2,	0,	1,	0),
	(h_setmesshandler,	$+2,	1,	0,	0),
	(h_$getstdinout,	$+2,	1,	1,	0),
	(h_$getparam,		$+2,	1,	1,	0),
	(h_makeempty,		$+2,	1,	1,	0),
	(h_$smallmemtotal,	$+2,	0,	1,	0),
	(h_$id,				$+2,	1,	1,	0),
	(h_copy,			$+2,	1,	1,	0),
	(h_$nan,			$+2,	0,	1,	0),
	(h_$infinity,		$+2,	0,	1,	0),

	(h_$nprocs,			$+2,	0,	1,	0),
	(h_$procname,		$+2,	1,	1,	0),
	(h_$procref,		$+2,	1,	1,	0),

	(h_allocexec,		$+2,	1,	1,	0),
	(h_runnative,		$+2,	2,	1,	0),
	(h_setlwb,			$+2,	2,	0,	0),

	(h_last,			$+2,	0,	0,	1),
end

proc start=
	for i to exprendtokens.len do
		endsexpr[exprendtokens[i]]:=1
	end

	for i to D_exprstarter.len do
		exprstarter[D_exprstarter[i]]:=1
	end

	isbooltag[u_cmp]:=1
	isbooltag[u_cmpchain]:=1
	isbooltag[u_andl]:=1
	isbooltag[u_orl]:=1
	isbooltag[u_notl]:=1
	isbooltag[u_istruel]:=1
	isbooltag[u_isfalsel]:=1
	isbooltag[u_inrange]:=1
	isbooltag[u_inset]:=1
end
